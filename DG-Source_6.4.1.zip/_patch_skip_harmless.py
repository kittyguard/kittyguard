# -*- coding: utf-8 -*-
"""性能优化补丁：快速扫描跳过多媒体无害类型（图片/音视频/字体），deep/strong 保真不跳"""
import io

ENGINE = r"F:\桌面保护\desktopguard\engine.py"
MAIN = r"F:\桌面保护\desktopguard\main.py"

# ---------- 1) engine.py: enum_files 加 skip_harmless ----------
with io.open(ENGINE, "r", encoding="utf-8") as f:
    e = f.read()

old_sig = 'def enum_files(root: str, recursive: bool = True, skip_system: bool = False,\n               skip_bulk: bool = False, appdata_mode: str = "skip",\n               skip_hidden_dir: bool = True):'
new_sig = 'def enum_files(root: str, recursive: bool = True, skip_system: bool = False,\n               skip_bulk: bool = False, appdata_mode: str = "skip",\n               skip_hidden_dir: bool = True, skip_harmless: bool = False):'
assert old_sig in e, "engine enum_files 签名未找到"
e = e.replace(old_sig, new_sig)

# 在 SYS_FILES 定义后插入无害扩展名集合
anchor = '    SYS_FILES = {"pagefile.sys", "hiberfil.sys", "swapfile.sys", "dumpstack.log.tmp"}'
assert anchor in e, "SYS_FILES 锚点未找到"
harmless_block = anchor + '''
    # 快速扫描跳过：明确不可能携带 PE 载荷的纯数据/媒体类型（哈希纯浪费，尤其大视频）
    # 仅快速扫描启用；绝不包含 exe/dll/sys/脚本等可执行类型；深度/高级扫描不启用
    HARMLESS_EXTS = {
        ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".cur", ".webp", ".svg", ".tif", ".tiff", ".heic",
        ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma", ".opus",
        ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v", ".ts", ".m2ts",
        ".ttf", ".otf", ".woff", ".woff2", ".fon", ".eot",
    }'''
e = e.replace(anchor, harmless_block)

# 文件分支过滤
old_yield = '''                        elif entry.is_file(follow_symlinks=False):
                            fn = entry.name
                            if fn.lower() in SYS_FILES:
                                continue'''
new_yield = '''                        elif entry.is_file(follow_symlinks=False):
                            fn = entry.name
                            if fn.lower() in SYS_FILES:
                                continue
                            if skip_harmless and os.path.splitext(fn)[1].lower() in HARMLESS_EXTS:
                                continue'''
assert old_yield in e, "enum_files 文件分支未找到"
e = e.replace(old_yield, new_yield)

with io.open(ENGINE, "w", encoding="utf-8") as f:
    f.write(e)
print("[OK] engine.py 已打补丁")

# ---------- 2) main.py: enum_files 调用传 skip_harmless（仅快速扫描且非拖放）----------
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()

old_call = '''                for p in engine.enum_files(path, recursive=recursive, skip_system=skip_sys,
                                           skip_bulk=skip_bulk, appdata_mode=appdata_mode):'''
new_call = '''                for p in engine.enum_files(path, recursive=recursive, skip_system=skip_sys,
                                           skip_bulk=skip_bulk, appdata_mode=appdata_mode,
                                           skip_harmless=(mode == "quick" and not is_custom)):'''
assert old_call in m, "main.py enum_files 调用未找到"
m = m.replace(old_call, new_call)

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)
print("[OK] main.py 已打补丁")

# ---------- 3) 语法校验 ----------
import py_compile
py_compile.compile(ENGINE, doraise=True)
py_compile.compile(MAIN, doraise=True)
print("[OK] 语法校验通过")
