# -*- coding: utf-8 -*-
"""
DG 应急恢复脚本：把正式版恢复为最新版本（3.3.2）
用法：双击 restore_latest.bat，或运行 python restore_latest.py
场景：版本切换锁死在旧版（打不开设置/无法切回）时使用。
"""
import os
import shutil
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
TARGET_VER = "3.3.2"


def main():
    snap = os.path.join(BASE, "versions", TARGET_VER)
    if not os.path.isdir(snap):
        print(f"[ERR] 找不到版本快照目录: {snap}")
        input("按回车退出...")
        return 1
    # 备份当前被锁死的版本
    bk = os.path.join(BASE, "swap_backup", "locked_backup")
    os.makedirs(bk, exist_ok=True)
    for f in os.listdir(BASE):
        if f.endswith(".py") or f.endswith(".exe"):
            src = os.path.join(BASE, f)
            if os.path.isfile(src):
                try:
                    shutil.copy2(src, os.path.join(bk, f))
                except Exception:
                    pass
    # 恢复最新版全套
    count = 0
    for f in os.listdir(snap):
        src = os.path.join(snap, f)
        if os.path.isfile(src):
            try:
                shutil.copy2(src, os.path.join(BASE, f))
                count += 1
            except Exception as e:
                print(f"[WARN] 恢复失败 {f}: {e}")
    print(f"[OK] 已恢复 {count} 个文件到 v{TARGET_VER}")
    print("[OK] 现在可以重新打开 DG 安全（桌面快捷方式 / 双击 main.py）")
    input("按回车退出...")
    return 0


if __name__ == "__main__":
    sys.exit(main())
