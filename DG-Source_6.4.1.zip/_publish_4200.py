# -*- coding: utf-8 -*-
"""发布 4.20.0：快照（含 dg_ema_watch.exe）+ 重建防篡改清单 + version.json"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "4.20.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件（dg_ema_watch.exe %s）" % (
    NEW_VER, copied,
    "已含" if os.path.isfile(os.path.join(ver_dir, "dg_ema_watch.exe")) else "缺失!"))

# 重建防篡改清单（当前安装态 = 受信任态）
sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

# 更新 version.json（更新服务器读取）
notes = {
    "latest_version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "4.20.0 内容更新：EMA 环境恶意活动监测（C++ ETW 毫秒级进程监控）接入实时防护；进程创建事件毫秒级捕获、Device 路径自动转盘符、复用行为链/高风险路径判定；免打扰模式联动（开启后自动结束可疑进程不弹窗）；保护页 EMA 状态行 + 设置开关；启动自动清理残留 ETW 会话；CPU≈0",
    "features": [
        "EMA ETW 毫秒级进程监控（dg_ema_watch.exe）",
        "进程事件接入实时防护告警队列（免打扰联动）",
        "Device 路径自动转盘符",
        "保护页 EMA 状态 + 设置开关（默认开启）",
        "残留 ETW 会话自动清理"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
