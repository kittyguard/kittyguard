#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DG 全球通用杀毒软件标准测试
测试项目：
1. EICAR标准测试（所有杀毒软件必须能检测到）
2. 误报率测试（正常文件不应该报毒）
3. 双扩展名伪装检测
4. PowerShell编码命令检测
5. 高熵文件检测
6. 压缩包扫描检测
7. 性能测试（扫描速度）
"""

import os
import sys
import time

# 添加程序目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import engine

def run_test():
    print("=" * 70)
    print("  DG 全球通用杀毒软件标准测试")
    print("=" * 70)
    print()

    # 初始化扫描器
    scanner = engine.Scanner()
    test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_samples")

    results = {
        "eicar": {"pass": False, "detail": ""},
        "false_positive": {"pass": False, "detail": ""},
        "double_ext": {"pass": False, "detail": ""},
        "powershell_encoded": {"pass": False, "detail": ""},
        "high_entropy": {"pass": False, "detail": ""},
        "archive_scan": {"pass": False, "detail": ""},
        "performance": {"pass": False, "detail": ""},
    }

    scan_results = {}

    # ===== 测试1：EICAR标准测试 =====
    print("【测试1】EICAR标准测试（所有杀毒软件必须能检测到）")
    print("-" * 70)
    eicar_path = os.path.join(test_dir, "suspicious", "eicar_test.com")
    if os.path.exists(eicar_path):
        result = scanner.scan_file(eicar_path)
        scan_results["eicar"] = result
        level = getattr(result, "level", "安全")
        score = getattr(result, "score", 0)
        tags = getattr(result, "tags", [])
        print(f"  文件: eicar_test.com")
        print(f"  风险等级: {level}")
        print(f"  风险评分: {score}")
        print(f"  命中标签: {tags}")
        if level in ["严重", "高危", "中危"] or score >= 3:
            results["eicar"]["pass"] = True
            results["eicar"]["detail"] = f"检测到EICAR测试文件（等级:{level}, 评分:{score}）"
            print(f"  结果: ✅ 通过 - 成功检测到EICAR标准测试文件")
        else:
            results["eicar"]["detail"] = f"未检测到EICAR测试文件（等级:{level}, 评分:{score}）"
            print(f"  结果: ❌ 失败 - 未检测到EICAR标准测试文件")
    else:
        print(f"  结果: ⚠️ 跳过 - EICAR测试文件不存在")
    print()

    # ===== 测试2：误报率测试 =====
    print("【测试2】误报率测试（正常文件不应该报毒）")
    print("-" * 70)
    safe_dir = os.path.join(test_dir, "safe")
    safe_files = [f for f in os.listdir(safe_dir) if os.path.isfile(os.path.join(safe_dir, f))]
    false_positives = 0
    total_safe = len(safe_files)
    for fname in safe_files:
        fpath = os.path.join(safe_dir, fname)
        result = scanner.scan_file(fpath)
        scan_results[f"safe_{fname}"] = result
        level = getattr(result, "level", "安全")
        score = getattr(result, "score", 0)
        tags = getattr(result, "tags", [])
        print(f"  文件: {fname}")
        print(f"    风险等级: {level}, 评分: {score}, 标签: {tags}")
        if level in ["严重", "高危", "中危"] or score >= 3:
            false_positives += 1
            print(f"    ⚠️  误报！正常文件被报为风险")
    fp_rate = (false_positives / total_safe * 100) if total_safe > 0 else 0
    print(f"  统计: {total_safe}个正常文件，{false_positives}个误报，误报率: {fp_rate:.1f}%")
    if false_positives == 0:
        results["false_positive"]["pass"] = True
        results["false_positive"]["detail"] = f"{total_safe}个正常文件0误报，误报率0%"
        print(f"  结果: ✅ 通过 - 正常文件零误报")
    elif fp_rate <= 10:
        results["false_positive"]["pass"] = True
        results["false_positive"]["detail"] = f"{total_safe}个正常文件{false_positives}个误报，误报率{fp_rate:.1f}%"
        print(f"  结果: ✅ 通过 - 误报率在可接受范围内（≤10%）")
    else:
        results["false_positive"]["detail"] = f"{total_safe}个正常文件{false_positives}个误报，误报率{fp_rate:.1f}%"
        print(f"  结果: ❌ 失败 - 误报率过高（>10%）")
    print()

    # ===== 测试3：双扩展名伪装检测 =====
    print("【测试3】双扩展名伪装检测（invoice.pdf.exe）")
    print("-" * 70)
    double_ext_path = os.path.join(test_dir, "suspicious", "invoice.pdf.exe")
    if os.path.exists(double_ext_path):
        result = scanner.scan_file(double_ext_path)
        scan_results["double_ext"] = result
        level = getattr(result, "level", "安全")
        score = getattr(result, "score", 0)
        tags = getattr(result, "tags", [])
        print(f"  文件: invoice.pdf.exe")
        print(f"  风险等级: {level}")
        print(f"  风险评分: {score}")
        print(f"  命中标签: {tags}")
        has_double_ext = any("双扩展名" in t or "伪装" in t or "double" in t.lower() for t in tags)
        if has_double_ext or level in ["严重", "高危", "中危"]:
            results["double_ext"]["pass"] = True
            results["double_ext"]["detail"] = f"检测到双扩展名伪装（等级:{level}, 标签:{tags}）"
            print(f"  结果: ✅ 通过 - 成功检测到双扩展名伪装")
        else:
            results["double_ext"]["detail"] = f"未检测到双扩展名伪装（等级:{level}, 标签:{tags}）"
            print(f"  结果: ❌ 失败 - 未检测到双扩展名伪装")
    print()

    # ===== 测试4：PowerShell编码命令检测 =====
    print("【测试4】PowerShell编码命令检测")
    print("-" * 70)
    ps_path = os.path.join(test_dir, "suspicious", "malicious_ps.ps1")
    if os.path.exists(ps_path):
        result = scanner.scan_file(ps_path)
        scan_results["powershell"] = result
        level = getattr(result, "level", "安全")
        score = getattr(result, "score", 0)
        tags = getattr(result, "tags", [])
        print(f"  文件: malicious_ps.ps1")
        print(f"  风险等级: {level}")
        print(f"  风险评分: {score}")
        print(f"  命中标签: {tags}")
        has_ps = any("powershell" in t.lower() or "编码" in t or "base64" in t.lower() or "IEX" in t for t in tags)
        if has_ps or level in ["严重", "高危", "中危"]:
            results["powershell_encoded"]["pass"] = True
            results["powershell_encoded"]["detail"] = f"检测到PowerShell编码命令（等级:{level}, 标签:{tags}）"
            print(f"  结果: ✅ 通过 - 成功检测到PowerShell编码命令")
        else:
            results["powershell_encoded"]["detail"] = f"未检测到PowerShell编码命令（等级:{level}, 标签:{tags}）"
            print(f"  结果: ❌ 失败 - 未检测到PowerShell编码命令")
    print()

    # ===== 测试5：高熵文件检测 =====
    print("【测试5】高熵文件检测（模拟加壳/混淆）")
    print("-" * 70)
    entropy_path = os.path.join(test_dir, "suspicious", "high_entropy.bin")
    if os.path.exists(entropy_path):
        result = scanner.scan_file(entropy_path)
        scan_results["high_entropy"] = result
        level = getattr(result, "level", "安全")
        score = getattr(result, "score", 0)
        tags = getattr(result, "tags", [])
        print(f"  文件: high_entropy.bin (100KB随机数据)")
        print(f"  风险等级: {level}")
        print(f"  风险评分: {score}")
        print(f"  命中标签: {tags}")
        has_entropy = any("熵" in t or "entropy" in t.lower() or "高熵" in t for t in tags)
        if has_entropy:
            results["high_entropy"]["pass"] = True
            results["high_entropy"]["detail"] = f"检测到高熵文件（等级:{level}, 标签:{tags}）"
            print(f"  结果: ✅ 通过 - 成功检测到高熵文件")
        else:
            results["high_entropy"]["detail"] = f"未检测到高熵特征（等级:{level}, 标签:{tags}）"
            print(f"  结果: ⚠️  部分通过 - 未明确检测到高熵特征（但高熵单独不应判高危）")
    print()

    # ===== 测试6：压缩包扫描检测 =====
    print("【测试6】压缩包扫描检测")
    print("-" * 70)
    archive_dir = os.path.join(test_dir, "archive")
    archive_files = [f for f in os.listdir(archive_dir) if f.endswith('.zip')]
    archive_detected = 0
    for fname in archive_files:
        fpath = os.path.join(archive_dir, fname)
        result = scanner.scan_file(fpath)
        scan_results[f"archive_{fname}"] = result
        level = getattr(result, "level", "安全")
        score = getattr(result, "score", 0)
        tags = getattr(result, "tags", [])
        print(f"  文件: {fname}")
        print(f"    风险等级: {level}, 评分: {score}, 标签: {tags}")
        if level in ["严重", "高危", "中危"] or score >= 3:
            archive_detected += 1
            print(f"    ✅ 检测到压缩包内风险")
        else:
            print(f"    ⚠️  未检测到压缩包内风险（可能需要高级/深度扫描）")
    if archive_detected > 0:
        results["archive_scan"]["pass"] = True
        results["archive_scan"]["detail"] = f"{len(archive_files)}个压缩包中检测到{archive_detected}个风险"
        print(f"  结果: ✅ 通过 - 成功检测到压缩包内风险")
    else:
        results["archive_scan"]["detail"] = f"{len(archive_files)}个压缩包均未检测到风险（可能仅高级/深度扫描支持）"
        print(f"  结果: ⚠️  部分通过 - 快速扫描可能不支持压缩包深度扫描")
    print()

    # ===== 测试7：性能测试 =====
    print("【测试7】性能测试（扫描速度）")
    print("-" * 70)
    all_files = []
    for root, dirs, files in os.walk(test_dir):
        for f in files:
            all_files.append(os.path.join(root, f))
    total_files = len(all_files)
    start_time = time.time()
    for fpath in all_files:
        try:
            scanner.scan_file(fpath)
        except Exception:
            pass
    end_time = time.time()
    duration = end_time - start_time
    speed = total_files / duration if duration > 0 else 0
    print(f"  扫描文件数: {total_files} 个")
    print(f"  扫描耗时: {duration:.2f} 秒")
    print(f"  扫描速度: {speed:.1f} 文件/秒")
    if speed >= 10:
        results["performance"]["pass"] = True
        results["performance"]["detail"] = f"扫描速度{speed:.1f}文件/秒（{total_files}个文件{duration:.2f}秒）"
        print(f"  结果: ✅ 通过 - 扫描速度优秀（≥10文件/秒）")
    elif speed >= 5:
        results["performance"]["pass"] = True
        results["performance"]["detail"] = f"扫描速度{speed:.1f}文件/秒（{total_files}个文件{duration:.2f}秒）"
        print(f"  结果: ✅ 通过 - 扫描速度良好（≥5文件/秒）")
    else:
        results["performance"]["detail"] = f"扫描速度{speed:.1f}文件/秒（{total_files}个文件{duration:.2f}秒）"
        print(f"  结果: ⚠️  部分通过 - 扫描速度一般（<5文件/秒）")
    print()

    # ===== 测试结果汇总 =====
    print("=" * 70)
    print("  测试结果汇总")
    print("=" * 70)
    print()
    passed = 0
    failed = 0
    partial = 0
    for test_name, test_result in results.items():
        status = "✅ 通过" if test_result["pass"] else "❌ 失败"
        if "部分" in test_result["detail"] or "⚠️" in test_result["detail"]:
            status = "⚠️  部分通过"
            partial += 1
        elif test_result["pass"]:
            passed += 1
        else:
            failed += 1
        print(f"  {status} | {test_name:20s} | {test_result['detail']}")
    print()
    total_tests = len(results)
    pass_rate = (passed + partial * 0.5) / total_tests * 100
    print(f"  总分: {passed}通过 + {partial}部分通过 + {failed}失败 = {total_tests}项测试")
    print(f"  通过率: {pass_rate:.1f}%")
    print()
    if pass_rate >= 90:
        print("  🏆 评级：S级 - 杀毒能力优秀，达到专业级水平")
    elif pass_rate >= 75:
        print("  🥇 评级：A级 - 杀毒能力良好，超过大多数轻量工具")
    elif pass_rate >= 60:
        print("  🥈 评级：B级 - 杀毒能力合格，基础检测能力具备")
    elif pass_rate >= 40:
        print("  🥉 评级：C级 - 杀毒能力一般，需要继续优化")
    else:
        print("  💪 评级：D级 - 杀毒能力较弱，需要大幅改进")
    print()
    print("=" * 70)

    return results, scan_results

if __name__ == "__main__":
    run_test()
