# -*- coding: utf-8 -*-
"""验证 2.7.0 C++ 深度扫描集成"""
import os, sys, time
sys.path.insert(0, r'F:\桌面保护\desktopguard-beta')

import scan_core_bridge as scb
import engine

print("=" * 50)
print("DG 2.7.0 C++ 加速核心验证")
print("=" * 50)

# 1. 检查 C++ 核心
print("\n[1] C++ 核心检测:", scb.has_scan_core())
print("    路径:", scb.get_scan_core_path())

# 2. 用 C++ deep 模式扫描程序目录（含哈希）
test_root = r'F:\桌面保护\desktopguard-beta'
t0 = time.time()
files, stats = scb.run_scan_core([test_root], 'deep')
t1 = time.time()
print(f"\n[2] C++ 遍历+哈希: {len(files)} 个文件, 耗时 {t1-t0:.2f} 秒")
print("    统计:", stats)
assert files, "C++ 返回为空！"

# 3. 验证哈希正确性（抽 3 个文件对比 Python 哈希）
import hashlib
print("\n[3] 哈希正确性抽查:")
def py_sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

checked = 0
for f in files:
    if f.size < 5 * 1024 * 1024 and f.sha256:
        py_h = py_sha256(f.path)
        ok = "✓" if py_h == f.sha256 else "✗ 不一致！"
        print(f"    {os.path.basename(f.path)[:40]:42s} {ok}")
        checked += 1
        if checked >= 3:
            break

# 4. 用 scanner.scan_file(sha256_pre=...) 验证预计算哈希被使用
print("\n[4] scan_file 预计算哈希验证:")
scanner = engine.Scanner(deep_strings=True, hash_all=True, max_hash_size=50 * 1024 * 1024)
# 对比：带预计算哈希 vs 不带（应结果一致）
sample = files[0]
r_with = scanner.scan_file(sample.path, sha256_pre=sample.sha256 or "")
r_without = scanner.scan_file(sample.path)
print(f"    文件: {os.path.basename(sample.path)}")
print(f"    带预计算: level={r_with.level}, score={r_with.score}, sha256={r_with.sha256[:16]}...")
print(f"    不带预计算: level={r_without.level}, score={r_without.score}, sha256={r_without.sha256[:16]}...")
print(f"    结果一致: {'✓' if r_with.sha256 == r_without.sha256 else '✗'}")

# 5. 模拟完整 deep 扫描流程（生产者→消费者主循环核心）
print("\n[5] 完整 deep 扫描模拟（程序目录）:")
threats = junk = 0
scanned = 0
t0 = time.time()
for f in files:
    if f.size > 200 * 1024 * 1024:
        scanned += 1
        continue
    r = scanner.scan_file(f.path, sha256_pre=f.sha256 or "")
    scanned += 1
    if r.level == engine.LEVEL_JUNK:
        junk += 1
    elif r.level != engine.LEVEL_SAFE:
        threats += 1
t1 = time.time()
print(f"    扫描 {scanned} 个文件, 耗时 {t1-t0:.2f} 秒")
print(f"    威胁: {threats}, 垃圾: {junk}")

print("\n" + "=" * 50)
print("验证完成！C++ 加速核心工作正常")
print("=" * 50)
