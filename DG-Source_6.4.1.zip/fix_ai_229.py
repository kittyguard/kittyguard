# -*- coding: utf-8 -*-
with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 找到 _open_ai_chat 方法
start_marker = '    def _open_ai_chat(self):'
end_marker = '    def _open_security_checkup(self):'
start_idx = c.find(start_marker)
end_idx = c.find(end_marker)

# 完全重写 _open_ai_chat，添加完整的错误处理
new_method = '''    def _open_ai_chat(self):
        """AI助手聊天窗口：与DeepSeek AI对话，上下文最多20条。
        v2.2.9：完整错误处理版，确保任何异常都显示在UI上。
        """
        import json
        import os
        import threading
        import urllib.request
        import ssl
        import queue
        import traceback
        
        def load_ai_cfg():
            config_path = os.path.join(os.path.expanduser("~"), ".desktopguard", "ai_config.json")
            try:
                if os.path.exists(config_path):
                    with open(config_path, "r", encoding="utf-8") as f:
                        return json.load(f)
            except Exception:
                pass
            return {"ai_enabled": False, "ai_api_key": "", "ai_api_url": "", "ai_model": "deepseek-chat"}
        
        try:
            ai_cfg = load_ai_cfg()
            api_key = ai_cfg.get("ai_api_key", "").strip()
            api_url = ai_cfg.get("ai_api_url", "").strip()
            ai_model = [ai_cfg.get("ai_model", "deepseek-chat")]
        except Exception as e:
            api_key = ""
            api_url = ""
            ai_model = ["deepseek-chat"]
        
        chat_history = []
        MAX_CONTEXT = 20
        cancel_flag = [False]
        msg_queue = queue.Queue()
        
        win = tk.Toplevel(self.root)
        win.title("AI 助手 v2.2.9")
        win.configure(bg=C_BG)
        win.geometry("720x680")
        win.minsize(580, 480)
        
        header = tk.Frame(win, bg=C_CARD2, padx=16, pady=12)
        header.pack(fill="x")
        tk.Label(header, text="🤖 AI 助手", bg=C_CARD2, fg=C_TEXT,
                 font=("Microsoft YaHei UI", 14, "bold")).pack(side="left")
        
        model_frame = tk.Frame(header, bg=C_CARD2)
        model_frame.pack(side="left", padx=(16, 0))
        tk.Label(model_frame, text="模型:", bg=C_CARD2, fg=C_SUB,
                font=("Microsoft YaHei UI", 9)).pack(side="left")
        model_var = tk.StringVar(value=ai_model[0])
        model_combo = ttk.Combobox(model_frame, textvariable=model_var,
                                   values=["deepseek-chat", "deepseek-reasoner"],
                                   width=16, state="readonly")
        model_combo.pack(side="left", padx=(4, 0))
        
        status_label = tk.Label(header, text="", bg=C_CARD2, fg=C_SUB,
                                font=("Microsoft YaHei UI", 9))
        status_label.pack(side="right")
        
        chat_frame = tk.Frame(win, bg=C_BG)
        chat_frame.pack(fill="both", expand=True, padx=12, pady=(8, 4))
        
        chat_text = tk.Text(chat_frame, bg=C_CARD, fg=C_TEXT,
                            font=("Microsoft YaHei UI", 10), wrap="word",
                            relief="flat", padx=12, pady=10, cursor="arrow")
        chat_scroll = ttk.Scrollbar(chat_frame, orient="vertical", command=chat_text.yview)
        chat_text.configure(yscrollcommand=chat_scroll.set)
        chat_scroll.pack(side="right", fill="y")
        chat_text.pack(fill="both", expand=True)
        chat_text.config(state="disabled")
        
        chat_text.tag_config("user", foreground=C_PRIMARY, font=("Microsoft YaHei UI", 10, "bold"))
        chat_text.tag_config("ai", foreground=C_GREEN, font=("Microsoft YaHei UI", 10, "bold"))
        chat_text.tag_config("system", foreground=C_SUB, font=("Microsoft YaHei UI", 9, "italic"))
        chat_text.tag_config("content", foreground=C_TEXT, font=("Microsoft YaHei UI", 10))
        chat_text.tag_config("debug", foreground="#ff9966", font=("Microsoft YaHei UI", 8, "italic"))
        chat_text.tag_config("error", foreground="#ff4444", font=("Microsoft YaHei UI", 9, "bold"))
        
        def append_message(role, text):
            """只能在主线程调用！所有异常都吞掉，避免影响UI。"""
            try:
                chat_text.config(state="normal")
                if role == "user":
                    chat_text.insert("end", "\\n你：\\n", "user")
                    chat_text.insert("end", text + "\\n", "content")
                elif role == "ai":
                    chat_text.insert("end", "\\nAI助手：\\n", "ai")
                    chat_text.insert("end", text + "\\n", "content")
                elif role == "system":
                    chat_text.insert("end", "\\n" + text + "\\n", "system")
                elif role == "debug":
                    chat_text.insert("end", text + "\\n", "debug")
                elif role == "error":
                    chat_text.insert("end", "\\n" + text + "\\n", "error")
                chat_text.see("end")
                chat_text.config(state="disabled")
            except Exception:
                pass
        
        def safe_reset_loading():
            """安全重置加载状态，所有异常都吞掉。"""
            try:
                send_btn.config(state="normal", text="发送")
            except Exception:
                pass
            try:
                cancel_btn.config(state="disabled")
            except Exception:
                pass
            try:
                status_label.config(text="● 已连接", fg=C_GREEN)
            except Exception:
                pass
            is_loading[0] = False
        
        def poll_queue():
            """主线程轮询队列，更新UI。即使有异常也继续轮询。"""
            try:
                while True:
                    try:
                        msg = msg_queue.get_nowait()
                    except queue.Empty:
                        break
                    
                    try:
                        role = msg.get("role", "system")
                        text = msg.get("text", "")
                        append_message(role, text)
                        
                        if msg.get("type") in ("done", "error"):
                            safe_reset_loading()
                    except Exception:
                        pass
            except Exception:
                pass
            
            try:
                if win.winfo_exists():
                    win.after(100, poll_queue)
            except Exception:
                pass
        
        # 显示初始状态
        try:
            if not api_key or not api_url:
                status_label.config(text="⚠ 未配置API Key", fg="#ff9966")
                append_message("system", "⚠ 未检测到 API Key 配置。\\n请在设置里连续点击版本号5次，配置 API Key 和 API 地址。")
            else:
                status_label.config(text="● 已连接", fg=C_GREEN)
                append_message("system", f"✅ API 配置已加载（v2.2.9 完整错误处理版）。\\n模型: {ai_model[0]}\\nAPI地址: {api_url}\\n\\n输入消息后点击发送或按回车。")
        except Exception as e:
            append_message("error", f"初始化错误: {e}")
        
        input_frame = tk.Frame(win, bg=C_BG, padx=12, pady=8)
        input_frame.pack(fill="x", side="bottom")
        
        input_text = tk.Text(input_frame, height=3, bg=C_CARD, fg=C_TEXT,
                            font=("Microsoft YaHei UI", 10), wrap="word",
                            relief="flat", padx=10, pady=8)
        input_text.pack(fill="x", side="top")
        input_text.focus_set()
        
        btn_frame = tk.Frame(input_frame, bg=C_BG)
        btn_frame.pack(fill="x", pady=(6, 0))
        
        is_loading = [False]
        
        # 先定义按钮变量，避免on_send里引用未定义变量
        cancel_btn = tk.Button(btn_frame, text="取消",
                              bg=C_RED, fg="white", activebackground=C_RED,
                              activeforeground="white", font=("Microsoft YaHei UI", 10, "bold"),
                              relief="flat", cursor="hand2", padx=16, pady=4, state="disabled")
        cancel_btn.pack(side="right", padx=(0, 8))
        
        send_btn = tk.Button(btn_frame, text="发送",
                            bg=C_PRIMARY, fg="white", activebackground=C_PRIMARY,
                            activeforeground="white", font=("Microsoft YaHei UI", 10, "bold"),
                            relief="flat", cursor="hand2", padx=20, pady=4)
        send_btn.pack(side="right")
        
        def on_cancel():
            try:
                cancel_flag[0] = True
                append_message("system", "⏹ 已取消当前请求（后台可能仍在运行，但结果不会显示）。")
                safe_reset_loading()
            except Exception as e:
                append_message("error", f"取消错误: {e}")
        
        cancel_btn.config(command=on_cancel)
        
        def on_model_change(event):
            try:
                ai_model[0] = model_var.get()
                cfg_path = os.path.join(os.path.expanduser("~"), ".desktopguard", "ai_config.json")
                if os.path.exists(cfg_path):
                    with open(cfg_path, "r", encoding="utf-8") as f:
                        cfg = json.load(f)
                    cfg["ai_model"] = ai_model[0]
                    with open(cfg_path, "w", encoding="utf-8") as f:
                        json.dump(cfg, f, ensure_ascii=False, indent=2)
                append_message("system", f"已切换模型为: {ai_model[0]}")
            except Exception as e:
                append_message("error", f"切换模型错误: {e}")
        model_combo.bind("<<ComboboxSelected>>", on_model_change)
        
        def on_send():
            """发送消息：完整try-catch，任何异常都显示在UI上。"""
            try:
                append_message("debug", "[调试] on_send 被调用")
                
                if is_loading[0]:
                    append_message("system", "⏳ 正在等待上一条回复，请稍候或点击取消。")
                    return
                
                msg = input_text.get("1.0", "end").strip()
                if not msg:
                    append_message("debug", "[调试] 消息为空，返回")
                    return
                
                append_message("debug", f"[调试] 消息内容: {msg[:50]}")
                
                if not api_key or not api_url:
                    append_message("system", "⚠ 请先配置 API Key 和 API 地址。")
                    return
                
                is_loading[0] = True
                cancel_flag[0] = False
                
                try:
                    input_text.delete("1.0", "end")
                except Exception as e:
                    append_message("debug", f"[调试] 清空输入框异常: {e}")
                
                append_message("user", msg)
                
                chat_history.append({"role": "user", "content": msg})
                if len(chat_history) > MAX_CONTEXT * 2:
                    chat_history = chat_history[-(MAX_CONTEXT * 2):]
                
                try:
                    send_btn.config(state="disabled", text="思考中...")
                    cancel_btn.config(state="normal")
                    status_label.config(text="⏳ 调用中...", fg=C_PRIMARY)
                except Exception as e:
                    append_message("debug", f"[调试] 更新按钮状态异常: {e}")
                
                def ai_worker():
                    """后台线程：只做API调用，不碰tkinter控件，通过queue发消息。"""
                    try:
                        msg_queue.put({"role": "debug", "text": "[调试] 后台线程已启动"})
                        
                        if cancel_flag[0]:
                            msg_queue.put({"role": "debug", "text": "[调试] 已取消，返回"})
                            return
                        
                        system_prompt = "你是DG桌面安全软件的AI助手，专业、简洁、友好。"
                        messages = [{"role": "system", "content": system_prompt}]
                        messages.extend(chat_history[-(MAX_CONTEXT * 2):])
                        
                        payload = {
                            "model": ai_model[0],
                            "messages": messages,
                            "temperature": 0.7,
                            "max_tokens": 1000,
                        }
                        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                        
                        msg_queue.put({"role": "debug", "text": f"[调试] 正在构建请求，模型={ai_model[0]}, 消息数={len(messages)}"})
                        
                        req = urllib.request.Request(api_url, data=data,
                            headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
                            method="POST")
                        
                        msg_queue.put({"role": "debug", "text": f"[调试] 正在发送请求到 {api_url}..."})
                        
                        ctx = ssl.create_default_context()
                        ctx.check_hostname = False
                        ctx.verify_mode = ssl.CERT_NONE
                        
                        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
                            msg_queue.put({"role": "debug", "text": f"[调试] 收到响应，状态码={resp.status}"})
                            result = json.loads(resp.read().decode("utf-8"))
                        
                        if cancel_flag[0]:
                            msg_queue.put({"role": "debug", "text": "[调试] 已取消，不显示结果"})
                            return
                        
                        msg_queue.put({"role": "debug", "text": "[调试] 正在解析响应..."})
                        
                        ai_reply = result.get("choices", [{}])[0].get("message", {}).get("content", "")
                        if not ai_reply or not ai_reply.strip():
                            ai_reply = "（AI 未返回内容，请重试）"
                        
                        chat_history.append({"role": "assistant", "content": ai_reply})
                        if len(chat_history) > MAX_CONTEXT * 2:
                            chat_history = chat_history[-(MAX_CONTEXT * 2):]
                        
                        usage = result.get("usage", {})
                        usage_info = f"（消耗 {usage.get('total_tokens', 0)} tokens）" if usage else ""
                        
                        msg_queue.put({"role": "ai", "text": ai_reply + usage_info, "type": "done"})
                        
                    except Exception as e:
                        err_msg = str(e)[:300]
                        trace = traceback.format_exc()[:800]
                        msg_queue.put({"role": "debug", "text": f"[调试] 后台线程异常: {err_msg}"})
                        msg_queue.put({"role": "error", "text": f"❌ AI调用失败：{err_msg}\\n\\n详细错误：\\n{trace}", "type": "error"})
                
                msg_queue.put({"role": "debug", "text": "[调试] 正在启动后台线程..."})
                t = threading.Thread(target=ai_worker, daemon=True)
                t.start()
                msg_queue.put({"role": "debug", "text": f"[调试] 后台线程已启动，线程ID={t.ident}"})
                
            except Exception as e:
                append_message("error", f"❌ on_send 异常: {e}\\n\\n{traceback.format_exc()}")
                safe_reset_loading()
        
        send_btn.config(command=on_send)
        
        def on_clear():
            try:
                nonlocal chat_history
                chat_history = []
                chat_text.config(state="normal")
                chat_text.delete("1.0", "end")
                chat_text.config(state="disabled")
                append_message("system", "聊天记录已清空。")
            except Exception as e:
                append_message("error", f"清空错误: {e}")
        
        tk.Button(btn_frame, text="清空对话", command=on_clear,
                 bg=C_CARD2, fg=C_TEXT, activebackground=C_CARD2, activeforeground=C_TEXT,
                 font=("Microsoft YaHei UI", 9), relief="flat", cursor="hand2",
                 padx=12, pady=4).pack(side="right", padx=(0, 8))
        
        tk.Label(btn_frame, text=f"v2.2.9 | 上下文最多{MAX_CONTEXT}条 | 回车发送", bg=C_BG, fg=C_SUB,
                font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(8, 0))
        
        def on_enter(event):
            try:
                if event.state & 1:
                    return
                on_send()
                return "break"
            except Exception as e:
                append_message("error", f"回车事件错误: {e}")
        input_text.bind("<Return>", on_enter)
        
        # 启动队列轮询
        try:
            win.after(100, poll_queue)
            append_message("debug", "[调试] 队列轮询已启动")
        except Exception as e:
            append_message("error", f"启动轮询错误: {e}")
        
        win.transient(self.root)

'''

c = c[:start_idx] + new_method + c[end_idx:]

# 升级版本号
c = c.replace('APP_VERSION = "2.2.8"', 'APP_VERSION = "2.2.9"', 1)
c = c.replace(
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8"]',
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9"]'
)

old_history = '''VERSION_HISTORY = [
    ("2.2.8"'''
new_history = '''VERSION_HISTORY = [
    ("2.2.9", "重大修复：AI助手完整错误处理版。1.on_send函数添加完整try-catch，任何异常都显示在UI上（红色错误信息）；2.poll_queue函数添加完整try-catch，即使reset_loading异常也不会停止队列轮询；3.append_message添加异常保护，避免UI操作异常影响整体；4.按钮先定义再绑定command，避免引用未定义变量；5.添加[调试] on_send被调用，确认函数是否执行；6.窗口标题显示版本号v2.2.9"),
    ("2.2.8"'''
c = c.replace(old_history, new_history, 1)

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

# 创建快照
import shutil, os, json
os.makedirs('versions/2.2.9', exist_ok=True)
shutil.copy2('main.py', 'versions/2.2.9/main.py')
shutil.copy2('engine.py', 'versions/2.2.9/engine.py')
shutil.copy2('database.py', 'versions/2.2.9/database.py')
shutil.copy2('logger.py', 'versions/2.2.9/logger.py')

with open('version.json', 'r', encoding='utf-8') as f:
    vj = json.load(f)
vj['latest_version'] = '2.2.9'
with open('version.json', 'w', encoding='utf-8') as f:
    json.dump(vj, f, ensure_ascii=False, indent=2)

print('DG 2.2.9 已发布！')
print('AI助手完全重写，添加完整错误处理')
print('versions/2.2.9/ 快照已创建')
