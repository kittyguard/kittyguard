# -*- coding: utf-8 -*-
"""真实桌面点击：点击勒索弹窗的"取消"按钮（保持冻结）。坐标按 1920x1080 千分比换算。"""
import ctypes, time

user32 = ctypes.windll.user32
# 弹窗取消按钮 OCR box 560,610,600,640（千分比）→ 中心 580,625 → 像素
sw = user32.GetSystemMetrics(0)
sh = user32.GetSystemMetrics(1)
x = int(580 / 1000 * sw)
y = int(625 / 1000 * sh)
user32.SetCursorPos(x, y)
time.sleep(0.3)
user32.mouse_event(0x0002, 0, 0, 0, 0)  # LEFTDOWN
time.sleep(0.1)
user32.mouse_event(0x0004, 0, 0, 0, 0)  # LEFTUP
print("CLICKED", x, y, sw, sh)
