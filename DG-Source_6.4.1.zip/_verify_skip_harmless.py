# -*- coding: utf-8 -*-
"""验证 skip_harmless：对桌面保护目录测试产出差异"""
import os, sys, time
sys.path.insert(0, r"F:\桌面保护\desktopguard")
import engine

root = r"F:\桌面保护"  # 含图片/视频/文档的混合目录

def count_files(skip):
    n = 0
    t0 = time.time()
    for _ in engine.enum_files(root, recursive=True, skip_system=False,
                               skip_bulk=False, appdata_mode="all",
                               skip_harmless=skip):
        n += 1
    return n, time.time() - t0

n_off, t_off = count_files(False)
n_on, t_on = count_files(True)
print(f"不跳过无害类型: {n_off} 个文件, {t_off:.2f}s")
print(f"跳过无害类型  : {n_on} 个文件, {t_on:.2f}s")
print(f"跳过数量      : {n_off - n_on} ({100*(n_off-n_on)/max(n_off,1):.1f}%)")
print(f"提速          : {t_off/max(t_on,0.001):.2f}x")
