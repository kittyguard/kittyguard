# -*- coding: utf-8 -*-
"""官网 HTML 同步 6.3.0：zip 链接 + 版本号 + 时间轴插入 6.3.0 当前版 / 6.2.0 降为已发布 + version.json"""
import io, json, time

DG = r"F:\桌面保护\desktopguard"
paths = [
    DG + r"\官网\DG安全官网.html",
    DG + r"\官网\index.html",
    DG + r"\官网\publish\index.html",
]

# 6.2.0 当前版时间轴节点（作为插入锚点；先确认文件现状再执行）
old620 = ('<div class="tl-item">\n'
          '        <div class="tl-time">6.2.0</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>洪流冲刷一键直达 · 组件自检修复 · 勒索立即备份</h4>')

new630 = ('<div class="tl-item">\n'
          '        <div class="tl-time">6.3.0</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>自启动实时监控 · 扫描 IO 节流</h4><p>新增独立实时防线：每 5 秒快照对比注册表 Run/RunOnce（HKCU+HKLM）与用户/全局启动文件夹，发现新增自启动项立即记录防护日志；可疑项（命令含 PowerShell/mshta/rundll32/certutil/bitsadmin 等脚本宿主或下载执行链、从 Temp/AppData/Downloads/Public 可写目录启动、双扩展名伪装）自动弹窗告警，可一键去「工具 → 启动项管理」处理，免打扰模式静默记录；设置新增「自启动监控」开关，纯轮询轻量线程 CPU≈0。扫描节流再升级：扫描线程降优先级之外新增进程级 IO 优先级 VERY_LOW（NtSetInformationProcess IoPriority）——全盘扫描时 DG 的磁盘读写请求自动排到其他程序之后，鼠标/系统/游戏不再被扫描 IO 拖到一卡一卡，扫描结束自动恢复。</p></div>\n'
          '      </div>\n'
          + old620.replace('<span class="ver">当前版</span>洪流冲刷一键直达', '<span class="ver">已发布</span>洪流冲刷一键直达'))

ok = True
for p in paths:
    try:
        s = io.open(p, encoding="utf-8").read()
    except Exception as e:
        print("FAIL 读取", p, e)
        ok = False
        continue
    s = s.replace("DG-Security_6.2.0.zip", "DG-Security_6.3.0.zip")
    s = s.replace("DG-Source_6.2.0.zip", "DG-Source_6.3.0.zip")
    s = s.replace("DG 6.2.0", "DG 6.3.0")
    s = s.replace("当前版本 6.2.0", "当前版本 6.3.0")
    if old620 in s:
        s = s.replace(old620, new630, 1)
        print("[OK] %s：zip/版本号已改 6.3.0，时间轴已插 6.3.0 当前版 + 6.2.0 降为已发布" % p)
    else:
        # 兼容：时间轴可能已被部分改写，至少保证版本号替换完成
        print("[WARN] %s：时间轴 6.2.0 锚点未命中（版本号已改）；稍后人工核对" % p)
        ok = False
    io.open(p, "w", encoding="utf-8").write(s)

# version.json（根 + publish）
ver = {
    "latest_version": "6.3.0",
    "version": "6.3.0",
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.3.0 内容更新：自启动实时监控 + 扫描 IO 节流。",
    "features": [
        "自启动实时监控：每 5 秒快照对比注册表 Run/RunOnce + 启动文件夹，新增项记录日志；可疑项（脚本宿主/下载执行链/可写目录/双扩展名）弹窗告警，免打扰静默",
        "设置新增「自启动监控」开关（默认开启），CPU≈0",
        "扫描 IO 节流：进程级 IO 优先级 VERY_LOW，扫描不再拖卡鼠标/系统/游戏",
        "全程纯用户态、零驱动、不服务化"
    ]
}
for p in (DG + r"\官网\version.json", DG + r"\官网\publish\version.json"):
    io.open(p, "w", encoding="utf-8").write(json.dumps(ver, ensure_ascii=False, indent=2))
    print("[OK] %s -> 6.3.0" % p)
print("RESULT", "OK" if ok else "NEED_CHECK")
