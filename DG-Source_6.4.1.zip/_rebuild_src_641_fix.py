# -*- coding: utf-8 -*-
"""重打 6.4.1 源码 zip（排除大体积非源码文件）"""
import io, os, zipfile, hashlib

DG = r"F:\桌面保护\desktopguard"
OFF = os.path.join(DG, "官网")
PUB = os.path.join(OFF, "publish")

SKIP = {
    ".gitignore", "_online_641.zip",
    "DG安全.spec.bak", "DG安全.exe", "DG安全",
}
# 根目录只打包源码类文件（.py/.json/.txt/.md/.yar/.bat/.ico 等文本与配置），排除大二进制
BIG_EXT = {".zip", ".exe", ".dll", ".pyd", ".cvd", ".db", ".onnx", ".joblib", ".ico", ".log"}

root_files = set(f for f in os.listdir(DG) if os.path.isfile(os.path.join(DG, f)))
include = []
for f in sorted(root_files):
    if f in SKIP:
        continue
    ext = os.path.splitext(f)[1].lower()
    if ext in BIG_EXT:
        continue
    include.append(f)

out_zip = os.path.join(PUB, "DG-Source_6.4.1.zip")
if os.path.exists(out_zip):
    os.remove(out_zip)
with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for fn in include:
        p = os.path.join(DG, fn)
        if os.path.isfile(p):
            z.write(p, fn)
size = os.path.getsize(out_zip)
sha = hashlib.sha256()
with open(out_zip, "rb") as f:
    for chunk in iter(lambda: f.read(65536), b""):
        sha.update(chunk)
print("[OK] source zip: %d files / %d B / sha256 %s" % (len(include), size, sha.hexdigest().upper()))
# 同步官网根目录
import shutil
shutil.copy2(out_zip, os.path.join(OFF, "DG-Source_6.4.1.zip"))
print("[OK] synced to 官网 root")
