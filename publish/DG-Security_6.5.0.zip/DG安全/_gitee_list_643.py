# -*- coding: utf-8 -*-
import json, urllib.request
TOKEN = "964d5ca1cfc09792719272c1260170a8"
BASE = "https://gitee.com/api/v5/repos/kittyguard/kittyguard"
req = urllib.request.Request(BASE + "/releases?access_token=%s&per_page=5" % TOKEN, headers={"User-Agent": "kittyguard"})
with urllib.request.urlopen(req, timeout=30) as r:
    j = json.loads(r.read().decode("utf-8"))
    for rel in j:
        files = rel.get("assets", [])
        print("ID=%s tag=%s name=%s files=%d" % (rel.get("id"), rel.get("tag_name"), rel.get("name"), len(files)))
        for a in files:
            print("   ", a.get("name"), a.get("size"))
