# -*- coding: utf-8 -*-
"""
DesktopGuard P1-2 系统环境检查
================================
纯只读检测模块（只检测不启用），用于判断当前主机是否具备运行
Windows Sandbox（沙箱自动化）所需的环境条件。

检测项：
  1. Windows 版本（Win10/Win11、构建号、专业版/企业版）
  2. CPU 虚拟化（VT-x/AMD-V）是否在固件中开启
  3. Windows Sandbox 可选功能是否启用 + WindowsSandbox.exe 是否存在
  4. VT-d / IOMMU（HVCI 注册表项）状态及 DMA 攻击风险提示

硬约束：
  - 仅使用标准库；纯用户态，不修改任何系统设置
  - 所有 subprocess 调用加 CREATE_NO_WINDOW 与 timeout
"""

import os
import json
import winreg
import subprocess

# 避免弹窗的创建标志：CREATE_NO_WINDOW
CREATE_NO_WINDOW = 0x08000000

# Windows Sandbox 可执行文件固定路径
SANDBOX_EXE = r"C:\Windows\System32\WindowsSandbox.exe"

# Windows Sandbox 可选功能名（DISM / Get-WindowsOptionalFeature）
SANDBOX_FEATURE = "Containers-DisposableClientVM"


def _run(cmd, timeout=15):
    """
    静默执行外部命令，返回 (returncode, stdout_text, stderr_text)。
    任何异常都被捕获，保证调用方不会因为系统命令失败而崩溃。
    中文 Windows 控制台输出为 GBK(936)，按 GBK 解码并容错替换。
    """
    try:
        p = subprocess.run(
            cmd,
            capture_output=True,
            timeout=timeout,
            creationflags=CREATE_NO_WINDOW,
        )
        out = (p.stdout or b"").decode("gbk", errors="replace")
        err = (p.stderr or b"").decode("gbk", errors="replace")
        return p.returncode, out, err
    except FileNotFoundError as e:
        return -1, "", f"命令不存在: {e}"
    except subprocess.TimeoutExpired:
        return -2, "", f"命令超时({timeout}s)"
    except Exception as e:  # noqa: BLE001 - 检测模块必须兜底
        return -3, "", f"{type(e).__name__}: {e}"


# =====================================================================
# 1. Windows 版本信息
# =====================================================================
def get_windows_version() -> dict:
    """
    读取 HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion，
    返回版本号、版本名（Win10/Win11）、构建号、是否专业版/企业版等。
    """
    info = {
        "product_name": "",        # ProductName，如 "Windows 11 Pro"
        "build": "",               # CurrentBuild
        "ubr": "",                 # 更新版本号
        "release_id": "",          # ReleaseId（老字段）
        "display_version": "",     # DisplayVersion（22H2 等）
        "edition_id": "",          # EditionID（Professional / Enterprise...）
        "channel": "",            # InstallationType（Client 等）
        "build_number": 0,
        "os_name": "Windows",     # 判定后的 Win10/Win11
        "is_pro": False,
        "is_enterprise": False,
        "is_client_edition": True,
    }
    value_map = {
        "ProductName": "product_name",
        "CurrentBuild": "build",
        "UBR": "ubr",
        "ReleaseId": "release_id",
        "DisplayVersion": "display_version",
        "EditionID": "edition_id",
        "InstallationType": "channel",
    }
    try:
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows NT\CurrentVersion",
        )
        try:
            for reg_name, out_key in value_map.items():
                try:
                    val, _ = winreg.QueryValueEx(key, reg_name)
                    info[out_key] = str(val)
                except FileNotFoundError:
                    # 某些字段在新版本上缺失，属正常现象
                    continue
        finally:
            winreg.CloseKey(key)
    except Exception as e:  # noqa: BLE001
        info["error"] = f"读取版本注册表失败: {e}"

    # 构建号判定：>=22000 为 Win11
    try:
        info["build_number"] = int(info.get("build") or "0")
    except ValueError:
        info["build_number"] = 0
    bn = info["build_number"]
    if bn >= 22000:
        info["os_name"] = "Windows 11"
    elif bn >= 10240:
        info["os_name"] = "Windows 10"
    else:
        info["os_name"] = info.get("product_name") or "Windows"

    # 版本等级判定
    ed = (info.get("edition_id") or "").lower()
    pn = (info.get("product_name") or "").lower()
    info["is_pro"] = ("professional" in ed) or ("专业版" in info.get("product_name", "")) or ("pro" in pn)
    info["is_enterprise"] = ("enterprise" in ed) or ("企业版" in info.get("product_name", ""))
    info["is_client_edition"] = "server" not in ed
    return info


# =====================================================================
# 2. CPU 虚拟化（VT-x / AMD-V）
# =====================================================================
def check_virtualization() -> dict:
    """
    检测 CPU 虚拟化是否在固件（BIOS/UEFI）中开启。
    优先用 PowerShell CIM 查询 Win32_Processor.VirtualizationFirmwareEnabled，
    失败则回退解析 systeminfo 的 "Hyper-V 要求" / "Hyper-V requirements" 段。
    """
    result = {"enabled": None, "method": "", "detail": ""}

    # ---- 方法一：PowerShell CIM（快、准）----
    rc, out, err = _run(
        ["powershell", "-NoProfile", "-Command",
         "(Get-CimInstance Win32_Processor).VirtualizationFirmwareEnabled"],
        timeout=20,
    )
    txt = (out or "").strip()
    low = txt.lower()
    if low in ("true", "false"):
        result["enabled"] = (low == "true")
        result["method"] = "CIM Win32_Processor.VirtualizationFirmwareEnabled"
        result["detail"] = txt
        return result

    # ---- 方法二：解析 systeminfo ----
    rc, out, err = _run(["systeminfo"], timeout=60)
    if out:
        # 中文："固件中已启用虚拟化: 是" / 英文："Virtualization Enabled In Firmware: Yes"
        for line in out.splitlines():
            s = line.strip()
            if ("虚拟化" in s and "固件" in s) or ("virtualization" in s.lower()
                                                  and "firmware" in s.lower()):
                result["method"] = "systeminfo"
                result["detail"] = s
                # 判定：含"是"/"Yes"视为开启
                if ("是" in s) or ("yes" in s.lower()) or ("已启用" in s):
                    result["enabled"] = True
                elif ("否" in s) or ("no" in s.lower()):
                    result["enabled"] = False
                break
    if result["enabled"] is None:
        result["detail"] = (result["detail"]
                            or "无法自动判定，请在任务管理器->性能->CPU 中查看"
                            "“虚拟化: 已启用”")
    return result


# =====================================================================
# 3. Windows Sandbox 功能状态
# =====================================================================
def check_windows_sandbox() -> dict:
    """
    检测 Windows Sandbox：
      - 可选功能 Containers-DisposableClientVM 是否启用（DISM 查询）
      - C:\\Windows\\System32\\WindowsSandbox.exe 是否存在
    available = 功能已启用 且 exe 存在
    """
    result = {
        "available": False,
        "enabled": False,
        "exe_exists": False,
        "detail": "",
    }
    result["exe_exists"] = os.path.isfile(SANDBOX_EXE)

    # DISM 查询可选功能状态（只读）
    rc, out, err = _run(
        ["dism", "/online", "/get-featureinfo",
         f"/featurename:{SANDBOX_FEATURE}"],
        timeout=40,
    )
    combined = (out or "") + (err or "")
    detail_lines = []
    for line in combined.splitlines():
        ls = line.strip()
        # 中文 DISM："状态 : 已启用" / 英文："State : Enabled"
        if ("状态" in ls) or ls.lower().startswith("state"):
            detail_lines.append(ls)
            if ("已启用" in ls) or (ls.lower().rstrip().endswith("enabled")
                                    and "disable" not in ls.lower()):
                result["enabled"] = True
    result["detail"] = "; ".join(detail_lines) or (err or out or "DISM 无输出").strip()

    result["available"] = bool(result["enabled"] and result["exe_exists"])
    return result


# =====================================================================
# 4. VT-d / IOMMU 状态（DMA 硬件防护）
# =====================================================================
def check_vtd() -> dict:
    """
    检测 VT-d / IOMMU（通过 DeviceGuard 下 HVCI 注册表项间接判断）。
    注册表：HKLM\\SYSTEM\\CurrentControlSet\\Control\\DeviceGuard\\
            Scenarios\\HypervisorEnforcedCodeIntegrity
    """
    result = {
        "enabled": False,
        "detail": "",
        "risk_note": "VT-d未开启可能存在DMA硬件攻击风险",
    }
    reg_path = (r"SYSTEM\CurrentControlSet\Control\DeviceGuard"
                r"\Scenarios\HypervisorEnforcedCodeIntegrity")
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path)
        try:
            val, _ = winreg.QueryValueEx(key, "Enabled")
            if val == 1:
                result["enabled"] = True
                result["detail"] = f"HVCI(HypervisorEnforcedCodeIntegrity) Enabled={val}，VBS 隔离防护已开启"
            else:
                result["detail"] = f"HVCI Enabled={val}，未强制开启内核隔离"
        finally:
            winreg.CloseKey(key)
    except FileNotFoundError:
        result["detail"] = "未找到 HVCI 注册表项（通常表示内核隔离/VBS 未配置）"
    except Exception as e:  # noqa: BLE001
        result["detail"] = f"读取 DeviceGuard 注册表失败: {e}"
    return result


# =====================================================================
# 5. 汇总入口
# =====================================================================
def run_all_checks() -> dict:
    """一次性运行全部检查，任何单项异常都被兜住，不崩溃。"""
    summary = {
        "windows_version": {},
        "virtualization": {},
        "windows_sandbox": {},
        "vtd": {},
    }
    try:
        summary["windows_version"] = get_windows_version()
    except Exception as e:  # noqa: BLE001
        summary["windows_version"] = {"error": str(e)}
    try:
        summary["virtualization"] = check_virtualization()
    except Exception as e:  # noqa: BLE001
        summary["virtualization"] = {"enabled": None, "error": str(e)}
    try:
        summary["windows_sandbox"] = check_windows_sandbox()
    except Exception as e:  # noqa: BLE001
        summary["windows_sandbox"] = {"available": False, "error": str(e)}
    try:
        summary["vtd"] = check_vtd()
    except Exception as e:  # noqa: BLE001
        summary["vtd"] = {"enabled": False, "error": str(e)}
    return summary


# =====================================================================
# 6. 启用 Windows Sandbox 的指引（只读文案，不执行）
# =====================================================================
def get_enable_sandbox_guide() -> str:
    """返回启用 Windows Sandbox 的步骤指引（PowerShell 命令 + 手动步骤）。"""
    return (
        "===== 启用 Windows 沙盒 (Windows Sandbox) 指引 =====\n"
        "前置条件：\n"
        "  1) Windows 10/11 专业版或企业版（家庭版不支持）\n"
        "  2) CPU 虚拟化（VT-x / AMD-V）已在 BIOS/UEFI 中开启\n"
        "  3) 系统为 64 位\n"
        "\n"
        "方法一：管理员 PowerShell 一键启用（需重启）：\n"
        "  Enable-WindowsOptionalFeature -Online "
        "-FeatureName Containers-DisposableClientVM -All\n"
        "  或用 DISM：\n"
        "  dism /online /enable-feature /featurename:Containers-DisposableClientVM /all\n"
        "\n"
        "方法二：手动勾选：\n"
        "  控制面板 -> 程序 -> 启用或关闭 Windows 功能 ->\n"
        "  勾选“Windows 沙盒 (Windows Sandbox)” -> 确定 -> 重启电脑\n"
        "\n"
        "注意：开启后可能还需在 BIOS/UEFI 中确认“虚拟化技术/Virtualization Technology”"
        "与“Intel VT-d / AMD-Vi”为 Enabled。\n"
    )


# =====================================================================
# 自测块：只打印检查结果，不实际启用任何功能、不启动沙箱
# =====================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("DesktopGuard 系统环境检查（只读自测）")
    print("=" * 60)
    result = run_all_checks()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print("-" * 60)
    ws = result.get("windows_sandbox", {})
    print(f"Windows Sandbox 可用: {ws.get('available')} "
          f"(功能启用={ws.get('enabled')}, exe存在={ws.get('exe_exists')})")
    vt = result.get("virtualization", {})
    print(f"CPU 虚拟化开启: {vt.get('enabled')}  方式={vt.get('method')}")
    print("-" * 60)
    # 仅打印指引，不执行任何启用命令
    print(get_enable_sandbox_guide())
