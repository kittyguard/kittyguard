# -*- coding: utf-8 -*-
"""集成性能悬浮窗到 DG 主程序（4.2.0 -> 4.3.0）"""
import io

p = r'F:\桌面保护\desktopguard\main.py'
src = io.open(p, encoding='utf-8').read()
done = []

# 1. 版本号
old1 = 'APP_VERSION = "4.2.0"'
assert src.count(old1) == 1, 'version anchor'
src = src.replace(old1, 'APP_VERSION = "4.3.0"')
done.append('version 4.3.0')

# 2. 版本记录：在 4.2.0 条目前插入 4.3.0
anchor = '    ("4.2.0", "内容更新（受保护文件'
new_ver = ('    ("4.3.0", "内容更新（性能悬浮窗）：1.工具页新增「系统监控」卡片——一键打开桌面置顶性能悬浮窗（独立进程不阻塞主程序，防重复启动）；'
           '2.悬浮窗实时显示 CPU 占用/频率/核心数、GPU 占用/温度/显存/频率/功耗、内存、磁盘C、进程数，半透明置顶、可拖动、右键菜单可调刷新间隔(0.5/1/2秒)；'
           '3.CPU 温度采用 WMI ACPI 热区尽力读取，不支持机型显示 --（GPU 温度经 NVIDIA NVML 稳定获取，RTX 5060 实测正常）"),\n')
assert src.count(anchor) == 1, 'verlist anchor'
src = src.replace(anchor, new_ver + anchor)
done.append('verlist 4.3.0')

# 3. 工具页 t4 系统监控卡片
old3 = ('        ttk.Button(t3, text="打开 AI 聊天", style="Ghost.TButton", command=self._open_ai_chat).pack(anchor="w", pady=(6, 0))\n'
        '\n'
        '        # ============ 保护页（随新主题自动换肤） ============')
t4 = ('        ttk.Button(t3, text="打开 AI 聊天", style="Ghost.TButton", command=self._open_ai_chat).pack(anchor="w", pady=(6, 0))\n'
      '        t4 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)\n'
      '        t4.pack(fill="x", pady=4)\n'
      '        tk.Label(t4, text="系统监控", bg=C_CARD2, fg=C_PRIMARY,\n'
      '                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")\n'
      '        tk.Label(t4, text="桌面置顶性能悬浮窗：CPU/GPU 占用·GPU 温度·显存·功耗·内存·磁盘·进程数实时显示，可拖动、可调刷新间隔（CPU 温度需第三方传感器，暂显示 --）",\n'
      '                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))\n'
      '        ttk.Button(t4, text="打开性能悬浮窗", style="Accent.TButton", command=self._open_perf_overlay).pack(anchor="w", pady=(6, 0))\n'
      '\n'
      '        # ============ 保护页（随新主题自动换肤） ============')
assert src.count(old3) == 1, 'tools anchor'
src = src.replace(old3, t4)
done.append('tools card')

# 4. _open_perf_overlay 方法：插在 def _open_ai_chat 前
anchor4 = '    def _open_ai_chat(self):'
method = (
    '    def _open_perf_overlay(self):\n'
    '        """打开性能悬浮窗（独立进程，防重复启动）"""\n'
    '        import ctypes\n'
    '        found = []\n'
    '        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)\n'
    '        def cb(h, l):\n'
    '            if ctypes.windll.user32.IsWindowVisible(h):\n'
    '                buf = ctypes.create_unicode_buffer(256)\n'
    '                ctypes.windll.user32.GetWindowTextW(h, buf, 256)\n'
    '                if "性能悬浮窗" in buf.value:\n'
    '                    found.append(h)\n'
    '            return True\n'
    '        try:\n'
    '            ctypes.windll.user32.EnumWindows(cb, 0)\n'
    '        except Exception:\n'
    '            pass\n'
    '        if found:\n'
    '            messagebox.showinfo("性能悬浮窗", "性能悬浮窗已在运行（屏幕右上角），右键悬浮窗可退出或调整刷新间隔。")\n'
    '            return\n'
    '        script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "perf_overlay.py")\n'
    '        if not os.path.exists(script):\n'
    '            messagebox.showerror("性能悬浮窗", "未找到 perf_overlay.py（应位于 DG 程序目录）。")\n'
    '            return\n'
    '        try:\n'
    '            subprocess.Popen([sys.executable, script],\n'
    '                             cwd=os.path.dirname(os.path.abspath(__file__)),\n'
    '                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))\n'
    '            messagebox.showinfo("性能悬浮窗", "性能悬浮窗已打开（屏幕右上角，可拖动；右键菜单可调刷新间隔/退出）。")\n'
    '        except Exception as e:\n'
    '            messagebox.showerror("性能悬浮窗", f"启动失败：{e}")\n'
    '\n'
    '    def _open_ai_chat(self):'
)
assert src.count(anchor4) == 1, 'method anchor'
src = src.replace(anchor4, method)
done.append('method')

io.open(p, 'w', encoding='utf-8').write(src)
print('OK:', ', '.join(done))
