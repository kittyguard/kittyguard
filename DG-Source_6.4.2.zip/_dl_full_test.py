# -*- coding: utf-8 -*-
import subprocess, hashlib, os, tempfile

tmp = os.path.join(tempfile.gettempdir(), "dg_dl_test")
os.makedirs(tmp, exist_ok=True)
expected = {
    "DG-Security-Setup-6.4.1.exe": "9D10465B",
    "DG-Security_6.4.1.zip": "D8283EF3",
}
for name, prefix in expected.items():
    u = "https://kittyguard.github.io/kittyguard/" + name
    out = os.path.join(tmp, name)
    if os.path.exists(out):
        os.remove(out)
    r = subprocess.run(["curl", "-s", "-L", "--max-time", "300", "-o", out, u],
                       capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=330)
    if os.path.exists(out):
        size = os.path.getsize(out)
        h = hashlib.sha256()
        with open(out, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        sha = h.hexdigest().upper()
        print("%s: size=%d sha256=%s... 前缀匹配=%s" % (name, size, sha[:8], sha.startswith(prefix)))
    else:
        print("%s: 下载失败 %s" % (name, r.stdout[:200] or r.stderr[:200]))
