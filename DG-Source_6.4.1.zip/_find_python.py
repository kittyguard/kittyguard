# -*- coding: utf-8 -*-
import os, glob

roots = [
    r"C:\Users\Administrator\AppData\Local\Programs\Python",
    r"C:\Program Files\Python",
    r"C:\Python",
    r"C:\Python312",
    r"C:\Python314",
]
for r in roots:
    if os.path.isdir(r):
        print("ROOT:", r)
        for d in sorted(os.listdir(r)):
            p = os.path.join(r, d, "python.exe")
            if os.path.isfile(p):
                print("   ", p)

# 全盘搜 python.exe（限 Program 相关目录）
for pat in [
    r"C:\Users\Administrator\AppData\Local\Programs\Python\**\python.exe",
    r"C:\Program Files\**\python.exe",
    r"C:\Python*\python.exe",
]:
    for p in glob.glob(pat, recursive=True):
        print("GLOB:", p)
