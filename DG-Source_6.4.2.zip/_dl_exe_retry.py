# -*- coding: utf-8 -*-
import subprocess, hashlib, os, tempfile

tmp = os.path.join(tempfile.gettempdir(), "dg_dl_test3")
os.makedirs(tmp, exist_ok=True)
u = "https://kittyguard.github.io/kittyguard/DG-Security-Setup-6.4.1.exe"
out = os.path.join(tmp, "setup.exe")
want_size = 30898197

for attempt in range(1, 4):
    if os.path.exists(out):
        os.remove(out)
    r = subprocess.run(["curl", "-s", "-L", "--max-time", "420",
                        "-x", "http://127.0.0.1:33210", "-o", out, u],
                       capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=450)
    if os.path.exists(out):
        size = os.path.getsize(out)
        h = hashlib.sha256()
        with open(out, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        sha = h.hexdigest().upper()
        print("尝试%d: size=%d 完整=%s sha256=%s... 匹配=%s" %
              (attempt, size, size == want_size, sha[:8], sha.startswith("9D10465B")))
        if size == want_size and sha.startswith("9D10465B"):
            print("OK：安装包完整可用")
            break
    else:
        print("尝试%d: 失败 %s" % (attempt, (r.stdout or r.stderr)[:150]))
