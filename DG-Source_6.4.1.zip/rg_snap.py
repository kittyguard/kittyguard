# -*- coding: utf-8 -*-
"""真实桌面截图：ctypes BitBlt 抓 WinSta0\\Default 全屏。"""
import ctypes
from ctypes import wintypes
import os, time

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32

w = user32.GetSystemMetrics(0)
h = user32.GetSystemMetrics(1)
hdc = user32.GetDC(0)
mdc = gdi32.CreateCompatibleDC(hdc)
bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
gdi32.SelectObject(mdc, bmp)

class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long),
                ("biHeight", ctypes.c_long), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", ctypes.c_long),
                ("biYPelsPerMeter", ctypes.c_long), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]

gdi32.BitBlt(mdc, 0, 0, w, h, hdc, 0, 0, 0x00CC0020)  # SRCCOPY

bi = BITMAPINFOHEADER()
bi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
bi.biWidth = w
bi.biHeight = -h
bi.biPlanes = 1
bi.biBitCount = 32
bi.biCompression = 0
buf_size = w * h * 4
buf = ctypes.create_string_buffer(buf_size)
gdi32.GetDIBits(mdc, bmp, 0, h, buf, ctypes.byref(bi), 0)

bpp = 24
bmih = BITMAPINFOHEADER()
bmih.biSize = ctypes.sizeof(BITMAPINFOHEADER)
bmih.biWidth = w
bmih.biHeight = -h
bmih.biPlanes = 1
bmih.biBitCount = bpp
bmih.biCompression = 0
row = (w * bpp + 31) // 32 * 4
buf24 = ctypes.create_string_buffer(row * h)
gdi32.GetDIBits(mdc, bmp, 0, h, buf24, ctypes.byref(bmih), 0)

# 写 BMP 头 + 24bit 数据
file_header = b"BM" + (14 + ctypes.sizeof(bmih) + row * h).to_bytes(4, "little") + b"\x00\x00\x00\x00" + (14 + ctypes.sizeof(bmih)).to_bytes(4, "little")
out = r"F:\桌面保护\新建文件夹\real_desktop.bmp"
with open(out, "wb") as f:
    f.write(file_header)
    f.write(bytes(bmih))
    f.write(buf24.raw)

gdi32.DeleteObject(bmp)
gdi32.DeleteDC(mdc)
user32.ReleaseDC(0, hdc)
print("SNAPPED", w, h, os.path.getsize(out))
