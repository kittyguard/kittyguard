# -*- coding: utf-8 -*-
from PIL import Image
im = Image.open(r"F:\桌面保护\desktopguard\官网\_shots\DG安全官网_mobile.jpg")
print("size", im.size)
im.crop((0, 0, im.width, 1800)).save(r"F:\桌面保护\新建文件夹\mobile_top.png")
print("ok")
