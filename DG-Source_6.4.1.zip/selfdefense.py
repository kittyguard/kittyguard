# -*- coding: utf-8 -*-
"""
DG安全 · 自防护中心 v1（回滚中心 + 防篡改）
独立运行：python selfdefense.py
被 DG 主程序调用：subprocess 启动本脚本（互不阻塞）

【回滚中心】统一管理 DG 全部可回滚操作：
  - TCP 优化 / 结束后台进程（由 net_tools.py 写入操作日志）→ 一键回滚
  - 配置文件（config.json / rtp_config.json）自动备份 → 按时间点一键恢复
  - 数据库（dg_data.db）备份 → 一键恢复

【防篡改】保护 DG 自身核心文件：
  - 核心 .py 模块 + 配置文件哈希清单（manifest），周期性校验
  - 发现被篡改 / 删除 / 替换 → 自动从当前版本快照恢复 + 日志 + 弹窗提示
  - 配置类文件从备份恢复（不覆盖用户最新设置）

纯用户态，不碰内核。
"""
import os
import sys
import time
import json
import hashlib
import shutil
import threading
import subprocess
import tkinter as tk

# ---------- 主题（DG 4.x 深色科技风） ----------
BG      = "#0d1520"
FG      = "#d8e6f2"
DIM     = "#7fa3c0"
ACCENT  = "#00d4ff"
WARN    = "#ffb648"
DANGER  = "#ff5c5c"
OK      = "#3dff8e"
CARD    = "#14202e"
FONT    = ("Microsoft YaHei UI", 9)
FONT_S  = ("Microsoft YaHei UI", 8)
FONT_T  = ("Microsoft YaHei UI", 9, "bold")

DG_DIR  = os.path.dirname(os.path.abspath(__file__))
DG_DATA = os.path.join(os.path.dirname(DG_DIR), "dgdata")
ROLL_DIR = os.path.join(DG_DATA, "rollback")
CFG_BAK_DIR = os.path.join(ROLL_DIR, "config_backups")
DB_BAK_DIR  = os.path.join(ROLL_DIR, "db_backups")
MANIFEST = os.path.join(ROLL_DIR, "manifest.json")
ROLL_LOG = os.path.join(ROLL_DIR, "rollback_log.json")

# 核心 .py 模块（防篡改清单；快照恢复源=当前版本目录）
CORE_PY = [
    "main.py", "net_tools.py", "database.py", "engine.py",
    "realtime_protection.py", "logger.py", "paths.py", "perf_overlay.py",
    "tray.py", "popup_blocker.py", "ai_behavior_analyzer.py", "app_patrol.py",
    "cloud_lookup.py", "cloud_query.py", "dg_context.py", "sandbox_runner.py",
    "scan_core_bridge.py", "system_check.py", "system_guard.py", "yara_engine.py",
    "clamav_bridge.py", "ml_features.py", "ml_infer.py", "verdict_engine.py",
    "flush_engine.py",
]
# 配置文件（防篡改；备份/恢复）
CFG_FILES = ["config.json", "rtp_config.json"]
# 数据库
DB_FILE = "dg_data.db"

APP_VERSION = "6.4.1"


def _sha256(path):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                b = f.read(65536)
                if not b:
                    break
                h.update(b)
        return h.hexdigest()
    except Exception:
        return None


def snapshot_dir():
    """当前版本快照目录 versions/<APP_VERSION>/"""
    return os.path.join(DG_DIR, "versions", APP_VERSION)


def build_manifest():
    """重建清单：核心 .py 哈希以当前安装文件为基准（安装态=受信任态），恢复源=版本快照"""
    man = {"version": APP_VERSION, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
           "py": {}, "cfg": {}}
    snap = snapshot_dir()
    for name in CORE_PY:
        cur = os.path.join(DG_DIR, name)
        if os.path.exists(cur):
            h = _sha256(cur)
            if h:
                man["py"][name] = {"hash": h,
                                   "snap": os.path.join(snap, name)}
    for name in CFG_FILES:
        p = os.path.join(DG_DATA, name)
        if os.path.exists(p):
            h = _sha256(p)
            if h:
                man["cfg"][name] = {"hash": h}
    return man


def load_manifest():
    try:
        with open(MANIFEST, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def save_manifest(man):
    try:
        os.makedirs(ROLL_DIR, exist_ok=True)
        with open(MANIFEST, "w", encoding="utf-8") as f:
            json.dump(man, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def check_integrity():
    """校验核心文件完整性；返回问题列表 [ {name, issue, kind} ]"""
    issues = []
    man = load_manifest()
    if not man or man.get("version") != APP_VERSION:
        return [{"name": "(清单)", "issue": "清单缺失或版本不符，需重建", "kind": "manifest"}]
    for name, meta in man.get("py", {}).items():
        p = os.path.join(DG_DIR, name)
        if not os.path.exists(p):
            issues.append({"name": name, "issue": "文件被删除", "kind": "py"})
            continue
        h = _sha256(p)
        if h != meta.get("hash"):
            issues.append({"name": name, "issue": "文件被篡改（哈希不一致）", "kind": "py"})
    for name, meta in man.get("cfg", {}).items():
        p = os.path.join(DG_DATA, name)
        if not os.path.exists(p):
            issues.append({"name": name, "issue": "配置文件被删除", "kind": "cfg"})
            continue
        h = _sha256(p)
        if h != meta.get("hash"):
            issues.append({"name": name, "issue": "配置文件被修改（对比启动时基准）", "kind": "cfg"})
    return issues


def auto_repair(issues):
    """自动修复：.py 从快照恢复；配置文件从备份恢复；返回修复列表"""
    fixed = []
    for it in issues:
        if it["kind"] == "py":
            name = it["name"]
            snap = os.path.join(snapshot_dir(), name)
            if os.path.exists(snap):
                try:
                    shutil.copy2(snap, os.path.join(DG_DIR, name))
                    fixed.append(name + "（已从快照恢复）")
                except Exception as e:
                    fixed.append(name + "（恢复失败：" + str(e) + "）")
        elif it["kind"] == "cfg":
            name = it["name"]
            bak = newest_backup(CFG_BAK_DIR, name)
            if bak:
                try:
                    shutil.copy2(bak, os.path.join(DG_DATA, name))
                    fixed.append(name + "（已从备份恢复）")
                except Exception as e:
                    fixed.append(name + "（恢复失败：" + str(e) + "）")
            else:
                fixed.append(name + "（无备份，跳过）")
    if fixed:
        rebuild_manifest()
    return fixed


def rebuild_manifest():
    """修复后重建清单（以当前状态为基准）"""
    save_manifest(build_manifest())


def newest_backup(bak_dir, base_name):
    """返回最新的备份文件路径（按文件名时间戳倒序）"""
    try:
        if not os.path.isdir(bak_dir):
            return None
        cands = [os.path.join(bak_dir, f) for f in os.listdir(bak_dir)
                 if f.startswith(base_name + "_") and f.endswith(".json")]
        cands.sort(reverse=True)
        return cands[0] if cands else None
    except Exception:
        return None


# ---------- 回滚中心数据 ----------
def read_roll_log():
    try:
        with open(ROLL_LOG, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def append_roll_log(entry):
    """供 net_tools 等模块调用：追加一条可回滚操作记录"""
    try:
        os.makedirs(ROLL_DIR, exist_ok=True)
        lst = read_roll_log()
        lst.append(entry)
        with open(ROLL_LOG, "w", encoding="utf-8") as f:
            json.dump(lst, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def rollback_entry(entry):
    """执行单条回滚；返回说明文字"""
    typ = entry.get("type", "")
    if typ == "tcp_optimize":
        orig = entry.get("orig_level")
        if orig:
            r = _netsh_tcp_set(orig)
            return "已回滚 TCP 自动调谐为 " + orig + "：" + (r or "已执行")
        return "记录缺少原值，无法回滚"
    if typ == "kill_procs":
        ok = 0
        for rec in entry.get("records", []):
            exe = rec.get("exe")
            if exe and os.path.exists(exe):
                try:
                    subprocess.Popen([exe], cwd=os.path.dirname(exe),
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                    ok += 1
                except Exception:
                    pass
        return "已尝试恢复 %s 个进程" % ok
    return "未知操作类型：" + str(typ)


def _netsh_tcp_set(level):
    try:
        r = subprocess.run(["netsh", "int", "tcp", "set", "global",
                            "autotuninglevel=" + level],
                           capture_output=True, timeout=8,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                           encoding="gbk", errors="ignore")
        return (r.stdout or "").strip()
    except Exception as e:
        return str(e)


# ---------- 配置/数据库备份 ----------
def backup_configs():
    """备份当前配置文件（带时间戳）"""
    stamp = time.strftime("%Y%m%d_%H%M%S")
    made = []
    try:
        os.makedirs(CFG_BAK_DIR, exist_ok=True)
    except Exception:
        return made
    for name in CFG_FILES:
        p = os.path.join(DG_DATA, name)
        if os.path.exists(p):
            try:
                shutil.copy2(p, os.path.join(CFG_BAK_DIR, "%s_%s.json" % (name, stamp)))
                made.append(name)
            except Exception:
                pass
    return made


def backup_db():
    """备份数据库（带时间戳）"""
    stamp = time.strftime("%Y%m%d_%H%M%S")
    try:
        os.makedirs(DB_BAK_DIR, exist_ok=True)
        src = os.path.join(DG_DIR, DB_FILE)
        if os.path.exists(src):
            dst = os.path.join(DB_BAK_DIR, "dg_data_%s.db" % stamp)
            shutil.copy2(src, dst)
            return dst
    except Exception:
        pass
    return None


# ---------- DG 数据快照回滚（可用回滚通道） ----------
SNAP_DIR = os.path.join(ROLL_DIR, "snapshots")
# 参与快照的文件：配置 + 数据库 + 受保护文件（dgdata 下）
SNAP_FILES = CFG_FILES + ["ai_config.json", "blacklist.json", "whitelist.json"]


def file_snapshot(tag="手动快照"):
    """创建 DG 数据快照（配置文件+数据库+名单）到 rollback/snapshots/<时间戳>_<tag>"""
    stamp = time.strftime("%Y%m%d_%H%M%S")
    d = os.path.join(SNAP_DIR, "%s_%s" % (stamp, tag))
    try:
        os.makedirs(d, exist_ok=True)
    except Exception as e:
        return None, str(e)
    done = []
    for name in SNAP_FILES:
        p = os.path.join(DG_DATA, name)
        if os.path.exists(p):
            try:
                shutil.copy2(p, os.path.join(d, name))
                done.append(name)
            except Exception:
                pass
    dbp = os.path.join(DG_DIR, DB_FILE)
    if os.path.exists(dbp):
        try:
            shutil.copy2(dbp, os.path.join(d, DB_FILE))
            done.append(DB_FILE)
        except Exception:
            pass
    if not done:
        return d, "无可快照文件"
    try:
        with open(os.path.join(d, "_meta.json"), "w", encoding="utf-8") as f:
            json.dump({"created": stamp, "tag": tag, "files": done}, f,
                      ensure_ascii=False, indent=2)
    except Exception:
        pass
    return d, "快照完成：%s" % ", ".join(done)


def list_snapshots():
    """返回快照列表 [(目录名, 时间, 标签)]，按时间倒序"""
    try:
        if not os.path.isdir(SNAP_DIR):
            return []
        lst = []
        for name in os.listdir(SNAP_DIR):
            p = os.path.join(SNAP_DIR, name)
            if os.path.isdir(p):
                meta = {}
                try:
                    with open(os.path.join(p, "_meta.json"), "r", encoding="utf-8") as f:
                        meta = json.load(f)
                except Exception:
                    pass
                lst.append((name, meta.get("created", name), meta.get("tag", "?")))
        lst.sort(reverse=True)
        return lst
    except Exception:
        return []


def restore_snapshot(snap_name):
    """从快照恢复文件（回滚）；返回说明文字"""
    d = os.path.join(SNAP_DIR, snap_name)
    if not os.path.isdir(d):
        return "快照不存在：" + snap_name
    restored = []
    for f in os.listdir(d):
        if f == "_meta.json":
            continue
        src = os.path.join(d, f)
        if f == DB_FILE:
            dst = os.path.join(DG_DIR, f)
        else:
            dst = os.path.join(DG_DATA, f)
        try:
            shutil.copy2(src, dst)
            restored.append(f)
        except Exception as e:
            restored.append(f + "(失败:%s)" % e)
    return "已从快照 [%s] 恢复：%s" % (snap_name, ", ".join(restored))


# ---------- 系统回滚（系统还原点） ----------
def sys_restore_state():
    """系统保护是否开启（0=禁用 1=启用）；返回 (state_str, 是否可创建)"""
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            "(Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore').DisableSR"],
                           capture_output=True, timeout=15,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                           encoding="gbk", errors="ignore")
        val = (r.stdout or "").strip()
        return val, (val == "0" or val == "1")
    except Exception:
        return "", False


def sys_restore_points():
    """列出系统还原点；返回 [(创建时间, 描述)]"""
    pts = []
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            "Get-ComputerRestorePoint | Select-Object CreationTime,Description,SequenceNumber | ConvertTo-Json -Compress"],
                           capture_output=True, timeout=20,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                           encoding="gbk", errors="ignore")
        out = (r.stdout or "").strip()
        if out and out != "null":
            data = json.loads(out) if out.startswith("[") else [json.loads(out)]
            for d in data:
                t = (d.get("CreationTime") or "").replace("T", " ").split(".")[0]
                pts.append((t, d.get("Description") or d.get("SequenceNumber") or "?"))
    except Exception:
        pass
    if not pts:
        # 兜底：卷影副本
        try:
            r = subprocess.run(["vssadmin", "list", "shadows"],
                               capture_output=True, timeout=20,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                               encoding="gbk", errors="ignore")
            for line in (r.stdout or "").splitlines():
                if "创建时间" in line or "Creation Time" in line:
                    pts.append((line.strip(), "卷影副本"))
        except Exception:
            pass
    return pts


def sys_enable_protection():
    """开启系统保护（注册表 DisableSR=0 + 分配卷影存储；需管理员）"""
    try:
        # 1) 注册表允许系统还原
        r1 = subprocess.run(["reg", "add",
                             r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore",
                             "/v", "DisableSR", "/t", "REG_DWORD", "/d", "0", "/f"],
                            capture_output=True, timeout=20,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                            encoding="gbk", errors="ignore")
        if r1.returncode != 0:
            return "注册表修改失败（需要管理员权限）：" + (r1.stderr or "").strip()[:160]
        # 2) 为 C: 分配卷影存储（若已存在会提示，忽略）
        subprocess.run(["vssadmin", "add", "shadowstorage", "/for=C:", "/on=C:",
                        "/maxsize=10%"],
                       capture_output=True, timeout=30,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                       encoding="gbk", errors="ignore")
        return "系统保护已开启（C:），现在可以创建还原点了。"
    except Exception as e:
        return "开启失败：" + str(e)


def sys_create_restore_point(desc="DG 系统回滚点"):
    """创建系统还原点（WMI SystemRestore.CreateRestorePoint，需系统保护开启+管理员）"""
    try:
        cmd = ('$sr = Get-WmiObject -Namespace root\\default -Class SystemRestore; '
               '$sr.CreateRestorePoint("%s", 12) | Out-String' % desc)
        r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                           capture_output=True, timeout=120,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                           encoding="gbk", errors="ignore")
        out = ((r.stdout or "") + (r.stderr or "")).strip()
        if "ReturnValue" in out or "返回代码" in out or r.returncode == 0:
            return "还原点创建成功：" + out[:120]
        return "创建失败（系统保护未开启或无管理员权限）：" + out[:160]
    except Exception as e:
        return "创建还原点失败：" + str(e)


def sys_open_rstrui():
    """打开系统还原向导（引导用户选择还原点执行系统回滚）"""
    try:
        subprocess.Popen(["rstrui.exe"],
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return "系统还原向导已打开（请按向导选择还原点，完成后会重启）"
    except Exception as e:
        return "打开系统还原向导失败：" + str(e)


def sys_restore_status_text():
    """系统保护状态文字"""
    val, ok = sys_restore_state()
    if val == "":
        return "系统保护状态未知（需管理员权限查询）"
    if val == "0":
        return "系统保护：已启用（可创建还原点）"
    return "系统保护：未开启（需在 系统属性→系统保护 中开启后才能创建还原点）"


# ---------- GUI ----------
class SelfDefenseApp:
    def __init__(self, root):
        self.root = root
        root.title("自防护中心 - DG安全")
        root.configure(bg=BG)
        root.geometry("700x780")
        root.resizable(False, False)

        tk.Label(root, text="DG 安全 · 自防护中心", bg=BG, fg=ACCENT,
                 font=("Microsoft YaHei UI", 14, "bold")).pack(pady=(12, 2))
        tk.Label(root, text="回滚中心（操作/配置/数据库）+ 防篡改（核心文件完整性自愈）",
                 bg=BG, fg=DIM, font=FONT_S).pack()

        # 滚动容器：内容再多也能上下滚动（按钮不会被窗口高度挤没）
        body_wrap = tk.Frame(root, bg=BG)
        body_wrap.pack(fill="both", expand=True, padx=14, pady=8)
        _cv = tk.Canvas(body_wrap, bg=BG, highlightthickness=0, bd=0)
        _vsb = tk.Scrollbar(body_wrap, orient="vertical", command=_cv.yview)
        _cv.configure(yscrollcommand=_vsb.set)
        _vsb.pack(side="right", fill="y")
        _cv.pack(side="left", fill="both", expand=True)
        body = tk.Frame(_cv, bg=BG)
        _win_id = _cv.create_window((0, 0), window=body, anchor="nw")

        def _on_cv_cfg(e):
            _cv.itemconfig(_win_id, width=e.width)
        _cv.bind("<Configure>", _on_cv_cfg)

        def _on_body_cfg(e):
            _cv.configure(scrollregion=_cv.bbox("all"))
        body.bind("<Configure>", _on_body_cfg)

        def _on_wheel(e):
            _cv.yview_scroll(int(-e.delta / 120), "units")
        _cv.bind("<Enter>", lambda e: root.bind_all("<MouseWheel>", _on_wheel))
        _cv.bind("<Leave>", lambda e: root.unbind_all("<MouseWheel>"))

        # ---- 系统回滚区（系统还原点） ----
        self._section(body, "系统回滚（Windows 还原点）")
        self.sr_status = tk.Label(body, text=sys_restore_status_text(), bg=BG, fg=OK,
                                  font=FONT_S)
        self.sr_status.pack(anchor="w")
        self.sr_txt = tk.Text(body, height=4, bg=CARD, fg=FG, font=FONT_S,
                              relief="flat", state="disabled", wrap="word")
        self._bind_text_wheel(self.sr_txt)
        self.sr_txt.pack(fill="x", pady=(2, 4))
        row0 = tk.Frame(body, bg=BG)
        row0.pack(anchor="w")
        tk.Button(row0, text="刷新还原点", command=self._sr_refresh,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row0, text="开启系统保护", command=self._sr_enable,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row0, text="创建还原点", command=self._sr_create,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row0, text="打开系统还原向导", command=self._sr_wizard,
                  bg=ACCENT, fg="#001018", activebackground="#33e0ff",
                  activeforeground="#001018", relief="flat", font=FONT).pack(side="left")
        self._sr_refresh()

        # ---- 防篡改区 ----
        self._section(body, "防篡改（核心文件完整性）")
        self.int_txt = tk.Text(body, height=6, bg=CARD, fg=FG, font=FONT_S,
                               relief="flat", state="disabled", wrap="word")
        self._bind_text_wheel(self.int_txt)
        self.int_txt.pack(fill="x", pady=(2, 6))
        row1 = tk.Frame(body, bg=BG)
        row1.pack(anchor="w")
        tk.Button(row1, text="立即校验", command=self._check_now,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row1, text="自动修复篡改", command=self._repair_now,
                  bg=WARN, fg="#1a0e00", activebackground="#ffc46b",
                  activeforeground="#1a0e00", relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row1, text="重建清单", command=self._rebuild_now,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left")
        self._auto_label = tk.Label(body, text="后台自愈：开启（每 60 秒校验一次）", bg=BG, fg=OK,
                                    font=FONT_S)
        self._auto_label.pack(anchor="w", pady=(6, 0))

        # ---- 回滚中心区 ----
        self._section(body, "回滚中心（快照回滚 / 操作回滚）")
        snap_row = tk.Frame(body, bg=BG)
        snap_row.pack(anchor="w", pady=(0, 2))
        tk.Button(snap_row, text="创建数据快照", command=self._snap_create,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(snap_row, text="恢复最新快照", command=self._snap_restore_latest,
                  bg=OK, fg="#00240f", activebackground="#6bffb1",
                  activeforeground="#00240f", relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        self.snap_txt = tk.Text(body, height=4, bg=CARD, fg=FG, font=FONT_S,
                                relief="flat", state="disabled", wrap="word")
        self._bind_text_wheel(self.snap_txt)
        self.snap_txt.pack(fill="x", pady=(2, 4))
        self._snap_refresh()

        self.roll_txt = tk.Text(body, height=5, bg=CARD, fg=FG, font=FONT_S,
                                relief="flat", state="disabled", wrap="word")
        self._bind_text_wheel(self.roll_txt)
        self.roll_txt.pack(fill="x", pady=(2, 4))
        row2 = tk.Frame(body, bg=BG)
        row2.pack(anchor="w")
        tk.Button(row2, text="刷新记录", command=self._refresh_roll,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row2, text="备份配置", command=self._do_backup_cfg,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row2, text="备份数据库", command=self._do_backup_db,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(row2, text="回滚全部操作", command=self._rollback_all,
                  bg=ACCENT, fg="#001018", activebackground="#33e0ff",
                  activeforeground="#001018", relief="flat", font=FONT).pack(side="left", padx=(6, 0))

        # 日志
        self._section(body, "日志")
        self.log_txt = tk.Text(body, height=6, bg=CARD, fg=FG, font=FONT_S,
                               relief="flat", state="disabled", wrap="word")
        self._bind_text_wheel(self.log_txt)
        self.log_txt.pack(fill="both", expand=True, pady=(2, 0))

        self._refresh_integrity()
        self._refresh_roll()
        # 后台自愈线程
        threading.Thread(target=self._auto_guard, daemon=True).start()
        self.log("自防护中心就绪：防篡改每 60 秒校验，异常自动从快照恢复。")

    # ---- helpers ----
    def _section(self, parent, title):
        tk.Label(parent, text=title, bg=BG, fg=ACCENT,
                 font=FONT_T).pack(anchor="w", pady=(8, 0))

    def log(self, msg):
        try:
            self.log_txt.configure(state="normal")
            self.log_txt.insert("end", "[" + time.strftime("%H:%M:%S") + "] " + msg + "\n")
            self.log_txt.see("end")
            self.log_txt.configure(state="disabled")
        except Exception:
            pass

    def _bind_text_wheel(self, w):
        """让 Text 内容自己滚动，避免鼠标在其上时滚到整个页面"""
        def _tw(e):
            if int(e.delta) > 0:
                w.yview_scroll(-1, "units")
            else:
                w.yview_scroll(1, "units")
            return "break"
        try:
            w.bind("<MouseWheel>", _tw)
        except Exception:
            pass

    def set_text(self, widget, text):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    # ---- 回滚：快照 ----
    def _snap_refresh(self):
        snaps = list_snapshots()
        if snaps:
            lines = ["数据快照 %s 份（最新在前）：" % len(snaps)]
            for n, t, tag in snaps[:8]:
                lines.append("  - %s  [%s]" % (t, tag))
        else:
            lines = ["（还没有数据快照——点「创建数据快照」给配置/数据库/名单留个回滚点）"]
        self.set_text(self.snap_txt, "\n".join(lines))

    def _snap_create(self):
        d, msg = file_snapshot("手动快照")
        self.log("数据快照：" + msg)
        self.set_text(self.snap_txt, msg)
        self._snap_refresh()

    def _snap_restore_latest(self):
        snaps = list_snapshots()
        if not snaps:
            self.set_text(self.snap_txt, "没有快照可恢复——先创建一份")
            return
        name = snaps[0][0]
        msg = restore_snapshot(name)
        self.log("回滚：" + msg)
        self.set_text(self.snap_txt, msg)
        self._refresh_roll()

    # ---- 系统回滚 ----
    def _sr_refresh(self):
        pts = sys_restore_points()
        if pts:
            lines = ["共 %s 个还原点：" % len(pts)]
            for t, d in pts[:12]:
                lines.append("  - %s  %s" % (t, d))
        else:
            lines = ["（未查询到还原点）"]
        lines.append("提示：本机检测到系统还原组件缺失（srservice 服务不存在，商家魔改系统常见），"
                     "Windows 标准还原点不可用；DG 已用「数据快照」提供可用的回滚通道。")
        self.set_text(self.sr_txt, "\n".join(lines))
        self.sr_status.config(text=sys_restore_status_text())

    def _sr_create(self):
        self.log("正在创建系统还原点（约需 10-60 秒）…")
        self.root.update_idletasks()
        r = sys_create_restore_point()
        self.log(r)
        self.set_text(self.sr_txt, r)
        self._sr_refresh()

    def _sr_enable(self):
        self.log("正在开启系统保护（C:）…")
        self.root.update_idletasks()
        r = sys_enable_protection()
        self.log(r)
        self.set_text(self.sr_txt, r)
        self._sr_refresh()

    def _sr_wizard(self):
        r = sys_open_rstrui()
        self.log(r)

    # ---- 防篡改 ----
    def _refresh_integrity(self):
        issues = check_integrity()
        if not issues:
            self.set_text(self.int_txt, "✅ 核心文件完整性正常（%s 个模块 + 配置 + 数据库）\n清单版本：%s" % (
                len(CORE_PY), APP_VERSION))
            self._auto_label.config(text="后台自愈：开启（每 60 秒校验一次）", fg=OK)
        else:
            lines = ["⚠ 发现 %s 个异常：" % len(issues)]
            for it in issues:
                lines.append("  - %s：%s" % (it["name"], it["issue"]))
            self.set_text(self.int_txt, "\n".join(lines))
            self._auto_label.config(text="后台自愈：异常中，等待自动修复或手动修复", fg=DANGER)

    def _check_now(self):
        self._refresh_integrity()
        self.log("完整性校验完成")

    def _repair_now(self):
        issues = check_integrity()
        if not issues:
            self.set_text(self.int_txt, "核心文件全部正常，无需修复")
            return
        fixed = auto_repair(issues)
        self.set_text(self.int_txt, "\n".join("  - " + f for f in fixed))
        self.log("自动修复：%s 项" % len(fixed))
        self._refresh_integrity()

    def _rebuild_now(self):
        save_manifest(build_manifest())
        self.set_text(self.int_txt, "清单已重建（当前文件状态为基准）")
        self.log("清单重建完成")
        self._refresh_integrity()

    def _auto_guard(self):
        """后台自愈线程：每 60 秒校验一次，发现 .py 篡改自动恢复"""
        while True:
            try:
                time.sleep(60)
                issues = check_integrity()
                py_issues = [it for it in issues if it["kind"] == "py"]
                if py_issues:
                    fixed = auto_repair(py_issues)
                    self.log("后台自愈：检测到篡改，已修复 → " + "; ".join(fixed))
                    self._refresh_integrity()
            except Exception:
                pass

    # ---- 回滚 ----
    def _refresh_roll(self):
        lst = read_roll_log()
        lines = ["已记录 %s 条可回滚操作：" % len(lst)]
        for i, e in enumerate(lst):
            t = e.get("time", "--")
            typ = e.get("type", "?")
            detail = e.get("detail", "")
            lines.append("  %d. [%s] %s %s" % (i + 1, t, typ, detail))
        if not lst:
            lines.append("  （暂无操作记录——执行过网络工具箱的加速/TCP 优化后会自动记录）")
        # 备份情况
        try:
            cfgs = os.listdir(CFG_BAK_DIR) if os.path.isdir(CFG_BAK_DIR) else []
            dbs = os.listdir(DB_BAK_DIR) if os.path.isdir(DB_BAK_DIR) else []
            lines.append("配置备份：%s 份 | 数据库备份：%s 份" % (len(cfgs), len(dbs)))
        except Exception:
            pass
        self.set_text(self.roll_txt, "\n".join(lines))

    def _do_backup_cfg(self):
        made = backup_configs()
        self.log("配置备份完成：%s" % ", ".join(made) if made else "无配置可备份")
        self._refresh_roll()

    def _do_backup_db(self):
        dst = backup_db()
        if dst:
            self.log("数据库已备份 → " + os.path.basename(dst))
        else:
            self.log("数据库备份失败")
        self._refresh_roll()

    def _rollback_all(self):
        lst = read_roll_log()
        if not lst:
            self.set_text(self.roll_txt, "当前没有可回滚的操作记录")
            return
        outs = []
        # 从后往前回滚（后发生的先回滚）
        for e in reversed(lst):
            outs.append("  - " + rollback_entry(e))
        # 回滚后清空记录
        try:
            os.makedirs(ROLL_DIR, exist_ok=True)
            with open(ROLL_LOG, "w", encoding="utf-8") as f:
                json.dump([], f)
        except Exception:
            pass
        self.set_text(self.roll_txt, "回滚完成：\n" + "\n".join(outs))
        self.log("已回滚全部 %s 条操作记录" % len(lst))
        self._refresh_roll()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    SelfDefenseApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
