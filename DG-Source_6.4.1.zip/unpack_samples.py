# -*- coding: utf-8 -*-
"""unpack_samples.py — theZoo 样本 zip 解压（密码 infected，只静态提取不执行）"""
import os, zipfile, io

ZOO = r"F:\桌面保护\ml_training\zips"
OUT = r"F:\桌面保护\ml_training\malicious"
MAX_BYTES = 60 * 1024 * 1024  # 单文件上限 60MB
PASSWORD = b"infected"

os.makedirs(OUT, exist_ok=True)
count = 0
fail = 0

for dp, dn, fn in os.walk(ZOO):
    for name in fn:
        if not name.lower().endswith(".zip"):
            continue
        zp = os.path.join(dp, name)
        try:
            with zipfile.ZipFile(zp) as zf:
                for info in zf.infolist():
                    if info.file_size > MAX_BYTES or info.is_dir():
                        continue
                    try:
                        data = zf.read(info.filename, pwd=PASSWORD)
                    except Exception:
                        try:
                            data = zf.read(info.filename)  # 无密码试读
                        except Exception:
                            continue
                    if len(data) > MAX_BYTES:
                        continue
                    # 只保留可执行类
                    low = info.filename.lower()
                    if not (low.endswith((".exe", ".dll", ".scr", ".ocx", ".cpl"))):
                        continue
                    safe = os.path.join(OUT, os.path.basename(zp)[:-4] + "__" +
                                        os.path.basename(info.filename))
                    if os.path.exists(safe):
                        continue
                    with open(safe, "wb") as f:
                        f.write(data)
                    count += 1
                    if count % 20 == 0:
                        print("已解压", count, "个样本...")
        except Exception:
            fail += 1

print("[完成] 解压样本:", count, "| 跳过zip:", fail)
