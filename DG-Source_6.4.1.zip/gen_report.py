# -*- coding: utf-8 -*-
"""生成 DG 全版本整理报告（HTML）"""

import os, html

versions_info = [
    # (版本, 行数, 文件数, 阶段, 主要特点, 评价/备注)
    ("1.0.0", 482, 1, "雏形", "首个版本：三模式扫描（快速/高级/深度）、风险标记、一键删除", "认不出的文件直接标高危/远控后门，误报严重"),
    ("1.1.0", 482, 1, "雏形", "增加 AppData 防流氓软件扫描", "误报问题延续：认不出就标远程后门"),
    ("1.1.1", 482, 1, "雏形", "优化 1.1.0 的 TEMP 误报、优化性能", "误报问题延续"),
    ("1.1.2", 482, 1, "雏形", "修复 ncat/concat 正则词边界误报", "误报大幅下降，核心修复"),
    ("1.1.3", 482, 1, "雏形", "修复拖拽扫描不生效、快捷方式目标追踪", "拖拽扫描功能加入"),
    ("1.1.4", 482, 1, "雏形", "修复快捷方式图标等小 bug", "稳定性补丁"),
    ("1.1.5", 482, 1, "雏形", "UPX 加壳误报修复", "误报抑制"),
    ("1.2.0", 530, 1, "功能期", "UI 大改版，新版界面", "界面焕新"),
    ("1.2.1", 530, 1, "功能期", "界面微调、修复小 bug", "过渡版本"),
    ("1.2.2", 530, 1, "功能期", "历史版本切换功能加入", "版本体系建立"),
    ("1.2.3", 623, 1, "功能期", "拖拽扫描功能增强、版本切换修复", "AI 智能检查实验性埋入（用户强调 1.2.7 特殊地位）"),
    ("1.2.4", 623, 1, "功能期", "设置窗口扩充", "过渡版本"),
    ("1.2.5", 1446, 1, "功能期", "全新 UI、历史版本可视化", "大版本重写，性价比高的一代"),
    ("1.2.6", 1471, 1, "功能期", "风险显示置顶排序修复", "用户评价 1.2.x 性价比高"),
    ("1.2.7", 1492, 1, "功能期", "设置按钮全可用修复；唯一拥有 AI 智能检查实验性的版本", "★ 用户多次强调的特殊版本"),
    ("1.3.7", 585, 1, "功能期", "高威胁拦截弹窗（遇高威胁问是否删除）", "⚠ 快照异常：目录内实为 1.1.1 代码，真实 1.3.7 未保存"),
    ("1.4.0", 1581, 2, "功能期", "真正的算法优化（预编译正则+4线程），不卡了；AI 接口预埋", "性能里程碑，用户确认不卡"),
    ("1.5.0", 1740, 3, "功能期", "隔离区（XOR编码防误运行）、病毒库哈希导入", "数据库模块化开始"),
    ("1.6.0", 1971, 4, "增强期", "第一优先级升级：扩展名伪装检测、结果解释化、规则分级降权、文件指纹缓存、日志系统、扫描报告导出", "ChatGPT 建议落地"),
    ("1.6.1", 1989, 4, "增强期", "修复停止扫描无效 bug（三模式全修）", "稳定性补丁"),
    ("1.6.5", 2160, 4, "增强期", "半个 1.7.0：Office 宏检测、压缩包扫描、启动项管理", "新功能半版"),
    ("1.7.0", 2433, 4, "增强期", "计划任务检测、系统安全体检（UAC/Defender/RDP/hosts/代理/SMBv1）", "体检功能上线"),
    ("1.7.1", 2444, 4, "增强期", "算法优化（还是卡的问题）", "过渡版本"),
    ("1.7.2", 2499, 4, "增强期", "真正的算法优化：预编译正则+4线程并行扫描", "性能里程碑，用户确认确实不卡了"),
    ("1.8.0", 3319, 4, "处置期", "启动项禁用/恢复/删除、计划任务禁用/启用、安全体检8项+逐项修复、病毒库管理、隔离区增强", "处置能力完整版，但设置窗口有按钮bug"),
    ("1.9.0", 3345, 4, "处置期", "修复 1.8.0 设置按钮 bug", "★ 用户亲测：1.9.0 最好（无新功能只修bug）"),
    ("1.9.1", 3441, 4, "处置期", "修复剩余按钮 bug、版本切换按钮", "稳定性补丁"),
    ("2.0.0", 3455, 4, "重构期", "安全体检完全重写（后台线程+Queue，不卡窗口）", "架构升级"),
    ("2.0.1", 3789, 4, "重构期", "名单管理三标签页（病毒库/白名单/黑名单）", "完整功能基座"),
    ("2.1.0", 3790, 4, "AI期", "AI 智能检查功能完整埋入（高危文件自动AI二次判断，只传特征不上传文件）", "AI 接口正式落地"),
    ("2.1.0-beta", 3790, 4, "AI期", "内测版流程建立", "beta 概念引入"),
    ("2.2.0", 4004, 4, "AI期", "AI 助手聊天功能（最曲折阶段）", "用户反复反馈不回复"),
    ("2.2.1~2.2.6", 4000-4066, 4, "AI期", "多轮修复 AI 不回复（调试信息/取消按钮/SSL/超时）", "均未解决根本问题"),
    ("2.2.7", 4085, 4, "AI期", "★ 找到根本原因：后台线程直接操作tkinter控件→改用queue通信修复", "AI 助手终于能回复"),
    ("2.2.8", 4087, 4, "AI期", "更新不关窗口修复", "体验优化"),
    ("2.2.9", 4156, 4, "AI期", "chat_history 作用域 bug 修复", "稳定性"),
    ("2.3.0~2.3.2", 4178-4181, 4, "AI期", "AI 聊天完全稳定（20条上下文、模型切换、取消按钮）", "AI 功能成熟"),
    ("2.4.0", 4367, 5, "防护期", "轻量实时防护（进程扫描+高危弹窗）", "防护模块独立"),
    ("2.4.1", 4368, 5, "防护期", "修复 cmd 窗口闪烁（CREATE_NO_WINDOW）", "体验修复"),
    ("2.4.2", 4393, 5, "防护期", "方案B：版本切换自动注入AI代码", "版本管理智能化"),
    ("2.5.0", 4444, 5, "性能期", "扫描性能全面优化（动态线程/大文件限制/AI实时辅助）", "⚠ 但丢失大量功能（安全体检/启动项/计划任务/病毒库/隔离区/名单管理）"),
    ("2.6.0", 4439, 5, "重建期", "基于 2.0.1 完整功能重建 + 合并 2.5.0 新功能 + 轻量目录监控", "修复功能丢失；用户反馈扫描异常"),
    ("2.6.1", 4452, 5, "重建期", "性能优化（实时防护延迟初始化等）", "⚠ 2.6.1 初版打不开（rtp None bug），已修复"),
    ("2.7.0", 4460, 9, "混合引擎", "★ Python+C++混合引擎：C++扫描核心（8线程遍历+BCrypt哈希）+ 扫描结果自动刷新", "当前最新正式版，深度扫描55万文件6.5分钟完成不卡GUI"),
]

# 生成 HTML
rows_html = ""
for ver, lines, files, stage, feat, note in versions_info:
    note_color = "#C0392B" if "⚠" in note or "丢失" in note else ("#2E86C1" if "★" in note else "#666")
    rows_html += f"""<tr>
    <td class="ver">{html.escape(ver)}</td>
    <td>{lines}</td>
    <td>{files}</td>
    <td><span class="stage">{html.escape(stage)}</span></td>
    <td class="feat">{html.escape(feat)}</td>
    <td style="color:{note_color}">{html.escape(note)}</td>
</tr>\n"""

# 统计
counts = {}
for v, l, f, s, ft, n in versions_info:
    counts[s] = counts.get(s, 0) + 1

stage_summary = "".join(f"<span class='chip'>{k}: {v}个版本</span>" for k, v in counts.items())

html_doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>DG DesktopGuard 全版本报告</title>
<style>
body {{ font-family: "Microsoft YaHei UI", sans-serif; background: #f5f6fa; margin: 0; padding: 30px; }}
.container {{ max-width: 1200px; margin: 0 auto; }}
h1 {{ color: #1a5276; border-bottom: 3px solid #1a5276; padding-bottom: 10px; }}
h2 {{ color: #1a5276; margin-top: 30px; }}
.sub {{ color: #666; margin-bottom: 20px; }}
.chip {{ display: inline-block; background: #eaf2f8; color: #1a5276; padding: 4px 12px; border-radius: 15px; margin: 3px; font-size: 13px; }}
table {{ width: 100%; border-collapse: collapse; background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
th {{ background: #1a5276; color: white; padding: 10px 8px; text-align: left; font-size: 13px; }}
td {{ padding: 8px; border-bottom: 1px solid #eee; font-size: 12.5px; vertical-align: top; }}
tr:hover {{ background: #f0f8ff; }}
.ver {{ font-weight: bold; color: #1a5276; }}
.stage {{ background: #e8f8f5; color: #148f77; padding: 2px 8px; border-radius: 8px; font-size: 11px; }}
.feat {{ color: #333; }}
.best {{ background: #fef9e7; }}
.warn {{ background: #fdedec; }}
.box {{ background: white; border-radius: 8px; padding: 20px; margin: 20px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
.box h3 {{ margin-top: 0; color: #1a5276; }}
li {{ margin: 6px 0; }}
</style>
</head>
<body>
<div class="container">
<h1>🛡 DG DesktopGuard 全版本整理报告</h1>
<div class="sub">生成时间：2026-09-08 | 版本快照：50 个目录（合并展示 {len(versions_info)} 行） | 当前最新：2.7.0（Python+C++混合引擎）</div>
<div>{stage_summary}</div>

<div class="box">
<h3>📌 核心结论</h3>
<ul>
<li><b>最好用的版本：1.9.0</b>（用户亲测：无新功能、只修 1.8.0 bug，最稳定）</li>
<li><b>性价比最高的系列：1.2.x</b>（用户评价：功能与体验平衡好）</li>
<li><b>特殊版本：1.2.7</b>（唯一拥有 AI 智能检查实验性功能）</li>
<li><b>当前最强：2.7.0</b>（C++ 加速核心，55万文件深度扫描 6.5 分钟完成且不卡 GUI）</li>
<li><b>⚠ 数据问题：1.3.7 快照错误</b>（目录内容实为 1.1.1 代码，真实 1.3.7 未保存）</li>
<li><b>⚠ 功能丢失事故：2.5.0</b>（丢失安全体检/启动项/计划任务/病毒库/隔离区/名单管理，2.6.0 已基于 2.0.1 重建恢复）</li>
</ul>
</div>

<div class="box">
<h3>🔧 最近版本修复（本次完成）</h3>
<ul>
<li><b>扫描结果自动刷新</b>：扫描中每 120ms 自动刷新列表，不再需要手动点「显示全部文件」；增量刷新改为游标优化，扫描越快越流畅</li>
<li><b>2.6.1 打不开 bug</b>（rtp None）：已修复并验证</li>
<li><b>2.6.0/2.6.1 扫描异常</b>：源于 2.5.0 功能丢失事故，2.7.0 已基于 2.0.1 重建彻底解决</li>
</ul>
</div>

<div class="box">
<h3>📋 全部版本明细</h3>
<table>
<tr><th>版本</th><th>行数</th><th>文件</th><th>阶段</th><th>主要特点</th><th>评价/备注</th></tr>
{rows_html}
</table>
</div>

<div class="box">
<h3>📈 版本演进时间线</h3>
<ul>
<li><b>雏形期（1.0.0~1.1.5）</b>：扫描+标记+删除，误报严重→逐步修复</li>
<li><b>功能期（1.2.0~1.3.7）</b>：UI改版、拖拽、历史版本、AI实验性</li>
<li><b>增强期（1.4.0~1.7.2）</b>：算法优化、宏检测、启动项、计划任务、安全体检</li>
<li><b>处置期（1.8.0~1.9.1）</b>：禁用/恢复/删除闭环，稳定成熟</li>
<li><b>重构期（2.0.0~2.1.0）</b>：安全体检重写、名单管理、AI埋入</li>
<li><b>AI期（2.2.0~2.3.2）</b>：AI助手聊天（最曲折，最终修复）</li>
<li><b>防护期（2.4.0~2.4.2）</b>：实时防护、cmd隐藏</li>
<li><b>性能期（2.5.0）</b>：扫描优化但功能丢失</li>
<li><b>重建期（2.6.0~2.6.1）</b>：基于2.0.1重建恢复功能</li>
<li><b>混合引擎（2.7.0）</b>：★ Python+C++ 双引擎，性能飞跃</li>
</ul>
</div>

</div>
</body>
</html>
"""

out = r'F:\桌面保护\desktopguard\版本报告.html'
with open(out, 'w', encoding='utf-8') as f:
    f.write(html_doc)
print(f'报告已生成: {out}')
print(f'大小: {os.path.getsize(out)} 字节')
