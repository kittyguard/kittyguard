// ============================================================
// DG ScanCore - C++ 扫描加速核心
// 版本: 1.0 (配合 DG 2.7.0)
// 功能:
//   1. 快速目录遍历（多线程）
//   2. SHA256 哈希计算（Windows CNG API，超快）
//   3. 文件元数据收集（路径/大小/扩展名/mtime）
//   4. 输出 JSON 格式结果，供 Python 主程序消费
// 编译: g++ -O2 -std=c++17 -o scan_core.exe scan_core.cpp -lcrypt32 -lbcrypt
// 用法: scan_core.exe <mode> <path1> [path2...]
//       mode: quick=快速(只枚举+大小/扩展名), advanced=高级(+mtime), deep=深度(+sha256)
// ============================================================

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <queue>
#include <thread>
#include <atomic>
#include <mutex>
#include <chrono>
#include <filesystem>
#include <algorithm>
#include <condition_variable>
#include <functional>
#include <sstream>

namespace fs = std::filesystem;

// ===== 配置 =====
static const int WORKER_THREADS = 4;           // 工作线程数
static const size_t MAX_HASH_SIZE = 50ULL * 1024 * 1024;  // 哈希上限50MB（与Python对齐）
static const char* OUTPUT_BUF_FILE = "scan_core_output.tmp"; // 输出缓冲文件

// ===== 与 Python engine.enum_files 保持一致的过滤规则 =====
static bool is_always_skip_dir(const std::wstring& name_lower) {
    static const wchar_t* dirs[] = {
        L"$recycle.bin", L"system volume information", L"$windows.~bt",
        L"$windows.~ws", L"recovery", L"boot", L"efi", L"system.sav"
    };
    for (auto* d : dirs) {
        if (name_lower == d) return true;
    }
    return false;
}

static bool is_sys_file(const std::wstring& name_lower) {
    static const wchar_t* files[] = {
        L"pagefile.sys", L"hiberfil.sys", L"swapfile.sys", L"dumpstack.log.tmp"
    };
    for (auto* f : files) {
        if (name_lower == f) return true;
    }
    return false;
}

static std::wstring to_lower_w(const std::wstring& s) {
    std::wstring out = s;
    for (auto& c : out) c = towlower(c);
    return out;
}

// ===== 全局状态 =====
static std::atomic<long long> g_files_total{0};   // 找到的文件总数
static std::atomic<long long> g_files_done{0};    // 已完成处理数
static std::atomic<long long> g_bytes_total{0};   // 总字节数
static std::atomic<bool> g_cancel{false};
static std::mutex g_out_mutex;
static FILE* g_out = nullptr;
static bool g_do_hash = false;
static bool g_do_mtime = false;

// ===== 小工具函数 =====
static void json_escape(std::string& out, const std::string& s) {
    out.push_back('"');
    for (char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                    out += buf;
                } else {
                    out.push_back(c);
                }
        }
    }
    out.push_back('"');
}

static std::string get_extension(const std::string& path) {
    size_t pos = path.find_last_of('.');
    size_t slash = path.find_last_of("/\\");
    if (pos != std::string::npos && (slash == std::string::npos || pos > slash)) {
        std::string ext = path.substr(pos);
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        return ext;
    }
    return "";
}

// ===== SHA256 哈希（BCrypt API，超快） =====
static bool sha256_file(const wchar_t* path, char* out_hex) {
    HANDLE hFile = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                               nullptr, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, nullptr);
    if (hFile == INVALID_HANDLE_VALUE) return false;

    LARGE_INTEGER fsize;
    if (!GetFileSizeEx(hFile, &fsize)) { CloseHandle(hFile); return false; }
    // 超过上限直接返回空哈希（与Python行为一致）
    if (fsize.QuadPart > (LONGLONG)MAX_HASH_SIZE) {
        out_hex[0] = '\0';
        CloseHandle(hFile);
        return true;
    }

    BCRYPT_ALG_HANDLE hAlg = nullptr;
    if (BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) != 0) {
        CloseHandle(hFile);
        return false;
    }
    BCRYPT_HASH_HANDLE hHash = nullptr;
    if (BCryptCreateHash(hAlg, &hHash, nullptr, 0, nullptr, 0, 0) != 0) {
        BCryptCloseAlgorithmProvider(hAlg, 0);
        CloseHandle(hFile);
        return false;
    }

    const size_t BUF_SIZE = 1024 * 1024; // 1MB 读缓冲
    std::vector<unsigned char> buf(BUF_SIZE);
    DWORD bytesRead = 0;
    while (ReadFile(hFile, buf.data(), (DWORD)BUF_SIZE, &bytesRead, nullptr) && bytesRead > 0) {
        BCryptHashData(hHash, buf.data(), (ULONG)bytesRead, 0);
    }

    unsigned char hash[32];
    if (BCryptFinishHash(hHash, hash, 32, 0) != 0) {
        out_hex[0] = '\0';
    } else {
        static const char* hexdig = "0123456789abcdef";
        for (int i = 0; i < 32; i++) {
            out_hex[i * 2] = hexdig[hash[i] >> 4];
            out_hex[i * 2 + 1] = hexdig[hash[i] & 0xF];
        }
        out_hex[64] = '\0';
    }
    BCryptDestroyHash(hHash);
    BCryptCloseAlgorithmProvider(hAlg, 0);
    CloseHandle(hFile);
    return true;
}

// ===== 输出一行结果 =====
static void output_file(const fs::path& path, uintmax_t size, bool has_mtime,
                        const std::string& sha256_hex) {
    std::string path_u8 = path.u8string();  // UTF-8 编码，避免 GBK 乱码
    std::string ext_u8 = get_extension(path_u8);
    std::string line;
    line.reserve(512);
    line += "{\"p\":";
    json_escape(line, path_u8);
    line += ",\"s\":";
    line += std::to_string(size);
    line += ",\"e\":";
    json_escape(line, ext_u8);
    if (has_mtime) {
        line += ",\"m\":";
        try {
            auto ftime = fs::last_write_time(path);
            auto stime = std::chrono::time_point_cast<std::chrono::system_clock::duration>(
                ftime - fs::file_time_type::clock::now() + std::chrono::system_clock::now());
            line += std::to_string(std::chrono::system_clock::to_time_t(stime));
        } catch (...) {
            line += "0";
        }
    }
    if (g_do_hash) {
        line += ",\"h\":";
        if (sha256_hex.empty()) {
            line += "null";
        } else {
            json_escape(line, sha256_hex);
        }
    }
    line += "}\n";
    {
        std::lock_guard<std::mutex> lock(g_out_mutex);
        fputs(line.c_str(), g_out);
    }
    g_files_done.fetch_add(1);
    g_bytes_total.fetch_add((long long)size);
}

// ===== 目录遍历（显式栈，可跳过保留目录；过滤规则与Python一致） =====
// 4.11.1: 改为流式——发现文件即回调 sink（有界队列），不再全量收集到内存
static void walk_dir(const fs::path& root, const std::function<void(const fs::path&)>& sink) {
    std::vector<fs::path> stack;
    stack.push_back(root);
    while (!stack.empty() && !g_cancel.load()) {
        fs::path dirpath = stack.back();
        stack.pop_back();
        std::error_code ec;
        try {
            for (auto& entry : fs::directory_iterator(dirpath,
                    fs::directory_options::skip_permission_denied, ec)) {
                if (g_cancel.load()) break;
                std::error_code ec2;
                auto name = entry.path().filename().wstring();
                auto low = to_lower_w(name);
                if (entry.is_directory(ec2)) {
                    // 跳过系统保留目录 / 隐藏目录
                    if (is_always_skip_dir(low)) continue;
                    if (!name.empty() && name[0] == L'.') continue;
                    stack.push_back(entry.path());
                } else if (entry.is_regular_file(ec2)) {
                    // 跳过系统保留文件 / 隐藏文件
                    if (is_sys_file(low)) continue;
                    if (!name.empty() && name[0] == L'.') continue;
                    sink(entry.path());
                    g_files_total.fetch_add(1);
                }
            }
        } catch (...) {
            // 目录访问异常：跳过
        }
    }
}

// ===== 工作线程：处理文件（全程异常保护，防止特殊文件导致线程崩溃） =====
static void worker_thread(std::queue<fs::path>& task_q, std::mutex& q_mutex,
                          std::condition_variable& q_cv, bool& done) {
    try {
        while (true) {
            fs::path path;
            {
                std::unique_lock<std::mutex> lock(q_mutex);
                q_cv.wait(lock, [&] { return !task_q.empty() || done || g_cancel.load(); });
                if (task_q.empty()) {
                    if (done) return;
                    continue;
                }
                if (g_cancel.load()) return;
                path = task_q.front();
                task_q.pop();
            }

            std::error_code ec;
            uintmax_t size = 0;
            try { size = fs::file_size(path, ec); } catch (...) { size = 0; }
            if (ec) size = 0;
            std::string hash_hex;
            if (g_do_hash) {
                char hash_buf[65];
                try {
                    std::wstring wpath = path.wstring();
                    if (sha256_file(wpath.c_str(), hash_buf)) {
                        hash_hex = hash_buf;
                    } else {
                        hash_hex = "";
                    }
                } catch (...) {
                    hash_hex = "";
                }
            }
            try {
                output_file(path, size, g_do_mtime, hash_hex);
            } catch (...) {
                // 单个文件输出失败不影响整体
            }
        }
    } catch (...) {
        // 线程内未捕获异常：静默退出
    }
}

// ===== 只遍历一层（盘根顶层文件） =====
static void walk_top(const fs::path& root, const std::function<void(const fs::path&)>& sink) {
    std::error_code ec;
    for (auto& entry : fs::directory_iterator(root,
            fs::directory_options::skip_permission_denied, ec)) {
        if (g_cancel.load()) break;
        std::error_code ec2;
        auto name = entry.path().filename().wstring();
        auto low = to_lower_w(name);
        if (entry.is_regular_file(ec2)) {
            if (is_sys_file(low)) continue;
            if (!name.empty() && name[0] == L'.') continue;
            sink(entry.path());
            g_files_total.fetch_add(1);
        }
    }
}

// ===== 主函数 =====
int wmain(int argc, wchar_t* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "usage: scan_core.exe <quick|advanced|deep> <path1> [path2...]\n");
        return 1;
    }

    std::wstring mode = argv[1];
    std::vector<fs::path> roots;
    for (int i = 2; i < argc; i++) {
        roots.push_back(fs::path(argv[i]));
    }

    if (mode == L"deep") {
        g_do_hash = true;
        g_do_mtime = true;
    } else if (mode == L"advanced") {
        g_do_hash = false;
        g_do_mtime = true;
    } else {
        g_do_hash = false;
        g_do_mtime = false;
    }

    // 打开输出文件（先写临时文件，最后改名避免主程序读到半成品）
    g_out = fopen(OUTPUT_BUF_FILE, "w");
    if (!g_out) {
        fprintf(stderr, "cannot open output buffer\n");
        return 2;
    }
    setvbuf(g_out, nullptr, _IOFBF, 1 << 20); // 1MB缓冲

    auto t_start = std::chrono::steady_clock::now();

// ===== 阶段1+2: 流式——遍历线程直接入有界队列，工作线程边消费边输出 =====
    // 4.11.1 内存修复：有界队列上限 10 万条，遍历线程阻塞等待、不再全量收集，
    // 内存恒定（约 30MB），彻底解决深度扫描扫千万级文件时内存暴涨到 20GB+ 的问题。
    const size_t QUEUE_BOUND = 100000;
    std::queue<fs::path> task_q;
    std::mutex q_mutex;
    std::condition_variable q_cv;
    bool done = false;

    auto push_path = [&](const fs::path& p) {
        std::unique_lock<std::mutex> lock(q_mutex);
        q_cv.wait(lock, [&] { return task_q.size() < QUEUE_BOUND || g_cancel.load(); });
        if (g_cancel.load()) return;
        task_q.push(p);
        q_cv.notify_one();
    };

    std::vector<fs::path> walk_roots;
    std::vector<fs::path> walk_tops;   // 盘根顶层文件任务

    // 如果 root 是盘根，拆分为一级子目录并行
    for (auto& root : roots) {
        std::error_code ec;
        bool is_drive_root = (root.has_root_name() && root == root.root_path());
        if (is_drive_root) {
            for (auto& entry : fs::directory_iterator(root,
                    fs::directory_options::skip_permission_denied, ec)) {
                std::error_code ec2;
                if (entry.is_directory(ec2)) {
                    auto low = to_lower_w(entry.path().filename().wstring());
                    if (is_always_skip_dir(low)) continue;
                    walk_roots.push_back(entry.path());
                }
            }
            // 盘根本身的顶层文件单独一个"仅一层"任务
            walk_tops.push_back(root);
        } else {
            walk_roots.push_back(root);
        }
    }

    // 工作线程先启动（消费队列，避免遍历线程塞满有界队列后死锁）
    std::vector<std::thread> workers;
    int nthreads = g_do_hash ? WORKER_THREADS : 4;
    for (int i = 0; i < nthreads; i++) {
        workers.emplace_back(worker_thread, std::ref(task_q), std::ref(q_mutex),
                             std::ref(q_cv), std::ref(done));
    }

    // 限制并行遍历线程数（最多8个）
    const int MAX_WALKERS = 8;
    std::atomic<int> next_idx{0};
    std::vector<std::thread> walkers;
    auto walker_pool = [&] {
        while (true) {
            int idx = next_idx.fetch_add(1);
            if (idx >= (int)walk_roots.size()) break;
            if (g_cancel.load()) break;
            walk_dir(walk_roots[idx], push_path);
        }
    };
    int n_walkers = std::min((int)walk_roots.size(), MAX_WALKERS);
    for (int i = 0; i < n_walkers; i++) {
        walkers.emplace_back(walker_pool);
    }
    for (auto& t : walkers) t.join();
    // 顶层文件（盘根文件）流式入队
    for (auto& r : walk_tops) {
        walk_top(r, push_path);
    }

    auto t_walk = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lock(q_mutex);
        done = true;
    }
    q_cv.notify_all();
    for (auto& t : workers) t.join();

    fclose(g_out);
    auto t_end = std::chrono::steady_clock::now();

    // 输出统计到stderr（供主程序读取）
    double walk_ms = std::chrono::duration<double, std::milli>(t_walk - t_start).count();
    double total_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    fprintf(stderr, "STAT files=%lld bytes=%lld walk_ms=%.1f total_ms=%.1f threads=%d hash=%d\n",
            g_files_total.load(), g_bytes_total.load(), walk_ms, total_ms,
            nthreads, g_do_hash ? 1 : 0);
    return 0;
}
