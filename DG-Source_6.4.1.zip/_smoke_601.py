# -*- coding: utf-8 -*-
"""6.0.1 发布冒烟验证"""
import io, json, os, re

os.chdir(r"F:\桌面保护\desktopguard")

# 1) 主程序版本
src = io.open("main.py", encoding="utf-8").read()
m = re.search(r'APP_VERSION = "([^"]+)"', src)
print("main.py APP_VERSION =", m.group(1))

# 2) 版本历史第一条
mh = re.search(r"VERSION_HISTORY = \[\('([^']+)', '([^']+)'", src)
print("VERSION_HISTORY 首条:", mh.group(1), "<-", mh.group(2))

# 3) 自检清单（rollback/manifest.json）
import selfdefense as _sd
man = _sd.load_manifest() or {}
print("防篡改清单 version =", man.get("version"), "| py =", len(man.get("py", {})), "| cfg =", len(man.get("cfg", {})))

# 4) 根 version.json
v = json.load(io.open("version.json", encoding="utf-8"))
print("根 version.json:", v.get("latest_version"), "| version =", v.get("version"))

# 5) 官网 version.json 双字段兼容
ov = json.load(io.open("官网/version.json", encoding="utf-8"))
print("官网 version.json:", ov.get("latest_version"), "| version =", ov.get("version"), "| pkg =", ov.get("pkg"))

# 6) 产物
for p in ["dist/DG安全/DG安全.exe", "官网/DG-Security_6.0.1.zip", "versions/6.0.1/manifest.json", "官网/publish/index.html", "官网/publish/version.json"]:
    if os.path.exists(p):
        extra = "%.1fMB" % (os.path.getsize(p) / 1048576) if p.endswith(("zip", "exe")) else ""
        print("OK 存在:", p, extra)
    else:
        print("缺失:", p)

# 7) 新增功能代码存在性（血缘/冻结管理）
for pat in ["_pid_path", "_ransom_frozen_act", "当前被冻结的进程"]:
    print("main.py 含「%s」:" % pat, pat in src)
