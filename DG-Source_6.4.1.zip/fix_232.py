# -*- coding: utf-8 -*-
with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 找到 ai_worker 函数，在开头添加 nonlocal chat_history
old_worker_start = '''                def ai_worker():
                    try:
                        msg_queue.put({"role": "debug", "text": "[调试] 后台线程已启动"})'''

new_worker_start = '''                def ai_worker():
                    nonlocal chat_history
                    try:
                        msg_queue.put({"role": "debug", "text": "[调试] 后台线程已启动"})'''

if old_worker_start in c:
    c = c.replace(old_worker_start, new_worker_start, 1)
    print('ai_worker 添加 nonlocal chat_history 成功')
else:
    print('未找到 ai_worker 匹配字符串，尝试位置插入...')
    idx = c.find('def ai_worker():')
    if idx > 0:
        try_idx = c.find('try:', idx)
        if try_idx > 0:
            c = c[:try_idx] + '                    nonlocal chat_history\n' + c[try_idx:]
            print('通过位置插入成功')

# 同时把 ai_worker 里的 chat_history = chat_history[...] 改成 chat_history[:] = ...
# 避免重新赋值
old_truncate = '''                    chat_history.append({"role": "assistant", "content": ai_reply})
                    if len(chat_history) > MAX_CONTEXT * 2:
                        chat_history = chat_history[-(MAX_CONTEXT * 2):]'''

new_truncate = '''                    chat_history.append({"role": "assistant", "content": ai_reply})
                    if len(chat_history) > MAX_CONTEXT * 2:
                        chat_history[:] = chat_history[-(MAX_CONTEXT * 2):]'''

if old_truncate in c:
    c = c.replace(old_truncate, new_truncate, 1)
    print('chat_history 截断改用切片赋值成功')
else:
    print('未找到截断匹配字符串')

# 同样修复 on_send 里的 chat_history 截断
old_send_truncate = '''                chat_history.append({"role": "user", "content": msg})
                if len(chat_history) > MAX_CONTEXT * 2:
                    chat_history = chat_history[-(MAX_CONTEXT * 2):]'''

new_send_truncate = '''                chat_history.append({"role": "user", "content": msg})
                if len(chat_history) > MAX_CONTEXT * 2:
                    chat_history[:] = chat_history[-(MAX_CONTEXT * 2):]'''

if old_send_truncate in c:
    c = c.replace(old_send_truncate, new_send_truncate, 1)
    print('on_send 里的 chat_history 截断改用切片赋值成功')
else:
    print('未找到 on_send 截断匹配字符串')

# 升级版本号到 2.3.2
c = c.replace('APP_VERSION = "2.3.1"', 'APP_VERSION = "2.3.2"', 1)
c = c.replace(
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1"]',
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2"]'
)

old_history = '''VERSION_HISTORY = [
    ("2.3.1"'''
new_history = '''VERSION_HISTORY = [
    ("2.3.2", "补丁：修复ai_worker函数里的chat_history作用域bug。根本原因：ai_worker里有chat_history = chat_history[...]重新赋值，导致Python认为是局部变量，访问时报UnboundLocalError。修复：1.ai_worker开头添加nonlocal chat_history；2.所有chat_history截断改用切片赋值chat_history[:] = ...，避免重新赋值"),
    ("2.3.1"'''
c = c.replace(old_history, new_history, 1)

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

# 创建快照
import shutil, os, json
os.makedirs('versions/2.3.2', exist_ok=True)
shutil.copy2('main.py', 'versions/2.3.2/main.py')
shutil.copy2('engine.py', 'versions/2.3.2/engine.py')
shutil.copy2('database.py', 'versions/2.3.2/database.py')
shutil.copy2('logger.py', 'versions/2.3.2/logger.py')

with open('version.json', 'r', encoding='utf-8') as f:
    vj = json.load(f)
vj['latest_version'] = '2.3.2'
with open('version.json', 'w', encoding='utf-8') as f:
    json.dump(vj, f, ensure_ascii=False, indent=2)

print('DG 2.3.2 已发布！')
print('ai_worker 作用域 bug 已修复')
