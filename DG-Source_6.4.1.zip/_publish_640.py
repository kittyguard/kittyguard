# -*- coding: utf-8 -*-
"""发布 6.4.0：快照 + 重建防篡改清单 + version.json（自启动监控增强 + IO 节流补齐 + ClamAV 双库龄）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.4.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx", "sandbox_runner.exe",
           "dg_warden.exe", "dg_watcher_tpl.exe"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.4.0 内容更新：自启动监控增强 + 扫描 IO 节流补齐 + ClamAV 双库龄。",
    "features": [
        "自启动监控增强：新增自启动项告警弹窗升级为三动作按钮——「立即禁用」一键把注册表值名/启动文件夹文件名加 DG_OFF_ 前缀（保留原值完全可逆，收集逻辑自动跳过，可在启动项管理恢复）；「加入忽略」把该启动项写入忽略列表（config.startup_monitor_ignored 持久化），此后新增不再提示，适合确认为可信的常驻项；「稍后处理」本次不处置下次再提醒",
        "扫描 IO 节流补齐：IO 优先级 VERY_LOW 从主扫描线程扩展到生产者/消费者/应用巡检全部扫描线程（6.3.0 只覆盖主 worker）——全盘/深度扫描时所有 DG 磁盘读写统一让路，鼠标/系统/游戏彻底不再被扫描 IO 拖卡",
        "ClamAV 双库龄显示：规则中心病毒库状态改为 main 与 daily 双库龄分开显示——daily（每日更新库）超 7 天标「偏旧」，main（低频基线库）单独显示天数不再混淆",
        "更新后自动刷新：一键更新病毒库启动后台监视，检测到 daily 库更新完成后自动刷新规则中心统计并写日志，不用再手动点「刷新统计」",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
