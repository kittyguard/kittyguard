# -*- coding: utf-8 -*-
"""2.7.1 发布：同步内测版 + 版本号 + 快照"""
import os, shutil, json

src = r'F:\桌面保护\desktopguard'
beta = r'F:\桌面保护\desktopguard-beta'

# 1. 同步到内测版（内测版保持 beta 标题）
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp']:
    s = os.path.join(src, fname)
    d = os.path.join(beta, fname)
    if os.path.exists(s):
        shutil.copy2(s, d)
print("已同步到内测版")

# 2. 正式版版本号 -> 2.7.1
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py', 'scan_core_bridge.py']:
    p = os.path.join(src, fname)
    with open(p, 'r', encoding='utf-8') as f:
        c = f.read()
    c = c.replace('APP_VERSION = "2.7.0"', 'APP_VERSION = "2.7.1"')
    c = c.replace('"2.7.0"', '"2.7.1"')
    with open(p, 'w', encoding='utf-8') as f:
        f.write(c)
print("版本号 -> 2.7.1")

# 3. 更新 version.json
version_data = {
    "latest_version": "2.7.1",
    "release_date": "2026-09-08",
    "release_notes": "2.7.1 补丁：1.修复15处tk.Frame pady元组bug（安全体检/启动项/病毒库/名单/隔离区窗口打不开的根因）；2.修复计划任务CSV 3列解析（之前所有任务被跳过）；3.修复run_checkup延迟引用；4.APP_NAME去掉beta残留改DG；5.窗口加宽1280防止底部按钮截断",
    "features": [
        "安全体检全面修复：窗口能正常打开并显示10项检查结果",
        "计划任务检查修复：能正确解析schtasks 3列输出",
        "窗口标题改为 DG 桌面安全卫士",
        "窗口加宽到1280，底部按钮不再截断"
    ]
}
with open(os.path.join(src, 'version.json'), 'w', encoding='utf-8') as f:
    json.dump(version_data, f, ensure_ascii=False, indent=2)
print("version.json 已更新")

# 4. 创建 2.7.1 快照
snap = os.path.join(src, 'versions', '2.7.1')
os.makedirs(snap, exist_ok=True)
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp']:
    s = os.path.join(src, fname)
    if os.path.exists(s):
        shutil.copy2(s, os.path.join(snap, fname))
print("快照 versions/2.7.1 已创建")

print("\n2.7.1 发布完成！")
