# -*- coding: utf-8 -*-
import subprocess
r = subprocess.run(["tasklist", "/fo", "csv", "/nh"], capture_output=True, text=True, encoding="gbk", errors="ignore")
targets = ("python", "iscc", "git", "pyinstaller", "clamd", "freshclam", "scan_core",
           "dg_", "DG", "kittyguard", "msiexec", "powershell", "wmic", "svchost", "explorer", "dwm")
seen = {}
for line in r.stdout.splitlines():
    parts = line.split('","')
    if len(parts) >= 2:
        name = parts[0].strip('"').lower()
        for t in targets:
            if name.startswith(t.lower()):
                seen.setdefault(name, 0)
                seen[name] += 1
                break
print("=== suspect processes ===")
for k, v in sorted(seen.items()):
    print("%-30s x%d" % (k, v))
