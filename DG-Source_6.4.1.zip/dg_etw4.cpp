// dg_etw4.cpp — 二分：只保留 ETW 核心 + OnEvent 写固定路径文件
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "tdh.lib")

static const GUID KERNEL_PROCESS_PROVIDER = { 0x22FB2CD6, 0x0E7B, 0x422B, { 0xA0, 0xC7, 0x2F, 0xAD, 0x1F, 0xD0, 0xE7, 0x16 } };
static const wchar_t* SESSION_NAME = L"DG-ETW-DIAG";
static volatile bool g_done = false;
static HANDLE g_hOut = INVALID_HANDLE_VALUE;

static void WriteOut(const char* s) {
    if (g_hOut == INVALID_HANDLE_VALUE) return;
    DWORD w = 0;
    WriteFile(g_hOut, s, (DWORD)strlen(s), &w, NULL);
    WriteFile(g_hOut, "\n", 1, &w, NULL);
    FlushFileBuffers(g_hOut);
}

static void WINAPI OnEvent(EVENT_RECORD* rec) {
    if (!rec) return;
    UCHAR eid = rec->EventHeader.EventDescriptor.Id;
    if (eid != 1 && eid != 2) return;
    char line[128];
    sprintf_s(line, "{\"e\":%u,\"pid\":%u}", eid, rec->EventHeader.ProcessId);
    WriteOut(line);
    g_done = true;
}

static DWORD WINAPI TraceThread(LPVOID p) {
    ProcessTrace((PTRACEHANDLE)p, 1, 0, 0);
    return 0;
}

int wmain() {
    g_hOut = CreateFileW(L"C:\\etwtest\\ev_fixed.jsonl", FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                         NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (g_hOut == INVALID_HANDLE_VALUE) return 3;

    BYTE buf[sizeof(EVENT_TRACE_PROPERTIES) + 64 * sizeof(wchar_t)];
    EVENT_TRACE_PROPERTIES* props = (EVENT_TRACE_PROPERTIES*)buf;
    memset(buf, 0, sizeof(buf));
    props->Wnode.BufferSize = sizeof(buf);
    props->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
    props->Wnode.Guid = { 0x3B2E2C6A, 0x4E1A, 0x8A9F, { 0x6D, 0x5C, 0x4B, 0x3E, 0x2A, 0x10, 0x88, 0x99 } };
    props->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
    wcscpy_s((wchar_t*)(buf + props->LoggerNameOffset), 64, SESSION_NAME);
    props->LogFileMode = EVENT_TRACE_REAL_TIME_MODE;
    props->MinimumBuffers = 2; props->MaximumBuffers = 16; props->FlushTimer = 1;
    TRACEHANDLE sess = 0;
    ULONG r = StartTraceW(&sess, SESSION_NAME, props);
    if (r == ERROR_ALREADY_EXISTS) {
        ControlTraceW(0, SESSION_NAME, props, EVENT_TRACE_CONTROL_STOP);
        r = StartTraceW(&sess, SESSION_NAME, props);
    }
    if (r != ERROR_SUCCESS) { CloseHandle(g_hOut); return 4; }
    r = EnableTraceEx2(sess, &KERNEL_PROCESS_PROVIDER, EVENT_CONTROL_CODE_ENABLE_PROVIDER, 4, 0, 0, 0, NULL);
    if (r != ERROR_SUCCESS) { ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP); CloseHandle(g_hOut); return 5; }
    EVENT_TRACE_LOGFILEW lf; memset(&lf, 0, sizeof(lf));
    lf.LoggerName = (LPWSTR)SESSION_NAME;
    lf.ProcessTraceMode = PROCESS_TRACE_MODE_REAL_TIME | PROCESS_TRACE_MODE_EVENT_RECORD;
    lf.EventRecordCallback = (PEVENT_RECORD_CALLBACK)OnEvent;
    TRACEHANDLE h = OpenTraceW(&lf);
    if (h == (TRACEHANDLE)INVALID_HANDLE_VALUE) { CloseHandle(g_hOut); return 6; }
    HANDLE hThread = CreateThread(NULL, 0, TraceThread, &h, 0, NULL);
    system("start cmd /c ping -n 1 127.0.0.1 >nul & exit");
    for (int i = 0; i < 60 && !g_done; i++) Sleep(100);
    ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP);
    WaitForSingleObject(hThread, 3000);
    CloseHandle(hThread);
    WriteOut("{\"finish\"}");
    if (g_hOut != INVALID_HANDLE_VALUE) CloseHandle(g_hOut);
    return 0;
}
