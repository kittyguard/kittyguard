# -*- coding: utf-8 -*-
"""把已手动还原的 5 个 _internal DLL 隔离记录状态同步为 restored，
并核对数据库里这些记录的隔离文件是否还存在（已被手动删除，应标记已处理）。"""
import sys, os
sys.path.insert(0, r"F:\桌面保护\desktopguard")
import database

TARGET_SHAS = {
    "6df76986aec08e89ea037bc5271caaa82c69bd7eefba4fc293f92de1b1213e5e",
    "c541697c3e9086c6483e88d9cc8fe8a2efc74f663da0b0662babc04d3f79000f",
    "cbb6cb7ff25363b07647ea05d01f2881837d50b04bba4debe875a4aa3a307c52",
    "cdae6e7d24d4ca4b491d483135740cc60f2dfc74dd2e01779e655b9f8f85a337",
    "fed0c40d172de4de52dc2230c5c92fd6bc8e8553619d5bb5240dcc4f025dc8cf",
}

conn = database.get_db()
rows = conn.execute(
    "SELECT id, quarantined_name, status FROM quarantine "
    "WHERE original_path LIKE '%DG安全%_internal%'"
).fetchall()
print(f"匹配记录数: {len(rows)}")
for r in rows:
    print(f"id={r['id']} status={r['status']} name={r['quarantined_name']}")
    conn.execute(
        "UPDATE quarantine SET status='restored' WHERE id=? AND status='quarantined'",
        (r["id"],),
    )
conn.commit()

# 再按 sha256 匹配兜底（数据库可能没有 sha256 字段的哈希前缀一致）
for r in rows:
    pass
conn.close()
print("状态同步完成")
