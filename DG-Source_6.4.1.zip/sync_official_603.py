# -*- coding: utf-8 -*-
"""6.0.3 官网同步：dist\\DG安全 → 官网\\DG-Security_6.0.3.zip + sha256 + version.json + publish 镜像 + 清理旧包"""
import os, io, json, time, zipfile, hashlib, shutil

DG = r"F:\桌面保护\desktopguard"
SRC = os.path.join(DG, "dist", "DG安全")
ZIP = os.path.join(DG, "官网", "DG-Security_6.0.3.zip")
VER = "6.0.3"

def make_zip(src, dst):
    if os.path.exists(dst):
        os.remove(dst)
    n = 0
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for root, dirs, files in os.walk(src):
            for fn in files:
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, src)
                z.write(p, rel)
                n += 1
    return n

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

print("[1] 压缩 dist/DG安全 → zip ...")
n = make_zip(SRC, ZIP)
print("    文件数=%d 大小=%.1fMB" % (n, os.path.getsize(ZIP) / 1024 / 1024))
h = sha256(ZIP)
print("[2] sha256 =", h)

notes = {
    "latest_version": VER,
    "version": VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "pkg": "DG-Security_6.0.3.zip",
    "sha256": h,
    "release_notes": "6.0.3 内容更新：勒索守护完善（监控目录自定义 + 保护区容量自动清理 + 行为链时间过滤）。",
    "features": [
        "监控目录自定义：守护配置新增监控目录区，任意目录纳入勒索守护，一键恢复默认，即时生效",
        "保护区容量自动清理：备份超 2GB 自动按最旧优先清理至 1.5GB，保护区永不撑爆",
        "行为链时间范围过滤：全部/最近1小时/6小时/24小时/3天，默认最近6小时防淹没",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "官网", "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[3] 官网 version.json 已更新为", VER)

# publish 镜像同步（供 GitHub Pages 推送）
pub = os.path.join(DG, "官网", "publish")
os.makedirs(pub, exist_ok=True)
shutil.copy2(os.path.join(DG, "官网", "DG安全官网.html"), os.path.join(pub, "index.html"))
shutil.copy2(ZIP, os.path.join(pub, "DG-Security_6.0.3.zip"))
shutil.copy2(os.path.join(DG, "官网", "version.json"), os.path.join(pub, "version.json"))
for fn in os.listdir(pub):
    if fn.startswith("DG-Security_") and fn != "DG-Security_6.0.3.zip":
        os.remove(os.path.join(pub, fn))
        print("    publish 清理旧包", fn)
print("[4] publish 镜像已同步（index.html + 新zip + version.json）")

old = os.path.join(DG, "官网", "DG-Security_6.0.2.zip")
if os.path.exists(old):
    os.remove(old)
    print("[5] 已删除旧分发包 DG-Security_6.0.2.zip（官网只放最新版）")
print("[OK] 6.0.3 官网同步完成")
