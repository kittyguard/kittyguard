# -*- coding: utf-8 -*-
"""发布 6.0.1：快照 + 重建防篡改清单 + version.json（行为链血缘·勒索守护增强）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.0.1"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.0.1 内容更新：行为链血缘增强（父进程是谁一目了然）+ 勒索守护增强（备份占用统计·被冻结进程事后管理）。",
    "features": [
        "行为链血缘增强：行为链时间线详情显示父进程可执行路径（谁启动了谁一目了然）",
        "勒索备份占用统计：备份恢复窗口标题实时显示保护区当前占用",
        "被冻结进程事后管理：备份恢复窗口可对仍被冻结的进程一键恢复/终止/信任",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
