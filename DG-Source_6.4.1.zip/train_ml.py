# -*- coding: utf-8 -*-
"""
train_ml.py — 本地机器学习模型训练
=================================
输入：恶意样本目录（theZoo 解压后的 PE）+ 正常样本目录（系统/软件 exe）
输出：ml_model.joblib（随机森林）+ 训练指标 + 特征重要性
用法：python train_ml.py <恶意目录> <正常目录>
"""
import os, sys, glob, io, zipfile, random
import joblib
import numpy as np
import ml_features

MAL_DIR = sys.argv[1] if len(sys.argv) > 1 else r"F:\桌面保护\ml_training\malicious"
GOOD_DIRS = (sys.argv[2] if len(sys.argv) > 2 else
             r"C:\Windows\System32;C:\Program Files;C:\Program Files (x86)").split(";")
FP_LOG = r"F:\桌面保护\ml_training\eval_fp_log.txt"   # 上一轮误报修正样本（负样本强化）
MAX_FILES = 4000


def collect_fp_corrections(path):
    """读取 eval_fp_log.txt 的误报文件路径，作为额外负样本加入训练。"""
    files = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if "\t" in line:
                    p = line.split("\t", 1)[1]
                    try:
                        if os.path.exists(p) and os.path.getsize(p) > 0:
                            files.append(p)
                    except Exception:
                        pass
    return files


def collect_pe_files_roots(roots, per_root=900):
    """每个根目录限额收集，保证 System32/Program Files 均衡覆盖 + 随机打散"""
    files = []
    for root in roots:
        batch = []
        for dp, dn, fn in os.walk(root):
            for name in fn:
                if name.lower().endswith((".exe", ".dll", ".scr", ".ocx", ".cpl")):
                    p = os.path.join(dp, name)
                    try:
                        if os.path.getsize(p) > 0:
                            batch.append(p)
                    except Exception:
                        pass
                if len(batch) >= per_root:
                    break
            if len(batch) >= per_root:
                break
        random.shuffle(batch)
        files.extend(batch[:per_root])
    return files


def extract_vec(path):
    try:
        with open(path, "rb") as f:
            head = f.read(65536)
        size = os.path.getsize(path)
        fv, _ = ml_features.extract(path, head, size)
        return fv
    except Exception:
        return None


def main():
    random.seed(42)
    mal_files = collect_pe_files_roots([MAL_DIR])
    good_files = collect_pe_files_roots(GOOD_DIRS)
    # 误报修正：把上一轮误报文件并入负样本（去重）
    fp_corr = collect_fp_corrections(FP_LOG)
    seen = set(good_files)
    for p in fp_corr:
        if p not in seen:
            good_files.append(p)
            seen.add(p)
    print("[样本] 恶意:", len(mal_files), "正常:", len(good_files),
          "(含误报修正 %d)" % len(fp_corr))
    if len(mal_files) < 5 or len(good_files) < 5:
        print("样本不足，中止")
        return

    random.shuffle(mal_files)
    mal_files = mal_files[:MAX_FILES // 2]
    random.shuffle(good_files)
    # 误报修正样本优先保留（负样本强化），再截断
    fp_set = set(fp_corr)
    good_files = fp_corr + [p for p in good_files if p not in fp_set]
    good_files = good_files[:MAX_FILES // 2]

    X, y = [], []
    bad = 0
    for p in mal_files:
        v = extract_vec(p)
        if v:
            X.append(v); y.append(1)
        else:
            bad += 1
    for p in good_files:
        v = extract_vec(p)
        if v:
            X.append(v); y.append(0)
        else:
            bad += 1
    print("[特征] 成功提取:", len(X), "失败:", bad)
    if len(X) < 20:
        print("样本太少")
        return

    X = np.array(X, dtype=np.float64)
    y = np.array(y, dtype=np.int32)
    n_mal = int(y.sum()); n_good = len(y) - n_mal
    print("[标签] 恶意:", n_mal, "正常:", n_good)

    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import cross_val_score, train_test_split
    from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                                 f1_score, confusion_matrix, roc_auc_score)

    clf = RandomForestClassifier(n_estimators=200, max_depth=14,
                                 min_samples_leaf=2, n_jobs=-1, random_state=42,
                                 class_weight="balanced")
    scores = cross_val_score(clf, X, y, cv=5, scoring="f1")
    print("[交叉验证] F1: %.3f ± %.3f" % (scores.mean(), scores.std()))

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=42,
                                          stratify=y)
    clf.fit(Xtr, ytr)
    proba = clf.predict_proba(Xte)[:, 1]
    pred = clf.predict(Xte)

    print("[测试集] 准确率: %.3f" % accuracy_score(yte, pred))
    print("[测试集] 精确率(误报控制): %.3f" % precision_score(yte, pred))
    print("[测试集] 召回率(检出): %.3f" % recall_score(yte, pred))
    print("[测试集] F1: %.3f" % f1_score(yte, pred))
    print("[测试集] AUC: %.3f" % roc_auc_score(yte, proba))
    cm = confusion_matrix(yte, pred)
    print("[混淆矩阵] %s" % cm.tolist())
    fp = cm[0][1] if cm.shape == (2, 2) else -1
    fn = cm[1][0] if cm.shape == (2, 2) else -1
    print("[误报] 正常判恶意: %d / %d" % (fp, int((yte == 0).sum())))
    print("[漏报] 恶意判正常: %d / %d" % (fn, int((yte == 1).sum())))

    imp = sorted(zip(ml_features.FEATURE_NAMES, clf.feature_importances_),
                 key=lambda x: -x[1])[:12]
    print("[特征重要性]")
    for n, v in imp:
        print("   %-18s %.4f" % (n, v))

    # 阈值校准：统计恶意/正常在 proba 上的分布
    mal_proba = proba[yte == 1]
    good_proba = proba[yte == 0]
    if len(mal_proba):
        print("[恶意概率分布] min=%.3f p25=%.3f p50=%.3f" % (
            mal_proba.min(), np.percentile(mal_proba, 25), np.median(mal_proba)))
    if len(good_proba):
        print("[正常概率分布] p50=%.3f p90=%.3f max=%.3f" % (
            np.median(good_proba), np.percentile(good_proba, 90), good_proba.max()))

    out = r"F:\桌面保护\desktopguard\ml_model.joblib"
    joblib.dump({"clf": clf, "feature_names": ml_features.FEATURE_NAMES,
                 "trained_at": __import__("datetime").datetime.now().isoformat(),
                 "n_mal": n_mal, "n_good": n_good}, out)
    print("[模型已保存]", out)

    # ---- ONNX 双格式导出（本地推理引擎，不依赖外部服务）----
    try:
        from skl2onnx import convert_sklearn
        from skl2onnx.common.data_types import FloatTensorType
        n_feat = len(ml_features.FEATURE_NAMES)
        onx = convert_sklearn(clf, "dg_ml", [("input", FloatTensorType([None, n_feat]))],
                              target_opset=13)
        onx_path = r"F:\桌面保护\desktopguard\ml_model.onnx"
        with open(onx_path, "wb") as f:
            f.write(onx.SerializeToString())
        print("[ONNX 已导出]", onx_path, os.path.getsize(onx_path), "bytes")
    except Exception as e:
        print("[ONNX 导出失败]", e)


if __name__ == "__main__":
    main()
