# -*- coding: utf-8 -*-
"""4.15.0 补丁：免打扰模式 + 真进度条/弹性块开关 + 预统计总数 + 停止优化"""
import io

MAIN = r"F:\桌面保护\desktopguard\main.py"
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()
orig = m

def rep(old, new, tag):
    global m
    assert old in m, f"未找到锚点: {tag}"
    assert m.count(old) == 1, f"锚点重复: {tag} ({m.count(old)})"
    m = m.replace(old, new, 1)

# ============ 1) 设置页：扫描设置加「真进度条」开关 ============
rep('        self._make_toggle(box, "开发者模式（开发目录自动降权，减少误报）", "developer_mode")\n\n        # ---- 界面设置 ----\n        box = section("界面设置")',
    '        self._make_toggle(box, "开发者模式（开发目录自动降权，减少误报）", "developer_mode")\n'
    '        self._make_toggle(box, "真进度条（关闭则用弹性块动画）", "progress_bar_mode")\n'
    '\n        # ---- 界面设置 ----\n        box = section("界面设置")',
    "扫描设置-进度条开关")

# ============ 2) 设置页：界面设置加「免打扰」开关 ============
rep('        self._make_toggle(box, "删除前弹出确认提示", "delete_confirm")\n\n        # ---- 实时防护设置 ----\n        box = section("实时防护")',
    '        self._make_toggle(box, "删除前弹出确认提示", "delete_confirm")\n'
    '        self._make_toggle(box, "免打扰模式（开启后不弹任何弹窗）", "dnd_mode")\n'
    '\n        # ---- 实时防护设置 ----\n        box = section("实时防护")',
    "界面设置-免打扰开关")

# ============ 3) _dnd_active 方法（加在 _make_toggle 之后） ============
rep('''        toggle_btn.config(command=on_toggle)
        _update_btn()
        toggle_btn.pack(side="right")
        return var

    def _get_next_version(self):''',
    '''        toggle_btn.config(command=on_toggle)
        _update_btn()
        toggle_btn.pack(side="right")
        return var

    def _dnd_active(self):
        """免打扰模式：开启后所有安全告警弹窗静默（自动处理+写日志，不弹任何窗口）。"""
        try:
            return bool(self.config.get("dnd_mode", False))
        except Exception:
            return False

    def _get_next_version(self):''',
    "dnd_active 方法")

# ============ 4) 免打扰短路：系统关键告警 ============
rep('''    def _show_system_critical_alert(self, alert):
        """【3.5.8】系统文件破坏紧急告警：置顶红色弹窗，提示立即断网。"""
        try:
            missing = alert.get("missing", [])''',
    '''    def _show_system_critical_alert(self, alert):
        """【3.5.8】系统文件破坏紧急告警：置顶红色弹窗，提示立即断网。"""
        if self._dnd_active():
            return  # 免打扰：不弹窗（还原动作已自动执行）
        try:
            missing = alert.get("missing", [])''',
    "免打扰-系统关键")

# ============ 5) 免打扰短路：进程被终止提示 ============
rep('''    def _show_killed_alert(self, alert):
        """【3.5.0】DG 进程被外部终止并自动恢复提示。"""
        try:
            what = alert.get("what", "DG 进程")''',
    '''    def _show_killed_alert(self, alert):
        """【3.5.0】DG 进程被外部终止并自动恢复提示。"""
        if self._dnd_active():
            return  # 免打扰：恢复已完成，静默
        try:
            what = alert.get("what", "DG 进程")''',
    "免打扰-进程被终止")

# ============ 6) 免打扰短路：进程拦截（已自动处理） ============
rep('''    def _show_intercept_alert(self, alert):
        """【3.4.0】进程拦截弹窗：DG 已自动拦截攻击进程。"""
        try:
            name = alert.get("name", "未知")''',
    '''    def _show_intercept_alert(self, alert):
        """【3.4.0】进程拦截弹窗：DG 已自动拦截攻击进程。"""
        if self._dnd_active():
            return  # 免打扰：拦截+隔离已自动执行
        try:
            name = alert.get("name", "未知")''',
    "免打扰-进程拦截")

# ============ 7) 免打扰：进程告警 → 自动结束进程 ============
rep('''    def _show_process_alert(self, alert):
        """显示进程告警弹窗。"""
        try:
            pid = alert.get("pid", 0)
            name = alert.get("name", "未知")
            path = alert.get("path", "")
            cmd = alert.get("cmd", "")
            risks = alert.get("risks", [])''',
    '''    def _show_process_alert(self, alert):
        """显示进程告警弹窗。"""
        try:
            pid = alert.get("pid", 0)
            name = alert.get("name", "未知")
            path = alert.get("path", "")
            cmd = alert.get("cmd", "")
            risks = alert.get("risks", [])
            if self._dnd_active():
                # 免打扰：默认自动结束进程（安全动作），不弹窗
                try:
                    if self._rtp and self._rtp.kill_process(pid):
                        self._append_log(f"免打扰：已自动结束可疑进程 {name}（PID {pid}）")
                    else:
                        self._append_log(f"免打扰：结束进程失败 {name}（PID {pid}）")
                except Exception:
                    pass
                return''',
    "免打扰-进程告警")

# ============ 8) 免打扰：批量落盘 → 自动隔离 ============
rep('''    def _handle_batch_alert(self, alert):
        """批量落盘告警：窗口内新增大量脚本/可执行文件 -> 疑似蠕虫/下载器。
        3.5.9：立即定位来源文件夹 + 弹倒计时提示窗，
        10 秒内用户未回应则自动隔离高危文件（用户可点「立即隔离」或「信任跳过」）。
        """
        try:
            paths = alert.get("paths", []) or []
            count = alert.get("count", 0)
            if not paths:
                return''',
    '''    def _handle_batch_alert(self, alert):
        """批量落盘告警：窗口内新增大量脚本/可执行文件 -> 疑似蠕虫/下载器。
        3.5.9：立即定位来源文件夹 + 弹倒计时提示窗，
        10 秒内用户未回应则自动隔离高危文件（用户可点「立即隔离」或「信任跳过」）。
        """
        try:
            paths = alert.get("paths", []) or []
            count = alert.get("count", 0)
            if not paths:
                return
            if self._dnd_active():
                # 免打扰：自动隔离全部批量落盘文件，不弹窗
                try:
                    _cnt = 0
                    for _p in paths:
                        if os.path.exists(_p) and self._quarantine_file(_p):
                            _cnt += 1
                    self._append_log(f"免打扰：自动隔离批量落盘 {_cnt} 个文件")
                except Exception:
                    pass
                return''',
    "免打扰-批量落盘")

# ============ 9) 免打扰：文件告警 notify 分支 → 自动隔离 ============
rep('''            # notify：高危但仅弱特征/单维度 -> 弹窗让用户决定，绝不自动隔离
            try:
                from tkinter import messagebox as _mb
                _mb.showwarning(
                    "DG 下载保护",
                    f"发现疑似风险文件（{level}）\\n\\n{base}\\n\\n"
                    f"特征：{'、'.join(tags) if tags else '单一弱特征'}\\n\\n"
                    "该文件未被自动隔离。请自行判断：\\n"
                    "· 如确属可信文件，可点击「信任」加入白名单；\\n"
                    "· 如确认可疑，请在扫描结果中手动移入隔离区。",
                    parent=self.root)
            except Exception:
                pass''',
    '''            # notify：高危但仅弱特征/单维度 -> 弹窗让用户决定，绝不自动隔离
            if self._dnd_active():
                # 免打扰：高危弱特征自动隔离（可恢复），不弹窗
                try:
                    if self._quarantine_file(fpath):
                        self._append_log(f"免打扰：已自动隔离疑似风险文件 {base}")
                except Exception:
                    pass
                return
            try:
                from tkinter import messagebox as _mb
                _mb.showwarning(
                    "DG 下载保护",
                    f"发现疑似风险文件（{level}）\\n\\n{base}\\n\\n"
                    f"特征：{'、'.join(tags) if tags else '单一弱特征'}\\n\\n"
                    "该文件未被自动隔离。请自行判断：\\n"
                    "· 如确属可信文件，可点击「信任」加入白名单；\\n"
                    "· 如确认可疑，请在扫描结果中手动移入隔离区。",
                    parent=self.root)
            except Exception:
                pass''',
    "免打扰-文件告警")

# ============ 10) 免打扰：文件风暴 → 自动隔离 ============
rep('''    def _storm_alert(self, files):
        """4.11.0 文件风暴告警：置顶弹窗 + 10 秒倒计时，超时自动移入隔离区（可恢复）。
        按钮：立即隔离全部 / 这是我自己的文件忽略。"""
        try:
            if getattr(self, "_storm_alerting", False):
                return''',
    '''    def _storm_alert(self, files):
        """4.11.0 文件风暴告警：置顶弹窗 + 10 秒倒计时，超时自动移入隔离区（可恢复）。
        按钮：立即隔离全部 / 这是我自己的文件忽略。"""
        try:
            if getattr(self, "_storm_alerting", False):
                return
            if self._dnd_active():
                # 免打扰：文件风暴自动隔离，不弹窗
                try:
                    _cnt = 0
                    for _f in files:
                        if os.path.exists(_f) and self._quarantine_file(_f):
                            _cnt += 1
                    self._append_log(f"免打扰：文件风暴自动隔离 {_cnt} 个文件")
                except Exception:
                    pass
                return''',
    "免打扰-文件风暴")

# ============ 11) 扫描开始：进度条模式 ============
rep('''        self._set_status(f"{mode_label}中…", C_PRIMARY)
        self.progress.start(12)''',
    '''        self._set_status(f"{mode_label}中…", C_PRIMARY)
        if self.config.get("progress_bar_mode", False):
            # 真进度条：determinate，预统计总数到达后更新 maximum
            try:
                self.progress.config(mode="determinate", maximum=1, value=0)
            except Exception:
                pass
        else:
            self.progress.start(12)''',
    "扫描开始-进度条模式")

# ============ 12) 扫描 worker：预统计总数（非 deep，deep 用 C++ 自带） ============
rep('''        # 扫描任务已就绪，立即反馈（避免长时间停留在"正在初始化扫描引擎"）
        try:
            self.msg_q.put(("progress", 0, 0, 0, "", "扫描任务已就绪，正在遍历目录…"))
        except Exception:
            pass''',
    '''        # 扫描任务已就绪，立即反馈（避免长时间停留在"正在初始化扫描引擎"）
        try:
            self.msg_q.put(("progress", 0, 0, 0, "", "扫描任务已就绪，正在遍历目录…"))
        except Exception:
            pass

        # 真进度条：预统计待扫文件总数（仅快速/高级，枚举很快；深度用 C++ 核心自带 total）
        if mode != "deep":
            try:
                _pre_total = 0
                for _j in jobs:
                    _d, _p, _rec, _ss, _sb, _adm = _j
                    for _ in engine.enum_files(_p, recursive=_rec, skip_system=_ss,
                                               skip_bulk=_sb, appdata_mode=_adm,
                                               skip_harmless=(mode == "quick" and not is_custom)):
                        _pre_total += 1
                self.msg_q.put(("scan_total", _pre_total))
            except Exception:
                pass''',
    "预统计总数")

# ============ 13) UI 处理 scan_total ============
rep('''                elif kind == "status":
                    _, text, color = item
                    self._set_status(text, color)''',
    '''                elif kind == "scan_total":
                    _tot = item[1]
                    if self.config.get("progress_bar_mode", False):
                        try:
                            self.progress.config(mode="determinate",
                                                 maximum=max(_tot, 1), value=0)
                        except Exception:
                            pass
                elif kind == "status":
                    _, text, color = item
                    self._set_status(text, color)''',
    "UI-scan_total")

# ============ 14) UI progress 分支：更新真进度条 ============
rep('''                    if disk != self.cur_disk:
                        self.cur_disk = disk
                        self._set_status(f"正在扫描 {disk.rstrip(chr(92))} 盘…", C_PRIMARY)
                    self.cur_path.config(text=f"{disk} · {path[:140]}")
                    self._schedule_refresh()''',
    '''                    if disk != self.cur_disk:
                        self.cur_disk = disk
                        self._set_status(f"正在扫描 {disk.rstrip(chr(92))} 盘…", C_PRIMARY)
                    self.cur_path.config(text=f"{disk} · {path[:140]}")
                    if self.config.get("progress_bar_mode", False):
                        try:
                            _mx = getattr(self, "_scan_total", 0) or 1
                            self.progress.config(value=min(_show_n, _mx))
                        except Exception:
                            pass
                    self._schedule_refresh()''',
    "UI-progress 更新")

# ============ 15) UI core_progress 分支：更新真进度条 ============
rep('''                    if cur:
                        self.cur_path.config(text=f"{engine.drive_of(cur).rstrip(chr(92))} · {cur[:140]}")''',
    '''                    if cur:
                        self.cur_path.config(text=f"{engine.drive_of(cur).rstrip(chr(92))} · {cur[:140]}")
                    if self.config.get("progress_bar_mode", False):
                        try:
                            self.progress.config(maximum=max(total, 1),
                                                 value=min(done, total))
                        except Exception:
                            pass''',
    "UI-core_progress 更新")

# ============ 16) 扫描完成：进度条收尾 ============
rep('''        self.progress.stop()
        self._set_sub_status("")''',
    '''        self.progress.stop()
        if self.config.get("progress_bar_mode", False):
            try:
                self.progress.config(mode="determinate", maximum=1, value=1)
            except Exception:
                pass
        self._set_sub_status("")''',
    "扫描完成-进度条收尾")

# ============ 17) 停止优化：imap chunksize 256→64 ============
rep('''                for _r in _pool.imap_unordered(engine.mp_scan_file, _task_iter(), chunksize=256):''',
    '''                for _r in _pool.imap_unordered(engine.mp_scan_file, _task_iter(), chunksize=64):''',
    "chunksize 64")

# ============ 18) 版本号 & 历史 ============
rep('APP_VERSION = "4.14.1"', 'APP_VERSION = "4.15.0"', "版本号")
rep('''    ("4.14.1", "4.14.0", "补丁（UI视觉更新）：''',
    '''    ("4.15.0", "4.14.1", "内容更新（免打扰模式+真进度条）：1.【免打扰模式】设置-界面设置新增开关，开启后所有安全告警弹窗静默——进程告警自动结束进程、批量落盘/文件风暴/高危弱特征自动隔离、拦截与还原静默记录日志，不弹任何窗口（用户主动操作的确认框不受影响）；2.【真进度条】设置-扫描设置新增开关，开启后扫描进度条从弹性动画切换为真实进度——扫描前预统计文件总数、实时显示已扫/总数百分比（深度扫描用C++核心遍历数），当前文件路径同步显示；关闭则恢复弹性块动画；3.【停止优化】多进程扫描批量块 256→64，点停止后响应更快；4.【扫描提速】快速扫描跳过多媒体无害类型（图片/音视频/字体，哈希纯浪费），深度/高级扫描保真不跳、DLL/驱动永不跳"),
    ("4.14.1", "4.14.0", "补丁（UI视觉更新）：''',
    "版本历史")

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)

# 语法校验
import py_compile
py_compile.compile(MAIN, doraise=True)
print("[OK] main.py 补丁全部应用，语法通过")
print(f"文件长度: {len(orig)} -> {len(m)}")
