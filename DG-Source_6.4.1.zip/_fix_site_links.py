# -*- coding: utf-8 -*-
import io

targets = [
    r'F:\桌面保护\kittyguard_site\DG安全官网.html',
    r'F:\桌面保护\kittyguard_site\index.html',
    r'F:\桌面保护\kittyguard_site\publish\index.html',
]
old1 = 'href="DG-Security-Setup-6.4.1.exe"'
new1 = 'href="https://github.com/kittyguard/kittyguard/releases/download/v6.4.1/DG-Security-Setup-6.4.1.exe"'
old2 = 'href="DG-Security_6.4.1.zip"'
new2 = 'href="https://github.com/kittyguard/kittyguard/releases/download/v6.4.1/DG-Security_6.4.1.zip"'

for t in targets:
    with io.open(t, 'r', encoding='utf-8') as f:
        s = f.read()
    c1 = s.count(old1)
    c2 = s.count(old2)
    s = s.replace(old1, new1).replace(old2, new2)
    with io.open(t, 'w', encoding='utf-8') as f:
        f.write(s)
    print(t, 'exe:', c1, 'zip:', c2)
