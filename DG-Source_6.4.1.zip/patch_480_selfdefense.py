# -*- coding: utf-8 -*-
"""DG 4.8.0 补丁：工具页新增「自防护中心」卡片 + _open_selfdefense 方法 + 版本号升级"""
import io

P = r"F:\桌面保护\desktopguard\main.py"
src = io.open(P, "r", encoding="utf-8").read()

# ---------- 1. 版本号 ----------
old_ver = 'APP_VERSION = "4.7.0"'
new_ver = 'APP_VERSION = "4.8.0"'
assert old_ver in src, "version anchor not found"
src = src.replace(old_ver, new_ver, 1)

# ---------- 2. 工具页卡片（插在网络工具卡片后） ----------
old_card = '        ttk.Button(t5, text="打开网络工具箱", style="Accent.TButton", command=self._open_net_tools).pack(anchor="w", pady=(6, 0))\n'
assert old_card in src, "card anchor not found"
new_card = old_card + (
    '        t6 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)\n'
    '        t6.pack(fill="x", pady=4)\n'
    '        tk.Label(t6, text="自防护中心", bg=C_CARD2, fg=C_PRIMARY,\n'
    '                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")\n'
    '        tk.Label(t6, text="回滚中心（TCP/进程/配置/数据库一键回滚）+ 防篡改（核心文件完整性自愈：哈希校验→快照恢复），纯用户态",\n'
    '                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))\n'
    '        ttk.Button(t6, text="打开自防护中心", style="Accent.TButton", command=self._open_selfdefense).pack(anchor="w", pady=(6, 0))\n'
)
src = src.replace(old_card, new_card, 1)

# ---------- 3. 方法：在 _open_net_tools 方法结束后插入 ----------
anchor = '            messagebox.showerror("网络工具箱", f"启动失败：{e}")'
assert anchor in src, "method anchor not found"
idx = src.index(anchor) + len(anchor)
new_method = """

    def _open_selfdefense(self):
        \"\"\"打开自防护中心（独立进程，防重复启动）\"\"\"
        import ctypes
        found = []
        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def cb(h, l):
            if ctypes.windll.user32.IsWindowVisible(h):
                buf = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetWindowTextW(h, buf, 256)
                if "自防护中心" in buf.value:
                    found.append(h)
            return True
        try:
            ctypes.windll.user32.EnumWindows(cb, 0)
        except Exception:
            pass
        if found:
            messagebox.showinfo("自防护中心", "自防护中心已在运行。")
            return
        script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "selfdefense.py")
        if not os.path.exists(script):
            messagebox.showerror("自防护中心", "未找到 selfdefense.py（应位于 DG 程序目录）。")
            return
        try:
            exe = sys.executable
            if exe and exe.lower().endswith("python.exe"):
                exe = exe[:-len("python.exe")] + "pythonw.exe"
            if not exe or not os.path.exists(exe):
                exe = sys.executable
            subprocess.Popen([exe, script],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            messagebox.showinfo("自防护中心", "自防护中心已打开（回滚 + 防篡改，每 60 秒自动校验核心文件）。")
        except Exception as e:
            messagebox.showerror("自防护中心", f"启动失败：{e}")"""
src = src[:idx] + new_method + src[idx:]

# ---------- 4. 历史版本记录 ----------
old_vlist = '    ("4.7.0", "4.6.2", '
new_vlist = (
    '    ("4.8.0", "4.7.0", "内容更新（自防护中心 v1）：1.工具页新增「自防护中心」卡片——独立进程窗口不阻塞主程序、防重复启动；2.【回滚中心】统一管理可回滚操作：网络工具箱结束的进程/TCP 优化自动写入回滚日志（一条条/全部一键回滚），配置文件（config/rtp_config）支持带时间戳备份与最新备份恢复，数据库一键备份；3.【防篡改】核心 .py 模块哈希清单 + 周期性校验（每 60 秒后台自愈），发现被删除/篡改自动从当前版本快照恢复并写日志弹窗；配置文件被改从备份恢复；清单可重建；4.网络工具箱（4.7.0）操作全量接入回滚中心",),\n'
    '    ("4.7.0", "4.6.2", '
)
assert old_vlist in src, "vlist anchor not found"
src = src.replace(old_vlist, new_vlist, 1)

io.open(P, "w", encoding="utf-8").write(src)
print("PATCH OK, version now 4.8.0, size:", len(src))
