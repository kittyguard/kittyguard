# -*- coding: utf-8 -*-
import os, subprocess
SITE = r"F:\桌面保护\kittyguard_site"
for f in ("DG-Security-Setup-6.4.3.exe", "DG-Security_6.4.3.zip", "DG-Source_6.4.3.zip"):
    for base in (SITE, os.path.join(SITE, "publish")):
        p = os.path.join(base, f)
        print("OK" if os.path.isfile(p) else "MISS", os.path.relpath(p, SITE), os.path.getsize(p) if os.path.isfile(p) else "")
r = subprocess.run(["git", "-C", SITE, "status", "--short"], capture_output=True, text=True, encoding="utf-8", errors="ignore")
print((r.stdout or "")[:2000] or (r.stderr or "")[:500])
