# -*- coding: utf-8 -*-
"""
DG 安全 — Gitee Releases 一键发布脚本
=====================================
用法：
    1. 首次：在脚本同目录创建 gitee_config.json（或用环境变量）：
       {
         "owner": "你的Gitee用户名",
         "repo":  "仓库名（需提前在 Gitee 创建）",
         "token": "个人访问令牌（仓库 write 权限，不要发给任何人/不进对话）"
       }
    2. 运行：python dg_release_gitee.py [版本号，缺省自动读根目录 APP_VERSION]
    3. 脚本自动：打更新包 zip → 算 SHA256 → 生成 version.json →
       创建/更新 Gitee Release（tag=v{版本}）→ 上传附件 →
       输出"更新源 URL"（填进 DG 设置→软件更新→更新源）

安全约束：
    - Token 只从配置文件/环境变量读取，绝不硬编码、绝不打印。
    - 更新包只含程序目录运行必需文件，不含 dgdata 用户数据（配置/黑名单/病毒库/日志）。
    - 全程纯标准库（urllib），无第三方依赖。
"""

import os
import sys
import json
import glob
import hashlib
import zipfile
import urllib.request
import urllib.parse
import urllib.error

ROOT = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(ROOT, "gitee_config.json")
OUT_DIR = os.path.join(ROOT, "release_out")
API = "https://gitee.com/api/v5"

# ---------- 运行必需文件白名单 ----------
# C++ 组件（dg_etw*.exe 为历史测试件，不带；dg_watcher_tpl.exe 为乱码观察者模板，必须带）
EXE_REQUIRED = [
    "dg_monitor.exe", "dg_guard.exe", "dg_ema_watch.exe", "scan_core.exe",
    "dg_quarantine.exe", "dg_verdict.exe", "sandbox_runner.exe",
    "dg_warden.exe", "dg_watcher_tpl.exe",
]
# 模型与资源
RES_REQUIRED = ["ml_model.joblib", "ml_model.onnx", "shield.ico"]
# 显式必需的运行模块（排除法兜底之外的双保险）
PY_REQUIRED = [
    "main.py", "engine.py", "database.py", "realtime_protection.py",
    "selfdefense.py", "verdict_engine.py", "yara_engine.py", "clamav_bridge.py",
    "pe_heuristic.py", "ml_features.py", "ml_infer.py", "cloud_lookup.py",
    "cloud_query.py", "popup_blocker.py", "net_monitor.py", "net_tools.py",
    "process_manager.py", "security_log.py", "system_check.py", "system_guard.py",
    "startup_manager.py", "tray.py", "shred.py", "sandbox_runner.py", "paths.py",
    "logger.py", "flush_engine.py", "ai_behavior_analyzer.py",
    "scan_core_bridge.py", "gen_report.py", "app_patrol.py", "dg_ema_ctl.py",
    "dg_scan_cli.py", "dg_context.py", "perf_overlay.py",
]
# 一次性/开发脚本前缀（不打包）
DEV_PREFIXES = (
    "fix_", "patch_", "check_", "release_", "publish_", "optimize_", "mod_",
    "inject_", "integrate_", "restore_", "remove_", "sync_", "debug_", "test_",
    "_patch", "_publish", "_verify", "train_ml", "unpack_samples",
)
# 显式排除（发布脚本自身/旧版残留/验证脚本）
EXCLUDE_FILES = {"dg_release_gitee.py", "gen_report290.py", "verify_core.py"}


def read_app_version():
    """从根目录 main.py 读取 APP_VERSION。"""
    try:
        with open(os.path.join(ROOT, "main.py"), "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("APP_VERSION") and "=" in line:
                    return line.split("=", 1)[1].strip().strip("'\"").strip()
    except Exception:
        pass
    return ""


def collect_py_files():
    """收集运行必需 .py：显式白名单 + 非 dev 前缀兜底，排除 *_bak*。"""
    files = set(PY_REQUIRED)
    for p in glob.glob(os.path.join(ROOT, "*.py")):
        name = os.path.basename(p)
        if name in PY_REQUIRED or name in EXCLUDE_FILES:
            continue
        if "_bak" in name:
            continue
        if name.startswith(DEV_PREFIXES):
            continue
        files.add(name)
    return sorted(files)


def build_pkg(version):
    """打更新包 zip 到 release_out，返回 (zip路径, sha256)。"""
    os.makedirs(OUT_DIR, exist_ok=True)
    pkg_name = f"dg_{version}.zip"
    zip_path = os.path.join(OUT_DIR, pkg_name)
    py_files = collect_py_files()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for name in py_files:
            fp = os.path.join(ROOT, name)
            if os.path.isfile(fp):
                z.write(fp, name)
        for name in EXE_REQUIRED + RES_REQUIRED:
            fp = os.path.join(ROOT, name)
            if os.path.isfile(fp):
                z.write(fp, name)
    sha = hashlib.sha256()
    with open(zip_path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            sha.update(chunk)
    return zip_path, sha.hexdigest()


def notes_for(version):
    """从根目录 version.json 取发布说明（带回退）。"""
    try:
        with open(os.path.join(ROOT, "version.json"), "r", encoding="utf-8") as f:
            vj = json.load(f)
        notes = vj.get("release_notes") or ""
        return notes[:500]
    except Exception:
        return "DG 安全自动发布。"


def load_config():
    """读配置：优先环境变量，其次同目录 gitee_config.json。"""
    owner = os.environ.get("GITEE_OWNER", "")
    repo = os.environ.get("GITEE_REPO", "")
    token = os.environ.get("GITEE_TOKEN", "")
    if (not owner or not repo or not token) and os.path.isfile(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        owner = owner or cfg.get("owner", "")
        repo = repo or cfg.get("repo", "")
        token = token or cfg.get("token", "")
    return owner, repo, token


def api_get(url, params):
    full = url + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(full)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))


def api_post(url, fields, files=None):
    """POST multipart/form-data（files: [(字段名, 文件名, 二进制)]）。"""
    boundary = "----DG_" + hashlib.md5(os.urandom(16)).hexdigest()
    body = b""
    for k, v in fields.items():
        body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n"
                 f"{v}\r\n").encode("utf-8")
    for field, fname, data in (files or []):
        body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"; "
                 f"filename=\"{fname}\"\r\nContent-Type: application/octet-stream\r\n\r\n").encode("utf-8")
        body += data + b"\r\n"
    body += f"--{boundary}--\r\n".encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))


def api_delete(url, params):
    data = urllib.parse.urlencode(params).encode()
    req = urllib.request.Request(url, data=data, method="DELETE")
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status


def main():
    version = sys.argv[1] if len(sys.argv) > 1 else read_app_version()
    if not version:
        print("[失败] 未指定版本号且无法从 main.py 读取 APP_VERSION")
        sys.exit(1)
    owner, repo, token = load_config()
    if not owner or not repo or not token:
        print("[失败] 缺少 Gitee 配置。请创建 gitee_config.json（owner/repo/token）"
              "或设置环境变量 GITEE_OWNER/GITEE_REPO/GITEE_TOKEN。")
        sys.exit(1)

    print(f"[1/4] 打包 v{version} ...")
    zip_path, sha = build_pkg(version)
    pkg_name = os.path.basename(zip_path)
    print(f"      → {pkg_name} ({round(os.path.getsize(zip_path)/1048576, 2)} MB)")
    print(f"      → SHA256 {sha[:16]}…")

    print("[2/4] 生成 version.json ...")
    vj = {
        "version": version,
        "pkg": pkg_name,
        "sha256": sha,
        "notes": notes_for(version),
    }
    vj_path = os.path.join(OUT_DIR, "version.json")
    with open(vj_path, "w", encoding="utf-8") as f:
        json.dump(vj, f, ensure_ascii=False, indent=2)

    tag = f"v{version}"
    rel_url = f"{API}/repos/{owner}/{repo}/releases"
    print(f"[3/4] 发布 Gitee Release tag={tag} ...")
    try:
        existing = api_get(f"{rel_url}/tags/{tag}", {"access_token": token})
        if existing.get("id"):
            api_delete(f"{rel_url}/{existing['id']}",
                       {"access_token": token, "release_id": existing["id"]})
            print(f"      → 已删除旧 release（id={existing['id']}）")
    except urllib.error.HTTPError as e:
        if e.code not in (404,):
            print(f"      → 查询旧 release 失败：HTTP {e.code}（继续尝试新建）")
    rel = api_post(rel_url, {
        "access_token": token,
        "tag_name": tag,
        "target_commitish": "master",
        "name": f"DG 安全 v{version}",
        "body": (vj.get("notes") or ""),
    })
    rel_id = rel.get("id")
    if not rel_id:
        print(f"[失败] 创建 release 未返回 id：{json.dumps(rel, ensure_ascii=False)[:200]}")
        sys.exit(1)

    print("[4/4] 上传附件 ...")
    for fname, fpath in [(pkg_name, zip_path), ("version.json", vj_path)]:
        with open(fpath, "rb") as f:
            data = f.read()
        api_post(f"{rel_url}/{rel_id}/attach_files", {
            "access_token": token,
        }, files=[("file", fname, data)])
        print(f"      → 已上传 {fname}")

    url = f"https://gitee.com/{owner}/{repo}/releases/download/{tag}"
    print("")
    print("=" * 64)
    print(f"发布成功：DG 安全 v{version}")
    print(f"更新源 URL（填进 DG 设置→软件更新→更新源）：")
    print(f"    {url}")
    print("=" * 64)


if __name__ == "__main__":
    main()
