# -*- coding: utf-8 -*-
with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

old = '''        def reset_loading():
            is_loading[0] = False
            cancel_flag[0] = False
            send_btn.config(state="normal", text="发送")
            cancel_btn.config(state="disabled")
            status_label.config(text="● 已连接", fg=C_GREEN)
        
        def on_cancel():
            cancel_flag[0] = True
            append_message("system", "⏹ 已取消当前请求。")
            reset_loading()'''

new = '''        def reset_loading():
            is_loading[0] = False
            # 注意：不重置 cancel_flag，让后台线程知道用户已取消
            # cancel_flag 只在新的发送开始时重置
            send_btn.config(state="normal", text="发送")
            cancel_btn.config(state="disabled")
            status_label.config(text="● 已连接", fg=C_GREEN)
        
        def on_cancel():
            cancel_flag[0] = True
            append_message("system", "⏹ 已取消当前请求（后台可能仍在运行，但结果不会显示）。")
            reset_loading()'''

if old in c:
    c = c.replace(old, new, 1)
    with open('main.py', 'w', encoding='utf-8') as f:
        f.write(c)
    print('取消按钮bug已修复')
else:
    print('未找到匹配的字符串')
    idx = c.find('def reset_loading')
    if idx > 0:
        print('附近内容:')
        print(c[idx:idx+600])
