# -*- coding: utf-8 -*-
"""修复AI实时辅助的两个问题：
1. _ai_check是Scanner类方法，不是独立函数，需要用scanner._ai_check(r)
2. _poll_queue里添加ai_done消息处理
"""

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 1. 修复AI分析代码：用scanner._ai_check(r)而不是导入独立函数
old_ai = '''                def _ai_analyze_batch():
                    try:
                        from engine import _ai_check as _ai_check_fn
                        _analyzed = 0
                        for r in _high_risk[:10]:  # 最多分析10个高危文件
                            if self.stop_flag:
                                break
                            try:
                                _ai_result = _ai_check_fn(r)
                                if _ai_result:
                                    r.ai_verdict = _ai_result.get("verdict", "")
                                    r.ai_reason = _ai_result.get("reason", "")
                                    r.ai_confidence = _ai_result.get("confidence", 0)
                                    _analyzed += 1
                            except Exception:
                                pass
                            time.sleep(0.2)  # 避免API调用过快
                        self.msg_q.put(("ai_done", _analyzed))
                    except Exception:
                        self.msg_q.put(("ai_done", 0))'''

new_ai = '''                def _ai_analyze_batch():
                    try:
                        _analyzed = 0
                        for r in _high_risk[:10]:  # 最多分析10个高危文件
                            if self.stop_flag:
                                break
                            try:
                                # 用scanner的_ai_check方法（传统引擎+AI二次确认）
                                _before_score = r.score
                                _before_level = r.level
                                scanner._ai_check(r)  # 直接修改r对象，添加AI标签和调分
                                # 检查AI是否修改了结果
                                if r.score != _before_score or r.level != _before_level:
                                    _analyzed += 1
                            except Exception:
                                pass
                            time.sleep(0.3)  # 避免API调用过快，也降低CPU占用
                        self.msg_q.put(("ai_done", _analyzed))
                    except Exception:
                        self.msg_q.put(("ai_done", 0))'''

if old_ai in c:
    c = c.replace(old_ai, new_ai, 1)
    print('1. AI分析代码修复完成（用scanner._ai_check）')
else:
    print('1. 未找到AI分析代码，跳过')

# 2. 在_poll_queue里添加ai_done消息处理
# 找到done消息的处理，在前面添加ai_done
old_done = '''                elif kind == "done":
                    _, n, t, j = item
                    self.scanning = False'''

new_done = '''                elif kind == "ai_done":
                    _ai_count = item[1]
                    if _ai_count > 0:
                        self._set_status(f"AI分析完成：已分析 {_ai_count} 个高危文件", C_PRIMARY)
                        self._flush_refresh(force=True)
                elif kind == "done":
                    _, n, t, j = item
                    self.scanning = False'''

if old_done in c:
    c = c.replace(old_done, new_done, 1)
    print('2. _poll_queue添加ai_done处理完成')
else:
    print('2. 未找到done消息处理，尝试其他方式...')
    # 用更宽松的匹配
    idx = c.find('elif kind == "done":')
    if idx > 0:
        print(f'   找到done消息在索引 {idx}')
        # 在前面插入ai_done
        insert_text = '''                elif kind == "ai_done":
                    _ai_count = item[1]
                    if _ai_count > 0:
                        self._set_status(f"AI分析完成：已分析 {_ai_count} 个高危文件", C_PRIMARY)
                        self._flush_refresh(force=True)
'''
        c = c[:idx] + insert_text + c[idx:]
        print('   已插入ai_done处理')
    else:
        print('   未找到done消息')

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print('\n修复完成！')
