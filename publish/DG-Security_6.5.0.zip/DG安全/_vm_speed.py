# -*- coding: utf-8 -*-
import subprocess, os, time

VBM = r"C:\Program Files\Oracle\VirtualBox\VBoxManage.exe"
VM = "DG-VM"

def run(cmd, timeout=60):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=timeout)
        return r.stdout, r.stderr
    except Exception as e:
        return "", "ERR " + str(e)

# 1. Guest Additions 是否安装
out, _ = run([VBM, "showvminfo", VM, "--machinereadable"])
for line in out.splitlines():
    if line.startswith("GuestAdditions") or "GuestAdditions" in line:
        print(line)
print()

# 2. vdi 类型（动态/固定）与大小
out2, _ = run([VBM, "showmediuminfo", "disk", r"F:\桌面保护\vmware\DG-VM.vdi"])
for line in out2.splitlines():
    if any(k in line for k in ["Type", "Capacity", "Size on disk", "Location", "Disk"]):
        print(line)
print()

# 3. 宿主机 → GitHub Pages 下载测速（用 version.json 小文件 + 大文件前 2MB）
import urllib.request
def speed_test(url, limit=None, timeout=30):
    t0 = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            total = 0
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                total += len(chunk)
                if limit and total >= limit:
                    break
        dt = time.time() - t0
        return total, dt
    except Exception as e:
        return 0, 0, str(e)

b, d = speed_test("https://kittyguard.github.io/kittyguard/version.json", None)
if isinstance(d, str):
    print("version.json:", "FAIL", d)
else:
    print("version.json: %d B in %.2fs -> %.1f KB/s" % (b, d, b/1024/max(d,0.001)))
print()

b2, d2 = speed_test("https://kittyguard.github.io/kittyguard/DG-Security-Setup-6.4.2.exe", 2*1024*1024)
if isinstance(d2, str):
    print("Setup 测速: FAIL", d2)
else:
    print("Setup 前 2MB: %d B in %.2fs -> %.1f KB/s" % (b2, d2, b2/1024/max(d2,0.001)))
