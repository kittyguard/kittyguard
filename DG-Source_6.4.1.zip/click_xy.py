# -*- coding: utf-8 -*-
"""真实桌面点击（参数化）：python click_xy.py 334 974 [双击次数]"""
import ctypes, sys, time

user32 = ctypes.windll.user32
sw = user32.GetSystemMetrics(0)
sh = user32.GetSystemMetrics(1)
x = int(int(sys.argv[1]) / 1000 * sw)
y = int(int(sys.argv[2]) / 1000 * sh)
n = int(sys.argv[3]) if len(sys.argv) > 3 else 1
user32.SetCursorPos(x, y)
time.sleep(0.25)
for _ in range(n):
    user32.mouse_event(0x0002, 0, 0, 0, 0)
    time.sleep(0.08)
    user32.mouse_event(0x0004, 0, 0, 0, 0)
    time.sleep(0.12)
print("CLICKED", x, y, sw, sh, "n=", n)
