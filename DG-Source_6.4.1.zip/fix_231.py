# -*- coding: utf-8 -*-
with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 找到 on_send 函数，在开头添加 nonlocal chat_history
# 用更精确的方式替换
old_send_start = '''        def on_send():
            """发送消息：完整try-catch，任何异常都显示在UI上。"""
            try:
                append_message("debug", "[调试] on_send 被调用")'''

new_send_start = '''        def on_send():
            """发送消息：完整try-catch，任何异常都显示在UI上。"""
            nonlocal chat_history
            try:
                append_message("debug", "[调试] on_send 被调用")'''

if old_send_start in c:
    c = c.replace(old_send_start, new_send_start, 1)
    print('on_send 添加 nonlocal chat_history 成功')
else:
    print('未找到匹配的字符串，尝试其他方式...')
    # 找到 def on_send(): 后面的第一行
    idx = c.find('def on_send():')
    if idx > 0:
        # 找到下一个 try:
        try_idx = c.find('try:', idx)
        if try_idx > 0:
            # 在 try: 前面插入 nonlocal chat_history
            c = c[:try_idx] + '            nonlocal chat_history\n' + c[try_idx:]
            print('通过位置插入 nonlocal chat_history 成功')

# 同时修复 on_clear 里的 nonlocal 问题：用 clear() 代替重新赋值
old_clear = '''        def on_clear():
            try:
                nonlocal chat_history
                chat_history = []
                chat_text.config(state="normal")
                chat_text.delete("1.0", "end")
                chat_text.config(state="disabled")
                append_message("system", "聊天记录已清空。")'''

new_clear = '''        def on_clear():
            try:
                chat_history.clear()
                chat_text.config(state="normal")
                chat_text.delete("1.0", "end")
                chat_text.config(state="disabled")
                append_message("system", "聊天记录已清空。")'''

if old_clear in c:
    c = c.replace(old_clear, new_clear, 1)
    print('on_clear 改用 clear() 成功')
else:
    print('未找到 on_clear 匹配字符串')

# 升级版本号到 2.3.1
c = c.replace('APP_VERSION = "2.3.0"', 'APP_VERSION = "2.3.1"', 1)
c = c.replace(
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0"]',
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1"]'
)

old_history = '''VERSION_HISTORY = [
    ("2.3.0"'''
new_history = '''VERSION_HISTORY = [
    ("2.3.1", "补丁：修复AI助手chat_history作用域bug。根本原因：on_clear函数里的nonlocal chat_history声明导致Python认为chat_history是on_send的局部变量，在on_send里访问时报UnboundLocalError。修复：1.on_send函数开头添加nonlocal chat_history声明；2.on_clear改用chat_history.clear()代替重新赋值，避免nonlocal问题"),
    ("2.3.0"'''
c = c.replace(old_history, new_history, 1)

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

# 创建快照
import shutil, os, json
os.makedirs('versions/2.3.1', exist_ok=True)
shutil.copy2('main.py', 'versions/2.3.1/main.py')
shutil.copy2('engine.py', 'versions/2.3.1/engine.py')
shutil.copy2('database.py', 'versions/2.3.1/database.py')
shutil.copy2('logger.py', 'versions/2.3.1/logger.py')

with open('version.json', 'r', encoding='utf-8') as f:
    vj = json.load(f)
vj['latest_version'] = '2.3.1'
with open('version.json', 'w', encoding='utf-8') as f:
    json.dump(vj, f, ensure_ascii=False, indent=2)

print('DG 2.3.1 已发布！')
print('chat_history 作用域 bug 已修复')
