# -*- coding: utf-8 -*-
"""测试 dg_guard.exe 守护能力：杀进程自动拉起 + 删文件自动恢复"""
import subprocess, os, time, tempfile, shutil

deskguard = r'F:\桌面保护\desktopguard'
guard_exe = os.path.join(deskguard, 'dg_guard.exe')
monitor_exe = os.path.join(deskguard, 'dg_monitor.exe')
test_dir = os.path.join(tempfile.gettempdir(), 'dg_guard_test')
backup_dir = os.path.join(test_dir, 'backup')
os.makedirs(backup_dir, exist_ok=True)
heartbeat = os.path.join(test_dir, 'guard_hb.txt')
stop_flag = os.path.join(test_dir, 'stop.flag')

# 清理
for f in (heartbeat, stop_flag):
    if os.path.exists(f):
        os.remove(f)
# 准备监控目标的备份
monitor_backup = os.path.join(backup_dir, 'dg_monitor.exe')
if os.path.exists(monitor_exe):
    shutil.copy2(monitor_exe, monitor_backup)
print("监控目标备份:", os.path.exists(monitor_backup))

# 启动 dg_guard（守护 dg_monitor）
targets = monitor_exe
guard = subprocess.Popen(
    [guard_exe, targets, backup_dir, heartbeat, stop_flag],
    creationflags=0x08000000
)
print("dg_guard 已启动 PID:", guard.pid)
time.sleep(2)

# 1. 检查心跳
print("心跳文件:", os.path.exists(heartbeat))

# 2. dg_monitor 应被自动拉起
time.sleep(1)
def monitor_pids():
    r = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq dg_monitor.exe', '/FO', 'CSV', '/NH'],
                       capture_output=True, text=True, encoding='gbk', errors='ignore')
    return len([l for l in r.stdout.strip().split('\n') if 'dg_monitor' in l.lower()])

pids1 = monitor_pids()
print("dg_monitor 进程数（应≥1）:", pids1)

# 3. 杀掉 dg_monitor → 应被自动拉起
if pids1 > 0:
    subprocess.run(['taskkill', '/F', '/IM', 'dg_monitor.exe'], capture_output=True)
    print("已强制杀死 dg_monitor")
    time.sleep(2.5)
    pids2 = monitor_pids()
    print("杀后 dg_monitor 进程数（应≥1，自动拉起）:", pids2)

# 4. 删除 dg_monitor.exe → 应从备份恢复
if os.path.exists(monitor_exe):
    os.remove(monitor_exe)
    print("已删除 dg_monitor.exe")
    time.sleep(3)
    print("dg_monitor.exe 恢复:", os.path.exists(monitor_exe))

# 5. 心跳持续更新
hb1 = os.path.getmtime(heartbeat) if os.path.exists(heartbeat) else 0
time.sleep(4)
hb2 = os.path.getmtime(heartbeat) if os.path.exists(heartbeat) else 0
print("心跳持续更新:", hb2 > hb1)

# 6. 创建 stop flag → dg_guard 应退出
open(stop_flag, 'w').write('stop')
time.sleep(3)
print("dg_guard 已退出（stop flag）:", guard.poll() is not None)

# 清理
shutil.rmtree(test_dir, ignore_errors=True)
# 杀掉残留 dg_monitor（测试用）
subprocess.run(['taskkill', '/F', '/IM', 'dg_monitor.exe'], capture_output=True)
print("\n守护能力测试完成")
