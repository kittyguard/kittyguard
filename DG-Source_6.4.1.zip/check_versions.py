# -*- coding: utf-8 -*-
import re, os

for ver in ['1.3.7', '1.2.7', '1.2.5', '1.2.6']:
    p = rf'F:\桌面保护\desktopguard\versions\{ver}\main.py'
    if not os.path.exists(p):
        print(f'{ver}: 无快照')
        continue
    c = open(p, encoding='utf-8').read()
    m = re.search(r'VERSION\s*=\s*["\']([^"\']+)', c)
    methods = re.findall(r'\n    def (\w+)', c)
    print(f'=== {ver} === 行数:{len(c.splitlines())} 方法数:{len(methods)}')
    print('  声明版本:', m.group(1) if m else '?')
    print('  方法:', methods[:15])
    # 检查关键功能关键词
    for kw in ['AI', '拦截', 'askyesnocancel', 'scan', '拖拽', 'dnd']:
        if kw.lower() in c.lower():
            pass
    print()
