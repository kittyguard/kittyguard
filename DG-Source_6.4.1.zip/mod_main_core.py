# -*- coding: utf-8 -*-
"""main.py: 深度扫描优先使用 C++ 核心加速"""

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 1. 添加 import scan_core_bridge
if 'import scan_core_bridge' not in c:
    c = c.replace('import realtime_protection', 'import realtime_protection\nimport scan_core_bridge', 1)
    print("1. 添加 import scan_core_bridge 完成")

# 2. 在 _worker 的 producer 之前，插入 C++ 加速逻辑
# 找到 producer 定义
old_producer = '''        # 生产者线程：遍历目录，把文件路径放入任务队列
        def _producer():
            last_disk = None
            for idx, (disk, path, recursive, skip_sys, skip_bulk, appdata_mode) in enumerate(jobs):
                if stop_event.is_set() or self.stop_flag:
                    break
                if disk != last_disk:
                    last_disk = disk
                    self.msg_q.put(("disk", disk))
                for p in engine.enum_files(path, recursive=recursive, skip_system=skip_sys,
                                           skip_bulk=skip_bulk, appdata_mode=appdata_mode):
                    if stop_event.is_set() or self.stop_flag:
                        break
                    if skip_bytes > 0:
                        try:
                            if os.path.getsize(p) > skip_bytes:
                                result_q.put(("skip", p))
                                continue
                        except OSError:
                            pass
                    task_q.put(p)
            for _ in range(WORKER_COUNT):
                task_q.put(None)  # 结束标记'''

new_producer = '''        # ===== C++ 加速核心：深度扫描优先用 scan_core.exe 全盘遍历+哈希 =====
        _core_files = None  # list of scan_core_bridge.CoreFileInfo
        if mode == "deep" and not is_custom:
            try:
                if scan_core_bridge.has_scan_core():
                    self.msg_q.put(("status", "C++ 加速核心已启用，正在快速遍历所有磁盘…", C_PRIMARY))
                    _core_files, _core_stats = scan_core_bridge.run_scan_core(
                        drives, "deep",
                        cancel_event=stop_event,
                        max_seconds=1800,
                    )
                    if _core_files is not None:
                        self.msg_q.put(("status",
                            f"C++ 核心遍历完成：{len(_core_files)} 个文件，进入规则分析…", C_PRIMARY))
            except Exception:
                _core_files = None
        # 预计算哈希映射：path -> sha256
        _core_hash_map = {}
        if _core_files is not None:
            for _f in _core_files:
                if _f.sha256:
                    _core_hash_map[_f.path] = _f.sha256

        # 生产者线程：遍历目录，把文件路径放入任务队列
        def _producer():
            last_disk = None
            if _core_files is not None:
                # C++ 已枚举：直接使用文件列表（deep 模式过滤规则与 C++ 一致）
                for _f in _core_files:
                    if stop_event.is_set() or self.stop_flag:
                        break
                    disk = engine.drive_of(_f.path)
                    if disk != last_disk:
                        last_disk = disk
                        self.msg_q.put(("disk", disk))
                    if skip_bytes > 0 and _f.size > skip_bytes:
                        result_q.put(("skip", _f.path))
                        continue
                    task_q.put((_f.path, _f.sha256))
                for _ in range(WORKER_COUNT):
                    task_q.put(None)
                return
            for idx, (disk, path, recursive, skip_sys, skip_bulk, appdata_mode) in enumerate(jobs):
                if stop_event.is_set() or self.stop_flag:
                    break
                if disk != last_disk:
                    last_disk = disk
                    self.msg_q.put(("disk", disk))
                for p in engine.enum_files(path, recursive=recursive, skip_system=skip_sys,
                                           skip_bulk=skip_bulk, appdata_mode=appdata_mode):
                    if stop_event.is_set() or self.stop_flag:
                        break
                    if skip_bytes > 0:
                        try:
                            if os.path.getsize(p) > skip_bytes:
                                result_q.put(("skip", p))
                                continue
                        except OSError:
                            pass
                    task_q.put((p, ""))
            for _ in range(WORKER_COUNT):
                task_q.put(None)  # 结束标记'''

if old_producer in c:
    c = c.replace(old_producer, new_producer, 1)
    print("2. 生产者线程 C++ 加速接入完成")
else:
    print("2. 未找到生产者线程匹配，跳过！")

# 3. 消费者线程：task_q 现在传 (path, sha256_pre)
old_consumer2 = '''        # 消费者线程：从任务队列取出文件路径，扫描，把结果放入结果队列
        def _consumer():
            _processed = 0
            while True:
                p = task_q.get()
                if p is None:
                    break
                if stop_event.is_set() or self.stop_flag:
                    continue
                try:
                    r = scanner.scan_file(p)
                except Exception:
                    r = engine.ScanResult(path=p, name=os.path.basename(p),
                                          ext=os.path.splitext(p)[1].lower(),
                                          category="普通文件", size=0, sha256="")
                result_q.put(("result", r))
                _processed += 1
                if _processed % 50 == 0:
                    time.sleep(0.005)'''

new_consumer2 = '''        # 消费者线程：从任务队列取出文件路径，扫描，把结果放入结果队列
        def _consumer():
            _processed = 0
            while True:
                item = task_q.get()
                if item is None:
                    break
                p = item[0] if isinstance(item, tuple) else item
                _sha_pre = item[1] if isinstance(item, tuple) else ""
                if stop_event.is_set() or self.stop_flag:
                    continue
                try:
                    r = scanner.scan_file(p, sha256_pre=_sha_pre)
                except Exception:
                    r = engine.ScanResult(path=p, name=os.path.basename(p),
                                          ext=os.path.splitext(p)[1].lower(),
                                          category="普通文件", size=0, sha256="")
                result_q.put(("result", r))
                _processed += 1
                if _processed % 50 == 0:
                    time.sleep(0.005)'''

if old_consumer2 in c:
    c = c.replace(old_consumer2, new_consumer2, 1)
    print("3. 消费者线程支持预计算哈希完成")
else:
    print("3. 未找到消费者线程匹配，跳过！")

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print("\nmain.py C++ 加速接入完成")
