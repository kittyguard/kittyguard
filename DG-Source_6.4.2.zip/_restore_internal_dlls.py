# -*- coding: utf-8 -*-
"""6.4.2 修复：恢复被实时防护误隔离的便携版 _internal DLL（api-ms-win-core-*）
并验证恢复结果。隔离门槛 bug 在 main.py 已修复（DG 自身目录豁免）。"""
import sys, os, json
sys.path.insert(0, r"F:\桌面保护\desktopguard")
import database

QUARANTINE_DIR = database.QUARANTINE_DIR
META_DIR = os.path.join(QUARANTINE_DIR, "_meta")

def find_meta(sha256):
    """在 _meta 里按 sha256 找元数据（兼容 .dgq.meta.json 命名）。"""
    if not os.path.isdir(META_DIR):
        return None
    for fn in os.listdir(META_DIR):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(META_DIR, fn), "r", encoding="utf-8") as f:
                m = json.load(f)
            if m.get("sha256") == sha256 and m.get("original_path", "").lower().endswith(".dll"):
                return m
        except Exception:
            continue
    return None

def find_dgq(sha256):
    """按 sha256 前缀在隔离区找 .dgq 文件。"""
    if not os.path.isdir(QUARANTINE_DIR):
        return None
    pref = sha256[:16]
    for fn in os.listdir(QUARANTINE_DIR):
        if fn.lower().endswith(".dgq") and fn.startswith(pref):
            return os.path.join(QUARANTINE_DIR, fn)
    return None

# 5 个被误隔离的 api-ms-win-core DLL（来自隔离区元数据实证）
targets = [
    ("console",        "6df76986aec08e89ea037bc5271caaa82c69bd7eefba4fc293f92de1b1213e5e"),
    ("datetime",       "c541697c3e9086c6483e88d9cc8fe8a2efc74f663da0b0662babc04d3f79000f"),
    ("fibers",         "cbb6cb7ff25363b07647ea05d01f2881837d50b04bba4debe875a4aa3a307c52"),
    ("errorhandling",  "cdae6e7d24d4ca4b491d483135740cc60f2dfc74dd2e01779e655b9f8f85a337"),
    ("debug",          "fed0c40d172de4de52dc2230c5c92fd6bc8e8553619d5bb5240dcc4f025dc8cf"),
]

print("== 恢复前检查 ==")
for name, sha in targets:
    meta = find_meta(sha)
    if not meta:
        print(f"[{name}] 元数据未找到（跳过）")
        continue
    dest = meta["original_path"]
    dgq = find_dgq(sha)
    print(f"[{name}] dest={dest} 存在={os.path.exists(dest)} dgq={'存在' if dgq else '缺失'}")

print()
print("== 执行恢复（database.restore_file 按 id）==")
conn = database.get_db()
rows = conn.execute(
    "SELECT id, original_path, status FROM quarantine "
    "WHERE original_path LIKE '%DG安全\\_internal%' ORDER BY id"
).fetchall()
if not rows:
    # PG 后端路径可能是正斜杠
    rows = conn.execute(
        "SELECT id, original_path, status FROM quarantine "
        "WHERE original_path LIKE '%DG安全%_internal%' ORDER BY id"
    ).fetchall()
for r in rows:
    ok, msg = database.restore_file(r["id"])
    print(f"id={r['id']} status={r['status']} -> {ok} | {msg} | {r['original_path']}")
conn.close()

print()
print("== 恢复后验证 ==")
for name, sha in targets:
    meta = find_meta(sha)
    if not meta:
        continue
    dest = meta["original_path"]
    if os.path.exists(dest):
        sz = os.path.getsize(dest)
        print(f"[{name}] 已还原: {dest} ({sz}B) OK")
    else:
        print(f"[{name}] 仍缺失: {dest}")
