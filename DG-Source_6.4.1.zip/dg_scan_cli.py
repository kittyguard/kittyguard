# -*- coding: utf-8 -*-
"""
DG 右键操作器 (dg_scan_cli.py)
================================
供 Windows 右键菜单「DG 安全」二级菜单调用：
    pythonw.exe dg_scan_cli.py --scan      "<文件或文件夹路径>"
    pythonw.exe dg_scan_cli.py --quarantine "<文件路径>"
    pythonw.exe dg_scan_cli.py --trust     "<文件路径>"
    pythonw.exe dg_scan_cli.py --sandbox   "<文件路径>"
    pythonw.exe dg_scan_cli.py --shred     "<文件路径>"
对目标做对应处置，结果用置顶弹窗展示。
独立运行，不依赖主程序进程；无界面时静默完成。
注册：  pythonw.exe dg_scan_cli.py --install
卸载：  pythonw.exe dg_scan_cli.py --uninstall
"""

import os
import sys
import tkinter as tk
from tkinter import messagebox

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

APP_TITLE = "DG 安全 · 右键操作"


def _popup(title, msg, warn=False):
    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        root.update()
        if warn:
            messagebox.showwarning(title, msg, parent=root)
        else:
            messagebox.showinfo(title, msg, parent=root)
        root.destroy()
    except Exception:
        pass


def _target(args):
    """取右键传入的路径参数（%1）。"""
    for a in args:
        if a.startswith("--"):
            continue
        return a.strip('"')
    return None


# ---------------------------------------------------------------- 快速扫描
def _scan(target: str):
    try:
        import engine
    except Exception as e:
        _popup(APP_TITLE, f"引擎加载失败：{e}")
        return

    if not os.path.exists(target):
        _popup(APP_TITLE, f"路径不存在：\n{target}")
        return

    if os.path.isdir(target):
        try:
            from scanner import Scanner
            sc = Scanner()
            results = sc.scan_dir(target)
            risky = [r for r in results if r.level in (engine.LEVEL_CRIT, engine.LEVEL_HIGH)]
            total = len(results)
            if not risky:
                _popup(APP_TITLE, f"扫描完成：{total} 个文件，未发现风险。\n\n{target}")
            else:
                lines = [f"发现 {len(risky)} 个风险文件（共扫 {total}）："]
                for r in risky[:12]:
                    lines.append(f"  [{r.level}] {os.path.basename(r.path)}")
                if len(risky) > 12:
                    lines.append(f"  …还有 {len(risky) - 12} 个")
                lines.append("")
                lines.append("可打开 DG 主程序→扫描页→隔离区/删除威胁 处理。")
                _popup(APP_TITLE + " · 发现风险", "\n".join(lines), warn=True)
        except Exception as e:
            _popup(APP_TITLE, f"目录扫描失败：{e}")
        return

    try:
        from engine import Scanner
        sc = Scanner()
        r = sc.scan_file(target)
    except Exception:
        try:
            from engine import scan_file
            r = scan_file(target)
        except Exception as e:
            _popup(APP_TITLE, f"扫描失败：{e}")
            return
    level = getattr(r, "level", "未知")
    score = getattr(r, "score", None)
    tags = getattr(r, "tags", []) or []
    if level in (engine.LEVEL_CRIT, engine.LEVEL_HIGH):
        msg = (f"风险等级：{level}\n"
               + (f"风险分：{score}\n" if score is not None else "")
               + (f"特征：{', '.join(tags)}\n" if tags else "")
               + f"\n文件：{target}")
        _popup(APP_TITLE + " · 高危", msg, warn=True)
    else:
        msg = f"扫描结果：{level}"
        if score is not None:
            msg += f"（{score} 分）"
        if tags:
            msg += f"\n特征：{', '.join(tags)}"
        msg += f"\n\n文件：{target}"
        _popup(APP_TITLE, msg)


# ---------------------------------------------------------------- 移入隔离区
def _quarantine(target: str):
    if os.path.isdir(target):
        _popup(APP_TITLE, "移入隔离区仅支持单个文件。\n如需扫描整个文件夹，请使用「DG 安全 → 快速扫描」。")
        return
    if not os.path.isfile(target):
        _popup(APP_TITLE, f"文件不存在：\n{target}", warn=True)
        return
    try:
        import database
        success, msg = database.quarantine_file(
            target, sha256="", threat_level="右键手动隔离", reason="右键菜单手动移入隔离区")
        if success:
            _popup(APP_TITLE, f"已移入隔离区\n\n{os.path.basename(target)}\n\n可打开 DG 主程序→隔离区 恢复或彻底删除。")
        else:
            _popup(APP_TITLE, f"隔离失败：{msg}", warn=True)
    except Exception as e:
        _popup(APP_TITLE, f"隔离失败：{e}", warn=True)


# ---------------------------------------------------------------- 加入白名单
def _trust(target: str):
    if os.path.isdir(target):
        _popup(APP_TITLE, "加入白名单仅支持单个文件。")
        return
    if not os.path.isfile(target):
        _popup(APP_TITLE, f"文件不存在：\n{target}", warn=True)
        return
    try:
        import database
        try:
            import engine
            sha = engine.sha256_of(target)
        except Exception:
            sha = ""
        if not sha:
            import hashlib
            try:
                with open(target, "rb") as f:
                    sha = hashlib.sha256(f.read()).hexdigest()
            except Exception:
                sha = ""
        if not sha:
            _popup(APP_TITLE, "计算哈希失败，无法加入白名单。", warn=True)
            return
        database.add_whitelist(sha, target)
        _popup(APP_TITLE, f"已加入白名单（信任该文件）\n\n{os.path.basename(target)}\n\n之后 DG 将不再提示该文件。")
    except Exception as e:
        _popup(APP_TITLE, f"加入白名单失败：{e}", warn=True)


# ---------------------------------------------------------------- 沙箱行为分析
def _sandbox(target: str):
    if os.path.isdir(target):
        _popup(APP_TITLE, "沙箱行为分析仅支持单个文件。")
        return
    if not os.path.isfile(target):
        _popup(APP_TITLE, f"文件不存在：\n{target}", warn=True)
        return
    try:
        import sandbox_runner
    except Exception as e:
        _popup(APP_TITLE, f"沙箱模块未安装或加载失败：{e}", warn=True)
        return
    try:
        if not sandbox_runner.is_sandbox_available():
            _popup(APP_TITLE, "沙盒引擎当前不可用（sandbox_runner.exe 缺失，且 Windows Sandbox 未启用）。\n\n"
                              "可在 DG 主程序→工具页→环境体检 查看启用指引。", warn=True)
            return
    except Exception:
        _popup(APP_TITLE, "沙盒引擎状态检测失败。", warn=True)
        return
    _popup(APP_TITLE, f"正在沙箱中运行 {os.path.basename(target)}…\n\n"
                      "沙箱内会记录文件/进程/注册表/网络行为，请稍候（最长约 2 分钟）。")
    try:
        res = sandbox_runner.run_sample_in_sandbox(target, timeout=120)
        work_dir = res.get("work_dir", "")
        be = res.get("behavior", {}) or {}
        count = be.get("total_actions", 0)
        if res.get("success") or count:
            lines = [f"沙箱行为分析完成（{count} 条行为）："]
            for key, label in (("files_created", "新建文件"), ("files_modified", "修改文件"),
                               ("registry", "注册表写入"), ("network", "网络连接"),
                               ("processes", "新建进程")):
                v = be.get(key)
                if isinstance(v, list) and v:
                    lines.append(f"  {label}：{len(v)} 条")
                    for it in v[:6]:
                        lines.append(f"    - {str(it)[:90]}")
            lines.append(f"\n工作目录：{work_dir}")
            _popup(APP_TITLE + " · 沙箱报告", "\n".join(lines))
        else:
            err = res.get("error") or res.get("msg") or "未知错误"
            _popup(APP_TITLE, f"沙箱运行失败：{err}", warn=True)
    except Exception as e:
        _popup(APP_TITLE, f"沙箱分析异常：{e}", warn=True)


# ---------------------------------------------------------------- 彻底粉碎
def _shred(target: str):
    if os.path.isdir(target):
        _popup(APP_TITLE, "文件粉碎仅支持单个文件。")
        return
    if not os.path.isfile(target):
        _popup(APP_TITLE, f"文件不存在：\n{target}", warn=True)
        return
    try:
        import shred
        ok, fails = shred.shred_files([target])
        if ok:
            _popup(APP_TITLE, f"已彻底粉碎（多次覆写后删除，常规手段不可恢复）：\n\n{os.path.basename(target)}")
        else:
            reason = fails[0][1] if fails else "未知原因"
            _popup(APP_TITLE, f"粉碎失败：{reason}\n\n{os.path.basename(target)}", warn=True)
    except Exception as e:
        _popup(APP_TITLE, f"粉碎失败：{e}", warn=True)


# ---------------------------------------------------------------- 注册 / 卸载
MENU_NAME = "DG 安全"
SUB_COMMANDS = "DGScan;DGQuarantine;DGTrust;DGSandbox;DGShred"


def _reg_command(store_root, name, display, args):
    """在 CommandStore 注册一个子命令。"""
    import winreg
    k = winreg.CreateKey(winreg.HKEY_CURRENT_USER,
                         store_root + "\\" + name)
    winreg.SetValue(k, "", winreg.REG_SZ, display)
    kc = winreg.CreateKey(winreg.HKEY_CURRENT_USER,
                          store_root + "\\" + name + "\\command")
    cmd = f'"{sys.executable}" "{os.path.abspath(__file__)}" {args} "%1"'
    winreg.SetValue(kc, "", winreg.REG_SZ, cmd)
    winreg.CloseKey(kc)
    winreg.CloseKey(k)


def _reg_shell_menu(shell_root):
    """注册文件(*)或文件夹(Directory)的 DG 二级菜单。"""
    import winreg
    k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, shell_root)
    winreg.SetValue(k, "", winreg.REG_SZ, MENU_NAME)
    winreg.SetValueEx(k, "Icon", 0, winreg.REG_SZ, sys.executable)
    winreg.SetValueEx(k, "SubCommands", 0, winreg.REG_SZ, SUB_COMMANDS)
    winreg.SetValueEx(k, "MultiSelectModel", 0, winreg.REG_SZ, "Player")
    winreg.CloseKey(k)


def _install():
    """注册「DG 安全」二级右键菜单（HKCU，仅当前用户，可逆）。"""
    import winreg
    store = r"Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell"
    try:
        # 子命令（CommandStore）
        _reg_command(store, "DGScan", "快速扫描", "--scan")
        _reg_command(store, "DGQuarantine", "移入隔离区", "--quarantine")
        _reg_command(store, "DGTrust", "加入白名单", "--trust")
        _reg_command(store, "DGSandbox", "沙箱行为分析", "--sandbox")
        _reg_command(store, "DGShred", "彻底粉碎", "--shred")
        # 文件右键 + 文件夹右键
        _reg_shell_menu(r"Software\Classes\*\shell\DGShell")
        _reg_shell_menu(r"Software\Classes\Directory\shell\DGShell")
        # 兼容清理旧的单命令键
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Classes\*\shell\DGScan\command")
        except Exception:
            pass
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Classes\*\shell\DGScan")
        except Exception:
            pass
        _popup(APP_TITLE, "已注册右键二级菜单「DG 安全」。\n\n"
                          "现在对任意文件/文件夹点右键 → DG 安全，可：\n"
                          "  · 快速扫描\n  · 移入隔离区\n  · 加入白名单\n"
                          "  · 沙箱行为分析\n  · 彻底粉碎\n\n"
                          "卸载：右键菜单里移除（或运行 --uninstall）")
        return True
    except Exception as e:
        _popup(APP_TITLE, f"注册失败：{e}", warn=True)
        return False


def _uninstall():
    import winreg
    store = r"Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell"
    for name in ("DGScan", "DGQuarantine", "DGTrust", "DGSandbox", "DGShred"):
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, store + "\\" + name + "\\command")
        except Exception:
            pass
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, store + "\\" + name)
        except Exception:
            pass
    for shell in (r"Software\Classes\*\shell\DGShell",
                  r"Software\Classes\Directory\shell\DGShell"):
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, shell)
        except Exception:
            pass
    # 兼容清理旧单命令键
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER,
                         r"Software\Classes\*\shell\DGScan\command")
    except Exception:
        pass
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER,
                         r"Software\Classes\*\shell\DGScan")
    except Exception:
        pass
    _popup(APP_TITLE, "已移除右键菜单「DG 安全」")


if __name__ == "__main__":
    args = sys.argv[1:]
    if "--install" in args:
        _install()
    elif "--uninstall" in args:
        _uninstall()
    else:
        target = _target(args)
        if not target:
            _popup(APP_TITLE, "用法：右键任意文件 → DG 安全 → 选择操作")
        elif "--quarantine" in args:
            _quarantine(target)
        elif "--trust" in args:
            _trust(target)
        elif "--sandbox" in args:
            _sandbox(target)
        elif "--shred" in args:
            _shred(target)
        else:
            _scan(target)
