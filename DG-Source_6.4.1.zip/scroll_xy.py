# -*- coding: utf-8 -*-
"""真实桌面滚动：python scroll_xy.py 150 300 -5（负=向下，一格约120行）"""
import ctypes, sys, time

user32 = ctypes.windll.user32
sw = user32.GetSystemMetrics(0)
sh = user32.GetSystemMetrics(1)
x = int(int(sys.argv[1]) / 1000 * sw)
y = int(int(sys.argv[2]) / 1000 * sh)
delta = int(sys.argv[3]) if len(sys.argv) > 3 else -5
user32.SetCursorPos(x, y)
time.sleep(0.2)
for _ in range(abs(delta)):
    user32.mouse_event(0x0800, 0, 0, 120 if delta > 0 else -120, 0)  # WHEEL
    time.sleep(0.08)
print("SCROLLED", x, y, delta)
