# -*- coding: utf-8 -*-
"""
DG安全 3.0 —— AI 行为分析闭环
================================
模块职责：
1. 从 ~/.desktopguard/ai_config.json 加载 DeepSeek 配置（不抛异常）
2. 结构化采集进程/文件/注册表/网络行为事件（BehaviorEvent）
3. local_behavior_score()：本地规则初判（GTI 巡查思路，本地优先）
4. analyze_behavior()：本地初判 + 高风险/多事件时调用 DeepSeek 深度分析，
   任何异常都降级回本地结果，绝不中断主程序
5. analyze_behavior_batch()：批量分析，带 0.5s 速率控制
6. should_trigger_alert()：高危动作触发判定

硬约束：
- 仅使用标准库（urllib / json / os / time / re）
- API Key 只从配置文件读取，不硬编码
- 只传结构化特征，不上传文件内容
"""

from paths import DATA_DIR
import os
import re
import json
import time
import urllib.request
import urllib.error

# ---- 日志（同目录 logger.py，导入失败时降级为静默，保证模块可独立导入）----
try:
    from logger import app_logger
except Exception:  # pragma: no cover - 兜底
    class _NullLogger(object):
        def info(self, *a, **k): pass
        def warning(self, *a, **k): pass
        def error(self, *a, **k): pass
        def debug(self, *a, **k): pass
    app_logger = _NullLogger()


# ======================================================================
# 1. 配置加载
# ======================================================================

AI_CONFIG_PATH = os.path.join(DATA_DIR, "ai_config.json")

# 本地缓存的配置，避免每次分析都读盘
_cached_config = None


def load_ai_config(config_path: str = None) -> dict:
    """
    加载 AI 配置。任何异常都返回空 dict，绝不抛异常。
    返回: {"enabled": bool, "api_key": str, "api_url": str, "model": str}
    """
    global _cached_config
    if config_path is None:
        config_path = AI_CONFIG_PATH
        if _cached_config is not None:
            return _cached_config

    cfg = {"enabled": False, "api_key": "", "api_url": "", "model": "deepseek-chat"}
    try:
        if not os.path.exists(config_path):
            return cfg
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        cfg["enabled"] = bool(data.get("ai_enabled", False))
        cfg["api_key"] = str(data.get("ai_api_key", "") or "").strip()
        cfg["api_url"] = str(data.get("ai_api_url", "") or "").strip()
        cfg["model"] = str(data.get("ai_model", "deepseek-chat") or "deepseek-chat").strip()
        # 开关打开但缺少 key/url 视为不可用
        if not cfg["api_key"] or not cfg["api_url"]:
            cfg["enabled"] = False
    except Exception as e:
        try:
            app_logger.warning(f"[AI行为分析] 配置读取失败，降级本地模式: {e}")
        except Exception:
            pass
        cfg = {"enabled": False, "api_key": "", "api_url": "", "model": "deepseek-chat"}

    if config_path == AI_CONFIG_PATH:
        _cached_config = cfg
    return cfg


def reload_ai_config() -> dict:
    """强制重新读取配置（配置变更后调用）。"""
    global _cached_config
    _cached_config = None
    return load_ai_config()


# ======================================================================
# 2. 行为数据结构（BehaviorEvent，使用 dict）
# ======================================================================
# {
#   "timestamp": "2026-09-09 22:00:00",
#   "event_type": "process_create|file_write|file_create|network_connect|registry_write",
#   "process_name": "...",
#   "process_path": "...",
#   "pid": 1234,
#   "target_path": "...",        # 文件目标
#   "target_registry": "...",     # 注册表目标
#   "remote_ip": "...",           # 网络目标
#   "remote_port": 0,
#   "command_line": "...",
#   "parent_process": "..."
# }

# 已知/常见 C2 端口（启发式，非穷举）
_C2_PORTS = {4444, 1337, 6666, 8443, 9001, 4443, 5900, 12345, 54321, 27374}

# 敏感文件/目录特征（本地凭据、浏览器密码库）
_SENSITIVE_TARGETS = [
    (r"login data", "浏览器密码库(Login Data)"),
    (r"logins\.json", "火狐密码库(logins.json)"),
    (r"key4\.db", "火狐密钥库(key4.db)"),
    (r"places\.sqlite", "浏览器历史数据库"),
    (r"cookies", "浏览器Cookie数据"),
    (r"web data", "浏览器Web数据"),
    (r"\\config\\sam", "系统SAM凭据文件"),
    (r"\\config\\security", "系统安全 hive"),
    (r"ntds\.dit", "域控NTDS数据库"),
    (r"\.ssh\\", "SSH密钥目录"),
    (r"id_rsa", "SSH私钥"),
]

# 伪装系统进程
_IMPERSONATION = [
    (r"svch0st\.exe", "伪装 svchost.exe"),
    (r"expl0rer\.exe", "伪装 explorer.exe"),
    (r"ls4ss\.exe", "伪装 lsass.exe"),
    (r"csrs5\.exe", "伪装 csrss.exe"),
    (r"winl0gon\.exe", "伪装 winlogon.exe"),
    (r"smss5\.exe", "伪装 smss.exe"),
    (r"chrome_upd[a-z0-9_]*\.exe", "伪装 Chrome 更新程序"),
    (r"windows_update[a-z0-9_]*\.exe", "伪装 Windows 更新"),
    (r"security_[a-z0-9_]*\.exe", "伪装安全软件"),
]

# 可疑命令行特征
_SUSPICIOUS_CMDS = [
    (r"-enc(odedcommand)?\b", "PowerShell 编码执行"),
    (r"bypass", "绕过执行策略(-ExecutionPolicy Bypass)"),
    (r"hidden", "隐藏窗口执行"),
    (r"frombase64string", "Base64 解码执行"),
    (r"\biex\s*\(", "Invoke-Expression 执行"),
    (r"invoke-expression", "Invoke-Expression 执行"),
    (r"downloadstring", "远程下载执行(DownloadString)"),
    (r"downloadfile", "远程下载文件"),
    (r"mshta", "mshta 白名单绕过"),
    (r"regsvr32", "regsvr32 白名单绕过"),
    (r"rundll32", "rundll32 加载执行"),
    (r"certutil", "certutil 下载/解码"),
]

# 反分析/延迟执行特征
_ANTI_ANALYSIS = [
    (r"isdebuggerpresent", "调试器检测"),
    (r"checkremote调试", "调试器检测"),
    (r"vmware|virtualbox|vbox|qemu|vmtools", "虚拟机环境检测"),
    (r"\bsleep\s*\(", "主动休眠延迟执行"),
    (r"timeout\s*/?t", "timeout 延迟执行"),
    (r"ping\s+-n", "ping 延迟绕过"),
]

# 持久化目标特征
_PERSISTENCE = [
    (r"\\run\\", "注册表 Run 启动项"),
    (r"\\runonce\\", "注册表 RunOnce 启动项"),
    (r"\\currentversion\\run", "注册表 Run 启动项"),
    (r"\\startup", "启动目录"),
    (r"startupfolder", "用户启动目录"),
    (r"schtasks|计划任务", "计划任务持久化"),
]


def _norm(text: str) -> str:
    """路径/字符串归一化：转小写、正斜杠转反斜杠。"""
    if not text:
        return ""
    return str(text).replace("/", "\\").lower()


def _is_temp_path(path: str) -> bool:
    """是否来自临时/下载目录。"""
    p = _norm(path)
    if not p:
        return False
    return ("\\temp\\" in p) or ("\\tmp\\" in p) or ("\\windows\\temp\\" in p) \
        or ("\\appdata\\local\\temp\\" in p) or ("\\downloads\\" in p)


def _hour_of(ts: str):
    """从 'YYYY-MM-DD HH:MM:SS' 提取小时；失败返回 None。"""
    try:
        # 形如 2026-09-09 22:00:00
        m = re.search(r"(\d{1,2}):\d{1,2}:\d{1,2}", str(ts or ""))
        if m:
            return int(m.group(1))
        # 形如 epoch 秒
        return time.localtime(float(ts)).tm_hour
    except Exception:
        return None


# ======================================================================
# 3. 本地行为判定（GTI 巡查思路，本地规则优先）
# ======================================================================

def local_behavior_score(events: list) -> dict:
    """
    对一组行为事件做本地规则分析。
    返回: {"score": 0-100, "risk_level": "low/medium/high",
           "flags": [...], "reason": "..."}
    空列表 / 异常输入一律返回低风险，不抛异常。
    """
    score = 0
    flags = []

    if not events or not isinstance(events, list):
        return {"score": 0, "risk_level": "low",
                "flags": [], "reason": "无行为事件，默认低风险"}

    try:
        proc_names = [_norm(e.get("process_name", "")) for e in events]
        proc_paths = [_norm(e.get("process_path", "")) for e in events]
        cmds = [_norm(e.get("command_line", "")) for e in events]
        tgt_paths = [_norm(e.get("target_path", "")) for e in events]
        tgt_regs = [_norm(e.get("target_registry", "")) for e in events]
        etypes = [e.get("event_type", "") for e in events]

        joined_cmd = " ".join(c for c in cmds if c)
        joined_path = " ".join(p for p in proc_paths if p)
        joined_tgt = " ".join(t for t in tgt_paths if t)
        joined_reg = " ".join(r for r in tgt_regs if r)

        has_proc_create = "process_create" in etypes
        has_file_create = "file_create" in etypes
        has_file_write = "file_write" in etypes
        has_net = "network_connect" in etypes
        has_reg = "registry_write" in etypes

        # ---- 3.1 触发时机合理性：临时目录执行 / 非工作时间 ----
        temp_exec = any(_is_temp_path(p) for p in proc_paths)
        if temp_exec:
            score += 25
            flags.append("来自临时/下载目录的可执行文件")
        night = False
        for e in events:
            h = _hour_of(e.get("timestamp", ""))
            if h is not None and (h < 6 or h >= 23):
                night = True
                break
        if night:
            score += 10
            flags.append("非工作时间(深夜)启动")

        # ---- 3.2 伪装系统进程 ----
        for pat, desc in _IMPERSONATION:
            if re.search(pat, " ".join(proc_names)):
                score += 30
                flags.append(desc)
                break

        # ---- 3.3 可疑命令行（编码执行/远程下载/白名单绕过）----
        for pat, desc in _SUSPICIOUS_CMDS:
            if re.search(pat, joined_cmd):
                score += 20
                flags.append(desc)
                break  # 命中一类即可，避免叠加过多

        # ---- 3.4 行为链连贯性：下载 → 落地 → 执行 ----
        if has_net and has_file_create and temp_exec and has_proc_create:
            score += 25
            flags.append("下载→临时目录落地→执行 完整攻击链")

        # ---- 3.5 权限访问：敏感凭据/浏览器密码 ----
        for pat, desc in _SENSITIVE_TARGETS:
            if re.search(pat, joined_tgt):
                score += 30
                flags.append(desc)
                break

        # ---- 3.6 持久化：启动项/计划任务/Run 键 ----
        for pat, desc in _PERSISTENCE:
            if re.search(pat, joined_reg) or re.search(pat, joined_tgt):
                score += 30
                flags.append(desc)
                break

        # ---- 3.7 网络行为：异常 C2 端口 ----
        bad_port = False
        for e in events:
            try:
                if int(e.get("remote_port", 0) or 0) in _C2_PORTS:
                    bad_port = True
                    break
            except Exception:
                continue
        if bad_port:
            score += 20
            flags.append("连接常见 C2 异常端口")

        # ---- 3.8 反分析 / 延迟执行 ----
        for pat, desc in _ANTI_ANALYSIS:
            if re.search(pat, joined_cmd):
                score += 15
                flags.append(desc)
                break

        # ---- 3.9 自删除行为 ----
        if re.search(r"\bdel\b.*%0%|\brm\b.*-rf|selfdelete|/c del", joined_cmd) \
                or ("del " in joined_cmd and ".exe" in joined_cmd):
            score += 20
            flags.append("疑似自删除(痕迹清理)")

        # ---- 3.10 事件数量加权 ----
        if len(events) >= 8:
            score += 10
            flags.append(f"行为事件密集({len(events)}条)")
        elif len(events) >= 5:
            score += 5

        # 封顶
        score = max(0, min(100, int(score)))

        # 风险等级划分（本地三档）
        if score >= 60:
            level = "high"
        elif score >= 30:
            level = "medium"
        else:
            level = "low"

        reason = "；".join(flags) if flags else "未命中高风险规则"
        return {"score": score, "risk_level": level,
                "flags": flags, "reason": reason}
    except Exception as e:
        # 本地规则本身绝不能把主程序打挂
        try:
            app_logger.warning(f"[AI行为分析] 本地规则分析异常: {e}")
        except Exception:
            pass
        return {"score": 0, "risk_level": "low",
                "flags": [], "reason": "本地分析异常，按低风险处理"}


def _local_to_action(level: str) -> str:
    """本地等级 → 建议动作。"""
    return {"low": "allow", "medium": "monitor",
            "high": "quarantine"}.get(level, "monitor")


# ======================================================================
# 4. AI 深度分析
# ======================================================================

_SYSTEM_PROMPT = (
    "你是专业的 Windows 恶意软件行为分析师。根据给定的结构化进程/文件/注册表/网络行为日志，"
    "结合本地规则初判结果，判断该进程/文件的真实风险。"
    "只输出一个 JSON 对象，不要输出任何解释性文字或 Markdown 代码块。"
    '输出格式：{"risk_level":"low|medium|high|critical",'
    '"reason":"简要中文理由",'
    '"suggested_action":"quarantine|terminate|monitor|allow",'
    '"confidence":0.0到1.0之间的浮点数,'
    '"indicators":["威胁指标1","威胁指标2"]}'
)


def _build_user_content(events: list, local: dict, context: dict) -> str:
    """构造用户消息：结构化事件 + 本地初判 + 上下文（不含文件内容）。"""
    lines = []
    lines.append("【结构化行为事件列表】(仅特征，不含文件内容)：")
    for i, e in enumerate(events[:30], 1):  # 最多带 30 条，控制 token
        lines.append(f"{i}. {json.dumps(e, ensure_ascii=False)}")
    lines.append("")
    lines.append("【本地规则初判】：" + json.dumps(local, ensure_ascii=False))
    if context:
        # 只取上下文里的元信息字段，避免误传文件内容
        safe_ctx = {k: v for k, v in context.items()
                    if k in ("file_name", "file_path", "sha256", "md5",
                             "file_size", "file_hash", "whitelisted", "source")}
        if safe_ctx:
            lines.append("【上下文】：" + json.dumps(safe_ctx, ensure_ascii=False))
    lines.append("")
    lines.append("请输出风险判断 JSON。")
    return "\n".join(lines)


def _extract_json(text: str) -> dict:
    """从 AI 返回文本中提取 JSON 对象（兼容 ```json 代码块包裹）。"""
    if not text:
        raise ValueError("空响应")
    # 去掉 markdown 代码块
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*", "", t)
    t = re.sub(r"\s*```$", "", t)
    # 优先整体解析
    try:
        return json.loads(t)
    except Exception:
        pass
    # 兜底：抓取第一个 { ... } 块
    m = re.search(r"\{.*\}", t, re.DOTALL)
    if m:
        return json.loads(m.group(0))
    raise ValueError("无法解析 AI 返回为 JSON")


def _call_deepseek(api_url: str, api_key: str, model: str,
                   system_prompt: str, user_content: str) -> str:
    """
    调用 DeepSeek（OpenAI 兼容 chat completions）。
    返回 content 文本；失败抛异常，由上层降级。
    """
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        "temperature": 0.3,
        "max_tokens": 1024,
    }
    req = urllib.request.Request(
        api_url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=8) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    data = json.loads(raw)
    return data["choices"][0]["message"]["content"]


def analyze_behavior(events: list, context: dict = None) -> dict:
    """
    AI 行为分析主入口：
      1. 先做本地初判
      2. 本地分数 >= 40 或事件数 >= 5 且 AI 可用 → 调用 DeepSeek 深度分析
      3. 任何失败都降级回本地结果
    返回统一格式（见模块 docstring / 验收标准）。
    """
    # 统一兜底结果骨架
    local = local_behavior_score(events or [])
    fallback = {
        "risk_level": local["risk_level"],
        "reason": local["reason"],
        "suggested_action": _local_to_action(local["risk_level"]),
        "confidence": 0.5 if local["risk_level"] != "low" else 0.8,
        "local_score": local["score"],
        "ai_analyzed": False,
        "indicators": local["flags"],
        "error": "",
    }

    # ---- AI 未启用 / 未配置：直接返回本地分析结果（不崩溃）----
    cfg = load_ai_config()
    if not cfg["enabled"]:
        fallback["error"] = "AI未配置或未启用，已降级为本地规则分析"
        try:
            app_logger.info("[AI行为分析] AI未启用，使用本地初判结果")
        except Exception:
            pass
        return fallback

    # ---- 是否需要调用 AI ----
    need_ai = (local["score"] >= 40) or (len(events or []) >= 5)
    if not need_ai:
        fallback["error"] = "本地低风险，未触发AI深度分析"
        return fallback

    # ---- 调用 DeepSeek ----
    try:
        user_content = _build_user_content(events or [], local, context or {})
        content = _call_deepseek(
            cfg["api_url"], cfg["api_key"], cfg["model"],
            _SYSTEM_PROMPT, user_content,
        )
        ai = _extract_json(content)

        # 合并 AI 结论
        result = dict(fallback)
        lvl = str(ai.get("risk_level", "")).lower()
        if lvl in ("low", "medium", "high", "critical"):
            result["risk_level"] = lvl
        act = str(ai.get("suggested_action", "")).lower()
        if act in ("quarantine", "terminate", "monitor", "allow"):
            result["suggested_action"] = act
        try:
            conf = float(ai.get("confidence", 0.0))
            result["confidence"] = max(0.0, min(1.0, conf))
        except Exception:
            result["confidence"] = 0.6
        reason = ai.get("reason")
        if reason:
            result["reason"] = str(reason)
        inds = ai.get("indicators")
        if isinstance(inds, list) and inds:
            result["indicators"] = [str(x) for x in inds][:20]
        result["ai_analyzed"] = True
        result["error"] = ""
        try:
            app_logger.info(
                f"[AI行为分析] AI判定={result['risk_level']} "
                f"动作={result['suggested_action']} 分={local['score']}"
            )
        except Exception:
            pass
        return result
    except Exception as e:
        # 降级：返回本地初判，记录错误
        fallback["error"] = f"AI分析失败，已降级本地结果: {e}"
        try:
            app_logger.warning(f"[AI行为分析] 调用失败降级本地: {e}")
        except Exception:
            pass
        return fallback


# ======================================================================
# 5. 批量分析
# ======================================================================

def analyze_behavior_batch(event_groups: list,
                           context: dict = None,
                           interval: float = 0.5) -> list:
    """
    批量分析：每个元素是一组行为事件（对应一个可疑进程/文件）。
    逐个调用 analyze_behavior，每次间隔 interval 秒防止 API 限流。
    单组失败不影响其他组。
    """
    results = []
    if not event_groups:
        return results
    for idx, group in enumerate(event_groups):
        try:
            results.append(analyze_behavior(group, context))
        except Exception as e:
            results.append({
                "risk_level": "unknown",
                "reason": f"批量分析异常: {e}",
                "suggested_action": "monitor",
                "confidence": 0.0,
                "local_score": 0,
                "ai_analyzed": False,
                "indicators": [],
                "error": str(e),
            })
        # 速率控制：组间间隔（最后一组不用等）
        if idx < len(event_groups) - 1:
            try:
                time.sleep(interval)
            except Exception:
                pass
    return results


# ======================================================================
# 6. 高危动作触发接口
# ======================================================================

def should_trigger_alert(result: dict) -> bool:
    """
    根据分析结果判断是否需要触发高危告警：
      - risk_level 为 high/critical
      - suggested_action 为 quarantine/terminate
      - confidence >= 0.7 且 local_score >= 70
    """
    if not result or not isinstance(result, dict):
        return False
    try:
        level = str(result.get("risk_level", "")).lower()
        action = str(result.get("suggested_action", "")).lower()
        if level in ("high", "critical"):
            return True
        if action in ("quarantine", "terminate"):
            return True
        conf = float(result.get("confidence", 0.0) or 0.0)
        local_score = int(result.get("local_score", 0) or 0)
        if conf >= 0.7 and local_score >= 70:
            return True
    except Exception:
        return False
    return False


# ======================================================================
# 7. 自测块（不实际调用 AI）
# ======================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("DG安全 3.0 —— AI 行为分析模块 自测")
    print("=" * 60)

    # 7.1 空列表
    r0 = local_behavior_score([])
    print("\n[1] 空事件: ", r0)

    # 7.2 正常程序（低风险）
    benign = [
        {"timestamp": "2026-09-09 10:00:00", "event_type": "process_create",
         "process_name": "notepad.exe",
         "process_path": r"C:\Windows\notepad.exe", "pid": 1000,
         "command_line": "notepad.exe"},
        {"timestamp": "2026-09-09 10:00:05", "event_type": "file_write",
         "process_name": "notepad.exe",
         "target_path": r"C:\Users\test\Documents\note.txt"},
    ]
    r1 = local_behavior_score(benign)
    print("\n[2] 正常记事本: ", r1)

    # 7.3 恶意攻击链（下载→落地→执行→持久化→窃取）
    evil = [
        {"timestamp": "2026-09-09 02:13:00", "event_type": "network_connect",
         "process_name": "setup.exe",
         "process_path": r"C:\Users\test\AppData\Local\Temp\setup.exe",
         "remote_ip": "203.0.113.45", "remote_port": 4444,
         "command_line": "setup.exe /s"},
        {"timestamp": "2026-09-09 02:13:02", "event_type": "file_create",
         "process_name": "setup.exe",
         "target_path": r"C:\Users\test\AppData\Local\Temp\payload.exe"},
        {"timestamp": "2026-09-09 02:13:05", "event_type": "process_create",
         "process_name": "svch0st.exe",
         "process_path": r"C:\Users\test\AppData\Local\Temp\svch0st.exe",
         "command_line": "powershell -enc SQBFAFgA... -ExecutionPolicy Bypass"},
        {"timestamp": "2026-09-09 02:13:10", "event_type": "registry_write",
         "process_name": "svch0st.exe",
         "target_registry": r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
         "command_line": "reg add ..."},
        {"timestamp": "2026-09-09 02:13:12", "event_type": "file_read_probe",
         "process_name": "svch0st.exe",
         "target_path": r"C:\Users\test\AppData\Local\Google\Chrome\User Data\Default\Login Data"},
        {"timestamp": "2026-09-09 02:13:13", "event_type": "file_write",
         "process_name": "svch0st.exe",
         "command_line": "cmd /c del svch0st.exe"},
    ]
    r2 = local_behavior_score(evil)
    print("\n[3] 攻击链样本: ", r2)

    # 7.4 should_trigger_alert
    print("\n[4] 触发判定:")
    print("   攻击链结果触发告警?", should_trigger_alert(r2))
    print("   正常程序结果触发告警?", should_trigger_alert(r1))

    # 7.5 analyze_behavior 在无/有配置下的降级（不强制联网）
    # 自测：强制把 AI 配置视为未启用，确保只跑本地分析，不真实调用 DeepSeek
    _cached_config = {"enabled": False, "api_key": "",
                      "api_url": "", "model": "deepseek-chat"}
    print("\n[5] analyze_behavior 闭环(本地优先，已强制关闭AI):")
    print("   本地初判:", analyze_behavior(evil, {"file_name": "payload.exe"}))

    print("\n自测完成（未实际调用 DeepSeek）。")
