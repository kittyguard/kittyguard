# -*- coding: utf-8 -*-
"""6.0.4 restore_all_backups 单测"""
import os, tempfile, shutil, sys
sys.path.insert(0, r"F:\桌面保护\desktopguard")
import ransomware_guard as rg

td = tempfile.mkdtemp(prefix="dg_restore_test2_")
src_dir = os.path.join(td, "src")
os.makedirs(src_dir)
src0 = os.path.join(src_dir, "doc0.txt")
open(src0, "w").write("orig0")
g = rg.RansomwareGuard(data_dir=td, on_alert=lambda lv, i: None)
vault = os.path.join(td, "ransom_backup", "2026-10-06")
os.makedirs(vault, exist_ok=True)
dst = os.path.join(vault, "1_doc0.txt")
shutil.copy2(src0, dst)
g._backed[src0 + "|7|1"] = dst
g._backup_size = 7
open(src0, "w").write("RANSOMED-DATA-XXXX")
r = g.restore_all_backups()
print("restore_all:", r["ok"], "ok /", r["skip"], "skip /", r["fail"], "fail")
print("restored content:", open(src0).read())
print("backup dirs:", os.listdir(os.path.join(td, "ransom_backup")))
assert r["ok"] == 1 and open(src0).read() == "orig0", "FAIL"
print("PASS")
