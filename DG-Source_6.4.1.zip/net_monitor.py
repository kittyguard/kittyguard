# -*- coding: utf-8 -*-
"""
DG 网络连接监控 4.18.0
独立窗口：实时列出全部 TCP/UDP 连接（本地/远端地址、状态、所属进程），
突出 ESTABLISHED 外联（银狐类回连监控重点），按远端 IP 聚合可疑多连接，
过滤（进程名/远端IP/状态）、右键复制与定位。每 3 秒自动刷新。
深色科技风对齐 DG 4.0.0。
"""

import os
import sys
import time
import ctypes
import subprocess

try:
    import psutil
except ImportError:
    ctypes.windll.user32.MessageBoxW(0, "缺少 psutil 库，请执行：pip install psutil", "DG 网络连接监控", 0x10)
    sys.exit(1)

BG      = "#0d1520"
FG      = "#d8e6f2"
DIM     = "#7fa3c0"
ACCENT  = "#00d4ff"
WARN    = "#ffb648"
DANGER  = "#ff5c5c"
CARD    = "#14202e"
CARD2   = "#1b2b3d"
BORDER  = "#22303f"
GREEN   = "#3ddc84"
FONT    = ("Microsoft YaHei UI", 9)
FONT_B  = ("Microsoft YaHei UI", 10, "bold")
FONT_T  = ("Microsoft YaHei UI", 14, "bold")

_tk = None


def _init_ttk_style():
    global _tk
    try:
        import tkinter.ttk as ttk
        s = ttk.Style(_tk)
        s.theme_use("clam")
        s.configure("Treeview", background=CARD2, fieldbackground=CARD2,
                    foreground=FG, borderwidth=0, rowheight=24, font=FONT)
        s.configure("Treeview.Heading", background="#24384f", foreground=FG,
                    font=FONT_B, borderwidth=0, relief="flat")
        s.map("Treeview", background=[("selected", ACCENT)],
              foreground=[("selected", "#001018")])
        s.map("Treeview.Heading", background=[("active", "#2c4a66")])
    except Exception:
        pass


def collect_connections():
    """返回 [(local, remote, status, pid, pname)]，只取有远端地址的活跃连接优先"""
    pid2name = {}
    try:
        for p in psutil.process_iter(["pid", "name"]):
            try:
                pid2name[p.info["pid"]] = p.info["name"] or ""
            except Exception:
                pass
    except Exception:
        pass
    rows = []
    try:
        conns = psutil.net_connections(kind="inet")
    except Exception:
        return rows
    for c in conns:
        try:
            pid = c.pid or 0
            laddr = f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "-"
            raddr = f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "-"
            rows.append({"local": laddr, "remote": raddr, "status": c.status or "",
                         "pid": pid, "pname": pid2name.get(pid, "")})
        except Exception:
            continue
    # 外联 ESTABLISHED 优先，其次 TIME_WAIT，最后监听
    order = {"ESTABLISHED": 0, "SYN_SENT": 1, "TIME_WAIT": 2, "CLOSE_WAIT": 3, "LISTEN": 4}
    rows.sort(key=lambda r: (order.get(r["status"], 9), r["pid"]))
    return rows


class NetMonitorWin:
    def __init__(self, root):
        self.root = root
        self.filter_var = tk.StringVar()
        self._build()
        self.refresh()
        self._poll()

    def _build(self):
        self.root.title("DG 网络连接监控")
        self.root.configure(bg=BG)
        self.root.geometry("940x620")
        try:
            self.root.iconbitmap(os.path.join(os.path.dirname(os.path.abspath(__file__)), "shield.ico"))
        except Exception:
            pass

        head = tk.Frame(self.root, bg=BG)
        head.pack(fill="x", padx=14, pady=(12, 6))
        tk.Label(head, text="网络连接监控", bg=BG, fg=ACCENT, font=FONT_T).pack(side="left")
        tk.Label(head, text="全部 TCP/UDP 连接 · ESTABLISHED 外联优先（盯银狐类回连）· 每 3 秒自动刷新",
                 bg=BG, fg=DIM, font=FONT).pack(side="left", padx=(12, 0), pady=(4, 0))

        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=14, pady=4)
        tk.Label(bar, text="过滤:", bg=BG, fg=DIM, font=FONT).pack(side="left")
        self.filter_entry = tk.Entry(bar, bg=CARD2, fg=FG, insertbackground=FG,
                                     relief="flat", font=FONT, width=20)
        self.filter_entry.pack(side="left", padx=(4, 6))
        self.filter_entry.bind("<Return>", lambda e: self.refresh())
        tk.Button(bar, text="刷新", bg=ACCENT, fg="#001018", activebackground="#33e0ff",
                  relief="flat", font=FONT_B, command=self.refresh).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="按远端IP排序", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=lambda: self.set_sort("remote")).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="按进程排序", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=lambda: self.set_sort("pname")).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="按状态排序", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=lambda: self.set_sort("status")).pack(side="left", padx=(6, 0))

        self.info_var = tk.StringVar(value=" ")
        tk.Label(self.root, textvariable=self.info_var, bg=BG, fg=DIM,
                 font=FONT, anchor="w").pack(fill="x", padx=14, pady=(2, 4))

        wrap = tk.Frame(self.root, bg=BORDER)
        wrap.pack(fill="both", expand=True, padx=14, pady=(0, 6))
        cols = ("local", "remote", "status", "pid", "pname")
        heads = ("本地地址", "远端地址", "状态", "PID", "进程")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings",
                                 selectmode="browse", height=24)
        for c, h in zip(cols, heads):
            wd = 200 if c in ("local", "remote") else (90 if c in ("status", "pid") else 200)
            self.tree.heading(c, text=h)
            self.tree.column(c, width=wd, anchor="w", stretch=(c == "remote"))
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.tag_configure("est", foreground=ACCENT)
        self.tree.tag_configure("syn", foreground=WARN)
        self.tree.tag_configure("listen", foreground=DIM)
        self.tree.bind("<Button-3>", self._ctx_menu)

        foot = tk.Frame(self.root, bg=BG)
        foot.pack(fill="x", padx=14, pady=(0, 10))
        tk.Label(foot, text="青色=已建立外联（重点监控）· 黄=正在发起连接 · 灰=监听；右键可复制地址/定位进程；过滤支持 进程名/远端IP/状态",
                 bg=BG, fg=DIM, font=FONT).pack(side="left")

    def _poll(self):
        self.refresh()
        self.root.after(3000, self._poll)

    def set_sort(self, key):
        self.sort_key = key
        self.refresh()

    def refresh(self):
        rows = collect_connections()
        kw = (self.filter_var.get() or "").strip().lower()
        if kw:
            rows = [r for r in rows
                    if kw in (r["pname"] or "").lower()
                    or kw in r["remote"].lower()
                    or kw in r["local"].lower()
                    or kw in (r["status"] or "").lower()]
        key = getattr(self, "sort_key", None)
        if key in ("remote", "pname", "status"):
            rows.sort(key=lambda r: r[key])
        self.rows = rows
        self.tree.delete(*self.tree.get_children())
        n_est = 0
        for r in rows:
            tag = ""
            if r["status"] == "ESTABLISHED":
                tag = "est"
                n_est += 1
            elif r["status"] in ("SYN_SENT", "CLOSE_WAIT"):
                tag = "syn"
            elif r["status"] == "LISTEN":
                tag = "listen"
            self.tree.insert("", "end", iid=str(len(self.tree.get_children())),
                             values=(r["local"], r["remote"], r["status"],
                                     r["pid"], r["pname"] or "(系统/未知)"),
                             tags=(tag,))
        self.info_var.set(f"共 {len(rows)} 条连接 ｜ 已建立外联 {n_est} 条"
                          + (f"（过滤：{kw}）" if kw else ""))

    def _selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        idx = int(sel[0])
        if idx < len(self.rows):
            return self.rows[idx]
        return None

    def _ctx_menu(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        self.tree.selection_set(iid)
        r = self._selected()
        if r is None:
            return
        m = tk.Menu(self.root, tearoff=0, bg=CARD2, fg=FG, activebackground=ACCENT,
                    activeforeground="#001018", font=FONT)
        m.add_command(label="复制远端地址", command=lambda: self._copy(r["remote"]))
        m.add_command(label="复制整行", command=lambda: self._copy(" | ".join(
            [r["local"], r["remote"], r["status"], str(r["pid"]), r["pname"]])))
        m.add_command(label=f"定位进程 {r['pname'] or '(系统)'}", command=lambda: self._filter_proc(r))
        m.tk_popup(event.x_root, event.y_root)

    def _copy(self, t):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(t)
            self.info_var.set(f"已复制：{t[:60]}")
        except Exception:
            pass

    def _filter_proc(self, r):
        self.filter_var.set(r["pname"])
        self.refresh()


def main():
    global tk, messagebox, ttk
    import tkinter as tk
    import tkinter.messagebox as messagebox
    import tkinter.ttk as ttk
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def cb(h, l):
        if ctypes.windll.user32.IsWindowVisible(h):
            buf = ctypes.create_unicode_buffer(256)
            ctypes.windll.user32.GetWindowTextW(h, buf, 256)
            if "DG 网络连接监控" in buf.value:
                found.append(h)
        return True
    try:
        ctypes.windll.user32.EnumWindows(cb, 0)
    except Exception:
        pass
    if found:
        try:
            ctypes.windll.user32.ShowWindow(found[0], 9)
            ctypes.windll.user32.SetForegroundWindow(found[0])
        except Exception:
            pass
        return

    root = tk.Tk()
    _tk = root
    _init_ttk_style()
    app = NetMonitorWin(root)
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.mainloop()


if __name__ == "__main__":
    main()
