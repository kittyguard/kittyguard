# -*- coding: utf-8 -*-
"""集成实时防护到 main.py"""

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# ===== 1. 添加 import =====
c = c.replace(
    'import engine\nimport logger',
    'import engine\nimport logger\nimport realtime_protection'
)
print('1. 添加 import realtime_protection 完成')

# ===== 2. 在 __init__ 里初始化实时防护 =====
old_init = '''        self._build_styles()
        self._build_ui()
        self._poll_queue()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)'''

new_init = '''        # 实时防护
        self._rtp_alert_queue = queue.Queue()
        self._rtp = realtime_protection.RealTimeProtector(alert_queue=self._rtp_alert_queue)
        self._rtp_running = False
        
        self._build_styles()
        self._build_ui()
        self._poll_queue()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        
        # 启动实时防护（根据配置）
        if self._rtp.config.get("enabled", True):
            self._rtp.start()
            self._rtp_running = True'''

c = c.replace(old_init, new_init, 1)
print('2. __init__ 初始化实时防护完成')

# ===== 3. 在 _poll_queue 方法里添加处理 rtp 告警 =====
# 先找到 _poll_queue 方法
poll_idx = c.find('    def _poll_queue(self):')
if poll_idx > 0:
    # 找到方法的第一行（def之后的第一个非空行）
    # 在方法开头添加处理rtp告警的代码
    old_poll_start = '''    def _poll_queue(self):
        """主线程轮询扫描队列，更新UI。"""
        try:'''
    
    new_poll_start = '''    def _poll_queue(self):
        """主线程轮询扫描队列，更新UI。"""
        # 处理实时防护告警
        self._process_rtp_alerts()
        try:'''
    
    if old_poll_start in c:
        c = c.replace(old_poll_start, new_poll_start, 1)
        print('3. _poll_queue 添加处理rtp告警完成')
    else:
        print('3. 未找到 _poll_queue 匹配，跳过')

# ===== 4. 添加 _process_rtp_alerts 方法 =====
# 在 _poll_queue 方法前面添加
process_method = '''    def _process_rtp_alerts(self):
        """处理实时防护告警队列。"""
        try:
            while True:
                try:
                    alert = self._rtp_alert_queue.get_nowait()
                except queue.Empty:
                    break
                
                if alert.get("type") == "process_alert":
                    self._show_process_alert(alert)
        except Exception:
            pass
    
    def _show_process_alert(self, alert):
        """显示进程告警弹窗。"""
        try:
            pid = alert.get("pid", 0)
            name = alert.get("name", "未知")
            path = alert.get("path", "")
            cmd = alert.get("cmd", "")
            risks = alert.get("risks", [])
            max_level = alert.get("max_level", "low")
            
            level_text = {"high": "高危", "medium": "中危", "low": "低危"}.get(max_level, "未知")
            level_color = {"high": "#ff4444", "medium": "#ff9900", "low": "#999999"}.get(max_level, "#999999")
            
            risk_text = "\\n".join([f"  • {r['desc']}" for r in risks])
            
            msg = f"【实时防护告警】\n\n"
            msg += f"进程名: {name}\\n"
            msg += f"PID: {pid}\\n"
            if path:
                msg += f"路径: {path}\\n"
            if cmd:
                msg += f"命令行: {cmd[:100]}\\n"
            msg += f"\\n风险等级: {level_text}\\n"
            msg += f"风险项:\\n{risk_text}\\n\\n"
            msg += f"是否结束该进程？\\n（是=结束进程，否=信任并加入白名单，取消=忽略）"
            
            result = messagebox.askyesnocancel("DG 实时防护告警", msg, parent=self.root)
            
            if result is True:
                # 结束进程
                if self._rtp.kill_process(pid):
                    messagebox.showinfo("已处理", f"已结束进程: {name}", parent=self.root)
                else:
                    messagebox.showwarning("操作失败", f"无法结束进程: {name}\\n可能需要管理员权限", parent=self.root)
            elif result is False:
                # 加入白名单
                self._rtp.add_whitelist(name)
                messagebox.showinfo("已信任", f"已将 {name} 加入白名单", parent=self.root)
            # 取消=忽略，不做处理
        except Exception as e:
            pass
    
'''

# 在 _poll_queue 前面插入
c = c.replace('    def _poll_queue(self):', process_method + '    def _poll_queue(self):', 1)
print('4. 添加 _process_rtp_alerts 和 _show_process_alert 方法完成')

# ===== 5. 在设置页面添加实时防护开关 =====
# 找到设置页面的"启动设置"部分，在前面添加"实时防护设置"
settings_start = c.find('        # ===== 启动设置 =====')
if settings_start > 0:
    rtp_settings = '''        # ===== 实时防护设置 =====
        box = section("实时防护")
        rtp_frame = tk.Frame(box, bg=C_CARD2)
        rtp_frame.pack(fill="x", pady=4)
        
        # 实时防护开关
        rtp_switch_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        rtp_switch_frame.pack(fill="x", pady=2)
        tk.Label(rtp_switch_frame, text="启用实时防护（后台监控进程）", bg=C_CARD2, fg=C_TEXT,
                font=("Microsoft YaHei UI", 10)).pack(side="left")
        
        rtp_enabled = self._rtp.config.get("enabled", True)
        rtp_switch_var = StringVar(value="开" if rtp_enabled else "关")
        rtp_switch_btn = tk.Button(rtp_switch_frame, textvariable=rtp_switch_var, width=6,
                                   bg=(C_GREEN if rtp_enabled else C_SUB), fg="white",
                                   activebackground=(C_GREEN if rtp_enabled else C_SUB),
                                   activeforeground="white", font=("Microsoft YaHei UI", 9, "bold"),
                                   relief="flat", cursor="hand2")
        rtp_switch_btn.pack(side="right")
        
        def toggle_rtp():
            current = rtp_switch_var.get()
            if current == "开":
                rtp_switch_var.set("关")
                rtp_switch_btn.config(bg=C_SUB, activebackground=C_SUB)
                self._rtp.config["enabled"] = False
                self._rtp.save_config()
                if self._rtp.running:
                    self._rtp.stop()
            else:
                rtp_switch_var.set("开")
                rtp_switch_btn.config(bg=C_GREEN, activebackground=C_GREEN)
                self._rtp.config["enabled"] = True
                self._rtp.save_config()
                if not self._rtp.running:
                    self._rtp.start()
        rtp_switch_btn.config(command=toggle_rtp)
        
        # 扫描间隔
        interval_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        interval_frame.pack(fill="x", pady=2)
        tk.Label(interval_frame, text="进程扫描间隔（秒）", bg=C_CARD2, fg=C_TEXT,
                font=("Microsoft YaHei UI", 10)).pack(side="left")
        interval_var = StringVar(value=str(self._rtp.config.get("scan_interval", 5)))
        interval_spin = tk.Spinbox(interval_frame, from_=3, to=30, width=8,
                                   textvariable=interval_var, font=("Microsoft YaHei UI", 10),
                                   bg=C_CARD, fg=C_TEXT, relief="flat")
        interval_spin.pack(side="right")
        
        def save_interval(*args):
            try:
                val = int(interval_var.get())
                if 3 <= val <= 30:
                    self._rtp.config["scan_interval"] = val
                    self._rtp.save_config()
            except Exception:
                pass
        interval_var.trace_add("write", save_interval)
        
        # 自动结束高危进程
        auto_kill_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        auto_kill_frame.pack(fill="x", pady=2)
        tk.Label(auto_kill_frame, text="自动结束高危进程（谨慎开启）", bg=C_CARD2, fg=C_TEXT,
                font=("Microsoft YaHei UI", 10)).pack(side="left")
        
        auto_kill_enabled = self._rtp.config.get("auto_kill_high_risk", False)
        auto_kill_var = StringVar(value="开" if auto_kill_enabled else "关")
        auto_kill_btn = tk.Button(auto_kill_frame, textvariable=auto_kill_var, width=6,
                                  bg=(C_RED if auto_kill_enabled else C_SUB), fg="white",
                                  activebackground=(C_RED if auto_kill_enabled else C_SUB),
                                  activeforeground="white", font=("Microsoft YaHei UI", 9, "bold"),
                                  relief="flat", cursor="hand2")
        auto_kill_btn.pack(side="right")
        
        def toggle_auto_kill():
            current = auto_kill_var.get()
            if current == "开":
                auto_kill_var.set("关")
                auto_kill_btn.config(bg=C_SUB, activebackground=C_SUB)
                self._rtp.config["auto_kill_high_risk"] = False
            else:
                auto_kill_var.set("开")
                auto_kill_btn.config(bg=C_RED, activebackground=C_RED)
                self._rtp.config["auto_kill_high_risk"] = True
            self._rtp.save_config()
        auto_kill_btn.config(command=toggle_auto_kill)
        
        # 状态显示
        rtp_status_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        rtp_status_frame.pack(fill="x", pady=(8, 0))
        self._rtp_status_label = tk.Label(rtp_status_frame, text="", bg=C_CARD2, fg=C_SUB,
                                          font=("Microsoft YaHei UI", 9), justify="left", anchor="w")
        self._rtp_status_label.pack(fill="x")
        self._update_rtp_status()
        
'''
    c = c[:settings_start] + rtp_settings + c[settings_start:]
    print('5. 设置页面添加实时防护设置完成')
else:
    print('5. 未找到设置页面启动设置位置，跳过')

# ===== 6. 添加 _update_rtp_status 方法 =====
status_method = '''    def _update_rtp_status(self):
        """更新实时防护状态显示。"""
        try:
            if hasattr(self, '_rtp_status_label') and self._rtp_status_label.winfo_exists():
                status = self._rtp.get_status()
                if status["running"] and not status["paused"]:
                    state_text = "● 运行中"
                    state_color = C_GREEN
                elif status["paused"]:
                    state_text = "⏸ 已暂停"
                    state_color = "#ff9900"
                else:
                    state_text = "○ 已停止"
                    state_color = C_SUB
                
                text = f"实时防护状态: {state_text}  |  扫描次数: {status['scan_count']}  |  告警次数: {status['alert_count']}  |  上次扫描: {status['last_scan_time']}"
                self._rtp_status_label.config(text=text, fg=state_color)
        except Exception:
            pass
        # 每5秒更新一次状态
        try:
            self.root.after(5000, self._update_rtp_status)
        except Exception:
            pass
    
'''

# 在 _show_process_alert 方法后面插入
c = c.replace('    def _poll_queue(self):', status_method + '    def _poll_queue(self):', 1)
print('6. 添加 _update_rtp_status 方法完成')

# ===== 7. 升级版本号到 2.4.0 =====
c = c.replace('APP_VERSION = "2.3.2"', 'APP_VERSION = "2.4.0"', 1)
c = c.replace(
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2"]',
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2", "2.4.0"]'
)

old_history = '''VERSION_HISTORY = [
    ("2.3.2"'''
new_history = '''VERSION_HISTORY = [
    ("2.4.0", "内容更新：新增轻量实时防护功能。1.后台线程每5秒扫描进程列表；2.识别可疑进程（伪装系统进程、可疑命令行、高风险路径exe）；3.发现高危进程弹窗提示，可选结束进程/信任白名单/忽略；4.设置页面新增实时防护设置（开关、扫描间隔、自动结束高危）；5.主界面显示实时防护状态（运行中/扫描次数/告警次数）；6.独立模块 realtime_protection.py，配置保存在 ~/.desktopguard/rtp_config.json"),
    ("2.3.2"'''
c = c.replace(old_history, new_history, 1)
print('7. 升级版本号到 2.4.0 完成')

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print('\n集成完成！')
