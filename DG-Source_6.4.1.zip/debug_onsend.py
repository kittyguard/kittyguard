# -*- coding: utf-8 -*-
c = open('main.py', 'r', encoding='utf-8').read()

# 找到 _open_ai_chat 方法
start_idx = c.find('def _open_ai_chat(self):')
end_idx = c.find('def _open_security_checkup(self):')
method = c[start_idx:end_idx]

# 找到 on_send 函数
send_idx = method.find('def on_send():')
if send_idx > 0:
    # 找到 on_send 函数的结尾（下一个 def 或者 send_btn 的定义）
    next_def = method.find('        send_btn =', send_idx)
    if next_def > 0:
        print('on_send 函数完整内容:')
        print(method[send_idx:next_def])
    else:
        print('on_send 函数:')
        print(method[send_idx:send_idx+1500])
