# -*- coding: utf-8 -*-
with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

old_code = '''        # 启动后延迟2秒初始化实时防护（不阻塞启动）
        self.root.after(2000, self._init_rtp_lazy)
        
        # 启动实时防护（根据配置）
        if self._rtp.config.get("enabled", True):
            self._rtp.start()
            self._rtp_running = True
        
        # 轻量目录监控（下载/桌面/启动目录新文件自动扫描）'''

new_code = '''        # 启动后延迟2秒初始化实时防护（不阻塞启动）
        self.root.after(2000, self._init_rtp_lazy)
        
        # 轻量目录监控（下载/桌面/启动目录新文件自动扫描）'''

if old_code in c:
    c = c.replace(old_code, new_code, 1)
    print("已删除旧的实时防护启动代码")
else:
    print("未找到匹配代码，尝试用更短的匹配...")
    # 用更短的匹配
    old_short = '''        # 启动实时防护（根据配置）
        if self._rtp.config.get("enabled", True):
            self._rtp.start()
            self._rtp_running = True
        
        # 轻量目录监控'''
    new_short = '''        # 轻量目录监控'''
    if old_short in c:
        c = c.replace(old_short, new_short, 1)
        print("已删除旧的实时防护启动代码（短匹配）")
    else:
        print("还是未找到，直接用正则替换...")
        import re
        c = re.sub(r'        # 启动实时防护（根据配置）\n        if self\._rtp\.config\.get.*?\n            self\._rtp\.start\(\)\n            self\._rtp_running = True\n\n', '', c, count=1, flags=re.DOTALL)
        print("正则替换完成")

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print("修复完成")
