// dg_etw.exe — ETW 实时进程监控组件（DG 4.20.0）
// 订阅 Microsoft-Windows-Kernel-Process provider：
//   ProcessStart(EventId=1) / ProcessStop(EventId=2) 毫秒级事件驱动
// 输出 JSONL 事件流 + 心跳文件 + 退出标记（与 DG 守护体系一致）
// 用法: dg_etw.exe <jsonl路径> <心跳路径> <退出标记路径>
// 纯用户态、无内核驱动、管理员权限运行
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <mutex>
#include <chrono>
#include <thread>
#include <cstdio>
#include <cwchar>
#include <cstdarg>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "tdh.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "shell32.lib")

// Microsoft-Windows-Kernel-Process (Win7+，系统默认可用，无需审计策略)
static const GUID KERNEL_PROCESS_PROVIDER = { 0x22FB2CD6, 0x0E7B, 0x422B, { 0xA0, 0xC7, 0x2F, 0xAD, 0x1F, 0xD0, 0xE7, 0x16 } };
static const wchar_t* SESSION_NAME = L"DG-ETW-LIVE-7";

static std::wstring g_jsonl, g_hb, g_flag;
static const wchar_t* STATUS_FILE = L"F:\\桌面保护\\dgdata\\etw_status.txt";
static void LogStatus(const char* fmt, ...) {
    char b[512];
    va_list ap; va_start(ap, fmt);
    vsprintf_s(b, fmt, ap);
    va_end(ap);
    HANDLE h = CreateFileW(STATUS_FILE, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        DWORD w = 0; WriteFile(h, b, (DWORD)strlen(b), &w, NULL);
        WriteFile(h, "\r\n", 2, &w, NULL); CloseHandle(h);
    }
}
static HANDLE g_hOut = INVALID_HANDLE_VALUE;
static TRACEHANDLE g_hSession = 0;
static TRACEHANDLE g_hTrace = 0;
static EVENT_TRACE_LOGFILEW g_logfile;
static std::mutex g_mtx;
static volatile bool g_stop = false;
static volatile bool g_trace_done = false;
static volatile long long g_event_count = 0;

// ---------- 工具函数 ----------
static std::string ToUtf8(const std::wstring& s) {
    if (s.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0, NULL, NULL);
    if (n <= 0) return std::string();
    std::string out(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], n, NULL, NULL);
    return out;
}

static std::string JsonEsc(const std::wstring& s) {
    std::string u = ToUtf8(s);
    std::string out;
    out.reserve(u.size() + 16);
    for (unsigned char c : u) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) { char b[8]; sprintf_s(b, "\\u%04x", c); out += b; }
                else out += (char)c;
        }
    }
    return out;
}

static std::string NowEpoch() {
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    char b[32]; sprintf_s(b, "%lld", (long long)ms);
    return std::string(b);
}

// 按字段名取属性值：UInt32/UInt64 转数字字符串；UnicodeString 转宽串
static bool GetProp(PEVENT_RECORD rec, PCWSTR field, std::wstring& out) {
    PROPERTY_DATA_DESCRIPTOR desc;
    desc.PropertyName = (ULONGLONG)field;
    desc.ArrayIndex = 0;
    DWORD size = 0;
    if (TdhGetPropertySize(rec, 0, NULL, 1, &desc, &size) != ERROR_SUCCESS)
        return false;
    if (size == 0) return false;
    std::vector<BYTE> buf(size);
    if (TdhGetProperty(rec, 0, NULL, 1, &desc, size, buf.data()) != ERROR_SUCCESS)
        return false;
    if (size == 4) {
        unsigned v; memcpy(&v, buf.data(), 4);
        wchar_t b[16]; swprintf_s(b, L"%u", v); out = b;
        return true;
    }
    if (size == 8) {
        unsigned long long v; memcpy(&v, buf.data(), 8);
        wchar_t b[24]; swprintf_s(b, L"%llu", v); out = b;
        return true;
    }
    // 字符串（宽字符，可能带尾 \0）
    out.assign((wchar_t*)buf.data(), size / sizeof(wchar_t));
    while (!out.empty() && out.back() == L'\0') out.pop_back();
    return true;
}

static void WriteLine(const std::string& line) {
    std::lock_guard<std::mutex> lk(g_mtx);
    if (g_hOut == INVALID_HANDLE_VALUE) return;
    DWORD written = 0;
    WriteFile(g_hOut, line.data(), (DWORD)line.size(), &written, NULL);
    WriteFile(g_hOut, "\n", 1, &written, NULL);
    FlushFileBuffers(g_hOut);
}

// ---------- ETW 回调 ----------
static void WINAPI OnEvent(EVENT_RECORD* rec) {
    if (g_stop || !rec) return;
    InterlockedIncrement64(&g_event_count);
    UCHAR eid = rec->EventHeader.EventDescriptor.Id;
    if (eid != 1 && eid != 2) return;   // 只要 ProcessStart / ProcessStop

    std::wstring pid, ppid, img, status;
    GetProp(rec, L"ProcessID", pid);
    if (eid == 1) {
        GetProp(rec, L"ParentProcessID", ppid);
        GetProp(rec, L"ImageName", img);
    } else {
        GetProp(rec, L"ImageName", img);
        GetProp(rec, L"ExitCode", status);
    }

    std::string line;
    if (eid == 1)
        line = "{\"t\":" + NowEpoch() + ",\"e\":1,\"pid\":\"" + JsonEsc(pid) +
               "\",\"ppid\":\"" + JsonEsc(ppid) + "\",\"img\":\"" + JsonEsc(img) + "\"}";
    else
        line = "{\"t\":" + NowEpoch() + ",\"e\":2,\"pid\":\"" + JsonEsc(pid) +
               "\",\"img\":\"" + JsonEsc(img) + "\",\"status\":\"" + JsonEsc(status) + "\"}";
    WriteLine(line);
}

// ---------- 权限提升（SeDebugPrivilege，管理员必备） ----------
static void EnableDebugPriv() {
    HANDLE hTok = NULL;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hTok)) {
        TOKEN_PRIVILEGES tp; tp.PrivilegeCount = 1; tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        if (LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &tp.Privileges[0].Luid))
            AdjustTokenPrivileges(hTok, FALSE, &tp, 0, NULL, NULL);
        CloseHandle(hTok);
    }
}

// ---------- 心跳线程 ----------
static void HeartbeatLoop() {
    while (!g_stop) {
        HANDLE h = CreateFileW(g_hb.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (h != INVALID_HANDLE_VALUE) {
            std::string ts = NowEpoch();
            DWORD w = 0;
            SetFilePointer(h, 0, NULL, FILE_BEGIN);
            WriteFile(h, ts.data(), (DWORD)ts.size(), &w, NULL);
            CloseHandle(h);
        }
        for (int i = 0; i < 50 && !g_stop; i++) Sleep(100);  // 5 秒
    }
}

// ---------- Trace 线程（ProcessTrace 阻塞） ----------
static void TraceLoop() {
    LogStatus("processtrace start", 0);
    ULONG pt = ProcessTrace(&g_hTrace, 1, 0, 0);
    LogStatus("processtrace ret=%u", pt);
    g_trace_done = true;
}

// ---------- 主流程 ----------
int APIENTRY wWinMain(HINSTANCE, HINSTANCE, LPWSTR lpCmdLine, int) {
    // 解析参数：<jsonl> <heartbeat> <exitflag>
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(lpCmdLine, &argc);
    if (argc < 3) return 2;
    g_jsonl = argv[0]; g_hb = argv[1]; g_flag = argv[2];
    DeleteFileW(STATUS_FILE);
    char dbg[1024]; sprintf_s(dbg, "arg0=[%ls] arg1=[%ls] arg2=[%ls]", argv[0], argv[1], argv[2]);
    {
        HANDLE h = CreateFileW(STATUS_FILE, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (h != INVALID_HANDLE_VALUE) { DWORD w = 0; WriteFile(h, dbg, (DWORD)strlen(dbg), &w, NULL);
            WriteFile(h, "\r\n", 2, &w, NULL); CloseHandle(h); }
    }
    LocalFree(argv);

    EnableDebugPriv();

    // 退出标记已存在 → 直接退出（守护判定"正常退出"）
    if (GetFileAttributesW(g_flag.c_str()) != INVALID_FILE_ATTRIBUTES) return 0;

    // 打开事件输出文件（追加）
    g_hOut = CreateFileW(g_jsonl.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                         NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (g_hOut == INVALID_HANDLE_VALUE) return 3;
    LogStatus("open ok", 0);

    // 创建实时 session（若已存在先停旧）
    {
        std::vector<BYTE> buf(sizeof(EVENT_TRACE_PROPERTIES) + sizeof(wchar_t) * 64);
        EVENT_TRACE_PROPERTIES* props = (EVENT_TRACE_PROPERTIES*)buf.data();
        props->Wnode.BufferSize = (ULONG)buf.size();
        props->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
        props->Wnode.Guid = { 0x6B21A4C9, 0x5D3F, 0x9E18, { 0x7C, 0x2A, 0x4F, 0x8B, 0x1E, 0x60, 0xD5, 0x3A } };
        props->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
        wchar_t* sess_name = (wchar_t*)(buf.data() + props->LoggerNameOffset);
        wcscpy_s(sess_name, 64, SESSION_NAME);
        props->LogFileMode = EVENT_TRACE_REAL_TIME_MODE;
        props->MinimumBuffers = 2;
        props->MaximumBuffers = 16;
        props->FlushTimer = 1;
        ULONG r = StartTraceW(&g_hSession, SESSION_NAME, props);
        if (r == ERROR_ALREADY_EXISTS) {
            LogStatus("start exists, stop old", 0);
            ControlTraceW(0, SESSION_NAME, props, EVENT_TRACE_CONTROL_STOP);
            Sleep(500);   // 内核异步释放同名 session，必须等
            r = StartTraceW(&g_hSession, SESSION_NAME, props);
        }
        if (r == ERROR_ALREADY_EXISTS) {
            Sleep(1500);  // 再等一轮（防御性重试）
            r = StartTraceW(&g_hSession, SESSION_NAME, props);
        }
        LogStatus("start r=%u", r);
        if (r != ERROR_SUCCESS) {
            CloseHandle(g_hOut);
            return 4;
        }
    }

    // 启用 Kernel-Process provider（LEVEL 4 = Information，keyword 0 = 全部）
    if (EnableTraceEx2(g_hSession, &KERNEL_PROCESS_PROVIDER,
                       EVENT_CONTROL_CODE_ENABLE_PROVIDER, 4, 0, 0, 0, NULL) != ERROR_SUCCESS) {
        LogStatus("enable failed", 0);
        ControlTraceW(g_hSession, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP);
        CloseHandle(g_hOut);
        return 5;
    }
    LogStatus("enable ok", 0);

    // 打开 trace（实时 + 事件记录回调）——主线程 OpenTrace，子线程 ProcessTrace
    ZeroMemory(&g_logfile, sizeof(g_logfile));
    g_logfile.LoggerName = (LPWSTR)SESSION_NAME;
    g_logfile.ProcessTraceMode = PROCESS_TRACE_MODE_REAL_TIME | PROCESS_TRACE_MODE_EVENT_RECORD;
    g_logfile.EventRecordCallback = (PEVENT_RECORD_CALLBACK)OnEvent;
    g_hTrace = OpenTraceW(&g_logfile);
    LogStatus("opentrace h=%llu", (unsigned long long)g_hTrace);
    if (g_hTrace == (TRACEHANDLE)INVALID_HANDLE_VALUE) {
        ControlTraceW(g_hSession, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP);
        CloseHandle(g_hOut);
        return 6;
    }

    std::thread thTrace{ TraceLoop };
    std::thread thHb{ HeartbeatLoop };

    // 主循环：每 500ms 检查退出标记
    int loop_n = 0;
    while (!g_stop) {
        DWORD fa = GetFileAttributesW(g_flag.c_str());
        if (fa != INVALID_FILE_ATTRIBUTES) {
            LogStatus("flag detected fa=0x%x", fa);
            g_stop = true;
            break;
        }
        loop_n++;
        if (loop_n % 6 == 0) LogStatus("loop alive, ev=%lld, fa=%ld", g_event_count, (long)fa);
        Sleep(500);
    }
    LogStatus("flag detected, ev=%lld", g_event_count);

    // 关闭：禁用 provider → 停 session → 等 trace 线程退出
    EnableTraceEx2(g_hSession, &KERNEL_PROCESS_PROVIDER,
                   EVENT_CONTROL_CODE_DISABLE_PROVIDER, 0, 0, 0, 0, NULL);
    ControlTraceW(g_hSession, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP);
    for (int i = 0; i < 40 && !g_trace_done; i++) Sleep(250);  // 最多等 10 秒

    thHb.join();
    if (thTrace.joinable()) thTrace.join();

    if (g_hOut != INVALID_HANDLE_VALUE) { CloseHandle(g_hOut); g_hOut = INVALID_HANDLE_VALUE; }
    return 0;
}
