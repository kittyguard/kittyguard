# -*- coding: utf-8 -*-
"""
ClamAV 集成桥接（clamav_bridge.py）
====================================
零依赖（仅标准库 socket）。通过 ClamAV clamd 守护进程协议接入病毒库：
- 检测到本机 clamd 运行 -> 启用实时查毒（INSTREAM 扫描）
- 未安装/未运行   -> 静默跳过，不影响 DG 安全任何功能
"""

import socket
import os

CLAMD_HOST = "127.0.0.1"
CLAMD_PORT = 3310
SCAN_TIMEOUT = 10
MAX_SCAN_SIZE = 50 * 1024 * 1024


def clamd_ping() -> bool:
    try:
        s = socket.create_connection((CLAMD_HOST, CLAMD_PORT), timeout=2)
        s.sendall(b"PING\r\n")
        resp = s.recv(64).decode(errors="ignore")
        s.close()
        return "PONG" in resp
    except Exception:
        return False


def clamd_version() -> str:
    try:
        s = socket.create_connection((CLAMD_HOST, CLAMD_PORT), timeout=2)
        s.sendall(b"VERSION\r\n")
        resp = s.recv(256).decode(errors="ignore").strip()
        s.close()
        return resp
    except Exception:
        return ""


def clamd_scan_file(path: str):
    try:
        size = os.path.getsize(path)
        if size <= 0 or size > MAX_SCAN_SIZE:
            return None
        with open(path, "rb") as f:
            data = f.read()
        if not data:
            return None

        s = socket.create_connection((CLAMD_HOST, CLAMD_PORT), timeout=SCAN_TIMEOUT)
        s.sendall(b"INSTREAM\r\n")
        chunk = 8192
        for i in range(0, len(data), chunk):
            part = data[i:i + chunk]
            s.sendall(len(part).to_bytes(4, "big") + part)
        s.sendall(b"\x00\x00\x00\x00")
        resp = s.recv(4096).decode(errors="ignore")
        s.close()

        resp = resp.upper()
        if "FOUND" in resp:
            name = resp.replace("FOUND", "").split(":")[-1].strip()
            return (True, name)
        if "OK" in resp or "CLEAN" in resp:
            return (False, "")
        return None
    except Exception:
        return None


def clamscan_available() -> bool:
    try:
        import shutil
        return shutil.which("clamscan") is not None
    except Exception:
        return False
