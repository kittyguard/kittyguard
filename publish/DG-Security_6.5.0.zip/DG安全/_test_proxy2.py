# -*- coding: utf-8 -*-
# 测更多 ghproxy 类镜像对 GitHub Pages 直链的支持
import urllib.request, time, socket

socket.setdefaulttimeout(15)
BASE = "https://kittyguard.github.io/kittyguard"

MIRRORS = [
    "https://ghproxy.net/",
    "https://ghproxy.cc/",
    "https://gh.ddlc.top/",
    "https://ghp.ci/",
    "https://github.moeyy.xyz/",
    "https://gh.api.99988866.xyz/",
    "https://ghproxy.link/",
    "https://mirror.ghproxy.com/",
    "https://gh-proxy.net/",
    "https://ghfast.top/",
]

def try_url(url, limit=8192, timeout=15):
    t0 = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            total = 0
            while total < limit:
                chunk = r.read(65536)
                if not chunk:
                    break
                total += len(chunk)
        dt = time.time() - t0
        return total, dt, None
    except Exception as e:
        return 0, 0, str(e)[:70]

# 每个镜像测试: 能否代理 Pages 直链(version.json 应返回 999B)
print("=== version.json (期望 999B) ===")
for m in MIRRORS:
    url = m + BASE + "/version.json"
    b, d, err = try_url(url)
    if err:
        print("  %-28s FAIL %s" % (m, err))
    elif b != 999:
        print("  %-28s ?    %dB %.2fs (非预期大小,可能被劫持/拦截页)" % (m, b, d))
    else:
        print("  %-28s OK   999B %.2fs" % (m, d))
