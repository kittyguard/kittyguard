# -*- coding: utf-8 -*-
"""Gitee 创建 v6.4.3 release（修正参数 target_commitish）"""
import json, urllib.request, urllib.parse

LOG = r"F:\桌面保护\desktopguard\_gitee_release.log"
TOKEN = "964d5ca1cfc09792719272c1260170a8"
BASE = "https://gitee.com/api/v5/repos/kittyguard/kittyguard"

def log(msg):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")

body_text = ("6.4.3 发行修复版（向导版三大 bug + 开机动画分离）\n"
             "1. ClamAV 病毒库更新不再依赖本机代理（相对路径多级自适应 + 国内镜像直连）\n"
             "2. 安装向导卸载零残留（退出标记 + 全进程清理 + 注册表清理 + 数据目录清理）\n"
             "3. 向导版 7 个工具全部可用（内置编译版 exe，不依赖 Python 环境）\n"
             "4. 开机自启不播动画、手动启动播动画\n"
             "5. 随包内置 ClamAV 引擎+病毒库 + YARA 引擎+内置规则，任何电脑开箱即用\n"
             "6. 全程纯用户态、零驱动、不服务化、CPU≈0")

try:
    data = urllib.parse.urlencode({
        "access_token": TOKEN,
        "tag_name": "v6.4.3",
        "target_commitish": "main",
        "name": "DG 安全 6.4.3 发行修复版",
        "body": body_text,
    }).encode("utf-8")
    req = urllib.request.Request(BASE + "/releases", data=data, method="POST",
                                 headers={"User-Agent": "kittyguard",
                                          "Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=90) as r:
        j = json.loads(r.read().decode("utf-8"))
        log("RELEASE_OK id=%s tag=%s url=%s" % (j.get("id"), j.get("tag_name"), j.get("html_url")))
except Exception as e:
    if hasattr(e, "read"):
        log("HTTP %s BODY=%s" % (getattr(e, "code", "?"), e.read().decode("utf-8", "ignore")[:800]))
    else:
        log("ERR %s" % e)
