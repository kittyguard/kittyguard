# -*- coding: utf-8 -*-
import re

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', c)
print('当前版本号:', m.group(1) if m else '未找到')

# 如果不是2.4.2，就更新
if m and m.group(1) != '2.4.2':
    c = c.replace('APP_VERSION = "' + m.group(1) + '"', 'APP_VERSION = "2.4.2"', 1)
    print('已更新版本号到 2.4.2')
    
    # 更新VERSION_LIST
    old_list = '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2", "2.4.0", "2.4.1"]'
    new_list = '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2", "2.4.0", "2.4.1", "2.4.2"]'
    if old_list in c:
        c = c.replace(old_list, new_list, 1)
        print('VERSION_LIST 已更新')
    
    # 更新VERSION_HISTORY
    old_hist = 'VERSION_HISTORY = [\n    ("2.4.1"'
    new_hist = 'VERSION_HISTORY = [\n    ("2.4.2", "内容更新：方案B版本切换自动注入最新AI助手代码。切换到1.2.5以后的任何旧版本时，自动把最新版的_open_ai_chat方法注入到目标版本的main.py里，这样旧版本也能使用最新的AI助手功能。"),\n    ("2.4.1"'
    if old_hist in c:
        c = c.replace(old_hist, new_hist, 1)
        print('VERSION_HISTORY 已更新')
    
    with open('main.py', 'w', encoding='utf-8') as f:
        f.write(c)
    print('main.py 已保存')
else:
    print('版本号已经是2.4.2，无需更新')
