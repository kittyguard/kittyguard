# -*- coding: utf-8 -*-
"""独立测试AI助手API调用，用和DG完全一样的代码逻辑。"""
import json
import os
import threading
import urllib.request
import ssl
import queue
import time

# 1. 加载配置（和DG一样）
config_path = os.path.join(os.path.expanduser("~"), ".desktopguard", "ai_config.json")
print(f"[1] 配置文件路径: {config_path}")
print(f"[1] 配置文件存在: {os.path.exists(config_path)}")

with open(config_path, "r", encoding="utf-8") as f:
    ai_cfg = json.load(f)

api_key = ai_cfg.get("ai_api_key", "").strip()
api_url = ai_cfg.get("ai_api_url", "").strip()
ai_model = ai_cfg.get("ai_model", "deepseek-chat")

print(f"[2] API Key: {api_key[:10]}...{api_key[-4:]}")
print(f"[2] API URL: {api_url}")
print(f"[2] 模型: {ai_model}")

# 2. 测试直接调用（不用线程，不用queue）
print("\n========== 测试1：直接调用（不用线程） ==========")
try:
    messages = [
        {"role": "system", "content": "你是测试助手。"},
        {"role": "user", "content": "你好，请回复'测试成功'"}
    ]
    payload = {
        "model": ai_model,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 100,
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    
    req = urllib.request.Request(api_url, data=data,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        method="POST")
    
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    print("[测试1] 正在发送请求...")
    with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
        print(f"[测试1] 收到响应，状态码={resp.status}")
        result = json.loads(resp.read().decode("utf-8"))
    
    ai_reply = result.get("choices", [{}])[0].get("message", {}).get("content", "")
    usage = result.get("usage", {})
    print(f"[测试1] AI回复: {ai_reply}")
    print(f"[测试1] Token消耗: {usage}")
    print("[测试1] ✅ 成功！")
except Exception as e:
    import traceback
    print(f"[测试1] ❌ 失败: {e}")
    print(f"[测试1] 详细错误:\n{traceback.format_exc()}")

# 3. 测试用线程+queue（和DG完全一样的逻辑）
print("\n========== 测试2：线程+queue（和DG完全一样） ==========")
msg_queue = queue.Queue()
cancel_flag = [False]
test_done = [False]

def ai_worker():
    """和DG的ai_worker完全一样的逻辑。"""
    try:
        msg_queue.put({"role": "debug", "text": "[调试] 后台线程已启动"})
        
        if cancel_flag[0]:
            return
        
        messages = [
            {"role": "system", "content": "你是测试助手。"},
            {"role": "user", "content": "你好，请回复'线程测试成功'"}
        ]
        payload = {
            "model": ai_model,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 100,
        }
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        
        msg_queue.put({"role": "debug", "text": "[调试] 正在构建请求"})
        
        req = urllib.request.Request(api_url, data=data,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
            method="POST")
        
        msg_queue.put({"role": "debug", "text": "[调试] 正在发送请求..."})
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
            msg_queue.put({"role": "debug", "text": f"[调试] 收到响应，状态码={resp.status}"})
            result = json.loads(resp.read().decode("utf-8"))
        
        if cancel_flag[0]:
            return
        
        msg_queue.put({"role": "debug", "text": "[调试] 正在解析响应..."})
        
        ai_reply = result.get("choices", [{}])[0].get("message", {}).get("content", "")
        usage = result.get("usage", {})
        usage_info = f"（消耗 {usage.get('total_tokens', 0)} tokens）" if usage else ""
        
        msg_queue.put({"role": "ai", "text": ai_reply + usage_info, "type": "done"})
        test_done[0] = True
        
    except Exception as e:
        import traceback
        err_msg = str(e)[:300]
        trace = traceback.format_exc()[:500]
        msg_queue.put({"role": "debug", "text": f"[调试] 发生异常: {err_msg}"})
        msg_queue.put({"role": "system", "text": f"❌ AI调用失败：{err_msg}\n\n详细错误：\n{trace}", "type": "error"})
        test_done[0] = True

print("[测试2] 正在启动后台线程...")
t = threading.Thread(target=ai_worker, daemon=True)
t.start()
print(f"[测试2] 后台线程已启动，线程ID={t.ident}")

# 模拟主线程轮询queue（和DG的poll_queue一样）
print("[测试2] 开始轮询队列...")
start_time = time.time()
while not test_done[0] and time.time() - start_time < 20:
    try:
        while True:
            msg = msg_queue.get_nowait()
            role = msg.get("role", "system")
            text = msg.get("text", "")
            print(f"  [队列消息] role={role}, text={text[:80]}")
    except queue.Empty:
        pass
    time.sleep(0.1)

if test_done[0]:
    print("[测试2] ✅ 线程+queue测试成功！")
else:
    print("[测试2] ❌ 超时（20秒），线程可能卡住了")

print("\n========== 测试完成 ==========")
print("如果测试1成功但测试2失败，说明是线程/queue的问题")
print("如果测试1也失败，说明是API/网络/配置的问题")
print("如果两个都成功，说明DG的UI代码有问题")
