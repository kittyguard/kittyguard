# -*- coding: utf-8 -*-
"""
把正式版最新代码同步到内测版，标记为beta版本
内测版使用独立配置路径 .desktopguard-beta
"""
import os
import shutil
import re

formal_dir = r"F:\桌面保护\desktopguard"
beta_dir = r"F:\桌面保护\desktopguard-beta"

# 需要同步的文件
files_to_sync = [
    "main.py",
    "engine.py", 
    "database.py",
    "logger.py",
    "realtime_protection.py",
    "shield.ico",
    "dg_icon.png",
]

print("=== 同步正式版 -> 内测版 ===")
for fname in files_to_sync:
    src = os.path.join(formal_dir, fname)
    dst = os.path.join(beta_dir, fname)
    if os.path.exists(src):
        shutil.copy2(src, dst)
        print(f"  同步: {fname}")
    else:
        print(f"  跳过(不存在): {fname}")

# 修改内测版的版本号为 2.5.0-beta
main_py = os.path.join(beta_dir, "main.py")
with open(main_py, 'r', encoding='utf-8') as f:
    c = f.read()

# 替换版本号
c = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "2.5.0-beta"', c, count=1)
print("\n版本号 -> 2.5.0-beta")

# 确保内测版使用独立的配置路径
# 查找配置路径相关的代码，确保内测版用 .desktopguard-beta
if '.desktopguard-beta' not in c:
    # 把所有 .desktopguard 替换为 .desktopguard-beta（仅限配置路径相关）
    # 注意：不要替换版本快照目录里的路径
    c = c.replace('os.path.join(os.path.expanduser("~"), ".desktopguard")', 
                  'os.path.join(os.path.expanduser("~"), ".desktopguard-beta")')
    c = c.replace('".desktopguard"', '".desktopguard-beta"')
    print("配置路径 -> .desktopguard-beta（独立配置）")
else:
    print("配置路径已经是 .desktopguard-beta")

with open(main_py, 'w', encoding='utf-8') as f:
    f.write(c)

# 同步versions目录（只同步最新的2.5.0快照）
beta_versions_dir = os.path.join(beta_dir, "versions")
os.makedirs(beta_versions_dir, exist_ok=True)

# 内测版只保留最新版本快照，不需要所有历史版本
beta_250_dir = os.path.join(beta_versions_dir, "2.5.0-beta")
os.makedirs(beta_250_dir, exist_ok=True)
for fname in ["main.py", "engine.py", "database.py", "logger.py", "realtime_protection.py"]:
    src = os.path.join(formal_dir, fname)
    dst = os.path.join(beta_250_dir, fname)
    if os.path.exists(src):
        shutil.copy2(src, dst)

# 把内测版快照里的版本号也改成beta
snapshot_main = os.path.join(beta_250_dir, "main.py")
if os.path.exists(snapshot_main):
    with open(snapshot_main, 'r', encoding='utf-8') as f:
        sc = f.read()
    sc = re.sub(r'APP_VERSION\s*=\s*"[^"]+"', 'APP_VERSION = "2.5.0-beta"', sc, count=1)
    with open(snapshot_main, 'w', encoding='utf-8') as f:
        f.write(sc)

print("\nversions/2.5.0-beta/ 快照已创建")

# 更新内测版的version.json
beta_version_json = os.path.join(beta_dir, "version.json")
import json
if os.path.exists(beta_version_json):
    with open(beta_version_json, 'r', encoding='utf-8') as f:
        vj = json.load(f)
    vj['latest_version'] = '2.5.0-beta'
    with open(beta_version_json, 'w', encoding='utf-8') as f:
        json.dump(vj, f, ensure_ascii=False, indent=2)
    print("version.json -> 2.5.0-beta")

# 创建/更新内测版启动脚本
run_beta_bat = os.path.join(beta_dir, "run-beta.bat")
with open(run_beta_bat, 'w', encoding='utf-8') as f:
    f.write('@echo off\n')
    f.write('cd /d "%~dp0"\n')
    f.write('start "" pythonw main.py\n')
print("run-beta.bat 已更新")

# 创建内测版README
readme_beta = os.path.join(beta_dir, "README-beta.txt")
with open(readme_beta, 'w', encoding='utf-8') as f:
    f.write("DesktopGuard 内测版 (Beta)\n")
    f.write("========================\n\n")
    f.write("当前版本: 2.5.0-beta\n\n")
    f.write("说明:\n")
    f.write("- 内测版用于测试新功能，可能存在bug\n")
    f.write("- 内测版使用独立配置路径: ~/.desktopguard-beta/\n")
    f.write("- 内测版数据与正式版完全隔离，互不影响\n")
    f.write("- 测试通过后，代码会同步到正式版发布\n\n")
    f.write("启动方式:\n")
    f.write("- 双击 run-beta.bat 启动\n")
    f.write("- 或命令行: pythonw main.py\n\n")
    f.write("特殊历史版本:\n")
    f.write("- 1.2.7: 唯一拥有 AI 智能检查实验性功能的版本\n")

print("README-beta.txt 已更新")

print("\n=== 内测版同步完成！===")
print("内测版目录:", beta_dir)
print("内测版版本: 2.5.0-beta")
print("配置路径: ~/.desktopguard-beta/（与正式版隔离）")
