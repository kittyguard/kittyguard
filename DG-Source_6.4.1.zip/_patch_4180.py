# -*- coding: utf-8 -*-
"""4.18.0 补丁：重启黑窗加固 + 工具页新增 网络连接监控/一键清理 卡片"""
import io

MAIN = r"F:\桌面保护\desktopguard\main.py"
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()

def rep(old, new, tag):
    global m
    assert old in m, f"未找到锚点: {tag}"
    assert m.count(old) == 1, f"锚点重复: {tag} ({m.count(old)})"
    m = m.replace(old, new, 1)

# ============ 1) _restart_app 加固：python.exe -> pythonw.exe 防黑窗 ============
rep('''            python_exe = sys.executable
            script = os.path.abspath(__file__)
            # 启动新进程
            subprocess.Popen([python_exe, script], cwd=os.path.dirname(script))''',
    '''            python_exe = sys.executable
            # 加固：控制台 python.exe 一律换 pythonw.exe，重启不再弹黑窗
            if python_exe and python_exe.lower().endswith("python.exe"):
                python_exe = python_exe[:-len("python.exe")] + "pythonw.exe"
            script = os.path.abspath(__file__)
            # 启动新进程
            subprocess.Popen([python_exe, script], cwd=os.path.dirname(script),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))''',
    "重启黑窗加固")

# ============ 2) 工具页新增 网络连接监控(t11) + 一键清理(t12) 卡片 ============
rep('''        ttk.Button(t10, text="粉碎文件…", style="Accent.TButton", command=self._on_shred_files).pack(anchor="w", pady=(6, 0))''',
    '''        ttk.Button(t10, text="粉碎文件…", style="Accent.TButton", command=self._on_shred_files).pack(anchor="w", pady=(6, 0))
        t11 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)
        t11.pack(fill="x", pady=4)
        tk.Label(t11, text="网络连接监控", bg=C_CARD2, fg=C_PRIMARY,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")
        tk.Label(t11, text="实时列出全部 TCP/UDP 连接（本地/远端地址/状态/所属进程），ESTABLISHED 外联优先高亮，每 3 秒自动刷新；过滤进程名/远端IP/状态，右键复制与定位——专门盯银狐类回连",
                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))
        ttk.Button(t11, text="打开网络连接监控", style="Accent.TButton", command=self._open_net_monitor).pack(anchor="w", pady=(6, 0))
        t12 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)
        t12.pack(fill="x", pady=4)
        tk.Label(t12, text="一键清理", bg=C_CARD2, fg=C_PRIMARY,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")
        tk.Label(t12, text="只清可再生的缓存/临时文件（用户&系统临时目录、Chrome/Edge 缓存、着色器缓存），后台线程执行不卡界面，释放量实时报告；绝不动个人文件、软件、回收站",
                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))
        ttk.Button(t12, text="开始清理…", style="Accent.TButton", command=self._on_clean).pack(anchor="w", pady=(6, 0))''',
    "工具页网络监控+一键清理卡片")

# ============ 3) 方法：网络连接监控 + 一键清理 ============
rep('''    def _open_process_manager(self):
        """打开进程管理器（独立进程，防重复启动）"""''',
    '''    def _open_net_monitor(self):
        """打开网络连接监控（独立进程，防重复启动）"""
        import ctypes
        found = []
        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def cb(h, l):
            if ctypes.windll.user32.IsWindowVisible(h):
                buf = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetWindowTextW(h, buf, 256)
                if "DG 网络连接监控" in buf.value:
                    found.append(h)
            return True
        try:
            ctypes.windll.user32.EnumWindows(cb, 0)
        except Exception:
            pass
        if found:
            messagebox.showinfo("网络连接监控", "网络连接监控已在运行。")
            return
        script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "net_monitor.py")
        if not os.path.exists(script):
            messagebox.showerror("网络连接监控", "未找到 net_monitor.py。")
            return
        try:
            exe = sys.executable
            if exe and exe.lower().endswith("python.exe"):
                exe = exe[:-len("python.exe")] + "pythonw.exe"
            if not exe or not os.path.exists(exe):
                exe = sys.executable
            subprocess.Popen([exe, script],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            messagebox.showinfo("网络连接监控", "网络连接监控已打开。")
        except Exception as e:
            messagebox.showerror("网络连接监控", f"启动失败：{e}")

    def _on_clean(self):
        """DG 一键清理：只清可再生的缓存/临时文件（白名单），绝不动个人文件"""
        targets = []
        def add(label, path):
            if path and os.path.exists(path):
                targets.append((label, path))
        add("用户临时文件", os.environ.get("TEMP", ""))
        add("系统临时文件", r"C:\\Windows\\Temp")
        add("Chrome 缓存", os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Google\\Chrome\\User Data\\Default\\Cache"))
        add("Edge 缓存", os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Microsoft\\Edge\\User Data\\Default\\Cache"))
        add("着色器缓存", os.path.join(os.environ.get("LOCALAPPDATA", ""), "D3DSCache"))
        add("缩略图缓存", os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Microsoft\\Windows\\Explorer"))
        if not targets:
            messagebox.showinfo("一键清理", "没有发现可清理的缓存。", parent=self.root)
            return
        ttl = "\\n".join("  · " + l for l, _ in targets)
        if not messagebox.askyesno("一键清理",
                                   "将清理以下可再生缓存（不会动你的个人文件、软件、回收站）：\\n" + ttl + "\\n\\n确认清理？",
                                   parent=self.root):
            return
        threading.Thread(target=self._clean_worker, args=(targets,), daemon=True).start()

    def _clean_worker(self, targets):
        import shutil
        freed = 0
        def dir_size(p):
            s = 0
            try:
                for root, _, files in os.walk(p):
                    for fn in files:
                        try:
                            s += os.path.getsize(os.path.join(root, fn))
                        except OSError:
                            pass
            except OSError:
                pass
            return s
        for label, path in targets:
            try:
                before = dir_size(path)
                if label == "缩略图缓存":
                    for fn in os.listdir(path):
                        if fn.startswith("thumbcache_"):
                            try:
                                os.remove(os.path.join(path, fn))
                            except OSError:
                                pass
                else:
                    for root, dirs, files in os.walk(path, topdown=False):
                        for fn in files:
                            try:
                                os.remove(os.path.join(root, fn))
                            except OSError:
                                pass
                        for d in dirs:
                            try:
                                os.rmdir(os.path.join(root, d))
                            except OSError:
                                pass
                freed += max(0, before - dir_size(path))
            except Exception:
                pass
        msg = "一键清理完成：释放约 %.1f MB" % (freed / 1024 / 1024)
        try:
            self.root.after(0, lambda: (self._append_log(msg),
                                        messagebox.showinfo("一键清理", msg, parent=self.root)))
        except Exception:
            pass

    def _open_process_manager(self):
        """打开进程管理器（独立进程，防重复启动）"""''',
    "网络监控+一键清理方法")

# ============ 4) 版本号 & 历史 ============
rep('APP_VERSION = "4.17.0"', 'APP_VERSION = "4.18.0"', "版本号")
rep('''    ("4.17.0", "4.16.1", "内容更新（启动项管家+文件粉碎）：''',
    '''    ("4.18.0", "4.17.0", "内容更新（黑窗修复+网络连接监控+一键清理+启动项管家搜索）：1.【黑窗修复】内测版启动从 run-beta.bat 改为 pythonw 直连（快捷方式已更新，不再闪命令符窗口）；主程序 _restart_app 加固——控制台 python.exe 一律换 pythonw.exe 并加 CREATE_NO_WINDOW，任何入口重启都不再弹黑窗；2.【网络连接监控】独立窗口——实时列出全部 TCP/UDP 连接（本地/远端地址/状态/所属进程），ESTABLISHED 外联青色高亮优先（银狐类回连监控重点），每 3 秒自动刷新；过滤进程名/远端IP/状态，右键复制地址与定位进程；3.【一键清理】工具页入口——只清可再生缓存（用户&系统临时目录、Chrome/Edge 缓存、着色器缓存、缩略图缓存），后台线程执行不卡界面，释放量实时报告，绝不动个人文件/软件/回收站；4.【启动项管家搜索】新增搜索框，按名称/命令/路径/来源即时过滤"),
    ("4.17.0", "4.16.1", "内容更新（启动项管家+文件粉碎）：''',
    "版本历史")

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)

import py_compile
for p in (MAIN, r"F:\桌面保护\desktopguard\net_monitor.py", r"F:\桌面保护\desktopguard\startup_manager.py"):
    py_compile.compile(p, doraise=True)
print("[OK] 4.18.0 补丁应用，main.py + net_monitor.py + startup_manager.py 语法通过")
