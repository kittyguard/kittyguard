# -*- coding: utf-8 -*-
"""手动 XOR(0xA5) 还原隔离区 DLL 到原路径（绕过数据库记录缺失问题）。"""
import os, json, sys

QUARANTINE_DIR = r"F:\桌面保护\desktopguard\quarantine"
META_DIR = os.path.join(QUARANTINE_DIR, "_meta")
TARGETS = [
    ("datetime",      "c541697c3e9086c6483e88d9cc8fe8a2efc74f663da0b0662babc04d3f79000f"),
    ("fibers",        "cbb6cb7ff25363b07647ea05d01f2881837d50b04bba4debe875a4aa3a307c52"),
    ("errorhandling", "cdae6e7d24d4ca4b491d483135740cc60f2dfc74dd2e01779e655b9f8f85a337"),
    ("debug",         "fed0c40d172de4de52dc2230c5c92fd6bc8e8553619d5bb5240dcc4f025dc8cf"),
]

def xor_file(src, dst):
    with open(src, "rb") as f:
        data = bytearray(f.read())
    for i in range(len(data)):
        data[i] ^= 0xA5
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, "wb") as f:
        f.write(bytes(data))
    return len(data)

for name, sha in TARGETS:
    meta_path = None
    for fn in os.listdir(META_DIR):
        if fn.endswith(".json"):
            try:
                with open(os.path.join(META_DIR, fn), "r", encoding="utf-8") as f:
                    m = json.load(f)
                if m.get("sha256") == sha:
                    meta_path = os.path.join(META_DIR, fn)
                    break
            except Exception:
                pass
    if not meta_path:
        print(f"[{name}] meta not found")
        continue
    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    dest = meta["original_path"]
    dgq = None
    for fn in os.listdir(QUARANTINE_DIR):
        if fn.lower().endswith(".dgq") and fn.startswith(sha[:16]):
            dgq = os.path.join(QUARANTINE_DIR, fn)
            break
    if not dgq:
        print(f"[{name}] dgq file not found (sha16={sha[:16]})")
        continue
    if os.path.exists(dest):
        print(f"[{name}] already exists, skip: {dest}")
        continue
    try:
        n = xor_file(dgq, dest)
        # 校验还原后的 SHA256
        import hashlib
        h = hashlib.sha256(open(dest, "rb").read()).hexdigest()
        ok = h == sha
        print(f"[{name}] restored {n}B to {dest} sha256_ok={ok}")
        if ok:
            os.remove(dgq)
            print(f"[{name}] removed dgq: {dgq}")
    except Exception as e:
        print(f"[{name}] FAILED: {e}")
