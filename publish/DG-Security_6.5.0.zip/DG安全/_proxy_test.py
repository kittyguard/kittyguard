# -*- coding: utf-8 -*-
import urllib.request, urllib.parse, json, sys

# 1) 系统代理设置
import winreg
try:
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
    pe, _ = winreg.QueryValueEx(k, "ProxyEnable")
    ps, _ = winreg.QueryValueEx(k, "ProxyServer")
    print("ProxyEnable:", pe, "ProxyServer:", ps)
    winreg.CloseKey(k)
except Exception as e:
    print("reg err", e)

# 2) 经 33210 代理测 github.com
for scheme, port in (("http", 33210), ("socks5", 7890)):
    try:
        proxy = "%s://127.0.0.1:%d" % (scheme, port)
        handler = urllib.request.ProxyHandler({"http": proxy, "https": proxy})
        opener = urllib.request.build_opener(handler)
        r = opener.open("https://github.com", timeout=15)
        print("PROXY_OK", scheme, port, "->", r.status, r.headers.get("Server"))
    except Exception as e:
        print("PROXY_FAIL", scheme, port, "->", repr(e)[:120])
