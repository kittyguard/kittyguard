# -*- coding: utf-8 -*-
"""
DG 启动项管家 4.17.0
独立窗口：扫描全部开机自启动项（注册表 Run/RunOnce + 启动文件夹），
支持 HKCU 与用户启动文件夹一键禁用/启用（可逆，不删除），
HKLM 项只读展示（需管理员改动，本工具不碰）。
深色科技风对齐 DG 4.0.0。
"""

import os
import sys
import time
import shutil
import ctypes
import winreg

# ============ 深色主题 ============
BG      = "#0d1520"
FG      = "#d8e6f2"
DIM     = "#7fa3c0"
ACCENT  = "#00d4ff"
WARN    = "#ffb648"
DANGER  = "#ff5c5c"
CARD    = "#14202e"
CARD2   = "#1b2b3d"
BORDER  = "#22303f"
GREEN   = "#3ddc84"
FONT    = ("Microsoft YaHei UI", 9)
FONT_B  = ("Microsoft YaHei UI", 10, "bold")
FONT_T  = ("Microsoft YaHei UI", 14, "bold")

OFF_PREFIX_REG   = "DG_OFF_"      # 注册表值名禁用前缀（可逆）
OFF_PREFIX_FILE  = "DG_OFF_"      # 启动文件夹文件禁用前缀（可逆）

RUN_HKCU  = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_ONCE_HKCU = r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
RUN_HKLM  = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_ONCE_HKLM = r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
RUN_HKLM64 = r"Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run"

USER_STARTUP = os.path.join(os.environ.get("APPDATA", ""),
                            r"Microsoft\Windows\Start Menu\Programs\Startup")
ALL_STARTUP = os.path.join(os.environ.get("PROGRAMDATA", r"C:\ProgramData"),
                           r"Microsoft\Windows\Start Menu\Programs\StartUp")

_tk = None


def _init_ttk_style():
    global _tk
    try:
        import tkinter.ttk as ttk
        s = ttk.Style(_tk)
        s.theme_use("clam")
        s.configure("Treeview", background=CARD2, fieldbackground=CARD2,
                    foreground=FG, borderwidth=0, rowheight=24, font=FONT)
        s.configure("Treeview.Heading", background="#24384f", foreground=FG,
                    font=FONT_B, borderwidth=0, relief="flat")
        s.map("Treeview", background=[("selected", ACCENT)],
              foreground=[("selected", "#001018")])
        s.map("Treeview.Heading", background=[("active", "#2c4a66")])
    except Exception:
        pass


def read_reg_run(key_path, root):
    """读注册表 Run/RunOnce，返回 [(value_name, command)]"""
    out = []
    try:
        k = winreg.OpenKey(root, key_path, 0, winreg.KEY_READ)
        i = 0
        while True:
            try:
                name, data, _ = winreg.EnumValue(k, i)
                i += 1
                if isinstance(data, str):
                    out.append((name, data))
            except OSError:
                break
        winreg.CloseKey(k)
    except OSError:
        pass
    return out


def list_startup():
    """返回 [{src, name, cmd, path, off}]"""
    items = []
    for name, cmd in read_reg_run(RUN_HKCU, winreg.HKEY_CURRENT_USER):
        off = name.startswith(OFF_PREFIX_REG)
        items.append({"src": "HKCU Run", "name": name, "cmd": cmd,
                      "path": "", "off": off, "kind": "reg"})
    for name, cmd in read_reg_run(RUN_ONCE_HKCU, winreg.HKEY_CURRENT_USER):
        off = name.startswith(OFF_PREFIX_REG)
        items.append({"src": "HKCU RunOnce", "name": name, "cmd": cmd,
                      "path": "", "off": off, "kind": "reg"})
    for name, cmd in read_reg_run(RUN_HKLM, winreg.HKEY_LOCAL_MACHINE):
        items.append({"src": "HKLM Run", "name": name, "cmd": cmd,
                      "path": "", "off": False, "kind": "reg_ro", "ro": True})
    for name, cmd in read_reg_run(RUN_ONCE_HKLM, winreg.HKEY_LOCAL_MACHINE):
        items.append({"src": "HKLM RunOnce", "name": name, "cmd": cmd,
                      "path": "", "off": False, "kind": "reg_ro", "ro": True})
    for name, cmd in read_reg_run(RUN_HKLM64, winreg.HKEY_LOCAL_MACHINE):
        items.append({"src": "HKLM Run(WOW64)", "name": name, "cmd": cmd,
                      "path": "", "off": False, "kind": "reg_ro", "ro": True})
    for d, src in ((USER_STARTUP, "启动文件夹(用户)"), (ALL_STARTUP, "启动文件夹(全局)")):
        try:
            for fn in os.listdir(d):
                fp = os.path.join(d, fn)
                if not os.path.isfile(fp):
                    continue
                off = fn.startswith(OFF_PREFIX_FILE)
                items.append({"src": src, "name": fn, "cmd": "",
                              "path": fp, "off": off, "kind": "file", "ro": src.endswith("(全局)")})
        except OSError:
            pass
    return items


def set_reg_off(name, cmd, root, key_path, off):
    """注册表项禁用/启用（改值名，可逆）"""
    k = winreg.OpenKey(root, key_path, 0, winreg.KEY_SET_VALUE)
    if off:
        new_name = OFF_PREFIX_REG + name
        winreg.SetValueEx(k, new_name, 0, winreg.REG_SZ, cmd)
        winreg.DeleteValue(k, name)
    else:
        if name.startswith(OFF_PREFIX_REG):
            real = name[len(OFF_PREFIX_REG):]
            winreg.SetValueEx(k, real, 0, winreg.REG_SZ, cmd)
            winreg.DeleteValue(k, name)
    winreg.CloseKey(k)


def set_file_off(path, off):
    """启动文件夹项禁用/启用（改名，可逆）"""
    d, fn = os.path.split(path)
    if off:
        new_fn = OFF_PREFIX_FILE + fn
    else:
        if fn.startswith(OFF_PREFIX_FILE):
            new_fn = fn[len(OFF_PREFIX_FILE):]
        else:
            return
    os.rename(path, os.path.join(d, new_fn))


class StartupManagerWin:
    def __init__(self, root):
        self.root = root
        self.items = []
        self._build()
        self.refresh()

    def _build(self):
        self.root.title("DG 启动项管家")
        self.root.configure(bg=BG)
        self.root.geometry("880x600")
        try:
            self.root.iconbitmap(os.path.join(os.path.dirname(os.path.abspath(__file__)), "shield.ico"))
        except Exception:
            pass

        head = tk.Frame(self.root, bg=BG)
        head.pack(fill="x", padx=14, pady=(12, 6))
        tk.Label(head, text="启动项管家", bg=BG, fg=ACCENT, font=FONT_T).pack(side="left")
        tk.Label(head, text="开机自启动项一览 · 禁用/启用可逆 · HKLM 项只读（改动需管理员，本工具不碰）",
                 bg=BG, fg=DIM, font=FONT).pack(side="left", padx=(12, 0), pady=(4, 0))

        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=14, pady=4)
        tk.Label(bar, text="搜索:", bg=BG, fg=DIM, font=FONT).pack(side="left")
        self.filter_entry = tk.Entry(bar, bg=CARD2, fg=FG, insertbackground=FG,
                                     relief="flat", font=FONT, width=18)
        self.filter_entry.pack(side="left", padx=(4, 6))
        self.filter_entry.bind("<Return>", lambda e: self.refresh())
        tk.Button(bar, text="搜索", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=self.refresh).pack(side="left")
        tk.Button(bar, text="刷新", bg=ACCENT, fg="#001018", activebackground="#33e0ff",
                  relief="flat", font=FONT_B, command=self.refresh).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="禁用选中", bg=WARN, fg="#1a0e00", activebackground="#ffc46b",
                  relief="flat", font=FONT_B, command=lambda: self.set_off(True)).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="启用选中", bg=GREEN, fg="#001407", activebackground="#5eeea0",
                  relief="flat", font=FONT_B, command=lambda: self.set_off(False)).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="打开文件位置", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=self.open_location).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="删除选中", bg=DANGER, fg="#ffffff", activebackground="#ff7d7d",
                  relief="flat", font=FONT, command=self.delete_selected).pack(side="left", padx=(16, 0))

        self.info_var = tk.StringVar(value=" ")
        tk.Label(self.root, textvariable=self.info_var, bg=BG, fg=DIM,
                 font=FONT, anchor="w").pack(fill="x", padx=14, pady=(2, 4))

        wrap = tk.Frame(self.root, bg=BORDER)
        wrap.pack(fill="both", expand=True, padx=14, pady=(0, 6))
        cols = ("off", "src", "name", "cmd")
        heads = ("状态", "来源", "名称", "命令 / 目标")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings",
                                 selectmode="browse", height=22)
        for c, h in zip(cols, heads):
            wd = 90 if c == "off" else (140 if c == "src" else (160 if c == "name" else 460))
            self.tree.heading(c, text=h)
            self.tree.column(c, width=wd, anchor="w", stretch=(c == "cmd"))
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.tag_configure("off", foreground=DIM)
        self.tree.tag_configure("ro", foreground=WARN)
        self.tree.bind("<Button-3>", self._ctx_menu)

        foot = tk.Frame(self.root, bg=BG)
        foot.pack(fill="x", padx=14, pady=(0, 10))
        tk.Label(foot, text="禁用仅改注册表值名 / 启动项文件名（DG_OFF_ 前缀），随时可启用恢复；HKLM 与全局启动文件夹只读展示",
                 bg=BG, fg=DIM, font=FONT).pack(side="left")

    def refresh(self):
        self.items = list_startup()
        kw = (getattr(self, "filter_var", None).get() if hasattr(self, "filter_var") else "") or ""
        kw = kw.strip().lower()
        if kw:
            self.items = [it for it in self.items
                          if kw in (it["name"] or "").lower()
                          or kw in (it["cmd"] or "").lower()
                          or kw in (it["path"] or "").lower()
                          or kw in it["src"].lower()]
        self.tree.delete(*self.tree.get_children())
        for it in self.items:
            off = it.get("off", False)
            ro = it.get("ro", False)
            status = "已禁用" if off else ("只读" if ro else "正常")
            tags = []
            if off:
                tags.append("off")
            if ro:
                tags.append("ro")
            disp_name = it["name"]
            if off:
                disp_name = disp_name[len(OFF_PREFIX_REG):] if it["kind"] == "reg" else disp_name[len(OFF_PREFIX_FILE):]
            self.tree.insert("", "end", iid=str(len(self.tree.get_children())),
                             values=(status, it["src"], disp_name, it["cmd"] or it["path"]),
                             tags=tuple(tags))
        n_off = sum(1 for it in self.items if it.get("off"))
        self.info_var.set(f"共 {len(self.items)} 个自启动项 ｜ 已禁用 {n_off} 个")

    def _selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        idx = int(sel[0])
        if idx < len(self.items):
            return self.items[idx]
        return None

    def set_off(self, off):
        it = self._selected()
        if it is None:
            messagebox.showinfo("启动项管家", "请先选择一项。", parent=self.root)
            return
        if it.get("ro"):
            messagebox.showwarning("启动项管家", "该项位于 HKLM / 全局启动文件夹，属系统级配置，本工具只读不修改。", parent=self.root)
            return
        name = it["name"]
        if off:
            if it["kind"] == "reg":
                key_path = RUN_ONCE_HKCU if it["src"] == "HKCU RunOnce" else RUN_HKCU
                set_reg_off(name, it["cmd"], winreg.HKEY_CURRENT_USER, key_path, True)
            else:
                set_file_off(it["path"], True)
            self.info_var.set(f"已禁用：{name}")
        else:
            if it["kind"] == "reg":
                real = name[len(OFF_PREFIX_REG):]
                key_path = RUN_ONCE_HKCU if it["src"] == "HKCU RunOnce" else RUN_HKCU
                set_reg_off(name, it["cmd"], winreg.HKEY_CURRENT_USER, key_path, False)
            else:
                set_file_off(it["path"], False)
            self.info_var.set(f"已启用：{name}")
        self.refresh()

    def delete_selected(self):
        it = self._selected()
        if it is None:
            messagebox.showinfo("启动项管家", "请先选择一项。", parent=self.root)
            return
        if it.get("ro"):
            messagebox.showwarning("启动项管家", "系统级项只读，不可删除。", parent=self.root)
            return
        name = it["name"]
        if not messagebox.askyesno("删除启动项",
                                   f"确认删除启动项？\n\n名称：{name}\n来源：{it['src']}\n\n这是不可逆操作（删除后需手动重建）。",
                                   parent=self.root):
            return
        try:
            if it["kind"] == "reg":
                key_path = RUN_ONCE_HKCU if it["src"] == "HKCU RunOnce" else RUN_HKCU
                k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
                winreg.DeleteValue(k, name)
                winreg.CloseKey(k)
            else:
                os.remove(it["path"])
            self.info_var.set(f"已删除：{name}")
            self.refresh()
        except Exception as e:
            messagebox.showerror("删除失败", str(e), parent=self.root)

    def open_location(self):
        it = self._selected()
        if it is None:
            return
        if it["kind"] == "reg":
            # 尽力解析命令中的 exe 路径
            cmd = it["cmd"]
            import re
            m = re.search(r'"([^"]+\.exe)"', cmd) or re.search(r'([A-Za-z]:\\[^"\s]+\.exe)', cmd)
            if m:
                path = m.group(1)
            else:
                messagebox.showinfo("启动项管家", f"无法定位程序：{cmd[:80]}", parent=self.root)
                return
        else:
            path = it["path"]
        try:
            import subprocess
            subprocess.Popen(["explorer", "/select,", path])
        except Exception:
            pass

    def _ctx_menu(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        self.tree.selection_set(iid)
        it = self._selected()
        if it is None:
            return
        m = tk.Menu(self.root, tearoff=0, bg=CARD2, fg=FG, activebackground=ACCENT,
                    activeforeground="#001018", font=FONT)
        m.add_command(label="禁用", command=lambda: self.set_off(True))
        m.add_command(label="启用", command=lambda: self.set_off(False))
        m.add_command(label="打开文件位置", command=self.open_location)
        m.add_command(label="复制名称", command=lambda: self._copy(it["name"]))
        m.tk_popup(event.x_root, event.y_root)

    def _copy(self, t):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(t)
            self.info_var.set(f"已复制：{t[:60]}")
        except Exception:
            pass


def main():
    global tk, messagebox, ttk
    import tkinter as tk
    import tkinter.messagebox as messagebox
    import tkinter.ttk as ttk
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def cb(h, l):
        if ctypes.windll.user32.IsWindowVisible(h):
            buf = ctypes.create_unicode_buffer(256)
            ctypes.windll.user32.GetWindowTextW(h, buf, 256)
            if "DG 启动项管家" in buf.value:
                found.append(h)
        return True
    try:
        ctypes.windll.user32.EnumWindows(cb, 0)
    except Exception:
        pass
    if found:
        try:
            ctypes.windll.user32.ShowWindow(found[0], 9)
            ctypes.windll.user32.SetForegroundWindow(found[0])
        except Exception:
            pass
        return

    root = tk.Tk()
    _tk = root
    _init_ttk_style()
    app = StartupManagerWin(root)
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.mainloop()


if __name__ == "__main__":
    main()
