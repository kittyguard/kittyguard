# -*- coding: utf-8 -*-
"""6.4.2 官网 HTML 下载链接升级：6.4.1 -> 6.4.2（6 份 HTML，保留历史时间线节点）"""
import io, os

HTML_FILES = [
    r"F:\桌面保护\desktopguard\官网\DG安全官网.html",
    r"F:\桌面保护\desktopguard\官网\index.html",
    r"F:\桌面保护\desktopguard\官网\publish\index.html",
    r"F:\桌面保护\kittyguard_site\DG安全官网.html",
    r"F:\桌面保护\kittyguard_site\index.html",
    r"F:\桌面保护\kittyguard_site\publish\index.html",
]

# 只替换下载链接与“当前版本”文案；历史时间线节点（tl-time 6.4.1）不动
REPL = [
    ("/DG-Security-Setup-6.4.1.exe", "/DG-Security-Setup-6.4.2.exe"),
    ("/DG-Security_6.4.1.zip", "/DG-Security_6.4.2.zip"),
    ("/DG-Source_6.4.1.zip", "/DG-Source_6.4.2.zip"),
    ("DG-Security-Setup-6.4.1.exe", "DG-Security-Setup-6.4.2.exe"),
    ("DG-Security_6.4.1.zip", "DG-Security_6.4.2.zip"),
    ("DG-Source_6.4.1.zip", "DG-Source_6.4.2.zip"),
    ("DG 6.4.1</span> engine starting", "DG 6.4.2</span> engine starting"),
    ("当前版本 6.4.1", "当前版本 6.4.2"),
    (">6.4.1<", ">6.4.2<"),
]

for p in HTML_FILES:
    if not os.path.isfile(p):
        print("MISSING:", p)
        continue
    with io.open(p, "r", encoding="utf-8") as f:
        s = f.read()
    orig = s
    for a, b in REPL:
        s = s.replace(a, b)
    changed = s != orig
    with io.open(p, "w", encoding="utf-8") as f:
        f.write(s)
    # 统计剩余 6.4.1 引用（应为时间线历史节点）
    rest = s.count("6.4.1")
    print(("UPDATED " if changed else "UNCHANGED ") + p + " | remaining 6.4.1 refs: " + str(rest))
