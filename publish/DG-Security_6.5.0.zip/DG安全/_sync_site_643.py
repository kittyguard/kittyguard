# -*- coding: utf-8 -*-
"""同步 6.4.3 产物到 kittyguard_site（Pages 仓库）"""
import os, shutil

SITE = r"F:\桌面保护\kittyguard_site"
OFF = r"F:\桌面保护\desktopguard\官网"
PUB = os.path.join(OFF, "publish")
VER = "6.4.3"

files = ["DG-Security-Setup-%s.exe" % VER, "DG-Security_%s.zip" % VER, "DG-Source_%s.zip" % VER]
for f in files:
    for src in (OFF, PUB):
        p = os.path.join(src, f)
        if os.path.isfile(p):
            shutil.copy2(p, os.path.join(SITE, f))
            shutil.copy2(p, os.path.join(SITE, "publish", f))
            print("synced", f, os.path.getsize(p))
            break
    else:
        print("MISSING", f)
# 官网 html 同步（site 的双源版保留，仅同步 version.json 已做）
print("SITE_SYNC_DONE")
