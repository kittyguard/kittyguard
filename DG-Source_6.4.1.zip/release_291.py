# -*- coding: utf-8 -*-
"""2.9.1 发布：补丁（设置窗口崩溃修复 + AI助手验证）"""
import os, shutil, json, py_compile

src = r'F:\桌面保护\desktopguard'
beta = r'F:\桌面保护\desktopguard-beta'

# 1. 同步内测版
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp']:
    s = os.path.join(src, fname)
    d = os.path.join(beta, fname)
    if os.path.exists(s):
        shutil.copy2(s, d)
print("已同步内测版")

# 2. 版本号 -> 2.9.1
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py', 'scan_core_bridge.py']:
    p = os.path.join(src, fname)
    with open(p, 'r', encoding='utf-8') as f:
        c = f.read()
    c = c.replace('APP_VERSION = "2.9.0"', 'APP_VERSION = "2.9.1"')
    c = c.replace('"2.9.0"', '"2.9.1"')
    with open(p, 'w', encoding='utf-8') as f:
        f.write(c)
print("版本号 -> 2.9.1")

# 3. VERSION_LIST 加 2.9.1 + VERSION_HISTORY 加记录
mp = os.path.join(src, 'main.py')
with open(mp, 'r', encoding='utf-8') as f:
    c = f.read()
# VERSION_LIST
old_l = '"2.6.1", "2.7.0", "2.7.1", "2.8.0"]'
new_l = '"2.6.1", "2.7.0", "2.7.1", "2.8.0", "2.9.0", "2.9.1"]'
if old_l in c:
    c = c.replace(old_l, new_l, 1)
    print("VERSION_LIST 已加 2.9.1")
# VERSION_HISTORY（加到 2.9.0 记录前）
hist = '''    ("2.9.1", "补丁版：1.修复设置窗口打开崩溃（实时防护延迟初始化导致 self._rtp 为 None）；2.AI助手对话流程完整验证（后台线程+队列+15秒超时，DeepSeek 真实回复）；3.全部模块回归测试通过（设置/启动项22条/计划任务312条/隔离区/AI助手/目录监控/安全体检）"),
    ("2.9.0", "内容更新（重大修复）：1.修复扫描线程崩溃（LEVEL_CRITICAL→LEVEL_CRIT，三模式扫描恢复正常、停止有效）；2.修复subprocess编码崩溃（UTF-8模式解码GBK输出）；3.修复扫描后同步AI分析阻塞主线程（GUI未响应）；4.恢复AI辅助分析（DeepSeek实测0.8秒返回）；5.修复病毒库管理窗口崩溃（函数名冲突）；6.补全VERSION_LIST/HISTORY到2.8.0（版本切换恢复正常）"),
    ("2.8.0", "安全体检全面加固：1.新增30秒总超时兜底（任何检查卡住都会强制完成并显示已收集结果，不再永远卡在「正在体检」）；2.缩短所有subprocess超时（schtasks 8->6s，sc/netsh 5->4s）；3.体检线程全程异常保护；4.超时时自动补全未完成项提示；5.窗口标题统一为DG 桌面安全卫士，窗口加宽到1280按钮完整"),
'''
anchor = '    ("2.8.0", "安全体检全面加固'
if anchor in c:
    c = c.replace(anchor, hist, 1)
    print("VERSION_HISTORY 已加 2.9.0/2.9.1")
with open(mp, 'w', encoding='utf-8') as f:
    f.write(c)

# 4. version.json
version_data = {
    "latest_version": "2.9.1",
    "release_date": "2026-09-09",
    "release_notes": "2.9.1 补丁版：1.修复设置窗口打开崩溃（实时防护延迟初始化导致 self._rtp 为 None）；2.AI助手对话流程完整验证（DeepSeek 真实回复）；3.全部模块回归测试通过",
    "features": [
        "设置窗口永不崩溃",
        "AI 助手对话完整可用",
        "全部模块回归通过"
    ]
}
with open(os.path.join(src, 'version.json'), 'w', encoding='utf-8') as f:
    json.dump(version_data, f, ensure_ascii=False, indent=2)
print("version.json 已更新")

# 5. 快照
snap = os.path.join(src, 'versions', '2.9.1')
os.makedirs(snap, exist_ok=True)
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp']:
    s = os.path.join(src, fname)
    if os.path.exists(s):
        shutil.copy2(s, os.path.join(snap, fname))
print("快照 versions/2.9.1 已创建")

# 6. 语法验证
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py', 'scan_core_bridge.py']:
    py_compile.compile(os.path.join(src, fname), doraise=True)
print("全部语法通过")
print("\n2.9.1 发布完成！")
