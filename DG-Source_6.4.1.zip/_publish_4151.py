# -*- coding: utf-8 -*-
"""发布 4.15.1：同步 selfdefense 版本号 + 生成版本快照"""
import io, os, shutil, time, json

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "4.15.1"

SD = os.path.join(DG, "selfdefense.py")
with io.open(SD, "r", encoding="utf-8") as f:
    s = f.read()
old = 'APP_VERSION = "4.15.0"'
assert old in s, "selfdefense 当前版本号不是 4.15.0"
s = s.replace(old, 'APP_VERSION = "4.15.1"')
with io.open(SD, "w", encoding="utf-8") as f:
    f.write(s)
print("[OK] selfdefense.py 版本号 -> 4.15.1")

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico", "scan_core.exe", "dg_quarantine.exe"):
    sp = os.path.join(DG, fn)
    if os.path.isfile(sp):
        src_files.append(fn)
copied = 0
for fn in src_files:
    sp = os.path.join(DG, fn)
    dp = os.path.join(ver_dir, fn)
    try:
        shutil.copy2(sp, dp)
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print(f"  跳过 {fn}: {e}")
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print(f"[OK] 快照 {NEW_VER} 生成: {copied} 个文件")
