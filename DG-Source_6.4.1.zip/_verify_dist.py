# -*- coding: utf-8 -*-
import os, zipfile, hashlib, shutil, subprocess, io, json

DG = r"F:\桌面保护\desktopguard"
DIST = os.path.join(DG, "dist", "DG安全")

# 验证 python314.dll 与依赖
found = {}
for f in ["python314.dll", "python312.dll"]:
    p = os.path.join(DIST, "_internal", f)
    found[f] = os.path.isfile(p)
print("dist python dlls:", found)

deps = {
    "onnxruntime": os.path.exists(os.path.join(DIST, "_internal", "onnxruntime", "capi", "onnxruntime_pybind11_state.pyd")),
    "PIL": os.path.exists(os.path.join(DIST, "_internal", "PIL")),
    "psycopg2": os.path.exists(os.path.join(DIST, "_internal", "psycopg2")),
}
print("deps present:", deps)

exe = os.path.join(DIST, "DG安全.exe")
print("exe size:", os.path.getsize(exe) if os.path.exists(exe) else "MISSING")
