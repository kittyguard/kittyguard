# -*- coding: utf-8 -*-
import os

for p in [r"F:\桌面保护\desktopguard\quarantine\_meta",
          r"F:\桌面保护\desktopguard\quarantine\_restored_642"]:
    print("===", p, "===")
    print("exists:", os.path.isdir(p))
    if os.path.isdir(p):
        items = sorted(os.listdir(p))
        print("count:", len(items))
        # 只打印与 __init__ / 01dfa / api-ms 相关的
        for f in items:
            if "__init__" in f or "01dfa" in f or "api-ms" in f or "be5a" in f or "e3b0" in f or "47cf" in f or "8aa6" in f:
                print("  ", f)
    print()
