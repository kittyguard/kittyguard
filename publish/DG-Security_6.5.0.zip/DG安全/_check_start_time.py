# -*- coding: utf-8 -*-
import subprocess, os, datetime

r = subprocess.run(["powershell", "-NoProfile", "-Command",
    "$proc = Get-Process -Id 37780 -ErrorAction SilentlyContinue; if ($proc) { $proc.StartTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'NOT_RUNNING' }"],
    capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=30)
start = r.stdout.strip()

mt = os.path.getmtime(r"F:\桌面保护\desktopguard\main.py")
print("main.py last modified:", datetime.datetime.fromtimestamp(mt).strftime("%Y-%m-%d %H:%M:%S"))
print("pythonw(37780) start:", start)

if start != "NOT_RUNNING":
    try:
        st = datetime.datetime.strptime(start, "%Y-%m-%d %H:%M:%S")
        if st > datetime.datetime.fromtimestamp(mt):
            print("=> 主程序启动晚于修复写入，加载的是 6.4.2 修复版代码")
        else:
            print("=> 主程序启动早于修复写入，内存仍是旧逻辑（需重启）")
    except Exception as e:
        print("compare err:", e)
