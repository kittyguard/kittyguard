# -*- coding: utf-8 -*-
"""补处理 fce __init__.py 记录（01dfa508183b7e7a）"""
import os, glob, json, shutil

QM = r"F:\桌面保护\desktopguard\quarantine\_meta"
QP = r"F:\桌面保护\desktopguard\quarantine"
KEEP = r"F:\桌面保护\desktopguard\quarantine\_restored_642"

os.makedirs(KEEP, exist_ok=True)
moved = 0
if os.path.isdir(QM):
    for m in sorted(glob.glob(os.path.join(QM, "*.json")) + glob.glob(os.path.join(QM, "*.meta.json"))):
        base = os.path.basename(m)
        if "01dfa508183b7e7a" not in base:
            continue
        # 尝试解析 op
        op = ""
        try:
            with open(m, "r", encoding="utf-8", errors="replace") as f:
                d = json.load(f)
            op = d.get("original_path", "")
        except Exception as e:
            print("PARSE FAIL", base, repr(e))
        print("FOUND:", base, "| op:", op)
        # 移动 meta
        dst = os.path.join(KEEP, base)
        if os.path.exists(dst):
            dst = os.path.join(KEEP, "dup_" + base)
        shutil.move(m, dst)
        print("  MOVED meta ->", os.path.basename(dst))
        # 对应 .dgq：去掉 .meta.json 后缀
        dgq = os.path.join(QP, base.replace(".dgq.meta.json", ".dgq"))
        if os.path.isfile(dgq):
            shutil.move(dgq, os.path.join(KEEP, os.path.basename(dgq)))
            print("  MOVED dgq:", os.path.basename(dgq))
        moved += 1
print("total moved:", moved)
