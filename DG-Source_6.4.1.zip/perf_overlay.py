# -*- coding: utf-8 -*-
"""
DG安全 · 性能悬浮窗 v2（CPU/GPU/内存/磁盘/网络/系统 全量实时监控）
独立运行：python perf_overlay.py
被 DG 主程序调用：subprocess 启动本脚本（互不阻塞）
- CPU/GPU 占用 5 点平滑 + 启动预热，数字稳定
- CPU 温度 WMI ACPI 尽力读取（不支持机型显示 --）
- GPU 温度/显存/频率/功耗/风扇转速 经 NVIDIA NVML
- 跟随主程序：默认检测 DG 主程序（pythonw main.py）存活，主程序退出后自动关闭本悬浮窗
  （--standalone 可禁用跟随，单独手动运行时用）
"""
import os
import sys
import time
import threading
import subprocess
import collections
import tkinter as tk

_STANDALONE = "--standalone" in sys.argv

# ---------- 数据源（延迟导入，失败自动降级为 N/A） ----------
_psutil = None
_nvml = None
_nv_handle = None
_SMOOTH = collections.deque(maxlen=5)   # CPU 平滑
_SMOOTH_G = collections.deque(maxlen=5) # GPU 平滑
_last_net = None
_last_disk = None
_last_tick = None

def _load_sources():
    global _psutil, _nvml, _nv_handle
    try:
        import psutil
        _psutil = psutil
        _psutil.cpu_percent(interval=None)   # 预热基准
    except Exception:
        pass
    try:
        import pynvml
        pynvml.nvmlInit()
        _nvml = pynvml
        _nv_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    except Exception:
        _nvml = None
        _nv_handle = None

# ---------- 主题（DG 4.x 深色科技风） ----------
BG      = "#0d1520"
FG      = "#d8e6f2"
DIM     = "#7fa3c0"
ACCENT  = "#00d4ff"
WARN    = "#ffb648"
DANGER  = "#ff5c5c"
FONT    = ("Microsoft YaHei UI", 9)
FONT_S  = ("Microsoft YaHei UI", 8)
FONT_T  = ("Microsoft YaHei UI", 9, "bold")

def _color(v, hi=70, warn=45):
    if v >= hi:
        return DANGER
    if v >= warn:
        return WARN
    return ACCENT

# ---------- 数据采集（全部容错） ----------
_cpu_temp = None
_t0 = 0

def _read_reg_vram():
    """从注册表读显卡硬件内存大小 qwMemorySize（64位，不受 AdapterRAM 32位上限影响）。
    用于修正 NVML 读取异常（<2GB，疑似魔改驱动/伪报）时的显存显示。
    返回: 字节数（无则 None）。
    """
    try:
        import winreg
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        for i in range(10):
            try:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, "%s\\%04d" % (base, i))
                try:
                    val, _ = winreg.QueryValueEx(k, "HardwareInformation.qwMemorySize")
                    if val:
                        return int(val)
                finally:
                    winreg.CloseKey(k)
            except Exception:
                continue
    except Exception:
        pass
    return None


def _read_cpu_temp():
    """尽力读取 CPU 温度（WMI ACPI 热区；不支持则 None）"""
    try:
        out = subprocess.run(
            ["wmic", "/namespace:\\\\root\\wmi", "PATH",
             "MSAcpi_ThermalZoneTemperature", "get", "CurrentTemperature"],
            capture_output=True, text=True, timeout=3,
            encoding="gbk", errors="ignore",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        for line in out.stdout.splitlines():
            s = line.strip()
            if s.isdigit():
                return round(int(s) / 10.0 - 273.15, 1)
    except Exception:
        pass
    return None

def _fmt_speed(bps):
    """字节/秒 -> 可读速度"""
    if bps is None:
        return "--"
    if bps >= 1024**2:
        return f"{bps/1024**2:.1f}MB/s"
    if bps >= 1024:
        return f"{bps/1024:.0f}KB/s"
    return f"{bps:.0f}B/s"

def _fmt_uptime(sec):
    d = int(sec // 86400)
    h = int(sec % 86400 // 3600)
    m = int(sec % 3600 // 60)
    if d:
        return f"{d}天{h}时{m}分"
    if h:
        return f"{h}时{m}分"
    return f"{m}分"

def sample():
    global _cpu_temp, _t0, _last_net, _last_disk, _last_tick
    now = time.time()
    d = {}
    # CPU
    if _psutil:
        try:
            d["cpu"] = _psutil.cpu_percent(interval=None)
            _SMOOTH.append(d["cpu"])
            d["cpu"] = round(sum(_SMOOTH) / len(_SMOOTH), 1)
        except Exception:
            d["cpu"] = None
        try:
            f = _psutil.cpu_freq()
            d["freq"] = round(f.current or 0)
            d["freq_max"] = round(f.max or 0)
        except Exception:
            d["freq"] = d["freq_max"] = None
        d["cores"] = _psutil.cpu_count(logical=True)
        try:
            m = _psutil.virtual_memory()
            d["mem"] = m.percent
            d["mem_used"] = round(m.used / 1024**3, 1)
            d["mem_total"] = round(m.total / 1024**3, 1)
            d["mem_avail"] = round(m.available / 1024**3, 1)
        except Exception:
            d["mem"] = None
        try:
            du = _psutil.disk_usage("C:")
            d["disk"] = du.percent
        except Exception:
            d["disk"] = None
        try:
            d["procs"] = len(_psutil.pids())
        except Exception:
            d["procs"] = None
        try:
            d["boot"] = _fmt_uptime(now - _psutil.boot_time())
        except Exception:
            d["boot"] = None
        # 网速（差值）
        try:
            net = _psutil.net_io_counters()
            if _last_net is not None and _last_tick:
                dt = now - _last_tick
                d["down"] = max(0, (net.bytes_recv - _last_net[0]) / dt)
                d["up"] = max(0, (net.bytes_sent - _last_net[1]) / dt)
            _last_net = (net.bytes_recv, net.bytes_sent)
        except Exception:
            d["down"] = d["up"] = None
        # 磁盘读写（差值）
        try:
            dio = _psutil.disk_io_counters()
            if _last_disk is not None and _last_tick:
                dt = now - _last_tick
                d["dread"] = max(0, (dio.read_bytes - _last_disk[0]) / dt)
                d["dwrite"] = max(0, (dio.write_bytes - _last_disk[1]) / dt)
            _last_disk = (dio.read_bytes, dio.write_bytes)
        except Exception:
            d["dread"] = d["dwrite"] = None
        _last_tick = now
    # CPU 温度（每 10 秒刷新一次）
    if _cpu_temp is None or now - _t0 > 10:
        _cpu_temp = _read_cpu_temp()
        _t0 = now
    d["cput"] = _cpu_temp
    # GPU（NVIDIA）
    if _nvml and _nv_handle:
        try:
            util = _nvml.nvmlDeviceGetUtilizationRates(_nv_handle)
            _SMOOTH_G.append(util.gpu)
            d["gpu"] = round(sum(_SMOOTH_G) / len(_SMOOTH_G), 1)
        except Exception:
            d["gpu"] = None
        try:
            d["gpuc"] = _nvml.nvmlDeviceGetTemperature(_nv_handle, _nvml.NVML_TEMPERATURE_GPU)
        except Exception:
            d["gpuc"] = None
        try:
            mi = _nvml.nvmlDeviceGetMemoryInfo(_nv_handle)
            total_b = mi.total
            # C1：NVML 读数异常（<2GB，疑似魔改驱动伪报）时，用注册表硬件信息修正
            if total_b < 2048 * 1024**2:
                reg_b = _read_reg_vram()
                if reg_b and reg_b >= 2048 * 1024**2:
                    total_b = reg_b
                    d["vram_fixed"] = True
            d["vram_used"] = round(mi.used / 1024**3, 1)
            d["vram_total"] = round(total_b / 1024**3, 1)
            d["vram_pct"] = round(mi.used / total_b * 100, 0)
        except Exception:
            d["vram_used"] = d["vram_total"] = d["vram_pct"] = None
        try:
            d["gclk"] = _nvml.nvmlDeviceGetClockInfo(_nv_handle, _nvml.NVML_CLOCK_GRAPHICS)
        except Exception:
            d["gclk"] = None
        try:
            d["mclk"] = _nvml.nvmlDeviceGetClockInfo(_nv_handle, _nvml.NVML_CLOCK_MEM)
        except Exception:
            d["mclk"] = None
        try:
            d["pw"] = round(_nvml.nvmlDeviceGetPowerUsage(_nv_handle) / 1000.0, 0)
        except Exception:
            d["pw"] = None
        try:
            fan = _nvml.nvmlDeviceGetFanSpeed(_nv_handle)
            d["fan"] = fan if fan is not None else None
        except Exception:
            d["fan"] = None
    return d

# ---------- 悬浮窗 ----------
class PerfOverlay:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("DG 性能悬浮窗")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        try:
            self.root.attributes("-alpha", 0.95)
        except Exception:
            pass
        try:
            self.root.attributes("-toolwindow", True)
        except Exception:
            pass
        sw = self.root.winfo_screenwidth()
        self.root.geometry(f"300x392+{sw - 320}+60")
        self.root.configure(bg=BG)

        self._build()
        self._drag = None

        self.menu = tk.Menu(self.root, tearoff=0, bg=BG, fg=FG,
                            activebackground=ACCENT, activeforeground="#001018",
                            bd=1, relief="solid")
        self.menu.add_command(label="置顶：开 / 关", command=self._toggle_top)
        self.menu.add_command(label="刷新 0.5 秒", command=lambda: self._set_interval(0.5))
        self.menu.add_command(label="刷新 1 秒", command=lambda: self._set_interval(1.0))
        self.menu.add_command(label="刷新 2 秒", command=lambda: self._set_interval(2.0))
        self.menu.add_separator()
        self.menu.add_command(label="退出悬浮窗", command=self.root.destroy)

        self._interval = 1.0
        self._tick()

        # ---- 跟随主程序：DG 退出后自动关闭悬浮窗（--standalone 时禁用） ----
        self._master_gone = 0
        self._master_watch()

    def _master_watch(self):
        """每 5 秒检测主程序存活，连续约 30 秒未检测到（覆盖 DG 重启切换空窗）自动退出"""
        if not _STANDALONE:
            if not _master_alive():
                self._master_gone += 1
                if self._master_gone >= 6:
                    try:
                        self.root.destroy()
                        return
                    except Exception:
                        pass
            else:
                self._master_gone = 0
        try:
            self.root.after(5000, self._master_watch)
        except Exception:
            pass

    def _mk(self, parent, text, color=FG, font=FONT):
        return tk.Label(parent, text=text, bg=BG, fg=color, font=font,
                        anchor="w", justify="left")

    def _build(self):
        head = tk.Frame(self.root, bg=BG)
        head.pack(fill="x", padx=8, pady=(6, 2))
        self.title_lb = self._mk(head, "DG · 性能悬浮窗", ACCENT, FONT_T)
        self.title_lb.pack(side="left")
        btn_exit = tk.Label(head, text="✕", bg=BG, fg="#ff8080",
                            font=("Segoe UI", 12, "bold"), cursor="hand2",
                            padx=8, pady=2)
        btn_exit.pack(side="right")
        btn_exit.bind("<Button-1>", lambda e: self.root.destroy())

        self.lb = {}
        rows = [
            ("cpu",    "CPU   --", ACCENT, FONT_T),
            ("cput",   "温度 --", FG, FONT),
            ("gpu",    "GPU   --", ACCENT, FONT_T),
            ("vram",   "显存 --", FG, FONT),
            ("pw",     "功耗 --", FG, FONT),
            ("fan",    "风扇 --", FG, FONT),
            ("mem",    "内存 --", FG, FONT),
            ("disk",   "磁盘C --", FG, FONT),
            ("io",     "硬盘读写 --", FG, FONT),
            ("net",    "网速 --", FG, FONT),
            ("sys",    "系统 --", FG, FONT),
        ]
        for key, text, color, font in rows:
            lb = self._mk(self.root, text, color, font)
            lb.pack(fill="x", padx=10, pady=(1, 0))
            self.lb[key] = lb
        tip = self._mk(self.root, "拖动移动 · 右键菜单", DIM, FONT_S)
        tip.pack(fill="x", padx=10, pady=(4, 6))

        for w in (self.root, head, self.title_lb, tip):
            w.bind("<Button-1>", self._press)
            w.bind("<B1-Motion>", self._move)
            w.bind("<Button-3>", self._menu)
        # ✕ 单独绑定：保持关闭功能（不参与拖动）
        btn_exit.bind("<Button-1>", lambda e: self.root.destroy())
        btn_exit.bind("<Button-3>", lambda e: self._menu(e))
        for lb in self.lb.values():
            lb.bind("<Button-1>", self._press)
            lb.bind("<B1-Motion>", self._move)
            lb.bind("<Button-3>", self._menu)

    def _press(self, e):
        self._drag = (e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y())

    def _move(self, e):
        if self._drag:
            x, y = e.x_root - self._drag[0], e.y_root - self._drag[1]
            self.root.geometry(f"+{x}+{y}")

    def _menu(self, e):
        try:
            self.menu.tk_popup(e.x_root, e.y_root)
        finally:
            self.menu.grab_release()

    def _toggle_top(self):
        cur = self.root.attributes("-topmost")
        self.root.attributes("-topmost", not cur)

    def _set_interval(self, sec):
        self._interval = sec

    def _fmt(self, v, suffix="", na="--"):
        return f"{v}{suffix}" if v is not None else na

    def _tick(self):
        try:
            d = sample()
            L = self.lb
            if _psutil and d.get("cpu") is not None:
                c = _color(d["cpu"])
                L["cpu"].config(
                    text=f"CPU   {d['cpu']:>3.0f}%  {self._fmt(d.get('freq'), 'MHz')}  {d.get('cores','')}核",
                    fg=c)
            if d.get("cput") is not None:
                L["cput"].config(text=f"温度 {d['cput']:.1f} °C", fg=_color(d["cput"], 80, 60))
            if _nvml and _nv_handle and d.get("gpu") is not None:
                L["gpu"].config(
                    text=f"GPU   {d['gpu']:>3.0f}%  {self._fmt(d.get('gpuc'), ' °C')}",
                    fg=_color(d["gpu"]))
                if d.get("vram_total"):
                    vp = d.get("vram_pct")
                    vp_s = f"({vp:.0f}%)" if vp is not None else ""
                    fix = " *" if d.get("vram_fixed") else ""
                    L["vram"].config(
                        text=f"显存 {d['vram_used']:.1f}/{d['vram_total']:.1f}GB{fix} {vp_s}  核心{self._fmt(d.get('gclk'),'MHz')} 显存{self._fmt(d.get('mclk'),'MHz')}")
                if d.get("pw") is not None:
                    L["pw"].config(text=f"功耗 {d['pw']:.0f} W")
                if d.get("fan") is not None:
                    L["fan"].config(text=f"风扇 {d['fan']}%")
            if d.get("mem") is not None:
                L["mem"].config(
                    text=f"内存 {d['mem']:>3.0f}%  {d['mem_used']:.1f}/{d['mem_total']:.1f}GB 可用{d['mem_avail']:.1f}G",
                    fg=_color(d["mem"]))
            if d.get("disk") is not None:
                L["disk"].config(text=f"磁盘C {d['disk']:>3.0f}%", fg=_color(d["disk"]))
            if d.get("dread") is not None:
                L["io"].config(text=f"硬盘 读 {_fmt_speed(d['dread'])}  写 {_fmt_speed(d['dwrite'])}")
            if d.get("down") is not None:
                L["net"].config(text=f"网速  ↓{_fmt_speed(d['down'])}  ↑{_fmt_speed(d['up'])}")
            if d.get("sys") is not None or d.get("procs"):
                L["sys"].config(text=f"系统 运行{self._fmt(d.get('boot'))}  进程{self._fmt(d.get('procs'))}")
        except Exception:
            pass
        self.root.after(int(self._interval * 1000), self._tick)

def main():
    _load_sources()
    app = PerfOverlay()
    app.root.mainloop()

# ---------- 跟随主程序存活检测 ----------
def _master_alive():
    """DG 主程序（pythonw/python + main.py）是否存活"""
    if not _psutil:
        return True  # psutil 不可用时不判断，避免误关
    try:
        for proc in _psutil.process_iter(["name", "cmdline"]):
            try:
                nm = (proc.info.get("name") or "").lower()
                cl = " ".join(proc.info.get("cmdline") or [])
                if nm.startswith("python") and "main.py" in cl:
                    return True
            except Exception:
                continue
    except Exception:
        return True
    return False

if __name__ == "__main__":
    main()
