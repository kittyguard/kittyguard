# -*- coding: utf-8 -*-
"""
DesktopGuard 扫描引擎
======================
基于真实文件数据分析的风险判定引擎，零第三方依赖（仅标准库）。

判定思路（评分制，不是"是 exe 就高危"）：
  1. 文件类型识别        —— 读文件头 magic bytes + 扩展名，判断真实类型
  2. 哈希比对            —— SHA256 与用户维护的黑名单库比对（内置 EICAR 测试样本）
  3. PE 静态分析         —— 解析导入表、区段名（加壳）、可疑 API 组合
  4. 脚本/内容特征扫描   —— 自启动、下载执行、混淆、挖矿、勒索、远控等特征串
  5. 熵值检测            —— 高熵 = 加密/加壳/混淆嫌疑
  6. 文件属性            —— 隐藏属性 + 可执行 + 高风险类型的组合
  7. 数字签名(可选)      —— 有效签名显著降权（由 GUI 在强力/深度扫描时批量调用）

风险分累加，映射为：安全 / 低危 / 中危 / 高危 / 严重
命中黑名单或 EICAR 测试样本 → 直接"严重"。
"""

from paths import DATA_DIR
import os
import re
import hashlib
import json
import math
import string
import struct
import tempfile
import subprocess
from dataclasses import dataclass, field
from typing import List, Optional

# ---------------------------------------------------------------- 常量

# 最新版本号：发布新版本时同步更新（如 "1.2.3"）。
# 检查更新 = 比较主程序 APP_VERSION 与此值；低于此值提示有新版本。
LATEST_VERSION = "1.2.5"
ENGINE_VERSION = "3.0.2"  # 引擎版本，缓存失效依据（3.0.2 起缓存真正启用）

LEVEL_SAFE = "安全"
LEVEL_LOW = "低危"
LEVEL_MED = "中危"
LEVEL_HIGH = "高危"
LEVEL_CRIT = "严重"
LEVEL_JUNK = "垃圾"

# 显示排序：严重 > 高危 > 中危 > 低危 > 垃圾 > 安全 > 白名单
LEVEL_ORDER = {LEVEL_CRIT: 0, LEVEL_HIGH: 1, LEVEL_MED: 2, LEVEL_LOW: 3,
               LEVEL_JUNK: 4, LEVEL_SAFE: 5, "白名单": 6}

# 高风险扩展名 → 基础风险分。
# 注意：常见无害类型（exe/dll/bat/cmd/js/jar/reg/msi/lnk/普通文档）不给基础分，
# 完全靠内容/PE 分析判定——避免"见到 exe 就标记"的误报；只有真正高危的类型才加分。
RISKY_EXTS = {
    ".sys": 2, ".scr": 2, ".com": 2, ".cpl": 2, ".ocx": 2,
    ".ps1": 1, ".vbs": 1, ".vbe": 2, ".jse": 2, ".wsf": 2,
    ".hta": 2,
}

# 脚本类扩展名（读全文做内容特征扫描）
SCRIPT_EXTS = {".ps1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".bat", ".cmd", ".hta", ".reg", ".py", ".pyw"}

# 扩展名伪装检测：双扩展名模式（常见文档/图片后缀 + 可执行后缀）
SUSPICIOUS_DOUBLE_EXT = [
    ".jpg.exe", ".jpeg.exe", ".png.exe", ".gif.exe", ".bmp.exe", ".ico.exe",
    ".pdf.exe", ".doc.exe", ".docx.exe", ".xls.exe", ".xlsx.exe", ".ppt.exe", ".pptx.exe",
    ".txt.exe", ".rtf.exe", ".csv.exe", ".html.exe", ".htm.exe",
    ".mp3.exe", ".mp4.exe", ".avi.exe", ".mkv.exe", ".wav.exe",
    ".zip.exe", ".rar.exe", ".7z.exe", ".tar.exe",
    ".pdf.scr", ".jpg.scr", ".docx.scr", ".txt.scr",
    ".pdf.vbs", ".jpg.vbs", ".docx.vbs", ".txt.vbs",
    ".pdf.js", ".jpg.js", ".docx.js",
    # 注意：.exe.lnk / .scr.lnk 是「可执行文件的快捷方式」，Windows 上完全正常，
    # 不列入双扩展名伪装（恶意快捷方式由 LNK_SUSPICIOUS 内容检查覆盖）。
    ".docm.exe", ".xlsm.exe", ".pptm.exe",
]

def detect_disguised_extension(filename: str) -> list:
    """检测扩展名伪装：双扩展名、Unicode右向覆盖、大量空格隐藏后缀。
    返回命中原因列表，空列表表示未伪装。"""
    reasons = []
    lower = filename.lower()
    # 1. Unicode 右向覆盖字符 U+202E
    if "\u202e" in filename:
        reasons.append("文件名含Unicode右向覆盖字符(U+202E)，用于伪装扩展名")
    # 2. 双扩展名伪装
    for pattern in SUSPICIOUS_DOUBLE_EXT:
        if lower.endswith(pattern):
            reasons.append(f"双扩展名伪装：…{pattern}")
            break
    # 3. 大量空格隐藏真实后缀（文件名中间有5个以上连续空格，且以可执行后缀结尾）
    if "     " in filename and lower.endswith((".exe", ".scr", ".vbs", ".js", ".bat", ".cmd", ".ps1", ".com", ".cpl")):
        reasons.append("文件名含大量空格，可能隐藏真实扩展名")
    return reasons

# EICAR 测试样本前缀（用于验证杀软流程是否工作，安全无害）
EICAR_PREFIX = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE"

# ---------------------------------------------------------------- 特征库

def data_dir() -> str:
    """黑/白名单存储目录：打包为 exe 后也保持持久化（放在用户目录）。"""
    d = DATA_DIR
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d

# 1) 黑名单哈希库（用户可扩展）：{sha256: 描述}
BLACKLIST_PATH = os.path.join(data_dir(), "blacklist.json")
WHITELIST_PATH = os.path.join(data_dir(), "whitelist.json")

def _load_json(path: str, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def load_blacklist() -> dict:
    return _load_json(BLACKLIST_PATH, {})

def load_whitelist() -> dict:
    return _load_json(WHITELIST_PATH, {})

def save_blacklist(data: dict):
    with open(BLACKLIST_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def save_whitelist(data: dict):
    with open(WHITELIST_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# 2) PE 导入表敏感 API（组合式判定：单 API 命中不计分，避免正常程序误报。
#    比如 socket/connect 是所有联网程序标配，ShellExecute/CreateProcess 是常见操作，
#    GetAsyncKeyState 游戏也会用——这些都从误报源中移除，只保留组合特征。）
PE_API_GROUPS = {
    "进程注入": ["CreateRemoteThread", "WriteProcessMemory", "VirtualAllocEx", "QueueUserAPC", "NtCreateThreadEx"],
    "下载执行": ["URLDownloadToFileA", "URLDownloadToFileW"],
    "键盘钩子": ["SetWindowsHookExA", "SetWindowsHookExW", "GetAsyncKeyState"],
    "进程镂空": ["ZwUnmapViewOfSection", "NtUnmapViewOfSection", "VirtualAllocEx"],
}

# 3) 脚本/内容特征串（正则，大小写不敏感）
# 注意：所有裸词特征必须带 \b 词边界，否则会被正常代码里的子串误命中
# （历史教训：ncat 无边界 → 把 js 最常见的 .concat() 误判成远控后门）
SCRIPT_PATTERNS = {
    "自启动注册表": [r"\bCurrentVersion\\Run\b", r"\bCurrentVersion\\RunOnce\b", r"\bStartup\\", r"schtasks\s+/create"],
    "下载并执行": [r"powershell[^\n]{0,200}?-enc", r"certutil\s+-urlcache", r"bitsadmin\s+/transfer", r"IEX\s*\(|Invoke-Expression", r"(New-Object\s+Net\.WebClient)", r"wget[^\n]{0,100}-O|curl[^\n]{0,100}-o", r"DownloadFile\s*\(", r"MSXML2\.XMLHTTP|Microsoft\.XMLHTTP|WinHttp\.WinHttpRequest", r"ADODB\.Stream", r"XMLHTTP[^\n]{0,100}?\.send", r"WScript\.Shell[^\n]{0,100}?\.Run", r"\bRun\s*[\( ]\s*[^\n]{0,80}?\.(exe|vbs|bat|cmd|ps1)", r"Shell\.Run\s*[^)]{0,120}"],
    "混淆/免杀": [r"FromBase64String", r"Chr\s*\(\s*\d{2,3}", r"[A-Za-z0-9+/]{200,}={0,2}", r"\\x[0-9a-fA-F]{2}\\x[0-9a-fA-F]{2}", r"iex\s*\([^)]{100,}"],
    "挖矿": [r"\bxmrig\b", r"\bminerd\b", r"\bstratum\b", r"\bcryptonight\b", r"\bnicehash\b", r"pool\.mine"],
    "勒索提示": [r"YOUR\s+FILES\s+ARE\s+ENCRYPTED", r"\bransom\w*\b", r"bitcoin\s+wallet", r"decrypt\s+(your\s+files|files)\b", r"README_TO_DECRYPT"],
    "远控后门": [r"\breverse\s*shell\b", r"(?<![\\:?])\bncat\b|(?<![\\:?])\bnc\.exe\b", r"\bplink\.exe\b", r"\bmimikatz\b", r"\bGet-Process\s+.*\b(winlogon|lsass)\b", r"\bhook\s+keyboard\b"],
    "系统篡改": [r"disable\s+(defender|firewall)", r"Set-MpPreference", r"sc\s+stop\s+\w+", r"taskkill\s+/f", r"del\s+/f\s+/q", r"bcdedit\s+/set"],
}

# 区段名 → 加壳/异常标记
PACKED_SECTIONS = {b"UPX0", b"UPX1", b"UPX2", b".aspack", b".adata", b"ASPack", b".petite", b".MPRESS1", b".MPRESS2", b".nsp0", b".nsp1", b".packed"}

# ---------------------------------------------------------------- 垃圾/缓存文件识别
# 命中即标记为"垃圾"等级（可清理），不当作安全威胁。
JUNK_EXT_RULES = [
    ({".tmp", ".temp"}, "临时文件"),
    ({".cache", ".cacheddata"}, "缓存文件"),
    ({".bak", ".old", ".orig", ".backup", ".bac"}, "备份文件"),
    ({".swp", ".swo", ".un~", ".~", ".tmp~"}, "编辑器交换/备份文件"),
    ({".pyc", ".pyo"}, "Python 字节码缓存"),
    ({".dmp", ".mdmp", ".hprof", ".stackdump", ".wpr"}, "崩溃转储文件"),
    ({".part", ".crdownload", ".download", ".partial", ".opdownload", ".!ut"}, "未完成下载"),
    ({".thumb", ".thm", ".db-journal"}, "缓存/索引碎片"),
]
JUNK_NAME_PATTERNS = [
    (r"^~\$", "Office 临时锁文件"),
    (r"\.(py|txt|md|docx?|xlsx?|pptx?|zip|rar|7z)~$", "编辑器备份文件"),
    (r"^thumbcache_.*\.db$", "缩略图缓存"),
    (r"^\.[^.]{1,20}\.py\.un~$", "Python 编辑器备份"),
    (r"^\._", "Apple 元数据残留"),
]

# ---------------------------------------------------------------- 数据结构

@dataclass
class RuleHit:
    """单条命中规则的结构化信息，用于解释化展示。"""
    rule_id: str           # 规则唯一ID，如 "EXT_DISGUISED"、"PE_SUSPICIOUS_API"
    title: str             # 规则名称，如 "扩展名伪装"
    score: int             # 本条规则贡献的分数
    severity: str          # 规则级别：strong/medium/weak
    evidence: List[str] = field(default_factory=list)  # 证据列表
    description: str = ""  # 详细描述

@dataclass
class ScanResult:
    path: str
    name: str
    ext: str
    category: str            # PE可执行 / 脚本 / 文档宏 / 快捷方式 / 普通文件
    size: int
    sha256: str
    score: int = 0
    level: str = LEVEL_SAFE
    tags: List[str] = field(default_factory=list)   # 命中描述（简短标签）
    hits: List[RuleHit] = field(default_factory=list)  # 结构化命中规则（解释化）
    whitelisted: bool = False
    signed_valid: Optional[bool] = None
    junk_tag: Optional[str] = None      # 垃圾/缓存类别（可清理）
    verdict_info: Optional[dict] = None  # 5.0.0 统一裁决层结果（evidence/final_score/verdict/explanation）

    def to_row(self):
        return {
            "path": self.path, "name": self.name, "ext": self.ext,
            "category": self.category, "size": self.size, "sha256": self.sha256,
            "score": self.score, "level": self.level, "tags": self.tags,
            "hits": [{"rule_id": h.rule_id, "title": h.title, "score": h.score,
                       "severity": h.severity, "evidence": h.evidence,
                       "description": h.description} for h in self.hits],
            "whitelisted": self.whitelisted, "signed_valid": self.signed_valid,
            "junk_tag": self.junk_tag,
            "verdict_info": self.verdict_info,
        }

# ---------------------------------------------------------------- 工具函数

def sha256_of(path: str, chunk: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                b = f.read(chunk)
                if not b:
                    break
                h.update(b)
        return h.hexdigest()
    except Exception:
        return ""

def file_entropy(path: str, sample_limit: int = 4 * 1024 * 1024) -> float:
    """对文件（可限量采样）计算 Shannon 熵。加密/加壳/混淆的文件熵通常 > 7.5。"""
    data = b""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            if size <= sample_limit:
                data = f.read()
            else:
                # 采样首尾各一半
                half = sample_limit // 2
                data = f.read(half)
                f.seek(max(0, size - half))
                data += f.read(half)
    except Exception:
        return 0.0
    if not data:
        return 0.0
    freq = [0] * 256
    for byte in data:
        freq[byte] += 1
    length = len(data)
    ent = 0.0
    for c in freq:
        if c:
            p = c / length
            ent -= p * math.log2(p)
    return ent

def read_head(path: str, n: int = 4096) -> bytes:
    try:
        with open(path, "rb") as f:
            return f.read(n)
    except Exception:
        return b""

def is_pe(data: bytes) -> bool:
    return len(data) >= 2 and data[:2] == b"MZ"

def read_text_safe(path: str, limit: int = 2 * 1024 * 1024) -> str:
    """读取文本类文件内容用于特征扫描，超过 limit 截断，编码错误忽略。"""
    try:
        size = os.path.getsize(path)
        if size > limit:
            return ""
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        try:
            with open(path, "r", encoding="gbk", errors="ignore") as f:
                return f.read()
        except Exception:
            return ""

def scan_strings(data: bytes, min_len: int = 5) -> List[str]:
    """从二进制数据中提取 ASCII 字符串（用于 PE 内容特征扫描）。"""
    out = []
    cur = bytearray()
    for b in data:
        if 32 <= b < 127:
            cur.append(b)
        else:
            if len(cur) >= min_len:
                out.append(bytes(cur).decode("ascii", "ignore"))
            cur = bytearray()
    if len(cur) >= min_len:
        out.append(bytes(cur).decode("ascii", "ignore"))
    return out

# ---------------------------------------------------------------- PE 解析

class PEParser:
    """纯 Python PE 解析：DOS头 → PE头 → 区段表 → 导入表（DLL + API 名）。"""

    def __init__(self, data: bytes):
        self.data = data
        self.is_pe = False
        self.machine = 0
        self.sections = []
        self.imports = {}          # dll_lower -> [api_names]
        self.is64 = False

    def parse(self):
        d = self.data
        if len(d) < 64 or not is_pe(d):
            return
        pe_off = struct.unpack_from("<I", d, 0x3C)[0]
        if pe_off + 24 > len(d) or d[pe_off:pe_off + 4] != b"PE\x00\x00":
            return
        self.is_pe = True
        sig = struct.unpack_from("<H", d, pe_off + 4)[0]
        self.machine = sig
        self.is64 = (sig == 0x8664)
        # 可选头
        opt_off = pe_off + 24
        opt_magic = struct.unpack_from("<H", d, opt_off)[0] if opt_off + 2 <= len(d) else 0
        is_pe32plus = (opt_magic == 0x20B)
        num_sections = struct.unpack_from("<H", d, pe_off + 6)[0]
        size_opt = struct.unpack_from("<H", d, pe_off + 20)[0]
        # 数据目录位置
        dd_off = opt_off + (112 if is_pe32plus else 96)
        # 区段表
        sec_off = opt_off + size_opt
        for i in range(num_sections):
            off = sec_off + i * 40
            if off + 40 > len(d):
                break
            name = d[off:off + 8].rstrip(b"\x00")
            self.sections.append(name)
        # 导入表（数据目录第1项）
        if dd_off + 8 <= len(d):
            imp_rva, imp_size = struct.unpack_from("<II", d, dd_off)
            # 需要 RVA→文件偏移。简单方案：遍历区段头找包含该 RVA 的区段
            for i in range(num_sections):
                off = sec_off + i * 40
                if off + 40 > len(d):
                    break
                vsize, vaddr = struct.unpack_from("<II", d, off + 8)
                rawsize, rawptr = struct.unpack_from("<II", d, off + 16)
                if vaddr <= imp_rva < vaddr + max(vsize, rawsize):
                    delta = vaddr - rawptr
                    imp_off = imp_rva - delta
                    self._parse_imports(imp_off, imp_size, delta, num_sections, sec_off)
                    break

    def _parse_imports(self, imp_off, imp_size, delta, num_sections, sec_off):
        d = self.data
        MAX_DESCS = 256
        for i in range(MAX_DESCS):
            off = imp_off + i * 20
            if off + 20 > len(d):
                break
            orig_first, _, _, name_rva, first_thunk = struct.unpack_from("<IIIII", d, off)
            if orig_first == 0 and name_rva == 0 and first_thunk == 0:
                break
            dll_name = self._rva_cstr(name_rva, delta, num_sections, sec_off)
            if not dll_name:
                continue
            dll_key = dll_name.lower()
            apis = self.imports.setdefault(dll_key, [])
            thunk_rva = first_thunk or orig_first
            # 遍历 thunk 表
            for t in range(4096):
                toff = self._rva_off(thunk_rva + t * (8 if self.is64 else 4), delta, num_sections, sec_off)
                if toff is None or toff + (8 if self.is64 else 4) > len(d):
                    break
                if self.is64:
                    val = struct.unpack_from("<Q", d, toff)[0]
                else:
                    val = struct.unpack_from("<I", d, toff)[0]
                if val == 0:
                    break
                if val & (1 << 63 if self.is64 else 1 << 31):
                    continue  # 按序号导入，跳过
                hint_off = self._rva_off(val & 0x7FFFFFFF, delta, num_sections, sec_off)
                if hint_off is not None and hint_off + 2 <= len(d):
                    api = self._cstr_at(hint_off + 2)
                    if api and api not in apis:
                        apis.append(api)

    def _rva_off(self, rva, delta, num_sections, sec_off):
        d = self.data
        if rva == 0:
            return None
        for i in range(num_sections):
            off = sec_off + i * 40
            if off + 40 > len(d):
                break
            vsize, vaddr = struct.unpack_from("<II", d, off + 8)
            rawsize, rawptr = struct.unpack_from("<II", d, off + 16)
            if vaddr <= rva < vaddr + max(vsize, rawsize):
                return rva - (vaddr - rawptr)
        # 兜底：直接当作偏移（部分工具生成的文件）
        return rva

    def _rva_cstr(self, rva, delta, num_sections, sec_off):
        off = self._rva_off(rva, delta, num_sections, sec_off)
        if off is None:
            return None
        return self._cstr_at(off)

    def _cstr_at(self, off):
        d = self.data
        end = d.find(b"\x00", off)
        if end == -1:
            end = min(off + 256, len(d))
        try:
            return d[off:end].decode("ascii")
        except Exception:
            return None

def parse_startup_command(cmd: str):
    """从注册表启动项命令中提取可执行文件路径。"""
    if not cmd:
        return None
    cmd = cmd.strip()
    m = re.match(r'^"([^"]+)"', cmd)
    if m:
        return m.group(1)
    first = cmd.split(None, 1)[0] if cmd else ""
    if first.lower().endswith((".exe", ".com", ".bat", ".cmd", ".dll", ".scr", ".vbs", ".ps1", ".jar")):
        return first
    return None

def collect_startup_files():
    """收集开机自启动项指向的文件：{规范化路径: 来源描述}。
    来源：注册表 Run/RunOnce 键 + 用户/公共启动文件夹。
    这是杀毒软件"防流氓软件"的核心检查点——流氓软件普遍通过自启动常驻。
    """
    items = {}
    try:
        import winreg
    except Exception:
        winreg = None
    if winreg is not None:
        run_keys = [
            (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run"),
        ]
        for hive, key in run_keys:
            try:
                with winreg.OpenKey(hive, key) as k:
                    for i in range(winreg.QueryInfoKey(k)[0]):
                        try:
                            name, value, _ = winreg.EnumValue(k, i)
                        except OSError:
                            break
                        p = parse_startup_command(str(value))
                        if p and os.path.isfile(p):
                            items[os.path.normcase(os.path.normpath(p))] = f"注册表自启动项「{name}」"
            except OSError:
                pass
    # 启动文件夹
    appdata = os.environ.get("APPDATA", "")
    folders = []
    if appdata:
        folders.append(os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup"))
    folders.append(r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp")
    for folder in folders:
        if os.path.isdir(folder):
            for fn in os.listdir(folder):
                if fn.lower() in {"desktop.ini", "thumbs.db"}:
                    continue
                p = os.path.join(folder, fn)
                if os.path.isfile(p):
                    items[os.path.normcase(os.path.normpath(p))] = "启动文件夹"
    return items

# ---------------------------------------------------------------- 检测实现

class Scanner:
    def __init__(self, deep_strings: bool = False, hash_all: bool = True,
                 max_hash_size: int = 200 * 1024 * 1024):
        self.blacklist = load_blacklist()
        self.whitelist = load_whitelist()
        # 从 SQLite 数据库加载病毒哈希库（合并到黑名单）
        try:
            import database
            db_viruses = database.get_virus_hash_map()
            self.blacklist.update(db_viruses)
            db_whitelist = database.get_whitelist()
            for p in db_whitelist:
                self.whitelist[p] = "数据库白名单"
        except Exception:
            pass
        self.deep_strings = deep_strings      # 深度扫描：PE 也做全量字符串特征扫描
        self.hash_all = hash_all              # False=快速模式：只对可疑候选算哈希，省 CPU
        self.max_hash_size = max_hash_size    # 哈希大小上限（超大文件只做头部检测）
        self.startup = collect_startup_files()  # 开机自启动项（防流氓软件检查点）
        # 哈希缓存：(路径, 大小, 修改时间) -> sha256，避免重复计算
        self._hash_cache = {}
        self._cache_hits = 0
        # 扫描器自身核心源码：内含特征定义字符串，扫自己会自命中误报。
        self._self_files = set()
        try:
            _mod_dir = os.path.dirname(os.path.abspath(__file__))
            for _fn in ("engine.py", "main.py"):
                self._self_files.add(os.path.normcase(os.path.normpath(
                    os.path.join(_mod_dir, _fn))))
        except Exception:
            pass

        # ===== 真正的算法优化：预编译所有正则表达式 =====
        # 预编译脚本特征正则（避免每次扫描都重新编译，提速明显）
        self._compiled_script_patterns = {}
        for group, patterns in SCRIPT_PATTERNS.items():
            compiled = []
            for p in patterns:
                try:
                    compiled.append(re.compile(p, re.IGNORECASE))
                except Exception:
                    continue
            self._compiled_script_patterns[group] = compiled
        # 预编译垃圾文件名正则
        self._compiled_junk_patterns = []
        for pat, tag in JUNK_NAME_PATTERNS:
            try:
                self._compiled_junk_patterns.append((re.compile(pat, re.IGNORECASE), tag))
            except Exception:
                continue

    # -- 各检测维度，返回 (加分, 描述) --

    def _check_signature(self, sha256: str, path: str, head: bytes):
        if sha256 and sha256 in self.blacklist:
            return 10, f"命中黑名单哈希（{self.blacklist[sha256]}）"
        if head.startswith(EICAR_PREFIX):
            return 10, "EICAR 测试样本（用于验证杀软流程，无害）"
        # 4.5.0：云查缓存命中恶意 → 无条件判危（云端已知威胁 > 可信目录/签名降权）
        if sha256:
            try:
                import database as _db
                _cc = _db.get_cloud_cache(sha256)
                if _cc and _cc.get("verdict") == "malicious":
                    return 10, "云端已判恶意（" + (_cc.get("name") or _cc.get("source") or "云查") + "）"
            except Exception:
                pass
        return 0, None

    def _check_pe(self, head: bytes):
        pe = PEParser(head)
        pe.parse()
        if not pe.is_pe:
            return 0, None, None
        score = 0
        tags = []
        # 加壳区段
        packed = [s.decode("ascii", "ignore") for s in pe.sections if s.upper() in PACKED_SECTIONS]
        if packed:
            # UPX 是最常见的合法加壳工具（大量正常软件使用，如向日葵/各种压缩工具），
            # 不独立加分，仅作为已有风险时的辅助标签；其他少见加壳保留较低分值。
            non_upx = [p for p in packed if not p.upper().startswith("UPX")]
            if non_upx:
                score += 2
                tags.append(f"加壳区段: {','.join(packed)}")
            else:
                # 纯 UPX：不加分，标签仅在文件已有其他风险时作为辅助证据显示
                tags.append(f"加壳区段(UPX): {','.join(packed)}")
        # 可疑区段（如 UPX 常见 + 一个可写可执行区段）
        # 导入表 API 组合评分：单个 API 命中不计分，组合才加分（避免误报）
        def api_hit(group_names):
            all_apis = [a for apis in pe.imports.values() for a in apis]
            return [n for n in group_names if n in all_apis]

        inj = api_hit(PE_API_GROUPS["进程注入"])
        if len(inj) >= 2:
            score += 3
            tags.append(f"导入表含进程注入API组合: {', '.join(inj[:4])}")
        dl = api_hit(PE_API_GROUPS["下载执行"])
        if dl:
            score += 2
            tags.append(f"导入表含下载执行API: {', '.join(dl[:3])}")
        hk = api_hit(PE_API_GROUPS["键盘钩子"])
        if len(hk) >= 2:
            score += 2
            tags.append(f"导入表含键盘钩子/记录API组合: {', '.join(hk[:4])}")
        hl = api_hit(PE_API_GROUPS["进程镂空"])
        if len(hl) >= 2:
            score += 3
            tags.append(f"导入表含进程镂空API组合: {', '.join(hl[:4])}")
        return score, tags, pe

    def _check_script(self, text: str, ext: str):
        score = 0
        tags = []
        if not text:
            return 0, tags
        # 长 base64 串在正常代码里太常见（测试数据/序列化/嵌入资源），
        # 只对 PowerShell 脚本视为混淆特征；其余脚本若命中特定混淆 API 仍会提示。
        skip_groups = {"混淆/免杀"} if ext == ".js" else set()
        skip_base64 = ext not in (".js", ".ps1")
        for group, compiled_list in self._compiled_script_patterns.items():
            if group in skip_groups:
                continue
            cnt = 0
            for rx in compiled_list:
                if skip_base64 and "200," in rx.pattern:
                    continue  # 跳过长base64规则（非js/ps1脚本）
                try:
                    cnt += len(rx.findall(text))
                except Exception:
                    continue
            if cnt:
                # 混淆/自启动这类本身不一定危险，给低分；勒索/挖矿/远控给高分
                base = {"勒索提示": 3, "挖矿": 2, "远控后门": 3, "系统篡改": 1, "下载并执行": 1, "自启动注册表": 1, "混淆/免杀": 1}[group]
                if group in ("远控后门", "勒索提示"):
                    # 特异正则（reverse shell/mimikatz/勒索提示等），多次命中是强信号，保留线性叠加
                    add = min(base + (cnt - 1), base + 3)
                else:
                    # 宽泛正则：多次命中只在基础分上 +1 封顶，避免单维度堆分（正确率优化）
                    add = base + (1 if cnt > 1 else 0)
                score += add
                tags.append(f"内容含{group}特征 ×{cnt}")
        # 5.4.0：纯文本开发源码（.py/.js/.java 等明文代码）内容特征降权——
        # 安全分析/测试/正常工具源码常含"下载执行/自启动/远控"等关键词，
        # 单靠文本关键词无法区分恶意脚本与正常源码，行为链强信号降为弱信号；
        # .bat/.ps1/.vbs/.hta 等会被系统直接执行的高危脚本类型不降（保持强判定）。
        _dev_src = ext.lower() in (".py", ".js", ".ts", ".mjs", ".cjs", ".java", ".c", ".cpp",
                                   ".h", ".hpp", ".cs", ".go", ".php", ".rb", ".lua",
                                   ".html", ".htm", ".md", ".txt", ".json", ".yml", ".yaml",
                                   ".xml", ".css", ".sql", ".ini", ".cfg", ".log", ".csv")
        # 行为链升权：下载执行 + 自启动 + 混淆/远控 同时命中 = 典型木马链（单特征是弱信号，链路完整是强信号）
        try:
            _gh = set()
            for _t in tags:
                for _g in ("下载并执行", "自启动注册表", "混淆/免杀", "远控后门", "勒索提示"):
                    if _g in _t:
                        _gh.add(_g)
            if "下载并执行" in _gh and "自启动注册表" in _gh:
                if ("混淆/免杀" in _gh) or ("远控后门" in _gh) or ("勒索提示" in _gh):
                    score += (2 if _dev_src else 5)
                    tags.append("行为链完整：下载执行+自启动+混淆/远控（典型木马链，强信号）"
                                + ("（源码降权）" if _dev_src else ""))
                else:
                    score += (2 if _dev_src else 3)
                    tags.append("行为链可疑：下载执行+自启动（持久化下载链）"
                                + ("（源码降权）" if _dev_src else ""))
        except Exception:
            pass
        # 3.5.8 远控行为链组合：网络连接(socket/connect) + 命令执行(subprocess/os.system/popen)
        # 正常代码几乎不会同时「外连套接字 + 执行 shell 命令」，组合命中是强信号（6分）
        try:
            tl = text.lower()
            has_net = ("socket" in tl and "connect(" in tl) or ("urllib.request" in tl and "urlopen" in tl)
            has_exec = ("subprocess" in tl) or ("os.system" in tl) or ("popen" in tl) or ("createprocess" in tl)
            if has_net and has_exec:
                score += (2 if _dev_src else 6)
                tags.append("远控后门特征：网络连接+命令执行（强信号）"
                            + ("（源码降权）" if _dev_src else ""))
        except Exception:
            pass
        return score, tags

    def _check_attrs(self, path: str):
        """隐藏属性仅作为辅助标签（不单独加分），由主流程在已有风险时附带。"""
        try:
            attrs = os.stat(path).st_file_attributes
        except Exception:
            return False
        return bool(attrs & 0x2)  # FILE_ATTRIBUTE_HIDDEN

    def _check_junk(self, path: str, name: str, ext: str):
        """垃圾/缓存文件识别：临时、缓存、备份、交换、未完成下载、转储等。"""
        for exts, tag in JUNK_EXT_RULES:
            if ext in exts:
                return tag
        low = name.lower()
        for rx, tag in self._compiled_junk_patterns:
            if rx.search(low):
                return tag
        return None

    # -- Office 宏检测 --

    def check_office_macro(self, path: str, ext: str) -> tuple:
        """检测 Office 文档是否含宏。返回 (是否含宏, 可疑字符串列表)。"""
        macro_exts = {".docm", ".xlsm", ".pptm", ".doc", ".xls", ".ppt", ".rtf"}
        if ext not in macro_exts:
            return False, []
        has_macro = False
        suspicious = []
        try:
            # OOXML 格式（.docm/.xlsm/.pptm）本质是 zip，检查 vbaProject.bin
            if ext in {".docm", ".xlsm", ".pptm"}:
                import zipfile
                with zipfile.ZipFile(path, "r") as z:
                    names = z.namelist()
                    if any("vbaProject.bin" in n for n in names):
                        has_macro = True
                    # 读取 vbaProject.bin 内容检测可疑字符串
                    if has_macro:
                        for n in names:
                            if "vbaProject.bin" in n:
                                try:
                                    data = z.read(n)
                                    text = data.decode("utf-8", errors="ignore") + data.decode("gbk", errors="ignore")
                                    for kw in ["powershell", "cmd.exe", "wscript.shell", "shell.application",
                                               "winhttp", "msxml2.xmlhttp", "adodb.stream",
                                               "createobject", "execute", "eval"]:
                                        if kw.lower() in text.lower():
                                            suspicious.append(kw)
                                except Exception:
                                    pass
                                break
            else:
                # 旧版 OLE 格式（.doc/.xls/.ppt）：检查文件头是否有宏相关标记
                with open(path, "rb") as f:
                    head = f.read(65536)
                    # OLE 文件头标记
                    if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
                        # 简单启发式：搜索宏相关字符串
                        text = head.decode("utf-8", errors="ignore") + head.decode("gbk", errors="ignore")
                        for kw in ["ThisDocument", "AutoOpen", "AutoExec", "Document_Open",
                                   "Workbook_Open", "Auto_Open", "VBA", "Macros"]:
                            if kw in text:
                                has_macro = True
                                break
                        if has_macro:
                            for kw in ["powershell", "cmd.exe", "wscript.shell", "createobject"]:
                                if kw.lower() in text.lower():
                                    suspicious.append(kw)
        except Exception:
            pass
        return has_macro, suspicious

    # -- 压缩包扫描 --

    def scan_zip_archive(self, path: str, ext: str) -> tuple:
        """扫描 zip 格式压缩包内部。返回 (风险分数, 命中标签列表, 内部文件数)。"""
        zip_exts = {".zip", ".jar", ".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm"}
        if ext not in zip_exts:
            return 0, [], 0
        score = 0
        tags = []
        file_count = 0
        try:
            import zipfile
            with zipfile.ZipFile(path, "r") as z:
                names = z.namelist()
                file_count = len(names)
                # Zip Slip 防护：检查内部文件名是否包含路径穿越
                for n in names:
                    normalized = os.path.normpath(n)
                    if normalized.startswith("..") or os.path.isabs(normalized):
                        score += 3
                        tags.append("压缩包含路径穿越(Zip Slip风险)")
                        break
                # 检测内部可执行/脚本文件
                dangerous_exts = {".exe", ".scr", ".vbs", ".js", ".jse", ".wsf", ".hta",
                                  ".ps1", ".bat", ".cmd", ".com", ".cpl", ".ocx", ".sys", ".dll"}
                for n in names:
                    n_lower = n.lower()
                    n_ext = os.path.splitext(n_lower)[1]
                    if n_ext in dangerous_exts:
                        score += 2
                        tags.append(f"压缩包内含可执行文件: {os.path.basename(n)}")
                        break
                # 检测内部双扩展名伪装
                for n in names:
                    n_lower = n.lower()
                    for pattern in SUSPICIOUS_DOUBLE_EXT:
                        if n_lower.endswith(pattern):
                            score += 3
                            tags.append(f"压缩包内含双扩展名伪装: {os.path.basename(n)}")
                            break
                    if score >= 5:
                        break
                # Zip bomb 防护：检查解压后总大小
                try:
                    total_uncompressed = sum(info.file_size for info in z.infolist())
                    if total_uncompressed > 100 * 1024 * 1024:  # 超过 100MB
                        score += 2
                        tags.append(f"压缩包解压后过大({total_uncompressed // 1024 // 1024}MB, 疑似Zip Bomb)")
                except Exception:
                    pass
        except Exception:
            pass
        return score, tags, file_count

    # -- 主扫描 --

    def _cached_hash(self, path: str, size: int, limit: int) -> str:
        """带缓存的哈希计算：相同(路径,大小,修改时间)不重复算。"""
        try:
            mtime = os.path.getmtime(path)
            key = (path, size, int(mtime))
            if key in self._hash_cache:
                self._cache_hits += 1
                return self._hash_cache[key]
        except Exception:
            pass
        h = sha256_of(path) if size <= limit else ""
        try:
            if len(self._hash_cache) < 5000:
                self._hash_cache[key] = h
        except Exception:
            pass
        return h

    def _load_ai_config(self):
        """加载AI智能检查配置。"""
        import json
        import os
        config_path = os.path.join(DATA_DIR, "ai_config.json")
        try:
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {"ai_enabled": False, "ai_api_key": "", "ai_api_url": ""}

    def _ai_check(self, res: ScanResult) -> ScanResult:
        """AI二次智能检查：对高危文件调用AI接口进行二次判断。
        支持 DeepSeek / OpenAI 兼容格式，自动解析AI返回的JSON结论。
        """
        try:
            import json
            import urllib.request
            ai_cfg = self._load_ai_config()
            if not ai_cfg.get("ai_enabled", False):
                return res
            api_key = ai_cfg.get("ai_api_key", "").strip()
            api_url = ai_cfg.get("ai_api_url", "").strip()
            if not api_key or not api_url:
                return res
            if res.level not in [LEVEL_CRIT, LEVEL_HIGH]:
                return res
            
            # 构建发送给AI的文件特征摘要
            feature_text = f"文件名:{res.name} 类型:{res.category} 大小:{res.size}字节 SHA256:{res.sha256} 本地评分:{res.score} 本地等级:{res.level} 命中规则:{','.join([h.rule_id for h in res.hits]) if res.hits else '无'} 标签:{','.join(res.tags[:10])}"
            
            # 构建 OpenAI 兼容格式的请求（DeepSeek 兼容此格式）
            system_prompt = '你是一个专业的安全软件分析引擎。根据用户提供的文件特征信息，判断该文件是否为恶意软件。必须严格返回JSON格式，不要返回其他内容：{"verdict":"malicious或benign或suspicious","confidence":0.0到1.0之间的数字,"reason":["原因1","原因2"],"recommended_action":"quarantine或ignore或delete"}' 
            payload = {
                "model": ai_cfg.get("ai_model", "deepseek-chat"),
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"请分析以下文件特征：{feature_text}"}
                ],
                "temperature": 0.1,
                "max_tokens": 500,
                "response_format": {"type": "json_object"}
            }
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(api_url, data=data,
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}, method="POST")
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw_result = json.loads(resp.read().decode("utf-8"))
            
            # 解析 OpenAI 兼容格式的返回
            ai_content = raw_result.get("choices", [{}])[0].get("message", {}).get("content", "{}")
            try:
                ai_result = json.loads(ai_content)
            except Exception:
                # 如果AI返回的不是纯JSON，尝试提取JSON部分
                import re
                json_match = re.search(r'\{.*\}', ai_content, re.DOTALL)
                if json_match:
                    ai_result = json.loads(json_match.group())
                else:
                    ai_result = {}
            
            verdict = ai_result.get("verdict", "").lower()
            confidence = float(ai_result.get("confidence", 0.5))
            reason = ai_result.get("reason", [])
            recommended_action = ai_result.get("recommended_action", "")
            
            if verdict == "malicious":
                add_score = max(1, int(5 * confidence))
                res.score = min(20, res.score + add_score)
                res.tags.append(f"AI确认恶意(+{add_score}分,置信度{confidence:.0%})")
            elif verdict == "benign":
                reduce_score = max(1, int(5 * confidence))
                res.score = max(0, res.score - reduce_score)
                res.tags.append(f"AI判定良性(-{reduce_score}分,置信度{confidence:.0%})")
            elif verdict == "suspicious":
                add_score = max(1, int(2 * confidence))
                res.score = min(20, res.score + add_score)
                res.tags.append(f"AI可疑(+{add_score}分,置信度{confidence:.0%})")
            if reason:
                for r in reason[:2]:
                    if isinstance(r, str):
                        res.tags.append(f"AI: {r[:50]}")
            if recommended_action:
                res.tags.append(f"AI建议:{recommended_action}")
            if res.score >= 10: res.level = LEVEL_CRIT
            elif res.score >= 6: res.level = LEVEL_HIGH
            elif res.score >= 3: res.level = LEVEL_MED
            elif res.score >= 1: res.level = LEVEL_LOW
            else: res.level = LEVEL_SAFE
            return res
        except Exception as e:
            res.tags.append(f"AI检查失败({str(e)[:30]})")
            return res

    def scan_file(self, path: str, sha256_pre: str = "") -> ScanResult:
        """扫描单个文件，返回ScanResult。sha256_pre 为 C++ 核心预计算的哈希（加速）。"""

        def _engine_switch(key, default=True):
            """读取扫描引擎开关（config.json，缺失默认开启）。配置改动立即生效。"""
            try:
                _p = os.path.join(DATA_DIR, "config.json")
                if os.path.exists(_p):
                    with open(_p, "r", encoding="utf-8") as _f:
                        return bool(json.load(_f).get(key, default))
            except Exception:
                pass
            return default

        name = os.path.basename(path)
        ext = os.path.splitext(name)[1].lower()
        size = 0
        mtime = 0
        try:
            size = os.path.getsize(path)
            mtime = os.path.getmtime(path)
        except Exception:
            pass

        # 文件指纹缓存检查（加速重复扫描）
        try:
            import database
            cached = database.get_file_cache(path, size, mtime, ENGINE_VERSION)
            if cached is not None:
                # 缓存命中，直接返回
                res = ScanResult(path=path, name=name, ext=ext, category="普通文件",
                                 size=size, sha256=cached["sha256"],
                                 score=cached["score"], level=cached["level"],
                                 tags=cached["tags"])
                res.tags.append("缓存命中")
                return res
        except Exception:
            pass  # 数据库不可用时静默跳过

        # 提前路径白名单检查（在算哈希之前，省 IO）
        low_path = path.lower()
        if low_path in self.whitelist or any(
                low_path.startswith(k) for k in self.whitelist if k.endswith(("\\", "/"))):
            return ScanResult(path=path, name=name, ext=ext, category="普通文件",
                             size=size, sha256="", whitelisted=True, level=LEVEL_SAFE)

        head = read_head(path, 65536)
        if is_pe(head):
            category = "PE可执行"
        elif ext in SCRIPT_EXTS:
            category = "脚本"
        elif ext in {".docm", ".xlsm", ".ppsm", ".doc", ".xls", ".ppt", ".rtf"}:
            category = "文档宏"
        elif ext in {".zip", ".jar", ".7z", ".rar"}:
            category = "压缩包"
        elif ext == ".lnk":
            category = "快捷方式"
        else:
            category = "普通文件"

        # 快速模式性能优化：非可疑大文件(>2MB)直接返回安全
        junk_exts = set()
        for exts, _ in JUNK_EXT_RULES:
            junk_exts |= exts
        interesting = (category in ("PE可执行", "脚本", "快捷方式", "文档宏", "压缩包")
                       or ext in junk_exts
                       or self._check_junk(path, name, ext) is not None)
        if not self.hash_all and not interesting and size > 2 * 1024 * 1024:
            return ScanResult(path=path, name=name, ext=ext, category=category,
                             size=size, sha256="", level=LEVEL_SAFE)

        # 哈希：优先使用 C++ 核心预计算哈希（跳过 Python 重复计算）
        sha256 = ""
        if sha256_pre:
            sha256 = sha256_pre
        elif self.hash_all or interesting:
            limit = self.max_hash_size if self.hash_all else 20 * 1024 * 1024
            sha256 = self._cached_hash(path, size, limit)

        whitelisted = sha256 in self.whitelist
        res = ScanResult(path=path, name=name, ext=ext, category=category,
                         size=size, sha256=sha256, whitelisted=whitelisted)
        if whitelisted:
            res.level = LEVEL_SAFE
            return res

        score = 0
        tags = []
        base = RISKY_EXTS.get(ext, 0)
        if base:
            score += base
            if ext in {".scr", ".com", ".cpl", ".ocx", ".sys", ".hta", ".vbe", ".jse", ".wsf"}:
                tags.append("高风险文件类型")

        # 扩展名伪装检测（强规则，命中加较高分）
        disguised = detect_disguised_extension(name)
        if disguised:
            score += 5
            tags.extend(disguised)
            # 伪装为可执行文件（.exe/.scr/.vbs 等）：钓鱼实锤，额外升权
            if ext == ".exe" or ext in RISKY_EXTS or category in ("PE可执行", "脚本"):
                score += 3
                tags.append("伪装为可执行文件(高危)")

        s, t = self._check_signature(sha256, path, head)
        score += s
        if t:
            tags.append(t)

        # 提前终止：已达严重级别且命中黑名单/EICAR，不再做后续深度分析
        if score >= 10 and (sha256 in self.blacklist or head.startswith(EICAR_PREFIX)):
            res.score = score
            res.tags = tags
            res.level = LEVEL_CRIT
            return res

        if category == "PE可执行":
            s, t, pe = self._check_pe(head)
            score += s
            tags.extend(t or [])
            # 4.13.0：PE 静态启发式评分（模仿本地 ML 的特征子集：
            # 编译时间戳/入口点/W+X区段/区段熵/overlay/极小体积/无导入表/壳区段）
            # 5.4.0：设置页可开关（engine_pe_enabled，默认开）
            if _engine_switch("engine_pe_enabled", True):
                try:
                    import pe_heuristic
                    _hscore, _htags = pe_heuristic.analyze(path, head, size)
                    if _hscore:
                        score += _hscore
                        tags.extend(_htags)
                except Exception:
                    pass  # 启发式失败不影响主流程
            # 4.14.0：本地 ML 推理（随机森林；模型文件存在时自动启用，失败降级）
            # 5.4.0：设置页可开关（engine_ml_enabled，默认开）
            if _engine_switch("engine_ml_enabled", True):
                try:
                    import ml_infer
                    _prob, _nz = ml_infer.predict_malware(path, head, size)
                    _mscore = ml_infer.proba_to_score(_prob)
                    if _mscore:
                        score += _mscore
                        tags.append("本地AI模型判定(恶意概率%.0f%%)" % (_prob * 100))
                except Exception:
                    pass  # ML 缺失/失败不影响主流程

        _is_self = os.path.normcase(os.path.normpath(path)) in self._self_files
        if category == "脚本" and not _is_self:
            if not self.hash_all and size > 1024 * 1024:
                text = read_head(path, 512 * 1024).decode("utf-8", errors="ignore")
            else:
                text = read_text_safe(path)
            s, t = self._check_script(text, ext)
            score += s
            tags.extend(t)
        elif category == "快捷方式":
            strs = scan_strings(head)
            joined = "\n".join(strs[:2000])
            s, t = self._check_script(joined, ext)
            if s:
                score += s
                tags.append("快捷方式内嵌可疑命令")
        elif category == "PE可执行" and self.deep_strings and not _is_self:
            strs = scan_strings(head)
            joined = "\n".join(strs[:3000])
            s, t = self._check_script(joined, ext)
            if s:
                score += s
                tags.extend(t)

        # Office 宏检测（只对 Office 文档调用，减少开销）
        has_macro = False
        macro_suspicious = []
        if ext in {".docm", ".xlsm", ".ppsm", ".doc", ".xls", ".ppt", ".rtf"}:
            has_macro, macro_suspicious = self.check_office_macro(path, ext)
        if has_macro:
            score += 2
            tags.append("Office文档含宏")
            if macro_suspicious:
                score += 3
                tags.append(f"宏内含可疑命令: {', '.join(macro_suspicious[:3])}")
            # 下载目录的宏文档升权
            if "\\downloads" in path.lower() or "\\download" in path.lower():
                score += 2
                tags.append("下载目录宏文档(高风险)")

        # 压缩包扫描（只对压缩包调用，减少开销）
        zip_score = 0
        zip_tags = []
        zip_count = 0
        if ext in {".zip", ".jar", ".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm"}:
            zip_score, zip_tags, zip_count = self.scan_zip_archive(path, ext)
        if zip_score > 0:
            score += zip_score
            tags.extend(zip_tags)

        if score > 0 and path in self.startup:
            score += 2
            tags.append("开机自启动项")

        if score > 0 and category == "PE可执行" and size > 0:
            try:
                ent = file_entropy(path)
                if ent > 7.5:
                    score += 1
                    tags.append("高熵(疑似加壳/加密)")
            except Exception:
                pass  # 熵值计算失败不影响主流程

        res.score = score
        res.tags = tags

        # 生成结构化命中规则（解释化）
        # tag 文本 → rule_id/title/severity 映射表
        TAG_RULE_MAP = {
            "高风险文件类型": ("EXT_RISKY", "高风险文件类型", "medium"),
            "双扩展名伪装": ("EXT_DISGUISED", "扩展名伪装", "strong"),
            "文件名含Unicode右向覆盖字符": ("EXT_UNICODE_OVERRIDE", "Unicode扩展名伪装", "strong"),
            "文件名含大量空格": ("EXT_SPACE_HIDE", "空格隐藏扩展名", "strong"),
            "黑名单哈希匹配": ("HASH_BLACKLIST", "已知恶意哈希", "strong"),
            "EICAR测试样本": ("HASH_EICAR", "EICAR测试样本", "strong"),
            "PE可疑API组合": ("PE_SUSPICIOUS_API", "PE可疑API组合", "medium"),
            "PE加壳/区段异常": ("PE_PACKED", "PE加壳嫌疑", "weak"),
            "自启动注册表": ("SCRIPT_AUTOSTART", "自启动行为", "medium"),
            "下载并执行": ("SCRIPT_DOWNLOAD_EXEC", "下载执行行为", "medium"),
            "远控后门特征": ("SCRIPT_REMOTE", "远控特征", "medium"),
            "挖矿行为": ("SCRIPT_MINING", "挖矿特征", "medium"),
            "勒索行为": ("SCRIPT_RANSOM", "勒索特征", "strong"),
            "代码混淆/编码": ("SCRIPT_OBFUSCATED", "代码混淆", "weak"),
            "免杀/反调试": ("SCRIPT_ANTIVM", "免杀反调试", "medium"),
            "开机自启动项": ("STARTUP_ITEM", "开机自启动项", "medium"),
            "高熵(疑似加壳/加密)": ("ENTROPY_HIGH", "高熵文件", "weak"),
            "编译时间戳": ("PE_TIMESTAMP", "编译时间戳异常", "medium"),
            "入口点": ("PE_ENTRYPOINT", "入口点异常", "medium"),
            "可写可执行区段": ("PE_WX", "可写可执行区段", "medium"),
            "PE尾部附加数据": ("PE_OVERLAY", "PE覆盖数据", "weak"),
            "极小的可执行文件": ("PE_TINY", "极小可执行文件", "weak"),
            "高熵区段": ("PE_HIGH_ENTROPY", "高熵区段", "weak"),
            "无导入表": ("PE_NO_IMPORTS", "无导入表", "weak"),
            "区段数异常": ("PE_SECTIONS", "区段数异常", "weak"),
            "加壳特征": ("PE_PACKED_ALT", "加壳特征", "weak"),
            "本地AI模型判定": ("ML_MODEL", "本地AI模型判定", "medium"),
            "快捷方式内嵌可疑命令": ("LNK_SUSPICIOUS", "快捷方式可疑命令", "medium"),
        }
        hits = []
        for tag in tags:
            matched = False
            for keyword, (rid, title, sev) in TAG_RULE_MAP.items():
                if keyword in tag:
                    # 估算本条规则分数（平均分，总分数按命中数均分）
                    hit_score = max(1, score // max(1, len(tags)))
                    hits.append(RuleHit(
                        rule_id=rid, title=title, score=hit_score,
                        severity=sev, evidence=[tag],
                        description=f"命中规则：{tag}"
                    ))
                    matched = True
                    break
            if not matched:
                hits.append(RuleHit(
                    rule_id="GENERIC", title="其他特征", score=1,
                    severity="weak", evidence=[tag], description=tag
                ))
        res.hits = hits

        # ===== 降权机制：上下文判断，降低误报（1.9.0增强） =====
        has_strong = any(h.severity == "strong" for h in hits)
        has_medium = any(h.severity == "medium" for h in hits)
        only_weak = hits and not has_strong and not has_medium

        lower_path = path.lower()
        # 读取开发者模式配置（如果有）
        developer_mode = False
        try:
            import os as _os
            import json as _json
            cfg_path = _os.path.join(DATA_DIR, "config.json")
            if _os.path.exists(cfg_path):
                with open(cfg_path, "r", encoding="utf-8") as _f:
                    _cfg = _json.load(_f)
                developer_mode = _cfg.get("developer_mode", False)
        except Exception:
            pass

        # 1. 开发工具目录下的脚本 → 降权（这些目录下的脚本通常是正常开发工具）
        dev_dirs = ["\\python", "\\python3", "\\nodejs", "\\node_modules",
                    "\\git", "\\vscode", "\\microsoft vs code", "\\jetbrains",
                    "\\anaconda", "\\miniconda", "\\perl", "\\ruby",
                    "\\go", "\\golang", "\\rust", "\\cargo",
                    "\\program files\\python", "\\program files (x86)\\python",
                    "\\.git", "\\venv", "\\.venv", "\\__pycache__",
                    "\\dist", "\\build", "\\target", "\\out"]
        is_dev_script = category == "脚本" and any(d in lower_path for d in dev_dirs)
        if is_dev_script and not has_strong:
            reduce = 5 if developer_mode else 3
            score = max(0, score - reduce)
            tags.append(f"开发目录脚本(已降权{reduce}分)")

        # 1.5 开发者模式：开发目录下的所有文件（不仅是脚本）都降权
        if developer_mode and not has_strong:
            dev_all_dirs = ["\\node_modules", "\\.git", "\\venv", "\\.venv",
                           "\\__pycache__", "\\dist", "\\build", "\\target",
                           "\\python", "\\nodejs", "\\git", "\\vscode"]
            if any(d in lower_path for d in dev_all_dirs):
                score = max(0, score - 4)
                tags.append("开发者模式-开发目录(已降权4分)")

        # 2. 只有弱规则命中（高熵/加壳）且没有中/强规则 → 大幅降权
        if only_weak:
            score = max(0, score - 2)
            tags.append("仅弱特征(已降权2分)")

        # 3. 系统目录下的文件，若无强规则则降权（系统文件通常可信）
        system_dirs = ["c:\\windows\\system32", "c:\\windows\\syswow64",
                       "c:\\windows\\winsxs", "c:\\program files\\windows",
                       "c:\\program files\\common files"]
        is_system_file = any(lower_path.startswith(d) for d in system_dirs)
        if is_system_file and not has_strong:
            score = max(0, score - 3)
            tags.append("系统目录文件(已降权3分)")

        # 4. 可信软件目录（游戏/常用软件），若无强规则则降权（1.9.0新增）
        trusted_dirs = ["c:\\program files\\steam", "c:\\program files (x86)\\steam",
                        "\\steamapps", "\\steam",
                        "c:\\program files\\tencent", "c:\\program files (x86)\\tencent",
                        "c:\\program files\\netease", "c:\\program files (x86)\\netease",
                        "c:\\program files\\microsoft", "c:\\program files (x86)\\microsoft",
                        "c:\\program files\\adobe", "c:\\program files (x86)\\adobe",
                        "\\wechat", "\\qq", "\\tim", "\\钉钉",
                        "c:\\program files\\google", "c:\\program files (x86)\\google",
                        "c:\\program files\\mozilla", "c:\\program files (x86)\\mozilla"]
        is_trusted_file = any(lower_path.startswith(d) or d in lower_path for d in trusted_dirs)
        if is_trusted_file and not has_strong:
            score = max(0, score - 3)
            tags.append("可信软件目录(已降权3分)")

        # 4.5 可信数字签名降权：有有效签名的商业软件基本可信（签名信息在高级/深度扫描时校验）
        try:
            if getattr(res, 'signed_valid', False):
                if not has_strong:
                    if lower_path.startswith(("c:\\program files", "c:\\windows")):
                        score = max(0, score - 3)
                        tags.append("可信签名商业软件(已降权3分)")
                    # 4.0.0 加强：有效签名 + 无强规则 → 强制封顶低危（大幅降低商业软件误报）
                    if score >= 1:
                        score = min(score, 2)
                        tags.append("有效签名(已封顶低危)")
        except Exception:
            pass

        # 4.6 已知安全工具降权：防杀软互判误报（如 PyAS/火绒/360 被自身规则命中）
        known_sec = ("pyas", "360tray", "360safe", "huorong", "hips", "usysdiag", "wsctrl", "dg_monitor", "dg_guard")
        lower_name = name.lower()
        if not has_strong and any(k in lower_name for k in known_sec):
            score = max(0, score - 4)
            tags.append("已知安全工具(已降权4分)")

        # 5. 更新器/安装器/缓存上下文豁免（3.5.8）：Temp/AppData/下载目录下，
        #    文件名含 update/install/cache/setup 等且无远控/勒索强特征 → 大幅降权。
        #    正常更新器、安装脚本常含 download/startup 等字样，是最常见误报源之一。
        updater_hint = any(k in lower_name for k in ("update", "updater", "install", "setup",
                                                     "cache", "downloader", "bootstrap", "patch"))
        tempish_path = any(k in lower_path for k in ("\\temp\\", "\\appdata\\", "\\cache\\",
                                                     "\\downloads\\", "\\tmp\\", "\\update\\"))
        if updater_hint and tempish_path and not has_strong:
            score = max(0, score - 3)
            tags.append("更新器/安装器上下文(已降权3分)")

        # 5.5 包依赖目录降权（4.11.0）：AI工具/pip缓存/site-packages 的正常包脚本，
        #    命中通用内容特征（系统篡改/下载执行/网络命令组合）多为误报 → 大幅降权。
        #    有强规则（reverse shell/mimikatz/勒索等特异特征）时不降，不漏真毒。
        pkg_dirs = ["\\packages\\pip\\local", "\\site-packages", "\\dist-packages",
                    "\\resources\\packages", "\\pip\\local\\sets",
                    "\\package_cache", "\\.cache\\pip", "\\pip\\cache",
                    "\\qwen-agent\\skills", "\\qwen-agent",
                    "\\monica", "\\doubao", "\\coze"]
        if not has_strong and any(d in lower_path for d in pkg_dirs):
            score = max(0, score - 8)
            tags.append("包依赖目录脚本(已降权8分)")

        # 更新 res.score（降权后）
        res.score = score
        res.tags = tags

        # ===== 组合维度判定：正确率优化——单点命中堆分不允许直接上高危/严重 =====
        dims = set()
        if base or disguised:
            dims.add("类型/伪装")
        for _h in hits:
            if _h.rule_id.startswith(("SCRIPT_", "PE_", "LNK_")):
                dims.add("内容特征")
            if _h.rule_id == "STARTUP_ITEM":
                dims.add("启动项")
        has_strong_rule = any(h.severity == "strong" for h in hits)
        # 3.5.8：网络连接+命令执行组合（专用组合特征，非宽泛关键词，误报可控）
        # 视为强信号，允许直接定级——真实远控/下载器核心链路，不受单维度压级限制
        if not has_strong_rule:
            try:
                has_strong_rule = any("网络连接+命令执行" in (getattr(h, "evidence", [""]) or [""])[0]
                                       for h in hits)
            except Exception:
                pass

        if score >= 12:
            lvl = LEVEL_CRIT
        elif score >= 7:
            lvl = LEVEL_HIGH
        elif score >= 4:
            lvl = LEVEL_MED
        elif score >= 1:
            lvl = LEVEL_LOW
        else:
            lvl = None

        if lvl is None:
            junk = self._check_junk(path, name, ext)
            if junk is not None:
                res.level = LEVEL_JUNK
                res.tags = [junk]
            else:
                res.level = LEVEL_SAFE
        else:
            if not has_strong_rule:
                # 无强规则时：单维度命中最高中危；高危需 ≥2 个维度；严重需 ≥3 个维度
                if lvl == LEVEL_CRIT and len(dims) < 3:
                    lvl = LEVEL_HIGH
                if lvl == LEVEL_HIGH and len(dims) < 2:
                    lvl = LEVEL_MED
            res.level = lvl

        # ===== YARA 规则检测（离线第二层：YARA 规则库）=====
        # 命中规则 → 累加风险分 / 追加标签 / 只升不降定级
        # 引擎或规则缺失时静默跳过，不影响任何正常功能
        try:
            import yara_engine
            _y_add, _y_tags, _y_level = yara_engine.scan_scan_result(path)
            if _y_add:
                res.score += _y_add
                for _t in _y_tags:
                    if _t not in res.tags:
                        res.tags.append(_t)
                if _y_level and LEVEL_ORDER.get(_y_level, 9) < LEVEL_ORDER.get(res.level, 9):
                    res.level = _y_level
        except Exception:
            pass

        # ===== ClamAV 病毒库检测（离线第三层：900万签名引擎）=====
        # 经 clamd 守护进程 INSTREAM 协议扫描；clamd 未运行/未命中时静默跳过
        try:
            import clamav_bridge
            if clamav_bridge.clamd_ping():
                _c_res = clamav_bridge.clamd_scan_file(path)
                if _c_res and _c_res[0]:
                    _c_name = _c_res[1] or "ClamAV 病毒库命中"
                    res.score += 15
                    _tag = "ClamAV:%s" % _c_name
                    if _tag not in res.tags:
                        res.tags.append(_tag)
                    res.level = LEVEL_CRIT
        except Exception:
            pass

        # ===== 5.0.0 统一裁决层：多证据风险评分（最终权威，覆盖 level）=====
        # 原则：哈希黑名单/EICAR/云端恶意直接定罪；单条弱特征不报毒；
        #       白名单=降分器非免死金牌；AI 仅辅助；结果存 verdict_info 供风险解释页展示。
        try:
            import verdict_engine as _ve
            _vi = _ve.assess(
                path=path, name=name, category=category, sha256=sha256,
                res_tags=res.tags, res_hits=res.hits, res_score=res.score,
                res_level=res.level, whitelisted=whitelisted,
                signed_valid=bool(getattr(res, "signed_valid", False)))
            res.verdict_info = _vi
            # verdict 是最终裁决（黑名单/EICAR/云端恶意仍 100 定罪，行为与旧版一致）
            if _vi.get("level"):
                res.level = _vi["level"]
            # 综合评分回写 score 显示位（0-100），供 UI 展示与风险解释页
            # 注意：不要覆盖 CRIT 类强证据判定（verdict 已保证），垃圾/安全档不受影响
        except Exception:
            pass
        return res

# ===== 3.5.8 降误报核心：自动隔离门槛判定 =====
def should_auto_quarantine(res, path: str = "") -> str:
    """决定实时防护/下载保护对扫描结果的处理方式，避免正常软件被自动隔离。

    返回三种处置：
      "quarantine" —— 立即自动隔离（严重，或高危且特征足够硬）
      "notify"     —— 仅弹窗提示、不自动隔离（高危但只有弱特征/单维度，等用户决定）
      "skip"       —— 放行（白名单 / 中危及以下 / 有有效签名）

    原则：宁可提示打扰，不可误杀正常文件。误杀可恢复但会打断用户正常使用。
    """
    try:
        if res is None:
            return "skip"
        if getattr(res, "whitelisted", False):
            return "skip"
        level = getattr(res, "level", "")
        if level == LEVEL_SAFE or level == LEVEL_JUNK or not level:
            return "skip"
        if level not in (LEVEL_CRIT, LEVEL_HIGH):
            return "skip"  # 中危及以下一律不自动隔离

        # 维度重算（与组合维度判定保持一致）
        dims = set()
        for h in getattr(res, "hits", []) or []:
            rid = getattr(h, "rule_id", "")
            if rid.startswith(("SCRIPT_", "PE_", "LNK_")):
                dims.add("内容特征")
            if rid == "STARTUP_ITEM":
                dims.add("启动项")
        for t in getattr(res, "tags", []) or []:
            if "伪装" in t or "双扩展名" in t or "欺骗" in t:
                dims.add("类型/伪装")
        has_strong = any(getattr(h, "severity", "") == "strong" for h in (getattr(res, "hits", []) or []))
        if not has_strong:
            try:
                has_strong = any("网络连接+命令执行" in (getattr(h, "evidence", [""]) or [""])[0]
                               for h in (getattr(res, "hits", []) or []))
            except Exception:
                pass
        # 已隔离过/自保护目录
        low_p = str(path).lower()
        if low_p and ("\\quarantine\\" in low_p or "\\versions\\" in low_p or "\\swap_backup\\" in low_p):
            return "skip"

        signed_ok = bool(getattr(res, "signed_valid", False))
        if signed_ok:
            return "skip"  # 有效签名 → 可信组件放行

        if level == LEVEL_CRIT:
            return "quarantine"  # 严重：黑名单哈希/EICAR/勒索强特征 → 直接隔离

        # 高危：必须有强规则或 ≥2 个特征维度才自动隔离；
        # 只有弱特征（宽泛关键词/高熵/加壳）或单维度 → 只提示，等用户确认
        if has_strong or len(dims) >= 2:
            return "quarantine"
        return "notify"
    except Exception:
        return "notify"  # 判定失败时宁可不自动隔离，避免误杀


def list_all_drives() -> List[str]:
    """枚举所有存在的盘符（C:\\, D:\\, ...）。"""
    drives = []
    for c in string.ascii_uppercase:
        p = f"{c}:\\"
        if os.path.exists(p):
            drives.append(p)
    return drives

def drive_of(path: str) -> str:
    d = os.path.splitdrive(path)[0]
    return d + "\\" if d else ""

def user_home():
    return os.path.expanduser("~")

def desktop_paths():
    import ctypes.wintypes
    paths = []
    buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
    if ctypes.windll.shell32.SHGetFolderPathW(0, 0x0000, 0, 0, buf) == 0:  # CSIDL_DESKTOPDIRECTORY
        paths.append(buf.value)
    if ctypes.windll.shell32.SHGetFolderPathW(0, 0x0010, 0, 0, buf) == 0:  # CSIDL_COMMON_DESKTOPDIRECTORY
        if buf.value not in paths:
            paths.append(buf.value)
    return paths

def user_common_dirs():
    """用户常用目录（桌面/下载/文档/图片/视频/音乐），返回 [(path, recursive)]。"""
    home = user_home()
    out = [(p, True) for p in desktop_paths()]
    for sub in ["Downloads", "下载", "Documents", "文档", "Pictures", "图片",
                "Videos", "视频", "Music", "音乐"]:
        p = os.path.join(home, sub)
        if os.path.isdir(p) and (p, True) not in out:
            out.append((p, True))
    return out

def quick_scan_targets():
    """快速查杀：所有盘根目录（顶层）+ 桌面/下载（递归）+ 程序自身目录（递归）。
    刻意保持小范围——"大概扫一下"。Temp 等大目录交给高级/深度扫描，
    避免快速查杀又慢又扫出一大堆临时文件。
    程序自身目录必须纳入：防止病毒伪装成程序文件藏在安装目录里逃过扫描。
    """
    targets = []
    for dv in list_all_drives():
        targets.append((dv, False))                 # 各盘根目录顶层文件
    for p in desktop_paths():
        targets.append((p, True))                   # 桌面（递归）
    home = user_home()
    for sub in ["Downloads", "下载"]:
        p = os.path.join(home, sub)
        if os.path.isdir(p):
            targets.append((p, True))               # 下载（递归）
    # 程序自身安装目录（递归）——防止病毒藏入安装目录逃过扫描
    prog_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.isdir(prog_dir):
        targets.append((prog_dir, True))
    return targets

def appdata_roots():
    """所有盘上所有用户的 AppData 根目录（流氓软件/病毒的主要藏身地）。"""
    roots = []
    for dv in list_all_drives():
        users = os.path.join(dv, "Users")
        if os.path.isdir(users):
            try:
                for u in os.listdir(users):
                    p = os.path.join(users, u, "AppData")
                    if os.path.isdir(p):
                        roots.append(p)
            except OSError:
                pass
    return roots

def resolve_lnk_targets(lnk_dirs):
    """批量解析目录下所有 .lnk 快捷方式指向的目标路径。
    返回 [(lnk_path, target_path), ...]，目标不存在的不返回。
    用于扫描时追踪快捷方式指向的程序，防止病毒通过快捷方式藏身逃过扫描。
    """
    import subprocess
    if not lnk_dirs:
        return []
    dirs_arg = ",".join(f"'{d}'" for d in lnk_dirs)
    ps = (
        "$sh = New-Object -ComObject WScript.Shell\n"
        f"$dirs = @({dirs_arg})\n"
        "foreach ($d in $dirs) {\n"
        "  if (Test-Path $d) {\n"
        "    Get-ChildItem -Path $d -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {\n"
        "      try {\n"
        "        $lnk = $sh.CreateShortcut($_.FullName)\n"
        "        if ($lnk.TargetPath -and (Test-Path $lnk.TargetPath)) {\n"
        "          Write-Output \"$($_.FullName)|$($lnk.TargetPath)\"\n"
        "        }\n"
        "      } catch {}\n"
        "    }\n"
        "  }\n"
        "}\n"
    )
    try:
        # CREATE_NO_WINDOW：隐藏 powershell 黑窗（Windows 专用标志）
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           capture_output=True, text=True, encoding="gbk", errors="ignore", timeout=8,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        results = []
        for line in r.stdout.splitlines():
            if "|" in line:
                lnk, target = line.split("|", 1)
                results.append((lnk.strip(), target.strip()))
        return results
    except Exception:
        return []

def enum_files(root: str, recursive: bool = True, skip_system: bool = False,
               skip_bulk: bool = False, appdata_mode: str = "skip",
               skip_hidden_dir: bool = True, skip_harmless: bool = False):
    """遍历目录，产出文件绝对路径。用 os.scandir 代替 os.walk，更快。"""
    if os.path.isfile(root):
        yield root
        return

    SYS_FILES = {"pagefile.sys", "hiberfil.sys", "swapfile.sys", "dumpstack.log.tmp"}
    # 快速扫描跳过：明确不可能携带 PE 载荷的纯数据/媒体类型（哈希纯浪费，尤其大视频）
    # 仅快速扫描启用；绝不包含 exe/dll/sys/脚本等可执行类型；深度/高级扫描不启用
    HARMLESS_EXTS = {
        ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".cur", ".webp", ".svg", ".tif", ".tiff", ".heic",
        ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma", ".opus",
        ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v", ".ts", ".m2ts",
        ".ttf", ".otf", ".woff", ".woff2", ".fon", ".eot",
    }
    # 始终跳过的目录（无意义/系统保护）
    ALWAYS_SKIP_DIRS = {"$recycle.bin", "system volume information", "$windows.~bt",
                         "$windows.~ws", "recovery", "boot", "efi", "system.sav"}
    # 系统目录（高级扫描跳过）
    SYSTEM_SKIP_DIRS = {"windows", "program files", "program files (x86)", "programdata"}
    # 大体积开发/缓存目录（高级扫描跳过）
    BULK_SKIP_DIRS = {"node_modules", ".git", "venv", "__pycache__", "dist", "build",
                       ".gradle", ".m2", ".npm", ".cache", "target", "bin", "obj"}
    # AppData pe 模式下只扫描的可执行/脚本扩展名
    APP_DATA_PE_EXTS = {".exe", ".dll", ".sys", ".scr", ".com", ".cpl", ".ocx",
                         ".ps1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".bat", ".cmd",
                         ".hta", ".reg", ".py", ".pyw", ".lnk", ".msi"}
    stack = [root]
    while stack:
        dirpath = stack.pop()
        try:
            low_path = dirpath.lower()
            in_appdata = "\\appdata\\" in low_path
            if in_appdata and appdata_mode == "skip":
                continue
            with os.scandir(dirpath) as it:
                dirs = []
                for entry in it:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            low = entry.name.lower()
                            if low in ALWAYS_SKIP_DIRS:
                                continue
                            if skip_hidden_dir and entry.name.startswith("."):
                                continue
                            if skip_system and low in SYSTEM_SKIP_DIRS:
                                continue
                            if skip_bulk and low in BULK_SKIP_DIRS:
                                continue
                            dirs.append(entry.path)
                        elif entry.is_file(follow_symlinks=False):
                            fn = entry.name
                            if fn.lower() in SYS_FILES:
                                continue
                            if skip_harmless and os.path.splitext(fn)[1].lower() in HARMLESS_EXTS:
                                continue
                            if in_appdata and appdata_mode == "pe":
                                if os.path.splitext(fn)[1].lower() not in APP_DATA_PE_EXTS:
                                    continue
                            yield entry.path
                    except (PermissionError, OSError):
                        continue
                if recursive:
                    stack.extend(dirs)
        except (PermissionError, OSError):
            continue


# ============================================================
# C++ 深度判定引擎接口（dg_verdict.exe，配合 2.16.0）
# ============================================================
CXX_VERDICT_EXE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_verdict.exe")

# C++ 英文等级 -> 引擎中文等级
_CXX_LEVEL_MAP = {
    "critical": LEVEL_CRIT, "high": LEVEL_HIGH, "medium": LEVEL_MED,
    "low": LEVEL_LOW, "info": LEVEL_SAFE,
}


def cxx_verdict(path, timeout=3):
    """C++ 深度判定引擎复核单个文件。

    :param path: 文件绝对路径
    :param timeout: 单文件超时（秒），超时/失败返回 None（不阻断扫描）
    :return: dict(success/file/sha256/score/level/hits) 或 None
    """
    if not os.path.isfile(CXX_VERDICT_EXE) or not os.path.isfile(path):
        return None
    try:
        p = subprocess.run([CXX_VERDICT_EXE, path], capture_output=True,
                           timeout=timeout, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if p.returncode != 0:
            return None
        raw = p.stdout
        data = None
        for enc in ("utf-8", "gbk", "utf-16"):
            try:
                data = json.loads(raw.decode(enc))
                break
            except Exception:
                continue
        if not data or not data.get("success"):
            return None
        return data
    except Exception:
        return None


def merge_cxx_hits(result, cxx):
    """把 C++ 判定结果合并进 ScanResult（分数取较高者，命中规则去重合并）。"""
    if not cxx or not isinstance(result, ScanResult):
        return result
    try:
        cxx_score = int(cxx.get("score", 0) or 0)
        if cxx_score > result.score:
            result.score = cxx_score
        # 等级提升（只升不降）
        nl = _CXX_LEVEL_MAP.get(cxx.get("level", ""), "")
        if nl and nl != LEVEL_SAFE:
            if LEVEL_ORDER.get(nl, 9) < LEVEL_ORDER.get(result.level, 9):
                result.level = nl
        # 命中规则合并（按 rule_id 去重）
        existing = {h.rule_id for h in result.hits}
        for h in (cxx.get("hits") or []):
            rid = h.get("rule_id", "")
            if not rid or rid in existing:
                continue
            result.hits.append(RuleHit(
                rule_id=rid,
                title=h.get("title", "") or "C++ 判定",
                score=int(h.get("score", 0) or 0),
                severity="strong",
                evidence=[h.get("evidence", "")] if h.get("evidence") else [],
                description="C++ 深度判定引擎命中",
            ))
            existing.add(rid)
        if not any("C++" in t for t in result.tags):
            result.tags.append("C++ 深度判定")
    except Exception:
        pass
    return result


# ============================================================
# 多进程扫描 worker（4.6.1：每个进程独立 GIL，真并行吃满物理核）
# ============================================================
_MP_SCANNER = None

def _mp_lower_priority():
    try:
        import ctypes
        ctypes.windll.kernel32.SetThreadPriority(
            ctypes.windll.kernel32.GetCurrentThread(), -1)  # THREAD_PRIORITY_BELOW_NORMAL
        ctypes.windll.kernel32.SetPriorityClass(
            ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)  # BELOW_NORMAL_PRIORITY_CLASS
    except Exception:
        pass

def mp_scan_init(deep_strings, hash_all, max_hash_size):
    """multiprocessing.Pool initializer：每进程构造独立 Scanner，并降优先级不抢 UI"""
    global _MP_SCANNER
    _mp_lower_priority()
    _MP_SCANNER = Scanner(deep_strings=deep_strings, hash_all=hash_all,
                          max_hash_size=max_hash_size)

def mp_scan_file(item):
    """worker 函数：item=(path, sha256_pre) -> ScanResult；异常兜底返回安全结果"""
    global _MP_SCANNER
    try:
        if _MP_SCANNER is None:
            _MP_SCANNER = Scanner(deep_strings=False, hash_all=True,
                                  max_hash_size=200 * 1024 * 1024)
        if isinstance(item, tuple) and len(item) == 2:
            return _MP_SCANNER.scan_file(item[0], sha256_pre=item[1])
        return _MP_SCANNER.scan_file(item, sha256_pre="")
    except Exception:
        import os as _os
        return ScanResult(path=item[0] if isinstance(item, tuple) else item,
                          name=_os.path.basename(item[0] if isinstance(item, tuple) else item),
                          ext=_os.path.splitext(item[0] if isinstance(item, tuple) else item)[1].lower(),
                          category="普通文件", size=0, sha256="")
