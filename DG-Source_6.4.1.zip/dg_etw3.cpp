// dg_etw3.cpp — 逐字复制 diag_etw.cpp（已验证能收事件）的结构，仅附加 jsonl/心跳/flag 输出
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <shellapi.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "tdh.lib")
#pragma comment(lib, "shell32.lib")

static const GUID KERNEL_PROCESS_PROVIDER = { 0x22FB2CD6, 0x0E7B, 0x422B, { 0xA0, 0xC7, 0x2F, 0xAD, 0x1F, 0xD0, 0xE7, 0x16 } };
static const wchar_t* SESSION_NAME = L"DG-ETW-DIAG";
static volatile bool g_done = false;
static volatile long long g_ev = 0;
static HANDLE g_hOut = INVALID_HANDLE_VALUE;

static void WriteOut(const char* s) {
    if (g_hOut == INVALID_HANDLE_VALUE) return;
    DWORD w = 0;
    WriteFile(g_hOut, s, (DWORD)strlen(s), &w, NULL);
    WriteFile(g_hOut, "\n", 1, &w, NULL);
    FlushFileBuffers(g_hOut);
}

static void WINAPI OnEvent(EVENT_RECORD* rec) {
    if (!rec) return;
    g_ev++;
    UCHAR eid = rec->EventHeader.EventDescriptor.Id;
    if (eid != 1 && eid != 2) return;
    // 完全复刻 diag：TdhGetEventInformation
    ULONG need = 0;
    TDHSTATUS st = TdhGetEventInformation(rec, 0, NULL, NULL, &need);
    TRACE_EVENT_INFO* info = NULL;
    if (st == ERROR_INSUFFICIENT_BUFFER) {
        info = (TRACE_EVENT_INFO*)malloc(need);
        st = TdhGetEventInformation(rec, 0, NULL, info, &need);
    }
    char line[128];
    if (st != ERROR_SUCCESS || !info) {
        sprintf_s(line, "{\"tdh_fail\":%u}", st);
        if (info) free(info);
        WriteOut(line);
        return;
    }
    sprintf_s(line, "{\"e\":%u,\"pid\":%u,\"props\":%u}", eid, rec->EventHeader.ProcessId, info->TopLevelPropertyCount);
    free(info);
    WriteOut(line);
    g_done = true;   // 与 diag 一致：收到事件立即结束
}

static DWORD WINAPI TraceThread(LPVOID p) {
    ProcessTrace((PTRACEHANDLE)p, 1, 0, 0);
    return 0;
}

int wmain() {
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (argc < 4) return 2;
    std::wstring jsonl = argv[1], hb = argv[2], flag = argv[3];
    LocalFree(argv);

    if (GetFileAttributesW(flag.c_str()) != INVALID_FILE_ATTRIBUTES) return 0;
    g_hOut = CreateFileW(jsonl.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                         NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (g_hOut == INVALID_HANDLE_VALUE) return 3;

    BYTE buf[sizeof(EVENT_TRACE_PROPERTIES) + 64 * sizeof(wchar_t)];
    EVENT_TRACE_PROPERTIES* props = (EVENT_TRACE_PROPERTIES*)buf;
    memset(buf, 0, sizeof(buf));
    props->Wnode.BufferSize = sizeof(buf);
    props->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
    props->Wnode.Guid = { 0x3B2E2C6A, 0x4E1A, 0x8A9F, { 0x6D, 0x5C, 0x4B, 0x3E, 0x2A, 0x10, 0x88, 0x99 } };
    props->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
    wcscpy_s((wchar_t*)(buf + props->LoggerNameOffset), 64, SESSION_NAME);
    props->LogFileMode = EVENT_TRACE_REAL_TIME_MODE;
    props->MinimumBuffers = 2; props->MaximumBuffers = 16; props->FlushTimer = 1;
    TRACEHANDLE sess = 0;
    ULONG r = StartTraceW(&sess, SESSION_NAME, props);
    if (r == ERROR_ALREADY_EXISTS) {
        ControlTraceW(0, SESSION_NAME, props, EVENT_TRACE_CONTROL_STOP);
        r = StartTraceW(&sess, SESSION_NAME, props);
    }
    if (r != ERROR_SUCCESS) { CloseHandle(g_hOut); return 4; }
    r = EnableTraceEx2(sess, &KERNEL_PROCESS_PROVIDER, EVENT_CONTROL_CODE_ENABLE_PROVIDER, 4, 0, 0, 0, NULL);
    if (r != ERROR_SUCCESS) { ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP); CloseHandle(g_hOut); return 5; }
    EVENT_TRACE_LOGFILEW lf; memset(&lf, 0, sizeof(lf));
    lf.LoggerName = (LPWSTR)SESSION_NAME;
    lf.ProcessTraceMode = PROCESS_TRACE_MODE_REAL_TIME | PROCESS_TRACE_MODE_EVENT_RECORD;
    lf.EventRecordCallback = (PEVENT_RECORD_CALLBACK)OnEvent;
    TRACEHANDLE h = OpenTraceW(&lf);
    if (h == (TRACEHANDLE)INVALID_HANDLE_VALUE) { CloseHandle(g_hOut); return 6; }
    HANDLE hThread = CreateThread(NULL, 0, TraceThread, &h, 0, NULL);
    // 与 diag 完全一致：立即产生一个子进程事件
    system("start cmd /c ping -n 1 127.0.0.1 >nul & exit");
    // 主循环：6 秒（diag 同款），期间心跳也写
    for (int i = 0; i < 60 && !g_done; i++) {
        if (i % 10 == 0) {
            HANDLE hb2 = CreateFileW(hb.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                     NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
            if (hb2 != INVALID_HANDLE_VALUE) {
                char b2[32]; sprintf_s(b2, "%lld", (long long)GetTickCount64());
                DWORD w2 = 0; WriteFile(hb2, b2, (DWORD)strlen(b2), &w2, NULL); CloseHandle(hb2);
            }
        }
        // 每 1 秒强制 flush，验证是否 flush 通知问题
        if (i % 10 == 0) ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_FLUSH);
        // 每 1 秒强制 flush，验证是否 flush 通知问题
        if (i % 10 == 0) ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_FLUSH);
        Sleep(100);
    }
    // flag 出现则提前结束（守护正常退出契约）
    if (GetFileAttributesW(flag.c_str()) != INVALID_FILE_ATTRIBUTES) { g_done = true; }
    ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP);
    WaitForSingleObject(hThread, 3000);
    CloseHandle(hThread);
    char fin[64]; sprintf_s(fin, "{\"final\":%lld}", g_ev); WriteOut(fin);
    if (g_hOut != INVALID_HANDLE_VALUE) CloseHandle(g_hOut);
    return 0;
}
