# -*- coding: utf-8 -*-
"""真实通道截图：PIL ImageGrab 截全屏存 PNG"""
import os, sys
try:
    from PIL import ImageGrab
except Exception:
    import subprocess
    subprocess.run([sys.executable, "-m", "pip", "install", "pillow", "-q"], check=False)
    from PIL import ImageGrab
outdir = r"F:\桌面保护\新建文件夹"
os.makedirs(outdir, exist_ok=True)
path = os.path.join(outdir, "screen_6413.png")
img = ImageGrab.grab(all_screens=True)
img.save(path, "PNG")
print("SAVED", path, img.size)
