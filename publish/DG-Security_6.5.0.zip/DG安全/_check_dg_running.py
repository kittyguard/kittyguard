# -*- coding: utf-8 -*-
"""确认 api-ms-win-core-datetime DLL 现状 + 便携版进程版本"""
import os, subprocess, json

DL_INTERNAL = r"C:\Users\Administrator\Downloads\DG安全\_internal"
dll = os.path.join(DL_INTERNAL, "api-ms-win-core-datetime-l1-1-0.dll")
print("datetime DLL exists:", os.path.isfile(dll))
if os.path.isfile(dll):
    print("  size:", os.path.getsize(dll), "B")

print()
print("=== 运行中的 DG 相关进程 ===")
r = subprocess.run(["powershell", "-NoProfile", "-Command",
    "Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'DG|dg_' } | Select-Object Name, ProcessId, ExecutablePath | Format-List"],
    capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=60)
print((r.stdout or "")[:3000] or "(none)")

print()
print("=== 便携版根目录 version 标识 ===")
for vf in [r"C:\Users\Administrator\Downloads\DG安全\version.json",
           r"C:\Users\Administrator\Downloads\DG安全\_internal\version.json",
           r"C:\Users\Administrator\Downloads\DG安全\dgdata\version.json"]:
    if os.path.isfile(vf):
        try:
            with open(vf, "r", encoding="utf-8") as f:
                d = json.load(f)
            print(vf, "->", d.get("latest_version", d.get("version")))
        except Exception as e:
            print(vf, "parse err", e)
    else:
        print(vf, "-> not found")
