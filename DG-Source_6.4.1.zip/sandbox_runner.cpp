// DG Native Sandbox Runner (自研轻量沙盒)
// 受限令牌 + Job Object + 行为监控（文件/进程/网络/注册表）
// 用法: sandbox_runner.exe <sample_path> <work_dir> <timeout_sec>
// 输出: <work_dir>/output/behavior_log.json
// 编译(MSYS2): g++ -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -municode -mwindows -o sandbox_runner.exe sandbox_runner.cpp -liphlpapi -ladvapi32
#include <windows.h>
#include <winternl.h>
#include <iphlpapi.h>
#include <sddl.h>
#include <aclapi.h>
#include <tlhelp32.h>
#include <wchar.h>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <thread>
#include <atomic>
#include <chrono>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

extern "C" NTSTATUS NTAPI NtResumeProcess(HANDLE);
#ifndef PROC_THREAD_ATTRIBUTE_TOKEN
#define PROC_THREAD_ATTRIBUTE_TOKEN 0x20002
#endif

// ---------------- JSON 简单转义 ----------------
static std::string w2u(const std::wstring &ws) {
    if (ws.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, ws.c_str(), (int)ws.size(), NULL, 0, NULL, NULL);
    std::string out(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, ws.c_str(), (int)ws.size(), &out[0], n, NULL, NULL);
    return out;
}
static std::wstring u2w(const std::string &s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0);
    std::wstring out(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], n);
    return out;
}
static std::string json_escape(const std::string &s) {
    std::string r;
    r.reserve(s.size() + 8);
    for (char c : s) {
        switch (c) {
            case '"': r += "\\\""; break;
            case '\\': r += "\\\\"; break;
            case '\n': r += "\\n"; break;
            case '\r': r += "\\r"; break;
            case '\t': r += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) { char b[16]; snprintf(b, sizeof(b), "\\u%04x", (unsigned char)c); r += b; }
                else r += c;
        }
    }
    return r;
}

// ---------------- 日志 ----------------
static std::wstring g_workdir;
static void wlog(const std::wstring &msg) {
    FILE *f = _wfopen((g_workdir + L"\\output\\sandbox_log.txt").c_str(), L"ab");
    if (!f) return;
    SYSTEMTIME st; GetLocalTime(&st);
    fwprintf(f, L"[%02d:%02d:%02d] %ls\n", st.wHour, st.wMinute, st.wSecond, msg.c_str());
    fclose(f);
}

// ---------------- 行为收集器 ----------------
struct Behavior {
    std::set<std::wstring> files_created;
    std::set<std::wstring> files_modified;
    std::set<std::wstring> reg_writes;
    std::set<std::wstring> net_conns;
    std::set<std::wstring> procs_created;
    std::set<DWORD> job_pids;
};
static Behavior g_beh;
static std::atomic<bool> g_running{true};

// ---------------- 目录快照（基线） ----------------
static std::set<std::wstring> snapshot_dir(const std::wstring &dir) {
    std::set<std::wstring> s;
    std::wstring pattern = dir + L"\\*";
    WIN32_FIND_DATAW fd;
    HANDLE hFind = FindFirstFileW(pattern.c_str(), &fd);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
                s.insert(dir + L"\\" + fd.cFileName);
        } while (FindNextFileW(hFind, &fd));
        FindClose(hFind);
    }
    return s;
}

// ---------------- 文件监控（ReadDirectoryChangesW） ----------------
static void watch_dir_thread(const std::wstring &dir, bool recursive, std::atomic<bool> &stop, std::set<std::wstring> before) {
    HANDLE hDir = CreateFileW(dir.c_str(), FILE_LIST_DIRECTORY,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL,
        OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED, NULL);
    if (hDir == INVALID_HANDLE_VALUE) return;
    BYTE buf[65536];
    OVERLAPPED ov = {0};
    ov.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    DWORD bytes = 0;
    if (!ReadDirectoryChangesW(hDir, buf, sizeof(buf), recursive,
        FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME |
        FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
        &bytes, &ov, NULL)) {
        CloseHandle(ov.hEvent); CloseHandle(hDir);
        return;
    }
    while (!stop.load()) {
        if (WaitForSingleObject(ov.hEvent, 500) == WAIT_OBJECT_0) {
            DWORD got = 0;
            if (GetOverlappedResult(hDir, &ov, &got, FALSE) && got > 0) {
                BYTE *p = buf;
                while (p < buf + got) {
                    FILE_NOTIFY_INFORMATION *ni = (FILE_NOTIFY_INFORMATION*)p;
                    std::wstring name(ni->FileName, ni->FileNameLength / sizeof(WCHAR));
                    std::wstring full = dir + L"\\" + name;
                    if (ni->Action == FILE_ACTION_ADDED || ni->Action == FILE_ACTION_RENAMED_NEW_NAME) {
                        if (before.find(full) == before.end())
                            g_beh.files_created.insert(full);
                    } else if (ni->Action == FILE_ACTION_MODIFIED) {
                        g_beh.files_modified.insert(full);
                    }
                    if (ni->NextEntryOffset == 0) break;
                    p += ni->NextEntryOffset;
                }
            }
            ResetEvent(ov.hEvent);
            ReadDirectoryChangesW(hDir, buf, sizeof(buf), recursive,
                FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME |
                FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
                &bytes, &ov, NULL);
        }
    }
    CloseHandle(ov.hEvent);
    CloseHandle(hDir);
}

// ---------------- Job 进程枚举 ----------------
static std::set<DWORD> enum_job_pids(HANDLE hJob) {
    std::set<DWORD> pids;
    BYTE buf[8192] = {0};
    DWORD len = 0;
    if (QueryInformationJobObject(hJob, JobObjectBasicProcessIdList, buf, sizeof(buf), &len)) {
        JOBOBJECT_BASIC_PROCESS_ID_LIST *list = (JOBOBJECT_BASIC_PROCESS_ID_LIST*)buf;
        for (DWORD i = 0; i < list->NumberOfProcessIdsInList; i++)
            pids.insert((DWORD)list->ProcessIdList[i]);
    }
    return pids;
}

// ---------------- 网络监控（IPHLPAPI） ----------------
static void net_snapshot(HANDLE hJob) {
    // TCP
    ULONG sz = 0;
    GetExtendedTcpTable(NULL, &sz, TRUE, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0);
    if (sz == 0) return;
    std::vector<BYTE> buf(sz);
    if (GetExtendedTcpTable(buf.data(), &sz, TRUE, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0) != NO_ERROR) return;
    MIB_TCPTABLE_OWNER_PID *tbl = (MIB_TCPTABLE_OWNER_PID*)buf.data();
    std::set<DWORD> jobpids = enum_job_pids(hJob);
    for (DWORD i = 0; i < tbl->dwNumEntries; i++) {
        MIB_TCPROW_OWNER_PID &r = tbl->table[i];
        if (jobpids.find(r.dwOwningPid) == jobpids.end()) continue;
        if (r.dwRemoteAddr == 0 && r.dwRemotePort == 0) continue; // LISTEN only
        wchar_t line[160];
        swprintf(line, L"TCP %d.%d.%d.%d:%d -> %d.%d.%d.%d:%d (PID %u)",
            (r.dwRemoteAddr>>0)&0xff,(r.dwRemoteAddr>>8)&0xff,(r.dwRemoteAddr>>16)&0xff,(r.dwRemoteAddr>>24)&0xff,
            ntohs((u_short)r.dwRemotePort),
            (r.dwLocalAddr>>0)&0xff,(r.dwLocalAddr>>8)&0xff,(r.dwLocalAddr>>16)&0xff,(r.dwLocalAddr>>24)&0xff,
            ntohs((u_short)r.dwLocalPort), r.dwOwningPid);
        g_beh.net_conns.insert(line);
    }
    // UDP
    sz = 0;
    GetExtendedUdpTable(NULL, &sz, TRUE, AF_INET, UDP_TABLE_OWNER_PID, 0);
    if (sz == 0) return;
    buf.resize(sz);
    if (GetExtendedUdpTable(buf.data(), &sz, TRUE, AF_INET, UDP_TABLE_OWNER_PID, 0) != NO_ERROR) return;
    MIB_UDPTABLE_OWNER_PID *utbl = (MIB_UDPTABLE_OWNER_PID*)buf.data();
    for (DWORD i = 0; i < utbl->dwNumEntries; i++) {
        MIB_UDPROW_OWNER_PID &r = utbl->table[i];
        if (jobpids.find(r.dwOwningPid) == jobpids.end()) continue;
        wchar_t line[80];
        swprintf(line, L"UDP %d.%d.%d.%d:%d (PID %u)",
            (r.dwLocalAddr>>0)&0xff,(r.dwLocalAddr>>8)&0xff,(r.dwLocalAddr>>16)&0xff,(r.dwLocalAddr>>24)&0xff,
            ntohs((u_short)r.dwLocalPort), r.dwOwningPid);
        g_beh.net_conns.insert(line);
    }
}

// ---------------- 注册表快照 ----------------
static std::wstring reg_snapshot(HKEY root, const wchar_t *subkey) {
    HKEY hk = NULL;
    if (RegOpenKeyExW(root, subkey, 0, KEY_READ | KEY_WOW64_64KEY, &hk) != ERROR_SUCCESS) return L"";
    std::wstring out;
    for (DWORD i = 0;; i++) {
        wchar_t name[512] = {0}; DWORD nlen = 512;
        BYTE data[4096]; DWORD dlen = sizeof(data); DWORD type = 0;
        LONG r = RegEnumValueW(hk, i, name, &nlen, NULL, &type, data, &dlen);
        if (r != ERROR_SUCCESS) break;
        if (wcsstr(name, L"PS") == name) continue;
        out += name; out += L"=";
        out += std::wstring((wchar_t*)data, dlen / sizeof(wchar_t));
        out += L"|";
    }
    RegCloseKey(hk);
    return out;
}
static void reg_check() {
    struct { HKEY root; const wchar_t *key; } paths[] = {
        { HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Run" },
        { HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce" },
        { HKEY_CURRENT_USER, L"Environment" },
    };
    static std::map<std::wstring, std::wstring> base;
    static bool init = false;
    if (!init) {
        for (auto &p : paths) base[p.key] = reg_snapshot(p.root, p.key);
        init = true;
        return;
    }
    for (auto &p : paths) {
        std::wstring cur = reg_snapshot(p.root, p.key);
        if (cur != base[p.key]) g_beh.reg_writes.insert(p.key);
    }
}

// ---------------- 目录权限：允许 Low IL 写入 ----------------
static void grant_low_il_write(const std::wstring &dir) {
    // 1. Everyone 完全控制（隔离目录，样本输出写这里）
    EXPLICIT_ACCESSW ea = {0};
    wchar_t everyone[] = L"Everyone";
    BuildExplicitAccessWithNameW(&ea, everyone, GENERIC_ALL, GRANT_ACCESS,
        SUB_CONTAINERS_AND_OBJECTS_INHERIT);
    PACL pNewAcl = NULL;
    if (SetEntriesInAclW(1, &ea, NULL, &pNewAcl) == ERROR_SUCCESS) {
        SetNamedSecurityInfoW((LPWSTR)dir.c_str(), SE_FILE_OBJECT,
            DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
            NULL, NULL, pNewAcl, NULL);
        LocalFree(pNewAcl);
    }
    // 2. Low 完整性标签（否则 Low IL 进程被完整性策略挡在门外）
    SID_IDENTIFIER_AUTHORITY labelAuth = SECURITY_MANDATORY_LABEL_AUTHORITY;
    PSID lowSid = NULL;
    AllocateAndInitializeSid(&labelAuth, 1, SECURITY_MANDATORY_LOW_RID, 0,0,0,0,0,0,0, &lowSid);
    if (lowSid) {
        DWORD sidLen = GetLengthSid(lowSid);
        DWORD saclSize = sizeof(ACL) + sizeof(SYSTEM_MANDATORY_LABEL_ACE) + sidLen;
        std::vector<BYTE> buf(saclSize);
        PACL pSacl = (PACL)buf.data();
        if (InitializeAcl(pSacl, saclSize, ACL_REVISION)) {
            SYSTEM_MANDATORY_LABEL_ACE *ace = (SYSTEM_MANDATORY_LABEL_ACE*)(buf.data() + sizeof(ACL));
            ace->Header.AceType = SYSTEM_MANDATORY_LABEL_ACE_TYPE;
            ace->Header.AceFlags = 0;
            ace->Header.AceSize = (WORD)(sizeof(SYSTEM_MANDATORY_LABEL_ACE) + sidLen);
            ace->Mask = SYSTEM_MANDATORY_LABEL_NO_WRITE_UP;
            memcpy(&ace->SidStart, lowSid, sidLen);
            if (AddAce(pSacl, ACL_REVISION, MAXDWORD, ace, ace->Header.AceSize)) {
                SetNamedSecurityInfoW((LPWSTR)dir.c_str(), SE_FILE_OBJECT,
                    LABEL_SECURITY_INFORMATION, NULL, NULL, NULL, pSacl);
            }
        }
        FreeSid(lowSid);
    }
}

// ---------------- NtCreateUserProcess（内核路径，保留 Low IL） ----------------
typedef enum _PS_CREATE_STATE {
    PsCreateInitialState, PsCreateFailOnFileOpen, PsCreateFailOnSectionCreate,
    PsCreateFailExeFormat, PsCreateFailMachineMismatch, PsCreateFailExeMachineMismatch,
    PsCreateFailImageVerify, PsCreateDebuggerStart, PsCreateSuccess, PsCreateMaximum
} PS_CREATE_STATE;
typedef struct _PS_CREATE_INFO {
    SIZE_T Size;
    PS_CREATE_STATE State;
    union {
        struct { ULONG InitFlags; ULONG64 FileHandle; ULONG64 SectionHandle; ULONG64 UserProcessParametersNative; ULONG64 UserProcessParametersWow64; ULONG64 CurrentParameterFlags; ULONG64 PEBAddressNative; ULONG64 PEBAddressWow64; ULONG64 ManifestAddress; ULONG64 ManifestSize; } Success;
        struct { NTSTATUS ExitStatus; } Fail;
    } Union;
} PS_CREATE_INFO;

static HANDLE nt_create_process(const std::wstring &exe, const std::wstring &cmdline,
                                const std::wstring &workdir, HANDLE hPrimary) {
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll) return NULL;
    typedef NTSTATUS (NTAPI *pRtlInitUnicodeString)(PUNICODE_STRING, PCWSTR);
    typedef NTSTATUS (NTAPI *pRtlCreateProcessParameters)(PRTL_USER_PROCESS_PARAMETERS*, PUNICODE_STRING, PUNICODE_STRING, PUNICODE_STRING, PUNICODE_STRING, PVOID, PUNICODE_STRING, PUNICODE_STRING, PUNICODE_STRING, PUNICODE_STRING);
    typedef NTSTATUS (NTAPI *pRtlDestroyProcessParameters)(PRTL_USER_PROCESS_PARAMETERS);
    typedef NTSTATUS (NTAPI *pNtCreateUserProcess)(PHANDLE, PHANDLE, ACCESS_MASK, ACCESS_MASK, POBJECT_ATTRIBUTES, POBJECT_ATTRIBUTES, ULONG, ULONG, PRTL_USER_PROCESS_PARAMETERS, PVOID, PVOID);
    pRtlInitUnicodeString fnInit = (pRtlInitUnicodeString)GetProcAddress(ntdll, "RtlInitUnicodeString");
    pRtlCreateProcessParameters fnCreate = (pRtlCreateProcessParameters)GetProcAddress(ntdll, "RtlCreateProcessParameters");
    pRtlDestroyProcessParameters fnDestroy = (pRtlDestroyProcessParameters)GetProcAddress(ntdll, "RtlDestroyProcessParameters");
    pNtCreateUserProcess fnNtCreate = (pNtCreateUserProcess)GetProcAddress(ntdll, "NtCreateUserProcess");
    if (!fnInit || !fnCreate || !fnDestroy || !fnNtCreate) return NULL;

    UNICODE_STRING img, cmd, dir;
    fnInit(&img, exe.c_str());
    fnInit(&cmd, cmdline.c_str());
    fnInit(&dir, workdir.c_str());
    PRTL_USER_PROCESS_PARAMETERS params = NULL;
    NTSTATUS st = fnCreate(&params, &img, NULL, &dir, &cmd, NULL, NULL, NULL, NULL, NULL);
    if (st != 0) { wlog(L"NtCreate: RtlCreateProcessParameters=" + std::to_wstring(st)); return NULL; }

    // AttributeList 传受限令牌
    SIZE_T attrSize = 0;
    InitializeProcThreadAttributeList(NULL, 1, 0, &attrSize);
    BYTE attrBuf[512] = {0};
    PPROC_THREAD_ATTRIBUTE_LIST attrs = (PPROC_THREAD_ATTRIBUTE_LIST)attrBuf;
    if (attrSize > sizeof(attrBuf)) { fnDestroy(params); wlog(L"NtCreate: attrBuf too small"); return NULL; }
    if (!InitializeProcThreadAttributeList(attrs, 1, 0, &attrSize)) { fnDestroy(params); wlog(L"NtCreate: InitAttrList=" + std::to_wstring(GetLastError())); return NULL; }
    BOOL okAttr = UpdateProcThreadAttribute(attrs, 0, PROC_THREAD_ATTRIBUTE_TOKEN, hPrimary, sizeof(HANDLE), NULL, NULL);
    if (!okAttr) wlog(L"NtCreate: UpdateAttr=" + std::to_wstring(GetLastError()));

    HANDLE hProc = NULL, hThr = NULL;
    PS_CREATE_INFO ci;
    memset(&ci, 0, sizeof(ci));
    ci.Size = sizeof(ci);
    ci.State = PsCreateInitialState;
    NTSTATUS rc = okAttr ? fnNtCreate(&hProc, &hThr, PROCESS_ALL_ACCESS, THREAD_ALL_ACCESS,
        NULL, NULL, 0, 0, params, &ci, attrs) : 0xC0000005;
    DeleteProcThreadAttributeList(attrs);
    fnDestroy(params);
    if (rc != 0) { wlog(L"NtCreate: NtCreateUserProcess=" + std::to_wstring(rc)); return NULL; }
    // 线程挂起（NtCreate 默认挂起）→ 返回句柄，由调用方 ResumeThread
    return hProc;
}

// ---------------- 系统目录可执行文件快照（审计样本投放） ----------------
static std::set<std::wstring> snapshot_system_exes() {
    std::set<std::wstring> v;
    const wchar_t *dirs[] = {
        L"C:\\Windows\\System32", L"C:\\Windows\\SysWOW64",
        L"C:\\Program Files", L"C:\\Program Files (x86)",
        L"C:\\Users\\Administrator\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup",
    };
    for (auto d : dirs) {
        std::wstring pat = std::wstring(d) + L"\\*";
        WIN32_FIND_DATAW fd;
        HANDLE hF = FindFirstFileW(pat.c_str(), &fd);
        if (hF != INVALID_HANDLE_VALUE) {
            do {
                if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
                std::wstring name(fd.cFileName);
                std::wstring low = name;
                for (auto &c : low) c = towlower(c);
                if (low.find(L".exe") != std::wstring::npos || low.find(L".dll") != std::wstring::npos ||
                    low.find(L".bat") != std::wstring::npos || low.find(L".ps1") != std::wstring::npos ||
                    low.find(L".vbs") != std::wstring::npos || low.find(L".scr") != std::wstring::npos ||
                    low.find(L".lnk") != std::wstring::npos)
                    v.insert(std::wstring(d) + L"\\" + name);
            } while (FindNextFileW(hF, &fd));
            FindClose(hF);
        }
    }
    return v;
}

// ---------------- 主流程 ----------------
// ---------------- 脚本解释器解析（支持 .py/.vbs/.js/.bat/.ps1/.hta/.reg） ----------------
static bool dg_endswith(const std::wstring &s, const std::wstring &suf) {
    if (s.size() < suf.size()) return false;
    return s.compare(s.size() - suf.size(), suf.size(), suf) == 0;
}
static std::wstring dg_find_exe(const wchar_t *name) {
    wchar_t buf[MAX_PATH];
    if (SearchPathW(NULL, name, NULL, MAX_PATH, buf, NULL)) return std::wstring(buf);
    std::wstring cands[] = {
        std::wstring(L"C:\\Windows\\System32\\") + name,
        std::wstring(L"C:\\Windows\\SysWOW64\\") + name,
        std::wstring(L"E:\\ProgramData\\anaconda3\\") + name,
    };
    for (auto &c : cands) {
        if (GetFileAttributesW(c.c_str()) != INVALID_FILE_ATTRIBUTES) return c;
    }
    return std::wstring(name);
}
// 根据样本扩展名解析出解释器路径 app 与完整命令行 cmdline；exe 保持原样。
static void resolve_sample_command(const std::wstring &sample, std::wstring &app, std::wstring &cmdline) {
    std::wstring lower = sample;
    for (size_t i = 0; i < lower.size(); i++) lower[i] = (wchar_t)towlower(lower[i]);
    std::wstring q = L"\"" + sample + L"\"";
    if (dg_endswith(lower, L".py") || dg_endswith(lower, L".pyw")) {
        std::wstring e = dg_find_exe(L"python.exe");
        app = e; cmdline = L"\"" + e + L"\" " + q; return;
    }
    if (dg_endswith(lower, L".vbs") || dg_endswith(lower, L".vbe") ||
        dg_endswith(lower, L".js") || dg_endswith(lower, L".jse") ||
        dg_endswith(lower, L".wsf")) {
        std::wstring e = dg_find_exe(L"wscript.exe");
        app = e; cmdline = L"\"" + e + L"\" " + q; return;
    }
    if (dg_endswith(lower, L".bat") || dg_endswith(lower, L".cmd")) {
        std::wstring e = dg_find_exe(L"cmd.exe");
        app = e; cmdline = L"\"" + e + L"\" /c " + q; return;
    }
    if (dg_endswith(lower, L".ps1")) {
        std::wstring e = dg_find_exe(L"powershell.exe");
        app = e; cmdline = L"\"" + e + L"\" -NoProfile -ExecutionPolicy Bypass -File " + q; return;
    }
    if (dg_endswith(lower, L".hta")) {
        std::wstring e = dg_find_exe(L"mshta.exe");
        app = e; cmdline = L"\"" + e + L"\" " + q; return;
    }
    if (dg_endswith(lower, L".reg")) {
        std::wstring e = dg_find_exe(L"regedit.exe");
        app = e; cmdline = L"\"" + e + L"\" /s " + q; return;
    }
    app = sample; cmdline = q;
}

int wmain(int argc, wchar_t **argv) {
    if (argc < 4) return 1;
    std::wstring sample = argv[1];
    g_workdir = argv[2];
    int timeout = _wtoi(argv[3]);
    if (timeout < 5) timeout = 5;
    // 模式开关：DG_SB_MODE 1=AsUser受限无IL 2=WithToken受限(默认,样本能跑) 3=AsUser+LowIL(实验) 4=NtCreate(实验)
    // 注意：本机无 SeAssignPrimaryToken/SeTcb 特权，非 logon 令牌 + AsUser/NtCreate 会导致
    // 样本 DLL 初始化失败(0xC0000142)；CreateProcessWithTokenW 会重建令牌(High+管理员)，
    // 因此隔离依赖 Job 限制+工作目录隔离+系统目录审计+行为监控。
    DWORD sbMode = 2;
    const wchar_t *envMode = _wgetenv(L"DG_SB_MODE");
    if (envMode) sbMode = _wtoi(envMode);
    if (sbMode < 1 || sbMode > 4) sbMode = 2;

    CreateDirectoryW((g_workdir + L"\\output").c_str(), NULL);
    // 启用 SeRelabelPrivilege（设置完整性标签需要）
    HANDLE hSelfT = NULL;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hSelfT)) {
        TOKEN_PRIVILEGES tp = {0};
        tp.PrivilegeCount = 1;
        LookupPrivilegeValueW(NULL, SE_RELABEL_NAME, &tp.Privileges[0].Luid);
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        AdjustTokenPrivileges(hSelfT, FALSE, &tp, 0, NULL, NULL);
        CloseHandle(hSelfT);
    }
    std::wstring workdir_out0 = g_workdir + L"\\output";
    grant_low_il_write(workdir_out0);
    std::set<std::wstring> sys_before = snapshot_system_exes();
    wlog(L"DG native sandbox start");
    wlog(sample);

    // 1. 受限令牌
    HANDLE hToken = NULL;
    OpenProcessToken(GetCurrentProcess(), TOKEN_DUPLICATE | TOKEN_QUERY | TOKEN_ASSIGN_PRIMARY | TOKEN_ADJUST_DEFAULT, &hToken);
    HANDLE hRestricted = NULL;
    std::wstring token_note;
    if (hToken) {
        // 删除管理员组 S-1-5-32-544
        SID_IDENTIFIER_AUTHORITY ntAuth = SECURITY_NT_AUTHORITY;
        PSID adminSid = NULL;
        AllocateAndInitializeSid(&ntAuth, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0,0,0,0,0,0, &adminSid);
        SID_AND_ATTRIBUTES del = { adminSid, 0 };
        if (CreateRestrictedToken(hToken, DISABLE_MAX_PRIVILEGE, 1, &del, 0, NULL, 0, NULL, &hRestricted)) {
            // 补全令牌权限（CreateRestrictedToken 输出令牌可能缺 ADJUST_DEFAULT）
            HANDLE hFull = NULL;
            if (DuplicateTokenEx(hRestricted,
                TOKEN_ASSIGN_PRIMARY | TOKEN_QUERY | TOKEN_DUPLICATE | TOKEN_ADJUST_DEFAULT,
                NULL, SecurityImpersonation, TokenPrimary, &hFull)) {
                CloseHandle(hRestricted);
                hRestricted = hFull;
            }
            // 完整性级别 -> Low（模式3/4；必须用 S-1-16 权威，不能用 S-1-5）
            if (sbMode == 3 || sbMode == 4) {
                PSID lowSid = NULL;
                SID_IDENTIFIER_AUTHORITY labelAuth = SECURITY_MANDATORY_LABEL_AUTHORITY;
                AllocateAndInitializeSid(&labelAuth, 1, SECURITY_MANDATORY_LOW_RID, 0,0,0,0,0,0,0, &lowSid);
                if (lowSid) {
                    TOKEN_MANDATORY_LABEL til;
                    til.Label.Attributes = SE_GROUP_INTEGRITY;
                    til.Label.Sid = lowSid;
                    DWORD tilSize = sizeof(til) + GetLengthSid(lowSid);
                    if (SetTokenInformation(hRestricted, TokenIntegrityLevel, &til, tilSize)) {
                        token_note = L"restricted+lowIL";
                    } else {
                        wchar_t eb[64]; swprintf(eb, L"SetIL failed=%u", GetLastError());
                        token_note = std::wstring(L"restricted(") + eb + L")";
                    }
                    FreeSid(lowSid);
                }
            } else {
                token_note = L"restricted";
            }
        } else {
            hRestricted = NULL;
        }
        if (adminSid) FreeSid(adminSid);
    }
    if (hRestricted) {
        // 验证受限令牌是否真的删掉了 Administrators 组
        BYTE rBuf[4096] = {0};
        DWORD rLen = 0;
        if (GetTokenInformation(hRestricted, TokenGroups, rBuf, sizeof(rBuf), &rLen)) {
            TOKEN_GROUPS *tg = (TOKEN_GROUPS*)rBuf;
            SID_IDENTIFIER_AUTHORITY ntAuth2 = SECURITY_NT_AUTHORITY;
            PSID adminSid2 = NULL;
            AllocateAndInitializeSid(&ntAuth2, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0,0,0,0,0,0, &adminSid2);
            bool hasAdmin2 = false;
            for (DWORD i = 0; i < tg->GroupCount; i++) {
                if (EqualSid(tg->Groups[i].Sid, adminSid2)) { hasAdmin2 = true; break; }
            }
            if (adminSid2) FreeSid(adminSid2);
            wlog(std::wstring(L"restricted token has Administrators: ") + (hasAdmin2 ? L"YES" : L"NO"));
        }
    }
    if (!hRestricted) {
        // 兜底：无受限令牌也要跑（用普通令牌 + Job 限制）
        wlog(L"WARN: CreateRestrictedToken failed, fallback to normal token");
        token_note = L"fallback";
    }
    wlog(L"token: " + token_note);

    // 2. Job Object
    HANDLE hJob = CreateJobObjectW(NULL, L"DG_Native_Sandbox");
    if (!hJob) { wlog(L"CreateJobObject failed"); return 2; }
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION jeli = {0};
    jeli.BasicLimitInformation.LimitFlags =
        JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE |
        JOB_OBJECT_LIMIT_ACTIVE_PROCESS |
        JOB_OBJECT_LIMIT_PROCESS_TIME |
        JOB_OBJECT_LIMIT_PROCESS_MEMORY;
    jeli.BasicLimitInformation.ActiveProcessLimit = 20;
    jeli.BasicLimitInformation.PerProcessUserTimeLimit.QuadPart = (LONGLONG)timeout * 2 * 10000000LL; // 100ns
    jeli.ProcessMemoryLimit = 1024 * 1024 * 1024ULL; // 1GB 进程内存上限
    SetInformationJobObject(hJob, JobObjectExtendedLimitInformation, &jeli, sizeof(jeli));
    // Job UI 限制：禁剪贴板读写、全局原子、句柄滥用
    JOBOBJECT_BASIC_UI_RESTRICTIONS ui = {0};
    ui.UIRestrictionsClass = JOB_OBJECT_UILIMIT_HANDLES | JOB_OBJECT_UILIMIT_READCLIPBOARD |
        JOB_OBJECT_UILIMIT_WRITECLIPBOARD | JOB_OBJECT_UILIMIT_GLOBALATOMS;
    SetInformationJobObject(hJob, JobObjectBasicUIRestrictions, &ui, sizeof(ui));
    wlog(L"job created");

    // 3. 启动样本（受限令牌 + CREATE_SUSPENDED）
    STARTUPINFOW si = {0}; si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_SHOW;  // 样本窗口可见，便于在桌面观察沙箱画面
    PROCESS_INFORMATION pi = {0};
    std::wstring app = sample;
    std::wstring cmdline = L"\"" + sample + L"\"";
    resolve_sample_command(sample, app, cmdline);
    wchar_t *cmdBuf = &cmdline[0];
    std::wstring workdir_out = g_workdir + L"\\output";
    BOOL created = FALSE;
    HANDLE hPrimary = NULL;
    if (hRestricted) {
        DuplicateTokenEx(hRestricted, TOKEN_ASSIGN_PRIMARY | TOKEN_QUERY | TOKEN_DUPLICATE | TOKEN_ADJUST_DEFAULT,
            NULL, SecurityImpersonation, TokenPrimary, &hPrimary);
    }
    if (sbMode == 1 || sbMode == 3) {
        // CreateProcessWithTokenW 会重新派生令牌导致 Low IL 丢失，改用 CreateProcessAsUserW
        // （直接使用受限令牌，保留完整性级别）。需要 SeAssignPrimaryTokenPrivilege + SeIncreaseQuotaPrivilege
        HANDLE hSelfTok = NULL;
        if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hSelfTok)) {
            TOKEN_PRIVILEGES tp = {0};
            tp.PrivilegeCount = 2;
            LookupPrivilegeValueW(NULL, SE_ASSIGNPRIMARYTOKEN_NAME, &tp.Privileges[0].Luid);
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
            LookupPrivilegeValueW(NULL, SE_INCREASE_QUOTA_NAME, &tp.Privileges[1].Luid);
            tp.Privileges[1].Attributes = SE_PRIVILEGE_ENABLED;
            AdjustTokenPrivileges(hSelfTok, FALSE, &tp, 0, NULL, NULL);
            CloseHandle(hSelfTok);
        }
        created = CreateProcessAsUserW(hPrimary, app.c_str(), cmdBuf, NULL, NULL, FALSE,
            CREATE_SUSPENDED | CREATE_NEW_PROCESS_GROUP | CREATE_UNICODE_ENVIRONMENT,
            NULL, workdir_out.c_str(), &si, &pi);
        if (!created) {
            wchar_t eb[64]; swprintf(eb, L"AsUser failed=%u, ", GetLastError());
            token_note += eb;
        }
    }
    if (sbMode == 4) {
        // 内核路径：NtCreateUserProcess + 受限令牌（保留 Low IL）
        if (hRestricted) {
            HANDLE hNt = nt_create_process(app, cmdline, workdir_out, hPrimary);
            if (hNt) {
                created = TRUE;
                pi.hProcess = hNt;
                pi.dwProcessId = GetProcessId(hNt);
                // 线程句柄不可得（NtCreate 返回了线程但我们没保存），通过主线程恢复
                // 用 NtResumeProcess 等价：ResumeThread 需要线程句柄 → 用 OpenThread
                HANDLE hThr = OpenThread(THREAD_SUSPEND_RESUME, FALSE, pi.dwProcessId);
                if (hThr) { ResumeThread(hThr); CloseHandle(hThr); }
                else { NtResumeProcess(hNt); }
            } else {
                wlog(L"NtCreateUserProcess failed");
            }
        }
    }
    if (!created && hPrimary) {
        // CreateProcessWithTokenW（样本能跑；注意：非 logon 令牌会被内部重建，隔离靠 Job+监控）
        created = CreateProcessWithTokenW(hPrimary,
            0,
            app.c_str(), cmdBuf,
            CREATE_SUSPENDED | CREATE_NEW_PROCESS_GROUP | CREATE_UNICODE_ENVIRONMENT,
            NULL, workdir_out.c_str(), &si, &pi);
    }
    if (!created) {
        // 兜底：普通创建
        created = CreateProcessW(app.c_str(), &cmdline[0], NULL, NULL, FALSE,
            CREATE_SUSPENDED | CREATE_NEW_PROCESS_GROUP | CREATE_UNICODE_ENVIRONMENT,
            NULL, workdir_out.c_str(), &si, &pi);
    }
    if (!created) {
        wlog(L"CreateProcess failed: " + std::to_wstring(GetLastError()));
        CloseHandle(hJob);
        return 3;
    }
    // 挂进 Job
    if (!AssignProcessToJobObject(hJob, pi.hProcess)) {
        wlog(L"AssignProcessToJobObject failed: " + std::to_wstring(GetLastError()));
    }
    if (pi.hThread) ResumeThread(pi.hThread);
    wlog(L"sample started PID=" + std::to_wstring(pi.dwProcessId));
    // 验证样本进程实际完整性级别 + 管理员组是否仍在
    HANDLE hProcTok = NULL;
    if (OpenProcessToken(pi.hProcess, TOKEN_QUERY, &hProcTok)) {
        BYTE ilBuf[64] = {0};
        DWORD ilLen = 0;
        if (GetTokenInformation(hProcTok, TokenIntegrityLevel, ilBuf, sizeof(ilBuf), &ilLen)) {
            TOKEN_MANDATORY_LABEL *til = (TOKEN_MANDATORY_LABEL*)ilBuf;
            DWORD rid = 0;
            SID_NAME_USE use;
            wchar_t name[64] = {0}, dom[64] = {0};
            DWORD nlen = 64, dlen = 64;
            if (LookupAccountSidW(NULL, til->Label.Sid, name, &nlen, dom, &dlen, &use)) {
                wlog(std::wstring(L"sample integrity: ") + name);
            } else {
                PSID p = til->Label.Sid;
                DWORD count = *(GetSidSubAuthorityCount(p));
                PDWORD sub = GetSidSubAuthority(p, count - 1);
                wlog(L"sample IL RID: " + std::to_wstring(sub ? *sub : 0));
            }
        }
        // 检查组是否含 Administrators (S-1-5-32-544)
        BYTE gBuf[4096] = {0};
        DWORD gLen = 0;
        if (GetTokenInformation(hProcTok, TokenGroups, gBuf, sizeof(gBuf), &gLen)) {
            TOKEN_GROUPS *tg = (TOKEN_GROUPS*)gBuf;
            SID_IDENTIFIER_AUTHORITY ntAuth = SECURITY_NT_AUTHORITY;
            PSID adminSid = NULL;
            AllocateAndInitializeSid(&ntAuth, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0,0,0,0,0,0, &adminSid);
            bool hasAdmin = false;
            for (DWORD i = 0; i < tg->GroupCount; i++) {
                if (EqualSid(tg->Groups[i].Sid, adminSid)) { hasAdmin = true; break; }
            }
            if (adminSid) FreeSid(adminSid);
            wlog(std::wstring(L"sample in Administrators: ") + (hasAdmin ? L"YES" : L"NO"));
        }
        CloseHandle(hProcTok);
    }
    g_beh.job_pids.insert(pi.dwProcessId);

    // 4. 启动文件监控线程（只监控隔离 output 目录，避免共享 Temp 噪音）
    //    基线快照必须在启动样本前拍好，否则样本写入会被当成"已存在"
    std::atomic<bool> stop_watch{false};
    std::set<std::wstring> before_out = snapshot_dir(workdir_out);
    std::thread t1(watch_dir_thread, workdir_out, true, std::ref(stop_watch), before_out);

    // 5. 观察循环：进程 + 网络 + 注册表
    auto start = std::chrono::steady_clock::now();
    int elapsed = 0;
    while (g_running.load()) {
        Sleep(1000);
        elapsed++;
        // 进程变化（每次枚举）
        std::set<DWORD> cur = enum_job_pids(hJob);
        for (DWORD pid : cur) {
            if (g_beh.job_pids.find(pid) == g_beh.job_pids.end()) {
                wchar_t line[80];
                swprintf(line, L"PID=%u", pid);
                g_beh.procs_created.insert(line);
                g_beh.job_pids.insert(pid);
            }
        }
        // 每 1 秒采样网络 / 每 2 秒注册表
        if (elapsed % 1 == 0) net_snapshot(hJob);
        if (elapsed % 2 == 0) reg_check();
        if (elapsed >= timeout) break;
        // 样本主进程退出后多等 3 秒（让子进程行为落盘）
        if (WaitForSingleObject(pi.hProcess, 0) == WAIT_OBJECT_0 && elapsed >= 3) {
            Sleep(3000);
            break;
        }
    }
    (void)start;

    // 6. 超时/结束 -> 强杀 Job
    DWORD sampleExit = 0;
    GetExitCodeProcess(pi.hProcess, &sampleExit);
    TerminateJobObject(hJob, 1);
    WaitForSingleObject(pi.hProcess, 5000);
    if (pi.hThread) CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    CloseHandle(hJob);
    g_running.store(false);
    stop_watch.store(true);
    if (t1.joinable()) t1.join();
    if (hPrimary) CloseHandle(hPrimary);
    if (hRestricted) CloseHandle(hRestricted);
    if (hToken) CloseHandle(hToken);

    // 6.5 兜底：退出后快照对比（ReadDirectoryChangesW 可能漏事件）
    std::set<std::wstring> after_out = snapshot_dir(workdir_out);
    for (auto &p : after_out) {
        if (before_out.find(p) == before_out.end()) g_beh.files_created.insert(p);
    }
    // 6.6 系统目录审计：样本是否在系统目录投放了新文件
    std::set<std::wstring> sys_after = snapshot_system_exes();
    for (auto &p : sys_after) {
        if (sys_before.find(p) == sys_before.end())
            g_beh.files_created.insert(p);
    }
    wlog(L"sample exit code: " + std::to_wstring(sampleExit));

    // 7. 写行为日志
    std::wstring logpath = g_workdir + L"\\output\\behavior_log.json";
    FILE *f = _wfopen(logpath.c_str(), L"wb");
    if (f) {
        auto dump = [&](const std::set<std::wstring> &s) {
            std::wstring out;
            for (auto &x : s) {
                std::string v = w2u(x);
                if (!out.empty()) out += L",";
                out += L"\"" + u2w(json_escape(v)) + L"\"";
            }
            return out;
        };
        std::wstring json;
        json += L"{\n";
        json += L"  \"sandbox\": \"native\",\n";
        json += L"  \"token\": \"" + u2w(json_escape(w2u(token_note))) + L"\",\n";
        json += L"  \"files_created\": [" + dump(g_beh.files_created) + L"],\n";
        json += L"  \"files_modified\": [" + dump(g_beh.files_modified) + L"],\n";
        json += L"  \"registry_writes\": [" + dump(g_beh.reg_writes) + L"],\n";
        json += L"  \"network_connections\": [" + dump(g_beh.net_conns) + L"],\n";
        json += L"  \"processes_created\": [" + dump(g_beh.procs_created) + L"]\n";
        json += L"}\n";
        std::string json8 = w2u(json);
        fwrite(json8.data(), 1, json8.size(), f);
        fclose(f);
    }
    wlog(L"done, behavior written");
    return 0;
}
