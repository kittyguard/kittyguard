# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, r"F:\桌面保护\desktopguard")
import database

conn = database.get_db()
rows = conn.execute(
    "SELECT id, original_path, status, quarantined_name FROM quarantine "
    "WHERE original_path LIKE '%DG安全%' ORDER BY id"
).fetchall()
print(f"DG安全相关隔离记录: {len(rows)}")
for r in rows:
    print(f"id={r['id']} | {r['status']} | {r['original_path']} | {r['quarantined_name']}")
conn.close()
