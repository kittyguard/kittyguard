# -*- coding: utf-8 -*-
"""
DG安全 6.0.0 · 勒索软件文档守护 ransomware_guard.py
纯用户态最后一道防线：监控用户文档目录，识别"批量加密/批量改写"风暴，
自动备份受影响文件 + 冻结肇事进程 + 弹窗让用户决策（恢复/终止/信任）。

设计原则（6.0.0 alpha 保守版）：
- 多记录、少 kill：中危只提醒，高危才 Suspend，终止必须用户确认
- 不误冻结正常软件：压缩/备份/云同步/IDE 等常见批量写进程只记录不自动冻结
- 零驱动、不服务化、CPU≈0（3 秒轻量采样，只 stat + 前 1KB 熵抽样）
"""
import os
import sys
import time
import math
import shutil
import ctypes
import threading
import collections

try:
    import psutil
except Exception:
    psutil = None

# ---------- 监控目录（Windows 已知文件夹，按系统语言自动解析） ----------
_KNOWN = {
    "桌面":  "B4BFCC3A-DB2C-424C-B029-7FE99A87C641",
    "文档":  "FDD39AD0-238F-46AF-ADB4-6C85480369C7",
    "图片":  "33E28130-4E1E-4676-835A-98395C3BC3BB",
    "下载":  "374DE290-4F4F-4D38-9E76-491B6E3EECAA",
}

def _known_folder(guid):
    """SHGetKnownFolderPath 解析系统已知文件夹路径。失败返回 None。"""
    try:
        from ctypes import wintypes
        buf = ctypes.c_wchar_p()
        hr = ctypes.windll.shell32.SHGetKnownFolderPath(
            ctypes.c_wchar_p("{%s}" % guid), 0, None, ctypes.byref(buf))
        if hr == 0 and buf.value:
            return buf.value
    except Exception:
        pass
    return None

def default_monitor_dirs():
    """默认监控目录（存在才加入）。"""
    dirs = []
    for name, guid in _KNOWN.items():
        p = _known_folder(guid)
        if p and os.path.isdir(p):
            dirs.append(p)
    # 兜底：已知文件夹 API 失败时用环境变量
    fallback = {
        "Desktop": "USERPROFILE/Desktop", "Documents": "USERPROFILE/Documents",
        "Pictures": "USERPROFILE/Pictures", "Downloads": "USERPROFILE/Downloads",
    }
    for env_key, rel in fallback.items():
        base = os.environ.get(env_key) or os.environ.get("USERPROFILE")
        if not base:
            continue
        p = os.path.join(base, rel.replace("USERPROFILE/", ""))
        if os.path.isdir(p) and p not in dirs:
            dirs.append(p)
    return dirs

# ---------- 文档类扩展名（监控重点） ----------
_DOC_EXTS = {
    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".rtf",
    ".odt", ".ods", ".csv", ".md", ".png", ".jpg", ".jpeg", ".bmp", ".gif",
    ".tiff", ".psd", ".ai", ".zip", ".rar", ".7z", ".tar", ".gz", ".db",
    ".sqlite", ".mdb", ".eml", ".pst", ".one", ".vsd", ".vsdx",
}
# 勒索加密常见新扩展名（命中即强信号）
_RANSOM_EXTS = {
    ".enc", ".lock", ".locked", ".crypt", ".crypted", ".cryp1", ".devil",
    ".wannacry", ".wcry", ".wnry", ".id_", ".ecc", ".ezz", ".exx", ".zzz",
    ".aaa", ".abc", ".xyz", ".pay", ".cryptolocker", ".zepto", ".cerber",
    ".odin", ".onion", ".torrent", ".mr", ".scorpio", ".heal", ".vesad",
}
# 勒索说明文件关键词（README/RECOVER/DECRYPT 等）
_RANSOM_NOTE_KW = ("README", "RECOVER", "DECRYPT", "HOW_TO", "RESTORE",
                   "WANNACRY", "LOCKY", "INSTRUCTIONS", "CONTACT", "PAYMENT")
# 常见"批量写文档"的正常软件：只记录不自动冻结（压缩/备份/云同步/IDE/同步盘）
_EXCLUDE_PROCS = (
    "7z", "7za", "winrar", "rar", "bandizip", "360zip", "2345zip", "haozip",
    "kuaizip", "izip", "peazip", "tar", "zip",
    "onedrive", "dropbox", "syncthing", "nutstore", "baidunetdisk",
    "obsidian", "typora", "code", "pycharm", "idea", "goland", "clion",
    "wps", "winword", "excel", "powerpnt", "et", "wpp", "dllhost",
    "autosave", "sqlite3", "node", "git", "svn", "hg",
)

# ---------- 工具 ----------
def _entropy_head(path, n=1024):
    """文件头部熵估算（抽样前 n 字节），失败返回 None。"""
    try:
        with open(path, "rb") as f:
            data = f.read(n)
        if not data:
            return 0.0
        cnt = collections.Counter(data)
        ent = 0.0
        ln = len(data)
        for c in cnt.values():
            p = c / ln
            if p > 0:
                ent -= p * math.log2(p)
        return ent
    except Exception:
        return None

class RansomwareGuard:
    """勒索文档守护：3 秒轻量采样 + 滑动窗口风暴评分 + 备份/冻结/弹窗回调。"""

    # 阈值（保守，可后续用误报闭环调优）
    WINDOW = 90          # 滑动窗口（秒）
    SAMPLE = 3.0         # 采样周期（秒）
    MOD_MID = 50         # 30 秒内修改/新增文档数 → 中危
    MOD_HIGH = 100       # 60 秒内修改/新增文档数 → 高危
    SCORE_MID = 40       # 评分中危线
    SCORE_HIGH = 60      # 评分高危线（触发备份+冻结）

    def __init__(self, data_dir=None, on_alert=None, dnd_provider=None,
                 dry_run=False, excludes=None):
        # data_dir: dgdata（保护区放 dgdata/ransom_backup）
        self.data_dir = data_dir or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "..", "dgdata")
        self.on_alert = on_alert          # on_alert(level, info)
        self.dnd_provider = dnd_provider  # 返回 True 表示免打扰（静默）
        self.dry_run = dry_run            # 6.0.2 试运行模式：只记录+备份，不冻结进程（防误伤）
        self._dirs = default_monitor_dirs()
        self._exclude_dirs = []
        # 6.0.2：启动即应用配置里的排除目录（编译输出/游戏/虚拟机镜像等，防误冻结）
        for _d in (excludes or []):
            try:
                _d = os.path.abspath(_d)
                if os.path.isdir(_d) and _d not in self._exclude_dirs:
                    self._exclude_dirs.append(_d)
            except Exception:
                pass
        self._thread = None
        self._stop_evt = threading.Event()
        self._lock = threading.Lock()
        # 每个目录的最近快照 {path: (size, mtime)}
        self._snap = {}
        # 滑动窗口事件（按目录分组的时间戳列表）
        self._events = collections.deque(maxlen=5000)
        self._frozen = {}          # pid -> {"name","path","ts"}
        self._trusted = set()      # 临时信任进程 pid/name
        self._backed = {}          # 已备份源路径 -> 备份路径（去重）
        self._backup_size = 0
        self._stats = {"started": 0, "checks": 0, "alerts": 0,
                       "froze": 0, "backups": 0, "events": 0}
        self._last_state = "idle"

    # ---------- 生命周期 ----------
    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_evt.clear()
        self._snap = {d: self._scan_dir(d) for d in self._dirs if os.path.isdir(d)}
        self._stats["started"] = int(time.time())
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="ransom_guard")
        self._thread.start()

    def stop(self):
        self._stop_evt.set()
        if self._thread:
            self._thread.join(timeout=5)
        self._thread = None

    def set_dirs(self, dirs):
        """自定义监控目录（覆盖默认）。"""
        with self._lock:
            self._dirs = [d for d in dirs if os.path.isdir(d)]
            self._snap = {d: self._scan_dir(d) for d in self._dirs}

    def add_exclude_dir(self, path):
        with self._lock:
            p = path.rstrip("\\/").lower()
            if p not in self._exclude_dirs:
                self._exclude_dirs.append(p)

    def trust_pid(self, pid):
        """用户确认可信：临时信任该进程（后续不再冻结/告警）。"""
        try:
            p = psutil.Process(pid) if psutil else None
            self._trusted.add(pid)
            if p:
                self._trusted.add(p.name().lower())
            self._resume(pid)
            return True
        except Exception:
            return False

    def resume_process(self, pid):
        return self._resume(pid)

    def kill_process(self, pid):
        """用户确认后终止肇事进程（含子进程）。"""
        try:
            if psutil:
                p = psutil.Process(pid)
                for ch in p.children(recursive=True):
                    try:
                        ch.kill()
                    except Exception:
                        pass
                p.kill()
            else:
                os.popen("taskkill /F /T /PID %d" % pid)
            self._frozen.pop(pid, None)
            return True
        except Exception:
            return False

    def get_status(self):
        st = dict(self._stats)
        st["monitor_dirs"] = list(self._dirs)
        st["frozen"] = [{"pid": k, **v} for k, v in self._frozen.items()]
        st["last_state"] = self._last_state
        return st

    # ---------- 内部 ----------
    def _scan_dir(self, d):
        """轻量采样目录：{name: (size, mtime)}，只 stat 不读内容。"""
        out = {}
        try:
            with os.scandir(d) as it:
                for e in it:
                    try:
                        if e.is_file(follow_symlinks=False):
                            st = e.stat(follow_symlinks=False)
                            out[e.name] = (st.st_size, int(st.st_mtime))
                    except Exception:
                        pass
        except Exception:
            pass
        return out

    def _in_exclude(self, path):
        lp = path.rstrip("\\/").lower()
        for ex in self._exclude_dirs:
            if lp == ex or lp.startswith(ex + "\\"):
                return True
        return False

    def _loop(self):
        _lower = getattr(threading, "current_thread", lambda: None)
        while not self._stop_evt.is_set():
            try:
                self._tick()
                self._stats["checks"] += 1
            except Exception:
                pass
            self._stop_evt.wait(self.SAMPLE)

    def _tick(self):
        now = time.time()
        changed = []      # (dir, name, path, size, mtime, is_new, is_del)
        for d in self._dirs:
            if not os.path.isdir(d) or self._in_exclude(d):
                continue
            cur = self._scan_dir(d)
            old = self._snap.get(d, {})
            for name, v in cur.items():
                if name not in old:
                    changed.append((d, name, os.path.join(d, name), v[0], v[1], True, False))
                elif old[name] != v:
                    changed.append((d, name, os.path.join(d, name), v[0], v[1], False, False))
            for name in old:
                if name not in cur:
                    changed.append((d, name, os.path.join(d, name), 0, now, False, True))
            self._snap[d] = cur

        if not changed:
            self._last_state = "idle"
            return

        # 过滤出文档类文件（改动统计只看文档）
        docs = []
        for (d, name, path, size, mtime, is_new, is_del) in changed:
            ext = os.path.splitext(name)[1].lower()
            low = name.lower()
            if is_del:
                if ext in _DOC_EXTS or ext in _RANSOM_EXTS:
                    docs.append((d, name, path, size, mtime, is_new, is_del, ext))
            elif ext in _DOC_EXTS or ext in _RANSOM_EXTS:
                docs.append((d, name, path, size, mtime, is_new, is_del, ext))
            elif any(kw in low for kw in _RANSOM_NOTE_KW) and ext in (".txt", ".html", ".htm", ".ini", ""):
                docs.append((d, name, path, size, mtime, is_new, is_del, ext))

        if not docs:
            self._last_state = "idle"
            return

        for ev in docs:
            self._events.append((now,) + ev)

        # 滑动窗口统计（事件结构：now, dir, name, path, size, mtime, is_new, is_del, ext）
        cutoff30 = now - 30
        cutoff60 = now - 60
        mod30 = [e for e in self._events if e[0] >= cutoff30 and not e[7]]
        mod60 = [e for e in self._events if e[0] >= cutoff60 and not e[7]]
        rans_ext = [e for e in self._events if e[0] >= cutoff60 and e[8] in _RANSOM_EXTS]
        notes = [e for e in self._events if e[0] >= cutoff60
                 and any(kw in e[3].lower() for kw in _RANSOM_NOTE_KW)]
        dels = [e for e in self._events if e[0] >= cutoff60 and e[7]]

        # 行为评分（保守权重）
        score = 0
        score += min(50, len(mod60) // 5)                  # 批量改写密度
        score += min(40, len(rans_ext) * 6)                # 异常扩展名风暴
        score += 25 if notes else 0                        # 勒索说明文件
        score += min(25, len(dels) // 4)                   # 原文件删除（替换加密）
        if len(mod30) >= self.MOD_MID:
            score += 10

        # 熵升高抽样（只抽高危候选，最多 6 个新文件，控制开销）
        if score >= 30:
            hi_ent = 0
            sampled = 0
            for e in reversed(self._events):
                if e[6] and e[8] in _DOC_EXTS and os.path.exists(e[3]):
                    ent = _entropy_head(e[3])
                    if ent is not None and ent > 7.3:
                        hi_ent += 1
                    sampled += 1
                    if sampled >= 6:
                        break
            if hi_ent >= 2:
                score += 15

        self._stats["events"] += len(docs)
        if score < self.SCORE_MID:
            self._last_state = "observe"
            return

        level = "high" if score >= self.SCORE_HIGH else "mid"
        info = {
            "score": score, "level": level,
            "modified_30s": len(mod30), "modified_60s": len(mod60),
            "ransom_exts": len(rans_ext), "notes": len(notes), "deleted": len(dels),
            "dirs_hit": sorted({e[1] for e in self._events if e[0] >= cutoff60}),
            "samples": [e[3] for e in self._events if e[0] >= cutoff30 and not e[7]][:12],
            "process": self._find_writer(),
        }

        dnd = bool(self.dnd_provider and self.dnd_provider())
        if level == "mid":
            self._last_state = "mid_alert"
            if not dnd:
                self._notify("mid", info)
            return

        # 高危：备份 + 冻结（保守：排除已知正常软件 + 临时信任进程）
        self._last_state = "high_action"
        self._stats["alerts"] += 1
        self._backup_changed(docs, info)
        if self.dry_run:
            # 6.0.2 试运行模式：只备份 + 记录，不冻结进程（先观察误伤，再决定是否真冻结）
            info["dryrun"] = True
            self._notify("high", info)
            return
        pid = self._freeze_writer(info.get("process"))
        if pid:
            info["frozen_pid"] = pid
        self._notify("high", info)

    _SKIP_PROCS = frozenset([
        "svchost.exe", "lsass.exe", "winlogon.exe", "csrss.exe", "services.exe",
        "dwm.exe", "conhost.exe", "smss.exe", "fontdrvhost.exe", "audiodg.exe",
        "taskhostw.exe", "explorer.exe", "SearchIndexer.exe", "Memory Compression",
        "Registry", "System", "Secure System", "RuntimeBroker.exe", "sihost.exe",
        "StartMenuExperienceHost.exe", "ShellExperienceHost.exe", "ctfmon.exe",
        "dllhost.exe", "WmiPrvSE.exe", "spoolsv.exe", "LogonUI.exe",
    ])

    def _find_writer(self):
        """找持有监控目录文档文件句柄的进程（按文件数排序）。
        两阶段快速版：先按 create_time 筛「近期启动」候选（勒索进程几乎都是新进程），
        排除系统/白名单进程，再只对候选查 open_files，2 秒硬超时。"""
        if not psutil:
            return None
        result = [None]

        def _inner():
            try:
                now = time.time()
                recent = []  # (pid, name, exe, create_time)
                for proc in psutil.process_iter(["pid", "name", "exe", "create_time"]):
                    try:
                        nm = (proc.info.get("name") or "").lower()
                        if nm in _EXCLUDE_PROCS or nm in self._SKIP_PROCS:
                            continue
                        ct = proc.info.get("create_time") or 0
                        if ct and now - ct > 600:
                            continue  # 只看 10 分钟内启动的进程
                        recent.append((proc.info["pid"], nm,
                                       proc.info.get("exe") or "", ct))
                    except Exception:
                        continue
                if not recent:
                    return
                recent.sort(key=lambda x: x[3], reverse=True)
                recent = recent[:24]  # 候选上限，控制遍历开销
                counts, names, paths = {}, {}, {}
                for pid, nm, exe, _ct in recent:
                    try:
                        p = psutil.Process(pid)
                        of = p.open_files() or []
                        hit = 0
                        for f in of:
                            fp = (f.path or "").lower()
                            if any(fp.startswith(d.rstrip("\\/").lower() + "\\")
                                   for d in self._dirs):
                                ext = os.path.splitext(fp)[1]
                                if ext in _DOC_EXTS or ext in _RANSOM_EXTS:
                                    hit += 1
                        if hit:
                            counts[pid] = counts.get(pid, 0) + hit
                            names[pid] = nm
                            paths[pid] = exe
                    except Exception:
                        continue
                if counts:
                    top = max(counts, key=counts.get)
                    result[0] = {"pid": top, "name": names[top], "path": paths.get(top),
                                 "files": counts[top]}
            except Exception:
                pass

        t = threading.Thread(target=_inner, daemon=True)
        t.start()
        t.join(timeout=2.0)
        return result[0]

    def _freeze_writer(self, proc):
        """Suspend 肇事进程（保守：跳过排除名单与临时信任）。"""
        if not proc or not psutil:
            return None
        pid = proc.get("pid")
        name = (proc.get("name") or "").lower()
        if pid in self._trusted or name in self._trusted:
            return None
        if name in _EXCLUDE_PROCS or (proc.get("path") or "").lower().endswith(".exe") and os.path.basename(proc.get("path") or "").lower() in _EXCLUDE_PROCS:
            return None
        try:
            p = psutil.Process(pid)
            p.suspend()
            self._frozen[pid] = {"name": proc.get("name"), "path": proc.get("path"),
                                 "ts": int(time.time())}
            self._stats["froze"] += 1
            return pid
        except Exception:
            return None

    def _resume(self, pid):
        try:
            if psutil:
                psutil.Process(pid).resume()
            self._frozen.pop(pid, None)
            return True
        except Exception:
            return False

    def _backup_changed(self, docs, info):
        """把窗口内改动的文档复制到保护区（去重 + 限流 + 总量上限 + 6.0.3 超限自动清理最旧备份）。"""
        vault = os.path.join(self.data_dir, "ransom_backup")
        day = time.strftime("%Y-%m-%d")
        # 6.0.3：容量超 2GB 时自动清理最旧备份到 1.5GB 留出余量，保护区永远不会被撑爆
        self._trim_oldest_backup(vault, 2 * 1024 * 1024 * 1024, int(1.5 * 1024 * 1024 * 1024))

    def _trim_oldest_backup(self, vault, hard_limit, soft_target):
        """按最旧优先删除备份文件，直到占用 <= soft_target；返回本次删除的字节数。"""
        if self._backup_size <= hard_limit:
            return 0
        freed = 0
        try:
            if not os.path.isdir(vault):
                return 0
            # 按 日期目录(正序=最旧在前) → 文件名(时间戳前缀) 收集全部备份文件
            oldest = []
            for day in sorted(os.listdir(vault)):
                d = os.path.join(vault, day)
                if not os.path.isdir(d):
                    continue
                for fn in sorted(os.listdir(d)):
                    fp = os.path.join(d, fn)
                    if os.path.isfile(fp):
                        oldest.append(fp)
            for fp in oldest:
                if self._backup_size - freed <= soft_target:
                    break
                try:
                    sz = os.path.getsize(fp)
                    os.remove(fp)
                    self._backed = {k: v for k, v in self._backed.items() if v != fp}
                    freed += sz
                except Exception:
                    continue
            self._backup_size = max(0, self._backup_size - freed)
            if freed:
                self._stats["trimmed"] = self._stats.get("trimmed", 0) + freed
        except Exception:
            pass
        return freed
        dest_dir = os.path.join(vault, day)
        try:
            os.makedirs(dest_dir, exist_ok=True)
        except Exception:
            return
        # 保护区加隐藏属性（实用级抗破坏）
        try:
            ctypes.windll.kernel32.SetFileAttributesW(vault, 0x2)
        except Exception:
            pass
        n = 0
        for (d, name, path, size, mtime, is_new, is_del, ext) in docs:
            if is_del or not os.path.exists(path):
                continue
            key = path + "|%s|%s" % (size, mtime)
            if key in self._backed:
                continue
            if n >= 50:
                break
            if self._backup_size > 2 * 1024 * 1024 * 1024:  # 总量上限 2GB
                break
            try:
                safe = "%d_%s" % (int(time.time() * 1000) % 100000000, name)
                dst = os.path.join(dest_dir, safe)
                shutil.copy2(path, dst)
                self._backed[key] = dst
                self._backup_size += size
                n += 1
            except Exception:
                continue
        if n:
            self._stats["backups"] += n
            info["backed_up"] = n

    # ---------- 手动立即备份全部（6.2.0：怀疑勒索时先保存当前好版本） ----------
    def backup_all_now(self):
        """手动把监控目录中的文档/办公文件全部备份到保护区（跳过排除目录与超大文件）。
        分块走 _backup_changed（去重 + 隐藏属性 + 2GB 容量自清理），返回本次实际备份数。"""
        try:
            _exts = (".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                     ".pdf", ".txt", ".md", ".rtf", ".csv", ".png", ".jpg",
                     ".jpeg", ".bmp", ".gif", ".zip", ".rar", ".7z")
            _docs = []
            _dirs = list(getattr(self, "_dirs", None) or default_monitor_dirs())
            for _d in _dirs:
                try:
                    if not os.path.isdir(_d) or self._in_exclude(_d):
                        continue
                    for _root, _subs, _files in os.walk(_d):
                        try:
                            _subs[:] = [_s for _s in _subs
                                        if not self._in_exclude(os.path.join(_root, _s))]
                        except Exception:
                            pass
                        for _fn in _files:
                            _p = os.path.join(_root, _fn)
                            if self._in_exclude(_p):
                                continue
                            if os.path.splitext(_fn)[1].lower() not in _exts:
                                continue
                            try:
                                _sz = os.path.getsize(_p)
                                _mt = os.path.getmtime(_p)
                            except Exception:
                                continue
                            if _sz > 200 * 1024 * 1024:  # 单个超大文件跳过（视频/镜像类）
                                continue
                            _docs.append((_root, _fn, _p, _sz, _mt, False, False,
                                          os.path.splitext(_fn)[1].lower()))
                except Exception:
                    continue
            if not _docs:
                return 0
            _total = 0
            for _i in range(0, len(_docs), 50):
                try:
                    _info = {}
                    self._backup_changed(_docs[_i:_i + 50], _info)
                    _total += _info.get("backed_up", 0)
                except Exception:
                    continue
            return _total
        except Exception:
            return 0

    def _notify(self, level, info):
        try:
            if self.on_alert:
                self.on_alert(level, info)
        except Exception:
            pass

    def _src_of_backup(self, backup_path):
        """从 _backed 缓存反查备份对应的原路径（key 形如 path|size|mtime，需剥离后缀）。"""
        try:
            for k, v in self._backed.items():
                if v == backup_path:
                    return k.split("|")[0]
        except Exception:
            pass
        return ""

    # ---------- 备份恢复（6.0.0 闭环：备份必须可恢复） ----------
    def list_backups(self):
        """列出保护区全部备份记录：[{src, backup, size, time}]，按时间倒序。"""
        vault = os.path.join(self.data_dir, "ransom_backup")
        out = []
        try:
            if not os.path.isdir(vault):
                return out
            for day in sorted(os.listdir(vault), reverse=True):
                d = os.path.join(vault, day)
                if not os.path.isdir(d):
                    continue
                for fn in os.listdir(d):
                    fp = os.path.join(d, fn)
                    try:
                        st = os.stat(fp)
                        out.append({"src": "", "backup": fp, "size": st.st_size,
                                    "time": "%s %s" % (day, fn.split("_")[0] if "_" in fn else "")})
                    except Exception:
                        continue
        except Exception:
            pass
        # 回填原路径（6.0.4：剥离 key 的 |size|mtime 后缀）
        for it in out:
            it["src"] = self._src_of_backup(it["backup"])
        return out

    def restore_backup(self, backup_path, dest_dir=None):
        """从保护区还原一个文件。

        dest_dir 为空：还原到原路径（原路径不存在则失败；存在则先备份当前副本再覆盖）。
        dest_dir 给定：无论原路径是否存在，都恢复到 dest_dir（原路径丢失/盘符变化时找回文件用）。
        """
        try:
            if not backup_path or not os.path.exists(backup_path):
                return (False, "备份文件不存在：%s" % backup_path)
            if dest_dir:
                try:
                    os.makedirs(dest_dir, exist_ok=True)
                except Exception:
                    return (False, "目标目录无法创建：%s" % dest_dir)
                _base = os.path.basename(backup_path)
                _name = _base.split("_", 1)[1] if "_" in _base else _base
                _dst = os.path.join(dest_dir, _name)
                _i = 1
                while os.path.exists(_dst):
                    _dst = os.path.join(dest_dir, "%d_%s" % (_i, _name))
                    _i += 1
                try:
                    shutil.copy2(backup_path, _dst)
                except Exception:
                    return (False, "恢复到目标目录失败（可能无权限）：%s" % _dst)
                self._stats["events"] += 1
                return (True, "已恢复到：%s" % _dst)
            src = self._src_of_backup(backup_path)
            if not src or not os.path.exists(src):
                return (False, "原文件路径不存在或已丢失，无法自动还原位置；可选用「恢复到指定目录」")
            try:
                shutil.copy2(backup_path, src)
            except Exception:
                return (False, "还原失败（文件可能被占用或无权限）：%s" % src)
            self._stats["events"] += 1
            return (True, "已还原：%s" % src)
        except Exception as e:
            return (False, "还原异常：%s" % e)

    # ---------- 6.0.4：一键恢复全部备份（勒索后批量找回文件） ----------
    def restore_all_backups(self, dest_dir=None):
        """把保护区全部备份按时间倒序还原。返回统计报告。

        dest_dir 为空：还原到原路径（原路径不存在记为「跳过」，存在则覆盖前留底）。
        dest_dir 给定：全部恢复到指定目录（不写原路径，原路径丢失/换盘/重装后找回文件用）。
        """
        reports = []
        ok = skip = fail = 0
        try:
            if dest_dir:
                try:
                    os.makedirs(dest_dir, exist_ok=True)
                except Exception:
                    return {"ok": 0, "skip": 0, "fail": 1,
                            "reports": [("", "失败", "目标目录无法创建：" + dest_dir)]}
            vault = os.path.join(self.data_dir, "ransom_backup")
            days = sorted(os.listdir(vault), reverse=True) if os.path.isdir(vault) else []
            for day in days:
                d = os.path.join(vault, day)
                if not os.path.isdir(d):
                    continue
                for fn in sorted(os.listdir(d)):
                    fp = os.path.join(d, fn)
                    if not os.path.isfile(fp):
                        continue
                    src = self._src_of_backup(fp)
                    if dest_dir:
                        try:
                            _name = fn.split("_", 1)[1] if "_" in fn else fn
                            _dst = os.path.join(dest_dir, _name)
                            _i = 1
                            while os.path.exists(_dst):
                                _dst = os.path.join(dest_dir, "%d_%s" % (_i, _name))
                                _i += 1
                            shutil.copy2(fp, _dst)
                            ok += 1
                            reports.append((fp, "已恢复", _dst))
                        except Exception as e:
                            fail += 1
                            reports.append((fp, "失败", str(e)))
                        continue
                    if not src:
                        skip += 1
                        reports.append((fp, "跳过", "原路径已丢失，无法定位还原位置"))
                        continue
                    try:
                        if not os.path.exists(src):
                            skip += 1
                            reports.append((fp, "跳过", "原路径不存在：" + src))
                            continue
                        # 覆盖前先把当前版本留底到保护区（防覆盖掉勒索后的关键现场）
                        try:
                            keep_dir = os.path.join(vault, "pre_restore_%s" % time.strftime("%Y%m%d_%H%M%S"))
                            os.makedirs(keep_dir, exist_ok=True)
                            shutil.copy2(src, os.path.join(keep_dir, os.path.basename(src)))
                        except Exception:
                            pass
                        shutil.copy2(fp, src)
                        ok += 1
                        reports.append((fp, "已还原", src))
                    except Exception as e:
                        fail += 1
                        reports.append((fp, "失败", str(e)))
            self._stats["events"] += ok
            return {"ok": ok, "skip": skip, "fail": fail, "reports": reports}
        except Exception as e:
            return {"ok": ok, "skip": skip, "fail": fail,
                    "reports": reports + [("", "失败", str(e))]}


if __name__ == "__main__":
    # 自测：模拟一次文档风暴（新建一堆 .docx + .enc 文件）
    import tempfile
    td = tempfile.mkdtemp(prefix="dg_ransom_test_")
    g = RansomwareGuard(data_dir=td, on_alert=lambda lv, i: print("ALERT", lv, i))
    g.set_dirs([td])
    g.start()
    for i in range(80):
        try:
            open(os.path.join(td, "doc%d.docx" % i), "w").write("x" * 100)
            open(os.path.join(td, "doc%d.docx.enc" % i), "w").write("y" * 100)
        except Exception:
            pass
    time.sleep(7)
    g.stop()
    print("STATUS", g.get_status())
    print("SELFTEST_DONE")
