# -*- coding: utf-8 -*-
"""
方案B：版本切换时自动注入最新AI助手代码
在 _switch_version 方法里，复制目标版本快照后，注入最新的 _open_ai_chat 方法
"""

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 1. 提取最新版的 _open_ai_chat 方法
start_marker = '    def _open_ai_chat(self):'
end_marker = '    def _open_security_checkup(self):'
start_idx = c.find(start_marker)
end_idx = c.find(end_marker)

if start_idx > 0 and end_idx > 0:
    ai_chat_code = c[start_idx:end_idx]
    print(f"提取到 _open_ai_chat 方法，长度: {len(ai_chat_code)} 字符")
else:
    print("未找到 _open_ai_chat 方法！")
    ai_chat_code = ""

# 2. 把 AI 助手代码保存为一个变量，用于注入
# 注意：需要把代码里的引号转义，或者用 base64 编码
import base64
ai_chat_b64 = base64.b64encode(ai_chat_code.encode('utf-8')).decode('utf-8')
print(f"AI代码base64编码长度: {len(ai_chat_b64)} 字符")

# 3. 在 _switch_version 方法里，找到注入VERSION_LIST的位置，在后面添加AI代码注入
old_inject_end = '''                        except Exception as _inject_err:
                            pass  # 注入失败不影响切换，只是旧版本看不到新版本列表
                        prog_label.config(text=f"已切换到 v{target_ver}，重启程序后生效。", fg=C_GREEN)'''

new_inject_end = '''                        except Exception as _inject_err:
                            pass  # 注入失败不影响切换，只是旧版本看不到新版本列表
                        
                        # ===== 注入最新AI助手代码（方案B）=====
                        try:
                            import base64 as _b64
                            _ai_b64 = "''' + ai_chat_b64 + '''"
                            _ai_code = _b64.b64decode(_ai_b64).decode('utf-8')
                            with open(curr_main, "r", encoding="utf-8") as f:
                                _target_content = f.read()
                            # 检查目标版本是否已有 _open_ai_chat 方法
                            if "def _open_ai_chat" not in _target_content:
                                # 找到 _open_security_checkup 方法，在它前面插入AI助手代码
                                _sec_idx = _target_content.find("    def _open_security_checkup(self):")
                                if _sec_idx > 0:
                                    _target_content = _target_content[:_sec_idx] + _ai_code + _target_content[_sec_idx:]
                                    with open(curr_main, "w", encoding="utf-8") as f:
                                        f.write(_target_content)
                                    prog_label.config(text=f"已切换到 v{target_ver}，已注入最新AI助手功能，重启后生效。", fg=C_GREEN)
                                else:
                                    prog_label.config(text=f"已切换到 v{target_ver}，重启程序后生效。", fg=C_GREEN)
                            else:
                                prog_label.config(text=f"已切换到 v{target_ver}，重启程序后生效。", fg=C_GREEN)
                        except Exception as _ai_err:
                            pass  # AI代码注入失败不影响切换
                        
                        prog_label.config(text=f"已切换到 v{target_ver}，重启程序后生效。", fg=C_GREEN)'''

if old_inject_end in c:
    c = c.replace(old_inject_end, new_inject_end, 1)
    print("3. _switch_version 添加AI代码注入逻辑完成")
else:
    print("3. 未找到注入位置，尝试其他方式...")
    # 找到 prog_label.config(text=f"已切换到 v{target_ver}
    idx = c.find('prog_label.config(text=f"已切换到 v{target_ver}')
    if idx > 0:
        print(f"找到位置在索引 {idx}")
    else:
        print("未找到位置")

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print("\n方案B注入逻辑添加完成！")
