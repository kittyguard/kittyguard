# -*- coding: utf-8 -*-
"""2.7.1 修复：正式版beta残留 + 计划任务3列解析 + 底部按钮截断"""
import os

path = r'F:\桌面保护\desktopguard\main.py'
with open(path, 'r', encoding='utf-8-sig') as f:
    c = f.read()

# 1. APP_NAME 去掉 beta 残留，改为 DG
old = 'APP_NAME = "desktopguard-beta 桌面安全卫士"'
new = 'APP_NAME = "DG 桌面安全卫士"'
if old in c:
    c = c.replace(old, new, 1)
    print("1. APP_NAME 已改为 DG 桌面安全卫士")
else:
    print("1. 未找到 APP_NAME beta 残留")

# 2. 窗口加宽，防止底部按钮截断
old_geo = 'root.geometry("1080x700")'
new_geo = 'root.geometry("1280x740")'
if old_geo in c:
    c = c.replace(old_geo, new_geo, 1)
    print("2. 窗口宽度 1080 -> 1280")
else:
    print("2. 未找到 geometry")

old_min = 'root.minsize(960, 620)'
new_min = 'root.minsize(1080, 640)'
if old_min in c:
    c = c.replace(old_min, new_min, 1)
    print("   minsize 960x620 -> 1080x640")
else:
    print("   未找到 minsize")

# 3. 底部按钮文字精简（节省宽度）
btn_renames = [
    ('text="一键清理垃圾"', 'text="清理垃圾"'),
    ('text="一键删除选中"', 'text="删除选中"'),
    ('text="一键删除全部威胁"', 'text="删除全部威胁"'),
]
for old_b, new_b in btn_renames:
    if old_b in c:
        c = c.replace(old_b, new_b, 1)
        print(f"3. 按钮精简: {old_b} -> {new_b}")
    else:
        print(f"3. 未找到: {old_b}")

# 4. 计划任务 CSV 解析：支持 3 列（任务名/下次运行/状态）
old_task = '''            # 解析 CSV 格式：每行是 "任务名","下次运行时间","状态","要运行的任务"
            reader = csv.reader(io.StringIO(output))
            for row in reader:
                if len(row) < 4:
                    continue
                task_name = row[0].strip().strip('"')
                next_run = row[1].strip().strip('"')
                status = row[2].strip().strip('"')
                task_to_run = row[3].strip().strip('"')
                if not task_name or not task_to_run:
                    continue'''
new_task = '''            # 解析 CSV 格式：schtasks 实际输出 3 列 "任务名","下次运行时间","状态"
            # （部分系统带第4列"要运行的任务"，兼容两种）
            reader = csv.reader(io.StringIO(output))
            for row in reader:
                if len(row) < 3:
                    continue
                task_name = row[0].strip().strip('"')
                next_run = row[1].strip().strip('"')
                status = row[2].strip().strip('"')
                task_to_run = row[3].strip().strip('"') if len(row) > 3 else ""
                if not task_name:
                    continue'''
if old_task in c:
    c = c.replace(old_task, new_task, 1)
    print("4. 计划任务 CSV 解析已修复（支持3列）")
else:
    print("4. 未找到计划任务解析代码")

with open(path, 'w', encoding='utf-8') as f:
    f.write(c)
print("\n修复完成！")
