# -*- coding: utf-8 -*-
"""4.15.2 补丁：开始扫描自动切到扫描页（首页按钮/拖放统一）"""
import io

MAIN = r"F:\桌面保护\desktopguard\main.py"
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()

def rep(old, new, tag):
    global m
    assert old in m, f"未找到锚点: {tag}"
    assert m.count(old) == 1, f"锚点重复: {tag} ({m.count(old)})"
    m = m.replace(old, new, 1)

rep('''            mode_label = SCAN_MODES[mode][0]
        self.scanning = True
        self.stop_flag = False
        self.results = []
        self.scanned_count = 0''',
    '''            mode_label = SCAN_MODES[mode][0]
        self.scanning = True
        try:
            self._nav_page("scan")  # 4.15.2：任何入口（首页按钮/拖放）开始扫描都切到扫描页，确保看到进度条
        except Exception:
            pass
        self.stop_flag = False
        self.results = []
        self.scanned_count = 0''',
    "扫描切页")

rep('APP_VERSION = "4.15.1"', 'APP_VERSION = "4.15.2"', "版本号")
rep('''    ("4.15.1", "4.15.0", "补丁（真进度条丝滑化）：''',
    '''    ("4.15.2", "4.15.1", "补丁（扫描自动切页）：从首页/拖放发起扫描时自动切换到扫描页，实时显示丝滑进度条+百分比+停止按钮（此前首页扫描停留在首页看不到进度）"),
    ("4.15.1", "4.15.0", "补丁（真进度条丝滑化）：''',
    "版本历史")

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)

import py_compile
py_compile.compile(MAIN, doraise=True)
print("[OK] 4.15.2 补丁应用，语法通过")
