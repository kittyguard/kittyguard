// ============================================================
// DG Verdict - C++ 深度判定引擎 (配合 DG 2.16.0)
// 功能: 单文件风险判定, 输出结构化 JSON
//   - SHA256 + 本地哈希库(内置示例/可扩展)
//   - PE 导入表解析: 网络/进程/注入/持久化/隐藏 API 行为链
//   - 熵值(压缩/混淆) / UPX 加壳 / 双扩展名伪装 / U+202E / 伪装系统名
//   - 脚本特征 (.ps1/.bat/.vbs/.js)
// 编译(MSVC, 无MinGW依赖): cl /nologo /O2 /EHsc /std:c++17 /utf-8 /DUNICODE /D_UNICODE dg_verdict.cpp bcrypt.lib crypt32.lib /Fe:dg_verdict.exe /link /SUBSYSTEM:CONSOLE
// 用法: dg_verdict.exe <file>
// 输出: JSON {score, level, sha256, entropy, hits:[{rule_id,title,score,evidence}]}
// ============================================================

#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <cmath>

// ---------------- 工具 ----------------
static std::string w2u(const std::wstring& w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), NULL, 0, NULL, NULL);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, NULL, NULL);
    return s;
}

static std::string json_escape(const std::string& s) {
    std::string out;
    for (char c : s) {
        if (c == '"') out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else if ((unsigned char)c < 0x20) { char b[8]; sprintf(b, "\\u%04x", c); out += b; }
        else out += c;
    }
    return out;
}

static std::string lower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(), ::tolower);
    return r;
}

static std::string base_name(const std::wstring& p) {
    size_t pos = p.find_last_of(L"\\/");
    std::wstring b = (pos == std::wstring::npos) ? p : p.substr(pos + 1);
    return w2u(b);
}

// ---------------- SHA256 (BCrypt) ----------------
static std::string sha256_file(const std::wstring& path) {
    BCRYPT_ALG_HANDLE alg = NULL;
    BCRYPT_HASH_HANDLE h = NULL;
    std::string out;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, NULL, 0) != 0)
        return out;
    if (BCryptCreateHash(alg, &h, NULL, 0, NULL, 0, 0) == 0) {
        BYTE buf[1 << 16];
        HANDLE hf = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hf != INVALID_HANDLE_VALUE) {
            DWORD rd = 0;
            while (ReadFile(hf, buf, sizeof(buf), &rd, NULL) && rd > 0)
                BCryptHashData(h, buf, rd, 0);
            CloseHandle(hf);
            BYTE digest[32];
            DWORD dlen = 32;
            if (BCryptFinishHash(h, digest, sizeof(digest), 0) == 0) {
                static const char* hex = "0123456789abcdef";
                for (DWORD i = 0; i < dlen; i++) {
                    out += hex[digest[i] >> 4];
                    out += hex[digest[i] & 0xF];
                }
            }
        }
        BCryptDestroyHash(h);
    }
    BCryptCloseAlgorithmProvider(alg, 0);
    return out;
}

// ---------------- 熵值 (前 4MB) ----------------
static double file_entropy(const std::wstring& path) {
    HANDLE hf = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) return -1.0;
    DWORD size = GetFileSize(hf, NULL);
    if (size == INVALID_FILE_SIZE || size == 0) { CloseHandle(hf); return 0.0; }
    size_t want = size < (4 << 20) ? size : (4 << 20);
    std::vector<BYTE> buf(want);
    DWORD rd = 0;
    ReadFile(hf, buf.data(), (DWORD)want, &rd, NULL);
    CloseHandle(hf);
    size_t n = rd;
    if (n == 0) return 0.0;
    long long freq[256] = {0};
    for (size_t i = 0; i < n; i++) freq[buf[i]]++;
    double ent = 0.0;
    for (int i = 0; i < 256; i++) {
        if (freq[i]) {
            double p = (double)freq[i] / (double)n;
            ent -= p * log2(p);
        }
    }
    return ent;
}

// ---------------- 读取小文件 ----------------
static bool read_small_file(const std::wstring& path, std::vector<BYTE>& out, size_t max_sz = 8 << 20) {
    HANDLE hf = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) return false;
    DWORD size = GetFileSize(hf, NULL);
    if (size == INVALID_FILE_SIZE || size == 0 || size > max_sz) { CloseHandle(hf); return false; }
    out.resize(size);
    DWORD rd = 0;
    ReadFile(hf, out.data(), size, &rd, NULL);
    CloseHandle(hf);
    return rd == size;
}

// ---------------- PE 解析 ----------------
struct PEInfo {
    bool is_pe = false;
    bool is_dll = false;
    bool upx = false;
    bool mz = false;
    std::set<std::string> imports; // 导入函数名
};

// RVA -> 文件偏移
static DWORD rva_to_offset(const std::vector<BYTE>& data, DWORD rva, DWORD size_of_image,
                           const IMAGE_SECTION_HEADER* secs, WORD nsec) {
    for (WORD i = 0; i < nsec; i++) {
        DWORD va = secs[i].VirtualAddress;
        DWORD vs = secs[i].Misc.VirtualSize;
        DWORD rs = secs[i].SizeOfRawData;
        if (rva >= va && rva < va + std::max(vs, rs)) {
            return secs[i].PointerToRawData + (rva - va);
        }
    }
    return 0;
}

static PEInfo parse_pe(const std::vector<BYTE>& data, const std::string& fname_lower) {
    PEInfo info;
    if (data.size() < 0x40) return info;
    if (data[0] == 'M' && data[1] == 'Z') info.mz = true; else return info;
    DWORD e_lfanew = *(DWORD*)(data.data() + 0x3C);
    if (e_lfanew + 0x18 > data.size()) return info;
    if (memcmp(data.data() + e_lfanew, "PE\0\0", 4) != 0) return info;

    IMAGE_FILE_HEADER* fh = (IMAGE_FILE_HEADER*)(data.data() + e_lfanew + 4);
    WORD magic = *(WORD*)(data.data() + e_lfanew + 4 + sizeof(IMAGE_FILE_HEADER));
    if (magic != 0x10B && magic != 0x20B) return info;
    info.is_pe = true;
    info.is_dll = (fh->Characteristics & IMAGE_FILE_DLL) != 0;

    // 数据目录 / 节表：用结构体精确定位（DataDirectory 在 OptionalHeader 内部，偏移 224/96）
    const IMAGE_DATA_DIRECTORY* dds = NULL;
    const IMAGE_SECTION_HEADER* secs = NULL;
    WORD nsec = fh->NumberOfSections;
    const BYTE* opt_base = data.data() + e_lfanew + 4 + sizeof(IMAGE_FILE_HEADER);
    if (magic == 0x20B) {
        const IMAGE_OPTIONAL_HEADER64* opt = (const IMAGE_OPTIONAL_HEADER64*)opt_base;
        if (opt_base + sizeof(IMAGE_OPTIONAL_HEADER64) + nsec * sizeof(IMAGE_SECTION_HEADER) > data.data() + data.size())
            return info;
        dds = opt->DataDirectory;
        secs = (const IMAGE_SECTION_HEADER*)(opt_base + sizeof(IMAGE_OPTIONAL_HEADER64));
    } else {
        const IMAGE_OPTIONAL_HEADER32* opt = (const IMAGE_OPTIONAL_HEADER32*)opt_base;
        if (opt_base + sizeof(IMAGE_OPTIONAL_HEADER32) + nsec * sizeof(IMAGE_SECTION_HEADER) > data.data() + data.size())
            return info;
        dds = opt->DataDirectory;
        secs = (const IMAGE_SECTION_HEADER*)(opt_base + sizeof(IMAGE_OPTIONAL_HEADER32));
    }

    // UPX 加壳 (字符串特征)
    std::string haystack(data.begin(), data.begin() + std::min<size_t>(data.size(), 4 << 20));
    if (haystack.find("UPX!") != std::string::npos || haystack.find("UPX0") != std::string::npos ||
        haystack.find("UPX1") != std::string::npos)
        info.upx = true;

    // 导入表
    if (dds[1].VirtualAddress && dds[1].Size) {
        DWORD imp_rva = dds[1].VirtualAddress;
        size_t max_desc = 512;
        for (size_t i = 0; i < max_desc; i++) {
            DWORD off = rva_to_offset(data, imp_rva + (DWORD)(i * sizeof(IMAGE_IMPORT_DESCRIPTOR)),
                                      0, secs, fh->NumberOfSections);
            if (!off || off + sizeof(IMAGE_IMPORT_DESCRIPTOR) > data.size()) break;
            IMAGE_IMPORT_DESCRIPTOR* desc = (IMAGE_IMPORT_DESCRIPTOR*)(data.data() + off);
            if (desc->Name == 0 && desc->FirstThunk == 0) break;
            // 遍历 thunk 取函数名
            DWORD thunk_rva = desc->OriginalFirstThunk ? desc->OriginalFirstThunk : desc->FirstThunk;
            for (size_t t = 0; t < 4096; t++) {
                DWORD toff = rva_to_offset(data, thunk_rva + (DWORD)(t * sizeof(DWORD64)), 0,
                                           secs, fh->NumberOfSections);
                if (!toff || toff + 8 > data.size()) break;
                ULONGLONG thunk = *(ULONGLONG*)(data.data() + toff);
                if (thunk == 0) break;
                if (!(thunk & 0x8000000000000000ULL)) {
                    DWORD name_rva = (DWORD)(thunk & 0x7FFFFFFF);
                    DWORD noff = rva_to_offset(data, name_rva, 0, secs, fh->NumberOfSections);
                    if (!noff || noff + 2 > data.size()) continue;
                    // 结构: WORD Hint + char Name[]
                    char* nm = (char*)(data.data() + noff + 2);
                    size_t maxlen = std::min<size_t>(64, data.size() - noff - 2);
                    std::string fn(nm, strnlen(nm, maxlen));
                    if (!fn.empty()) info.imports.insert(fn);
                }
            }
        }
    }
    return info;
}

// ---------------- 判定结果 ----------------
struct Hit {
    std::string rule_id, title, evidence;
    int score;
    std::string level;
};

static std::string level_of(int score) {
    if (score >= 80) return "critical";
    if (score >= 60) return "high";
    if (score >= 40) return "medium";
    if (score >= 20) return "low";
    return "info";
}

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) {
        printf("{\"success\":false,\"msg\":\"usage: dg_verdict.exe <file>\"}\n");
        return 1;
    }
    std::wstring path = argv[1];
    std::string fname = base_name(path);
    std::string fname_lower = lower(fname);

    std::vector<Hit> hits;
    int score = 0;
    std::string sha = sha256_file(path);
    double ent = file_entropy(path);
    std::vector<BYTE> fdata;
    bool has_data = read_small_file(path, fdata);
    PEInfo pe;
    if (has_data) pe = parse_pe(fdata, fname_lower);

    // ---------- 规则 1: 双扩展名伪装 ----------
    static const char* double_ext[] = { ".jpg.exe", ".png.exe", ".pdf.exe", ".doc.exe",
        ".docx.exe", ".xls.exe", ".xlsx.exe", ".txt.exe", ".pdf.scr", ".jpg.scr",
        ".docx.vbs", ".pdf.vbs", ".doc.vbs", ".exe.scr", ".zip.exe", ".rar.exe" };
    for (auto e : double_ext) {
        if (fname_lower.size() > strlen(e) &&
            fname_lower.compare(fname_lower.size() - strlen(e), strlen(e), e) == 0) {
            hits.push_back({"DISGUISED_EXT", "双扩展名伪装", std::string("文件名以 ") + e + " 结尾", 40});
            score += 40;
            break;
        }
    }

    // ---------- 规则 2: U+202E 右向覆盖 ----------
    if (fname.find("\u202E") != std::string::npos) {
        hits.push_back({"RLO_CHAR", "Unicode 右向覆盖字符", "文件名包含 U+202E, 可反转显示顺序", 40});
        score += 40;
    }

    // ---------- 规则 3: 大量空格隐藏扩展名 ----------
    if (fname.find("     ") != std::string::npos &&
        (fname_lower.rfind(".exe") != std::string::npos ||
         fname_lower.rfind(".scr") != std::string::npos ||
         fname_lower.rfind(".vbs") != std::string::npos)) {
        hits.push_back({"SPACES_HIDE", "空格隐藏扩展名", "文件名含大量空格且为可执行扩展名", 30});
        score += 30;
    }

    // ---------- 规则 4: 伪装系统名 ----------
    static const char* fake_names[] = { "svch0st", "expl0rer", "svchost32", "system32.exe",
        "winupdate", "chrome_update", "msupdate", "windowsdefender", "securityhealth" };
    for (auto n : fake_names) {
        if (fname_lower.find(n) != std::string::npos) {
            hits.push_back({"FAKE_SYSNAME", "伪装系统组件名", std::string("名称含 ") + n, 20});
            score += 20;
            break;
        }
    }

    // ---------- 规则 5: 高熵 ----------
    if (ent >= 7.2 && fdata.size() >= 1024) {
        char ev[64];
        sprintf(ev, "熵值 %.2f (≥7.2, 疑似压缩/混淆)", ent);
        hits.push_back({"HIGH_ENTROPY", "高熵(可疑混淆)", ev, 15});
        score += 15;
    }

    // ---------- 规则 6: UPX 加壳 ----------
    if (pe.upx) {
        hits.push_back({"UPX_PACKED", "UPX 加壳", "检测到 UPX 加壳特征", 20});
        score += 20;
    }

    // ---------- 规则 7: PE 行为链 (导入 API 组合) ----------
    if (pe.is_pe) {
        static const char* net_apis[] = { "WinHttpOpen", "WinHttpConnect", "InternetOpenA",
            "InternetOpenW", "InternetConnectA", "URLDownloadToFileA", "socket", "WSAStartup",
            "connect", "send", "recv", "HttpSendRequestA", "WinHttpOpenRequest" };
        static const char* proc_apis[] = { "CreateProcessA", "CreateProcessW", "WinExec",
            "ShellExecuteA", "ShellExecuteW", "system" };
        static const char* inj_apis[] = { "WriteProcessMemory", "VirtualAllocEx",
            "CreateRemoteThread", "SetWindowsHookExA", "SetWindowsHookExW", "QueueUserAPC" };
        static const char* persist_apis[] = { "RegSetValueExA", "RegSetValueExW", "RegCreateKeyExA",
            "CreateServiceA", "CreateServiceW", "StartServiceA", "Schtasks" };
        static const char* hide_apis[] = { "ShowWindow", "SetWindowDisplayAffinity",
            "SetFileAttributesA", "SetFileAttributesW" };

        int net_n = 0, proc_n = 0, inj_n = 0, persist_n = 0, hide_n = 0;
        std::vector<std::string> net_ev, proc_ev, inj_ev, persist_ev;
        for (auto& api : pe.imports) {
            for (auto a : net_apis) if (api == a) { net_n++; net_ev.push_back(api); }
            for (auto a : proc_apis) if (api == a) { proc_n++; proc_ev.push_back(api); }
            for (auto a : inj_apis) if (api == a) { inj_n++; inj_ev.push_back(api); }
            for (auto a : persist_apis) if (api == a) { persist_n++; persist_ev.push_back(api); }
            if (api == "ShowWindow" || api == "SetWindowDisplayAffinity") { hide_n++; }
        }
        // 行为链: 网络+进程 (下载执行)
        if (net_n >= 1 && proc_n >= 1) {
            hits.push_back({"CHAIN_NET_PROC", "下载执行链", "同时导入网络通信与进程创建 API", 35});
            score += 35;
        }
        // 注入链
        if (inj_n >= 1) {
            hits.push_back({"CHAIN_INJECT", "进程注入 API", "导入 WriteProcessMemory/CreateRemoteThread 等注入 API", 40});
            score += 40;
        }
        // 持久化链
        if (persist_n >= 1) {
            hits.push_back({"CHAIN_PERSIST", "持久化 API", "导入注册表/服务自启 API", 30});
            score += 30;
        }
        // 网络 + 持久化
        if (net_n >= 1 && persist_n >= 1) {
            hits.push_back({"CHAIN_NET_PERSIST", "网络+持久化组合", "外联 + 自启动行为组合", 25});
            score += 25;
        }
        // 隐藏窗口
        if (hide_n >= 1) {
            hits.push_back({"CHAIN_HIDE", "隐藏窗口 API", "导入 ShowWindow/隐藏显示 API", 10});
            score += 10;
        }
        // 纯净证据字段
        if (net_n || proc_n || inj_n || persist_n) {
            std::string ev;
            if (!net_ev.empty()) ev += "net:[" + net_ev[0] + (net_ev.size() > 1 ? ",...]" : "]");
            if (!proc_ev.empty()) ev += (ev.empty() ? "" : "; ") + std::string("proc:[") + proc_ev[0] + "]";
            if (!inj_ev.empty()) ev += (ev.empty() ? "" : "; ") + std::string("inj:[") + inj_ev[0] + "]";
            if (!persist_ev.empty()) ev += (ev.empty() ? "" : "; ") + std::string("persist:[") + persist_ev[0] + "]";
            if (!ev.empty() && hits.empty())
                hits.push_back({"PE_APIS", "PE API 行为特征", ev, 15});
            else if (!ev.empty())
                hits.back().evidence += " | " + ev;
        }
    }

    // ---------- 规则 8: 脚本特征 ----------
    if (fname_lower.rfind(".ps1") != std::string::npos ||
        fname_lower.rfind(".bat") != std::string::npos ||
        fname_lower.rfind(".cmd") != std::string::npos ||
        fname_lower.rfind(".vbs") != std::string::npos ||
        fname_lower.rfind(".js") != std::string::npos) {
        std::string content(fdata.begin(), fdata.end());
        std::string cl = lower(content);
        static const char* pats[] = { "-enc", "frombase64string", "iex(", "wscript",
            "cscript", "powershell", "downloadstring", "bypass", "cmd.exe", "mshta" };
        int hit_n = 0;
        std::vector<std::string> ev;
        for (auto p : pats) {
            if (cl.find(p) != std::string::npos) { hit_n++; ev.push_back(p); }
        }
        if (hit_n >= 2) {
            std::string evs;
            for (size_t i = 0; i < ev.size() && i < 4; i++) evs += (i ? "," : "") + ev[i];
            hits.push_back({"SCRIPT_SUSPICIOUS", "脚本可疑特征", "命中 " + evs, 25 + hit_n * 5});
            score += 25 + hit_n * 5;
        } else if (hit_n == 1) {
            hits.push_back({"SCRIPT_WEAK", "脚本弱特征", "命中 " + ev[0], 10});
            score += 10;
        }
    }

    // ---------- 规则 9: 已知哈希(内置演示) ----------
    // EICAR 测试串哈希: 275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f
    static const char* known[] = { "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f" };
    for (auto k : known) {
        if (sha == k) {
            hits.push_back({"KNOWN_EICAR", "已知恶意样本(EICAR)", "哈希命中已知测试样本", 90});
            score = 100;
            break;
        }
    }

    score = std::min(score, 100);

    // ---------- 输出 JSON ----------
    printf("{\n");
    printf("  \"success\": true,\n");
    printf("  \"file\": \"%s\",\n", json_escape(fname).c_str());
    printf("  \"path\": \"%s\",\n", json_escape(w2u(path)).c_str());
    printf("  \"sha256\": \"%s\",\n", sha.c_str());
    printf("  \"size\": %zu,\n", fdata.size());
    printf("  \"entropy\": %.2f,\n", ent);
    printf("  \"is_pe\": %s,\n", pe.is_pe ? "true" : "false");
    printf("  \"is_dll\": %s,\n", pe.is_dll ? "true" : "false");
    printf("  \"score\": %d,\n", score);
    printf("  \"level\": \"%s\",\n", level_of(score).c_str());
    printf("  \"hits\": [\n");
    for (size_t i = 0; i < hits.size(); i++) {
        printf("    {\"rule_id\":\"%s\",\"title\":\"%s\",\"score\":%d,\"evidence\":\"%s\"}%s\n",
               hits[i].rule_id.c_str(), json_escape(hits[i].title).c_str(), hits[i].score,
               json_escape(hits[i].evidence).c_str(), i + 1 < hits.size() ? "," : "");
    }
    printf("  ]\n");
    printf("}\n");
    return 0;
}
