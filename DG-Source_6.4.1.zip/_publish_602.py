# -*- coding: utf-8 -*-
"""发布 6.0.2：快照 + 重建防篡改清单 + version.json（勒索守护防误伤：试运行模式 + 排除目录管理）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.0.2"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.0.2 内容更新：勒索守护防误伤（试运行模式只记录不冻结 + 排除目录管理即时生效）。",
    "features": [
        "试运行模式：勒索守护可切换「只记录+备份、不冻结进程」，先观察防误伤，状态行实时显示",
        "排除目录管理：编译输出/游戏/虚拟机镜像等目录内批量改写不再冻结告警，添加移除即时生效",
        "配置持久化：ransom_guard_dryrun / ransom_guard_excludes 保存至 config.json",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
