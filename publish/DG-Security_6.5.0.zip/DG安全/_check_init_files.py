# -*- coding: utf-8 -*-
"""检查 __init__ 相关文件：隔离区记录 + 便携版/dist 现状"""
import os, glob, json

QM = r"F:\桌面保护\desktopguard\quarantine\_meta"
QP = r"F:\桌面保护\desktopguard\quarantine"
DL = r"C:\Users\Administrator\Downloads\DG安全"
DIST = r"F:\桌面保护\desktopguard\dist\DG安全"

print("=== 隔离区 meta 中含 __init__ / _init_ 的记录 ===")
if os.path.isdir(QM):
    for m in sorted(glob.glob(os.path.join(QM, "*.json")) + glob.glob(os.path.join(QM, "*.meta.json"))):
        try:
            with open(m, "r", encoding="utf-8") as f:
                d = json.load(f)
            op = d.get("original_path", "")
        except Exception:
            op = ""
        if "__init__" in op or "_init_" in op.lower():
            print("meta:", os.path.basename(m))
            print("  original:", op, "| size:", d.get("size"), "| sha:", str(d.get("sha256"))[:16])

print()
print("=== Downloads\\DG安全 中的 __init__ 文件 ===")
if os.path.isdir(DL):
    hits = []
    for root, dirs, files in os.walk(DL):
        for f in files:
            if "__init__" in f or "_init_" in f.lower():
                hits.append(os.path.join(root, f))
    print("found:", len(hits))
    for h in hits:
        print("  ", h, os.path.getsize(h))

print()
print("=== dist\\DG安全 中的 __init__ 文件 ===")
if os.path.isdir(DIST):
    hits = []
    for root, dirs, files in os.walk(DIST):
        for f in files:
            if "__init__" in f or "_init_" in f.lower():
                hits.append(os.path.join(root, f))
    print("found:", len(hits))
    for h in hits[:30]:
        print("  ", os.path.relpath(h, DIST), os.path.getsize(h))
