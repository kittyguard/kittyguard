# -*- coding: utf-8 -*-
"""
ml_infer.py — 本地 ML 模型推理（集成进 engine 的 PE 分支）
=========================================================
双通道推理：
  1. 优先 ONNX Runtime（ml_model.onnx，48 维 PE 特征，skl2onnx 导出）
  2. 缺失/失败时回退 joblib 随机森林（ml_model.joblib）
对 PE 文件输出恶意概率 → 映射为分数/标签。
模型文件缺失时静默降级（不影响主流程）。
"""

import os
import math

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ONNX_PATH = os.path.join(BASE_DIR, "ml_model.onnx")
JOBLIB_PATH = os.path.join(BASE_DIR, "ml_model.joblib")

_model = None
_model_names = None
_sess = None
_onnx_ok = None       # None=未尝试, True=可用, False=不可用
_joblib_ok = None


def _load_onnx():
    global _sess, _onnx_ok
    if _onnx_ok is not None:
        return _onnx_ok
    if not os.path.exists(ONNX_PATH):
        _onnx_ok = False
        return False
    try:
        import onnxruntime as ort
        _sess = ort.InferenceSession(ONNX_PATH, providers=["CPUExecutionProvider"])
        _onnx_ok = True
        return True
    except Exception:
        _onnx_ok = False
        return False


def _load_joblib():
    global _model, _model_names, _joblib_ok
    if _joblib_ok is not None:
        return _joblib_ok
    try:
        import joblib
        d = joblib.load(JOBLIB_PATH)
        _model = d.get("clf")
        _model_names = d.get("feature_names")
        _joblib_ok = _model is not None
        return _joblib_ok
    except Exception:
        _joblib_ok = False
        return False


def predict_malware(path: str, head: bytes = b"", size: int = 0):
    """返回 (mal_prob 0-1, 特征数非零个数)。失败返回 (0, 0)。"""
    try:
        import ml_features
        import numpy as np
        fv, feat = ml_features.extract(path, head, size)
        if not any(fv):
            return 0.0, 0
        nz = sum(1 for x in fv if x != 0)
        # 通道 1：ONNX Runtime
        if _load_onnx():
            x = np.array([fv], dtype=np.float32)
            outs = _sess.run(None, {"input": x})
            # 常规 probabilities 输出：(1, n_class) 数组
            for o in outs:
                arr = np.asarray(o)
                if arr.ndim == 2 and arr.shape[0] == 1 and arr.shape[1] == 2:
                    proba = arr[0]
                    return float(proba[1]), nz
            # skl2onnx zipmap 输出：object 数组，元素为 {class: prob} 字典
            for o in outs:
                arr = np.asarray(o)
                if arr.ndim == 1 and arr.dtype == object:
                    m = arr[0]
                    if isinstance(m, dict):
                        return float(m.get(1, 0.0)), nz
            return 0.0, nz
        # 通道 2：joblib 随机森林
        if _load_joblib():
            proba = _model.predict_proba(np.array([fv], dtype=np.float64))[0]
            mal_idx = list(_model.classes_).index(1) if 1 in _model.classes_ else 1
            return float(proba[mal_idx]), nz
        return 0.0, nz
    except Exception:
        return 0.0, 0


def engine_status() -> str:
    """返回当前推理引擎状态（供界面展示）。"""
    if _load_onnx():
        return "ONNX"
    if _load_joblib():
        return "joblib"
    return "无"


def proba_to_score(prob: float) -> int:
    """恶意概率 → 启发式叠加分（与 engine 评分体系对齐：>=12 严重、>=7 高危）。
    映射刻意收紧：恶意样本中位概率 0.946，误报集中在 0.5-0.9——
    只有 >0.9 才给高分，0.5-0.7 只给弱分（配合 engine 目录降权压误报）。"""
    if prob >= 0.95:
        return 15
    if prob >= 0.85:
        return 8
    if prob >= 0.70:
        return 5
    if prob >= 0.55:
        return 3
    if prob >= 0.40:
        return 1
    return 0


if __name__ == "__main__":
    import sys
    print("[引擎]", engine_status())
    for p in sys.argv[1:]:
        try:
            with open(p, "rb") as f:
                h = f.read(65536)
            sz = os.path.getsize(p)
            prob, nz = predict_malware(p, h, sz)
            print("%s => 恶意概率 %.3f (非零特征 %d) → 分 %d" % (
                os.path.basename(p), prob, nz, proba_to_score(prob)))
        except Exception as e:
            print(p, "ERR", e)
