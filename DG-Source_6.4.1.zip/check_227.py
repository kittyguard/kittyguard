# -*- coding: utf-8 -*-
c = open('versions/2.2.7/main.py', 'r', encoding='utf-8').read()

print('有 msg_queue:', 'msg_queue = queue.Queue()' in c)
print('有 poll_queue:', 'def poll_queue' in c)
print('有 win.after(100, poll_queue):', 'win.after(100, poll_queue)' in c)

# 检查 poll_queue 函数
poll_idx = c.find('def poll_queue')
if poll_idx > 0:
    print('\npoll_queue 函数内容:')
    print(c[poll_idx:poll_idx+500])

# 检查 win.after 的位置
after_idx = c.find('win.after(100, poll_queue)')
if after_idx > 0:
    print('\nwin.after 附近:')
    print(c[after_idx-200:after_idx+100])
