# -*- coding: utf-8 -*-
"""加固 _open_perf_overlay：显式用 pythonw 启动悬浮窗（无黑窗）"""
import io
import ast

p = r'F:\桌面保护\desktopguard\main.py'
src = io.open(p, encoding='utf-8').read()

old = """        try:
            subprocess.Popen([sys.executable, script],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            messagebox.showinfo("性能悬浮窗", "性能悬浮窗已打开（屏幕右上角，可拖动；右键菜单可调刷新间隔/退出）。")"""

new = """        try:
            exe = sys.executable
            if exe and exe.lower().endswith("python.exe"):
                exe = exe[:-len("python.exe")] + "pythonw.exe"
            if not exe or not os.path.exists(exe):
                exe = sys.executable
            subprocess.Popen([exe, script],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            messagebox.showinfo("性能悬浮窗", "性能悬浮窗已打开（屏幕右上角，可拖动；右键菜单可调刷新间隔/退出）。")"""

assert src.count(old) == 1, 'anchor not found'
src = src.replace(old, new)
io.open(p, 'w', encoding='utf-8').write(src)
ast.parse(src)
print('patched + syntax OK')
