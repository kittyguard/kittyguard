# -*- coding: utf-8 -*-
"""6.4.0 自测：静态断言 + 真注册表 DG_OFF_ 前缀方案 + 忽略列表过滤逻辑。"""
import io, os, re, sys, winreg, subprocess

ROOT = r"F:\桌面保护\desktopguard"
MAIN = os.path.join(ROOT, "main.py")
SRC = io.open(MAIN, encoding="utf-8").read()

PASS = 0
FAIL = []

def check(name, cond, detail=""):
    global PASS
    if cond:
        PASS += 1
        print("[PASS] %s%s" % (name, ("  (" + detail + ")" if detail else "")))
    else:
        FAIL.append(name)
        print("[FAIL] %s  %s" % (name, detail))

# ---- 1. 版本三件套 ----
check("APP_VERSION=6.4.0", "APP_VERSION = \"6.4.0\"" in SRC)
check("VERSION_LIST 尾部含 6.4.0", "'6.3.0', '6.4.0']" in SRC)
check("VERSION_HISTORY 首条为 6.4.0", "VERSION_HISTORY = [('6.4.0', '6.3.0'," in SRC)

# ---- 2. 自启动监控增强方法存在 ----
for m in ("_startup_quick_disable", "_startup_add_ignore", "_startup_handle_new", "_show_startup_alert"):
    check("方法存在 %s" % m, "def %s" % m in SRC)

# 三按钮文案
for t in ("立即禁用", "加入忽略", "稍后处理"):
    check("告警弹窗按钮 %s" % t, t in SRC)

# 忽略列表过滤
check("忽略列表过滤", "startup_monitor_ignored" in SRC and "if key in _ign" in SRC)
check("忽略持久化 save_config", "self.config[\"startup_monitor_ignored\"] = _ign" in SRC)

# ---- 3. IO 节流三处补齐（6.3.0 主 worker + 6.4.0 producer/consumer/patrol）----
n_io = SRC.count("_set_io_priority_low()")
check("IO 节流调用数>=4（主worker+producer+consumer+patrol）", n_io >= 4, "实际 %d 处" % n_io)
for anchor in ("_producer", "回退", "_patrol_worker"):
    pass
# 逐个锚点确认
for name, anchor in (("producer", "def _producer"), ("consumer", "def _consumer"), ("patrol", "def _patrol_worker")):
    idx = SRC.find(anchor)
    if idx < 0:
        check("%s 方法存在" % name, False)
        continue
    seg = SRC[idx:idx + 2600]
    check("%s 已补 IO 节流" % name, "_set_io_priority_low()" in seg)

# ---- 4. ClamAV 双库龄 ----
check("双库龄 daily 文案", "daily 库龄" in SRC)
check("双库龄 main 文案", "main 库龄" in SRC)
check("一键更新后自动监视刷新", "_rule_center_lab" in SRC and "病毒库更新完成" in SRC)

# ---- 5. 真注册表自测：DG_OFF_ 前缀方案（可逆、收集跳过语义）----
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
TEST_NAME = "DG_640_SELFTEST"
try:
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE)
    winreg.SetValueEx(k, TEST_NAME, 0, winreg.REG_SZ, "powershell -w hidden -enc dGVzdA==")
    winreg.CloseKey(k)
    # 读回
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ)
    _v, _t = winreg.QueryValueEx(k, TEST_NAME)
    winreg.CloseKey(k)
    check("模拟新增测试启动项写入", _v == "powershell -w hidden -enc dGVzdA==")

    # 模拟 _startup_quick_disable：值名加 DG_OFF_ 前缀（保留原值）
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ)
    _val, _typ = winreg.QueryValueEx(k, TEST_NAME)
    winreg.CloseKey(k)
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE)
    winreg.SetValueEx(k, "DG_OFF_" + TEST_NAME, 0, _typ, _val)
    winreg.DeleteValue(k, TEST_NAME)
    winreg.CloseKey(k)
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ)
    _off = False
    try:
        winreg.QueryValueEx(k, "DG_OFF_" + TEST_NAME)
        _off = True
    except FileNotFoundError:
        pass
    _gone = False
    try:
        winreg.QueryValueEx(k, TEST_NAME)
    except FileNotFoundError:
        _gone = True
    winreg.CloseKey(k)
    check("禁用后原名已删、DG_OFF_ 前缀保留原值", _off and _gone)

    # 可逆：去掉前缀即恢复（模拟 _enable 语义）
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ)
    _val, _typ = winreg.QueryValueEx(k, "DG_OFF_" + TEST_NAME)
    winreg.CloseKey(k)
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE)
    winreg.SetValueEx(k, TEST_NAME, 0, _typ, _val)
    winreg.DeleteValue(k, "DG_OFF_" + TEST_NAME)
    winreg.CloseKey(k)
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ)
    _v2, _ = winreg.QueryValueEx(k, TEST_NAME)
    winreg.CloseKey(k)
    check("恢复（去掉前缀）后值回原名", _v2 == "powershell -w hidden -enc dGVzdA==")
finally:
    # 清理
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(k, TEST_NAME)
        winreg.CloseKey(k)
    except FileNotFoundError:
        pass
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(k, "DG_OFF_" + TEST_NAME)
        winreg.CloseKey(k)
    except FileNotFoundError:
        pass

# ---- 6. 真实库目录双库龄计算 ----
DB = r"F:\桌面保护\dgdata\clamav\database"
_days = {}
for _f in ("daily.cld", "daily.cvd", "main.cvd"):
    _p = os.path.join(DB, _f)
    if os.path.isfile(_p):
        _days[_f] = (__import__("time").time() - os.path.getmtime(_p)) / 86400.0
check("daily 库存在且库龄新鲜(<7天)", "daily.cld" in _days or "daily.cvd" in _days,
      "daily 库龄 %.1f 天" % _days.get("daily.cld", _days.get("daily.cvd", -1)))
check("main 库存在", "main.cvd" in _days, "main 库龄 %.1f 天" % _days.get("main.cvd", -1))

print("\n===== 6.4.0 自测结果：%d 通过 / %d 失败 =====" % (PASS, len(FAIL)))
sys.exit(1 if FAIL else 0)
