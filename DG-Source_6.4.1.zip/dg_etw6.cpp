// dg_etw6.cpp — 文件模式 consumer：OpenTrace 回放 .etl，验证 consumer 本身是否正常
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "tdh.lib")
#pragma comment(lib, "shell32.lib")

static volatile long g_ev = 0;
static volatile long g_pid_ev = 0;

static void WINAPI OnEvent(EVENT_RECORD* rec) {
    if (!rec) return;
    g_ev++;
    UCHAR eid = rec->EventHeader.EventDescriptor.Id;
    if (eid == 1 || eid == 2) g_pid_ev++;
}

static DWORD WINAPI TraceThread(LPVOID p) {
    ProcessTrace((PTRACEHANDLE)p, 1, 0, 0);
    return 0;
}

int wmain() {
    // 参数1 = .etl 文件路径
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (argc < 2) return 2;
    LPCWSTR etl = argv[1];
    LocalFree(argv);

    EVENT_TRACE_LOGFILEW lf; memset(&lf, 0, sizeof(lf));
    lf.LogFileName = (LPWSTR)etl;
    lf.ProcessTraceMode = PROCESS_TRACE_MODE_EVENT_RECORD;   // 文件回放模式
    lf.EventRecordCallback = (PEVENT_RECORD_CALLBACK)OnEvent;
    TRACEHANDLE h = OpenTraceW(&lf);
    if (h == (TRACEHANDLE)INVALID_HANDLE_VALUE) {
        printf("OpenTrace failed\n");
        return 3;
    }
    HANDLE hThread = CreateThread(NULL, 0, TraceThread, &h, 0, NULL);
    WaitForSingleObject(hThread, 15000);
    CloseHandle(hThread);
    // 输出结果到文件
    char line[128];
    sprintf_s(line, "g_ev=%ld pid_ev=%ld\n", g_ev, g_pid_ev);
    HANDLE hf = CreateFileW(L"C:\\etwtest\\filemode_out.txt", FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                            NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf != INVALID_HANDLE_VALUE) {
        DWORD w = 0; WriteFile(hf, line, (DWORD)strlen(line), &w, NULL); CloseHandle(hf);
    }
    return 0;
}
