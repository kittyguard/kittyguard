# -*- coding: utf-8 -*-
import os, glob, json, datetime

DL_INTERNAL = r"C:\Users\Administrator\Downloads\DG安全\_internal"
QM = r"F:\桌面保护\desktopguard\quarantine\_meta"

need = ["api-ms-win-core-console-l1-1-0.dll", "api-ms-win-core-datetime-l1-1-0.dll",
        "api-ms-win-core-fibers-l1-1-0.dll", "api-ms-win-core-errorhandling-l1-1-0.dll",
        "api-ms-win-core-debug-l1-1-0.dll"]

print("=== DLL 终检 ===")
allok = True
for n in need:
    p = os.path.join(DL_INTERNAL, n)
    ok = os.path.isfile(p)
    allok = allok and ok
    print("  ", n, "->", "OK " + str(os.path.getsize(p)) + "B" if ok else "MISSING")

print()
print("=== 隔离区是否还有 _internal 记录 ===")
if os.path.isdir(QM):
    n = 0
    for m in glob.glob(os.path.join(QM, "*.json")) + glob.glob(os.path.join(QM, "*.meta.json")):
        try:
            with open(m, "r", encoding="utf-8") as f:
                d = json.load(f)
            op = d.get("original_path", "")
        except Exception:
            op = ""
        if "_internal" in op and "api-ms-win-core" in op:
            n += 1
            print("  REMAIN:", os.path.basename(m), "|", op)
    if n == 0:
        print("  无（干净）")
print("ALL_DLL_OK:", allok)
