# -*- coding: utf-8 -*-
c = open('versions/2.2.7/main.py', 'r', encoding='utf-8').read()

# 找到 _open_ai_chat 方法
start_idx = c.find('def _open_ai_chat(self):')
end_idx = c.find('def _open_security_checkup(self):')
method = c[start_idx:end_idx]

# 检查方法末尾有没有 win.after
print('方法末尾500字符:')
print(method[-500:])

# 检查 poll_queue 完整内容
poll_idx = method.find('def poll_queue():')
if poll_idx > 0:
    print('\n\npoll_queue 完整函数:')
    print(method[poll_idx:poll_idx+600])
