# -*- coding: utf-8 -*-
"""把 dist\DG安全 便携目录压缩为官网 DG-Security_6.4.1.zip，并清理旧版 DG-Security/DG-Source 包"""
import io, os, zipfile

DG = r"F:\桌面保护\desktopguard"
OFF = os.path.join(DG, "官网")
NEW_VER = "6.4.1"
SRC = os.path.join(DG, "dist", "DG安全")
OUT = os.path.join(OFF, "DG-Security_%s.zip" % NEW_VER)

n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
    for root, dirs, files in os.walk(SRC):
        for fn in files:
            p = os.path.join(root, fn)
            rel = os.path.relpath(p, os.path.dirname(SRC))
            z.write(p, rel)
            n += 1
print("[OK] %s: %d 文件 / %d B" % (OUT, n, os.path.getsize(OUT)))

removed = []
for x in os.listdir(OFF):
    if x.startswith("DG-Security_") and x.endswith(".zip") and x != "DG-Security_%s.zip" % NEW_VER:
        os.remove(os.path.join(OFF, x))
        removed.append(x)
    if x.startswith("DG-Source_") and x.endswith(".zip") and x != "DG-Source_%s.zip" % NEW_VER:
        os.remove(os.path.join(OFF, x))
        removed.append(x)
print("[OK] 已清理旧包:", removed)
