# -*- coding: utf-8 -*-
import urllib.request, ssl, json, sys, time

BASE = "https://kittyguard.github.io/kittyguard"
ctx = ssl.create_default_context()

for attempt in range(3):
    all_ok = True
    for f in ["version.json", "DG-Security-Setup-6.4.2.exe", "DG-Security_6.4.2.zip", "DG-Source_6.4.2.zip"]:
        url = BASE + "/" + f
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=90, context=ctx) as resp:
                data = resp.read()
                print(f, "HTTP", resp.status, "bytes", len(data))
                if f == "version.json":
                    v = json.loads(data.decode("utf-8"))
                    print("  version:", v.get("latest_version"), "| pkg:", v.get("pkg"), "| sha:", v.get("sha256")[:16])
        except Exception as e:
            print(f, "FAIL:", e)
            all_ok = False
    if all_ok:
        print("ALL_OK")
        sys.exit(0)
    print("retry", attempt + 1)
    time.sleep(30)
sys.exit(1)
