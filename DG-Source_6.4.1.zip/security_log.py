# -*- coding: utf-8 -*-
"""
B2 安全日志行为分析 (security_log.py)
====================================
读取 Windows 安全日志中的进程创建事件（EventID 4688），
提取 进程名/路径/命令行/父进程，用本地规则打分识别可疑行为链
（Temp 启动、混淆命令行、浏览器子进程、乱码进程名等），
供工具页展示与 ai_behavior_analyzer 二次研判。

依赖：wevtutil（Windows 自带），管理员可读 Security 日志；
若审计策略未启用 4688，自动降级读取不报错。
"""

import os
import re
import xml.etree.ElementTree as ET
import subprocess

# ===== 进程创建事件规则（本地打分，0-100 分） =====
def _norm(text: str) -> str:
    return (text or "").lower().replace("/", "\\").strip()

def _is_temp_path(path: str) -> bool:
    p = _norm(path)
    markers = (
        "\\temp\\", "\\appdata\\local\\temp\\", "\\appdata\\roaming\\",
        "\\programdata\\", "\\downloads\\", "\\cache\\", "\\writable\\",
        "\\users\\public\\",
    )
    return any(m in p for m in markers) and "\\windows\\" not in p

def _is_garbled_name(name: str) -> bool:
    """进程名含大量非字母数字字符（乱码/对抗性命名）。"""
    n = _norm(name)
    if not n:
        return False
    base = n.rsplit("\\", 1)[-1].rsplit(".", 1)[0]
    if not base:
        return False
    # 全乱码：字母数字占比 < 60%
    alpha = sum(1 for c in base if c.isalnum())
    return alpha / max(len(base), 1) < 0.6 and len(base) >= 6

_OLE_BROWSER_PARENTS = {
    "chrome.exe", "msedge.exe", "firefox.exe", "iexplore.exe",
    "winword.exe", "excel.exe", "powerpnt.exe", "outlook.exe", "wps.exe",
}

_OLE_CMDS = (
    "powershell -enc", "powershell.exe -enc", "pwsh -enc",
    "cmd /c", "cmd.exe /c", "rundll32", "wscript", "cscript", "mshta",
    "regsvr32", "certutil -urlcache", "bitsadmin", "schtasks /create",
    "-windowstyle hidden", "bypass", "-nop", "-w hidden",
)

_SYSTEM_SAFE_PREFIX = ("c:\\windows\\system32\\", "c:\\windows\\syswow64\\",
                       "c:\\windows\\microsoft.net\\", "c:\\program files\\")


def _score_event(ev: dict) -> tuple:
    """单事件本地打分。返回 (分数, [命中标签])。"""
    score = 0
    tags = []
    name = ev.get("process_name", "")
    path = ev.get("process_path", "")
    cmd = ev.get("command_line", "")
    parent = ev.get("parent_process", "")

    if _is_garbled_name(name):
        score += 25
        tags.append("乱码进程名")
    if _is_temp_path(path):
        score += 20
        tags.append("从临时目录启动")
    for c in _OLE_CMDS:
        if c in _norm(cmd):
            score += 20
            tags.append(f"混淆命令行({c})")
            break
    pn = _norm(parent).rsplit("\\", 1)[-1]
    if pn in _OLE_BROWSER_PARENTS:
        score += 15
        tags.append("浏览器/Office 子进程(钓鱼链)")
    if _is_temp_path(parent):
        score += 10
        tags.append("父进程来自临时目录")
    if path and _SYSTEM_SAFE_PREFIX and path.lower().startswith(_SYSTEM_SAFE_PREFIX):
        score = max(0, score - 15)
        tags.append("系统目录文件(降权)")
    if name.lower() == "explorer.exe":
        score = max(0, score - 10)
        tags.append("explorer(降权)")
    return min(score, 100), tags


def read_process_creation_events(count: int = 60) -> dict:
    """读取安全日志最近 count 条 4688 进程创建事件。

    返回: {"ok": bool, "audit_enabled": bool, "events": [dict], "error": str}
    每个事件: {ts, pid, parent_pid, process_name, process_path,
               command_line, parent_process, score, tags, level}
    """
    out = {"ok": False, "audit_enabled": True, "events": [], "error": ""}
    try:
        _cf = 0x08000000 if os.name == "nt" else 0
        query = "*[System[(EventID=4688)]]"
        r = subprocess.run(
            ["wevtutil", "qe", "Security", "/q:" + query,
             "/c:" + str(count), "/rd:true", "/f:xml"],
            capture_output=True, timeout=20, creationflags=_cf)
        if r.returncode != 0:
            err = (r.stderr or b"").decode("utf-8", errors="replace").strip()
            out["error"] = err or "wevtutil 退出码 %d" % r.returncode
            # 审计策略未启用时 4688 无事件，wevtutil 可能返回非 0
            out["audit_enabled"] = False
            return out
        raw = (r.stdout or b"").decode("utf-8", errors="replace")
        raw = raw.strip()
        # wevtutil 某些版本输出裸 <Event> 序列（无 <Events> 根），需容错包裹
        if not raw.startswith("<Events"):
            raw = "<Events>" + raw + "</Events>"
        if "<Event" not in raw:
            out["audit_enabled"] = False
            return out
        root = ET.fromstring(raw)
        ns = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}
        for ev_node in root.findall(".//e:Event", ns):
            try:
                ev = {}
                sys_node = ev_node.find("e:System", ns)
                if sys_node is None:
                    continue
                t = sys_node.findtext("e:TimeCreated", default="", namespaces=ns)
                eid = sys_node.findtext("e:EventID", default="", namespaces=ns)
                if eid != "4688":
                    continue
                ev["ts"] = t
                data = ev_node.find("e:EventData", ns)
                fields = {}
                if data is not None:
                    for d in data.findall("e:Data", ns):
                        name = d.get("Name", "")
                        if name:
                            fields[name] = (d.text or "")
                pid = fields.get("NewProcessId", "").replace("0x", "").strip()
                parent_pid = fields.get("ParentProcessId", "").replace("0x", "").strip()
                ev["pid"] = int(pid, 16) if pid else 0
                ev["parent_pid"] = int(parent_pid, 16) if parent_pid else 0
                ev["process_path"] = fields.get("NewProcessName", "")
                ev["command_line"] = fields.get("CommandLine", "")
                ev["parent_process"] = fields.get("ParentProcessName", "")
                ev["process_name"] = os.path.basename(ev["process_path"]) or ev["process_path"]
                ev["event_type"] = "process_create"
                # 本地打分
                sc, tags = _score_event(ev)
                ev["score"] = sc
                ev["tags"] = tags
                ev["level"] = "高危" if sc >= 60 else ("中危" if sc >= 30 else ("低危" if sc > 0 else "安全"))
                out["events"].append(ev)
            except Exception:
                continue
        out["ok"] = True
        return out
    except Exception as e:
        out["error"] = str(e)
        return out


def summarize(events: list) -> dict:
    """对事件列表做聚合摘要（供 UI 展示）。"""
    summary = {"total": len(events), "high": 0, "medium": 0, "low": 0,
               "safe": 0, "top": [], "max_score": 0}
    for ev in events:
        lv = ev.get("level", "安全")
        if lv == "高危":
            summary["high"] += 1
        elif lv == "中危":
            summary["medium"] += 1
        elif lv == "低危":
            summary["low"] += 1
        else:
            summary["safe"] += 1
        if ev.get("score", 0) > summary["max_score"]:
            summary["max_score"] = ev.get("score", 0)
    ranked = sorted(events, key=lambda e: e.get("score", 0), reverse=True)[:10]
    summary["top"] = [
        {"process_name": e.get("process_name", ""),
         "score": e.get("score", 0),
         "level": e.get("level", "安全"),
         "tags": e.get("tags", [])}
        for e in ranked if e.get("score", 0) > 0
    ]
    return summary


if __name__ == "__main__":
    res = read_process_creation_events(30)
    print("ok:", res["ok"], "| audit_enabled:", res["audit_enabled"],
          "| events:", len(res["events"]), "| error:", res["error"][:120])
    s = summarize(res["events"])
    print("summary:", s)
