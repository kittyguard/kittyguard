# -*- coding: utf-8 -*-
import re
import os
import subprocess

c = open('main.py', 'r', encoding='utf-8').read()
m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', c)
print('main.py 版本号:', m.group(1) if m else '未找到')
print('有 msg_queue:', 'msg_queue' in c)
print('有 poll_queue:', 'poll_queue' in c)
print('有 win.after(100, poll_queue):', 'win.after(100, poll_queue)' in c)

# 检查进程
print('\n当前 pythonw 进程:')
result = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq pythonw.exe', '/FO', 'CSV'], capture_output=True, text=True, encoding='gbk', errors='ignore')
print(result.stdout)

# 检查快捷方式
print('桌面快捷方式:')
lnk_path = r'C:\Users\Administrator\Desktop\DG安全.lnk'
print('存在:', os.path.exists(lnk_path))
