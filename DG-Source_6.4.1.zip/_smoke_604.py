# -*- coding: utf-8 -*-
"""6.0.4 冒烟：版本号 / 首条历史 / 清单 / 产物 / 新功能代码 / 官网 / 打包"""
import io, json, os, sys

DG = r"F:\桌面保护\desktopguard"
ok = 0
bad = []

def chk(name, cond):
    global ok
    if cond:
        ok += 1
        print("  [PASS]", name)
    else:
        bad.append(name)
        print("  [FAIL]", name)

# 1. 主程序版本
main = io.open(os.path.join(DG, "main.py"), encoding="utf-8").read()
chk("APP_VERSION=6.0.4", 'APP_VERSION = "6.0.4"' in main)
chk("VERSION_HISTORY 首条 6.0.4", main.index("VERSION_HISTORY = [('6.0.4'") < main.index("('6.0.3', '6.0.2'"))
# 2. 防篡改清单
sys.path.insert(0, DG)
import selfdefense as sd
man = json.load(io.open(sd.MANIFEST, encoding="utf-8"))
chk("防篡改清单 version=6.0.4", man.get("version") == "6.0.4")
# 3. 根 version.json
vj = json.load(io.open(os.path.join(DG, "version.json"), encoding="utf-8"))
chk("根 version.json=6.0.4", vj.get("version") == "6.0.4")
# 4. 官网镜像
wj = json.load(io.open(os.path.join(DG, "官网", "version.json"), encoding="utf-8"))
pj = json.load(io.open(os.path.join(DG, "官网", "publish", "version.json"), encoding="utf-8"))
chk("官网 version.json=6.0.4", wj.get("version") == "6.0.4")
chk("publish version.json=6.0.4", pj.get("version") == "6.0.4")
# 5. 官网 zip 存在 + 只留最新
zp = os.path.join(DG, "官网", "DG-Security_6.0.4.zip")
chk("官网 6.0.4 zip 存在", os.path.exists(zp))
zold = [x for x in os.listdir(os.path.join(DG, "官网")) if x.startswith("DG-Security_") and x.endswith(".zip") and x != "DG-Security_6.0.4.zip"]
chk("官网无旧版 zip", not zold)
# 6. 打包产物
exe = os.path.join(DG, "dist", "DG安全", "DG安全.exe")
chk("dist DG安全.exe 存在", os.path.exists(exe))
# 7. 6.0.4 新功能代码
rg = io.open(os.path.join(DG, "ransomware_guard.py"), encoding="utf-8").read()
chk("ransomware_guard.restore_all_backups", "def restore_all_backups" in rg)
chk("ransomware_guard._src_of_backup", "def _src_of_backup" in rg)
chk("restore_backup 用 _src_of_backup", "_src_of_backup(backup_path)" in rg)
chk("main 一键恢复全部按钮", "一键恢复全部" in main)
chk("main _restore_all_ransom_backups", "def _restore_all_ransom_backups" in main)
chk("main 导出 CSV 按钮", "导出 CSV" in main)
chk("main _export_csv", "def _export_csv" in main)
chk("main 防护中心 ransomware 模块", '"ransom", "勒索守护"' in main)
chk("main 防护中心 popup 模块", '"popup", "弹窗拦截"' in main)
chk("main 就绪度 8 模块", "_mod_total = 8" in main)
# 8. 快照版本
vm = json.load(io.open(os.path.join(DG, "versions", "6.0.4", "manifest.json"), encoding="utf-8"))
chk("快照 6.0.4 manifest", vm.get("version") == "6.0.4" and len(vm.get("files", [])) > 100)
# 9. 官网 HTML
h = io.open(os.path.join(DG, "官网", "DG安全官网.html"), encoding="utf-8").read()
chk("官网 HTML 含 6.0.4 当前版节点", "6.0.4" in h and "当前版</span>勒索恢复向导" in h)
chk("官网 HTML zip 链接 6.0.4", "DG-Security_6.0.4.zip" in h)

print("----")
print("冒烟结果: %d/%d 通过" % (ok, ok + len(bad)))
if bad:
    print("未通过:", bad)
    sys.exit(1)
