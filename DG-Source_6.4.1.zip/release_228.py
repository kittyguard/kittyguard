# -*- coding: utf-8 -*-
import shutil
import os
import json

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 升级版本号
c = c.replace('APP_VERSION = "2.2.7"', 'APP_VERSION = "2.2.8"', 1)

# 更新版本列表
c = c.replace(
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7"]',
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8"]'
)

# 更新版本历史
old_history = '''VERSION_HISTORY = [
    ("2.2.7"'''
new_history = '''VERSION_HISTORY = [
    ("2.2.8", "补丁：修复AI助手取消按钮无效的bug。根本原因：reset_loading()会把cancel_flag又设回False，导致后台线程以为没取消继续显示结果。修复后：reset_loading不再重置cancel_flag，只在新发送开始时重置；点取消后后台即使API返回也不会显示结果"),
    ("2.2.7"'''
c = c.replace(old_history, new_history, 1)

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

# 创建快照
os.makedirs('versions/2.2.8', exist_ok=True)
shutil.copy2('main.py', 'versions/2.2.8/main.py')
shutil.copy2('engine.py', 'versions/2.2.8/engine.py')
shutil.copy2('database.py', 'versions/2.2.8/database.py')
shutil.copy2('logger.py', 'versions/2.2.8/logger.py')

# 更新version.json
with open('version.json', 'r', encoding='utf-8') as f:
    vj = json.load(f)
vj['latest_version'] = '2.2.8'
with open('version.json', 'w', encoding='utf-8') as f:
    json.dump(vj, f, ensure_ascii=False, indent=2)

print('DG 2.2.8 已发布！')
print('版本号已更新')
print('versions/2.2.8/ 快照已创建')
print('version.json 已更新')
print('当前窗口未关闭，需要手动重启DG才能生效')
