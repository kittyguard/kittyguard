# -*- coding: utf-8 -*-
import re
c = open(r'F:\桌面保护\desktopguard\main.py', encoding='utf-8').read()

# 1. 修复 run_checkup 延迟引用
old = 'tk.Button(btn_bar, text="🔄 重新体检", command=run_checkup,'
new = 'tk.Button(btn_bar, text="🔄 重新体检", command=lambda: run_checkup(),'
if old in c:
    c = c.replace(old, new, 1)
    print("1. run_checkup 延迟引用已修复")
else:
    print("1. 未找到 run_checkup 按钮（可能已修复）")

# 2. 检查是否还有其他 command=xxx 定义在后的问题（按钮引用后定义的局部函数）
# 常见的：检查所有 tk.Button command= 引用
import ast
# 简单检查：找按钮 command= 名称是否在之前有 def
for m in re.finditer(r'tk\.Button\([^)]*command=(\w+)[,\)]', c):
    name = m.group(1)
    # 找该函数定义位置
    defpos = c.rfind(f'def {name}(', 0, m.start())
    btnpos = m.start()
    print(f"  按钮 command={name}: def在{defpos}, 按钮在{btnpos}, {'OK' if defpos < btnpos and defpos > 0 else '⚠ 定义在后！'}")

with open(r'F:\桌面保护\desktopguard\main.py', 'w', encoding='utf-8') as f:
    f.write(c)
print("\n完成")
