// dg_monitor.cpp — DG 后台实时监控引擎（C++ 事件驱动）
// 用法: dg_monitor.exe <dir1>;<dir2>;... <events_file> <heartbeat_file> [parent_pid]
// 基于 ReadDirectoryChangesW，毫秒级捕获文件变化，仅上报可执行/脚本类文件。
// 3.3.2 新增：守护 dg_guard —— guard 心跳超时(18s)自动重建 dg_guard.exe（双向互守闭环）
// 编译: g++ -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -municode dg_monitor.cpp -o dg_monitor.exe -mwindows
// 或 cl: cl /nologo /O2 /MT /EHsc /D "_CRT_SECURE_NO_WARNINGS" dg_monitor.cpp /Fe:dg_monitor.exe /link /SUBSYSTEM:WINDOWS /ENTRY:wmainCRTStartup
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include <vector>
#include <mutex>
#include <thread>
#include <atomic>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cwchar>

static std::atomic<bool> g_running{true};
static std::mutex g_file_mutex;
static std::wstring g_events_path;
static std::wstring g_heartbeat_path;
static std::wstring g_dirs; // 原始参数字符串（暂存，仅用于调试）

// ---- 3.3.2 守护 dg_guard 相关 ----
static std::wstring g_guard_exe;      // 同目录 dg_guard.exe
static std::wstring g_guard_hb;       // DATA_DIR\guard_heartbeat.txt
static std::wstring g_guard_stop;     // DATA_DIR\guard_stop.flag
static std::wstring g_guard_backup;   // DATA_DIR\guard_backup
static std::wstring g_self_exe;       // 自身完整路径
static long long    g_last_guard_restart = 0;
// ---- 3.5.1 守护主程序 pythonw（三方互守闭环：A=pythonw、B=guard、C=monitor 互守） ----
static std::wstring g_pyw_exe;      // pythonw.exe 完整路径（argv[5]）
static std::wstring g_main_py;      // main.py 完整路径（argv[6]）
static std::wstring g_app_exit;     // DATA_DIR\app_exit.flag（argv[7]）
static std::wstring g_app_hb;       // DATA_DIR\app_heartbeat.txt（由 monitor 心跳路径推导）
static DWORD g_app_pid = 0;         // 主程序 PID（argv[4]）
static std::wstring g_base_dir_app; // desktopguard 根目录（main.py 所在，用于启动工作目录）
static long long g_last_app_restart = 0;

// ---------- 工具 ----------
static std::wstring ws_lower(std::wstring s) {
    for (auto& c : s) if (c >= L'A' && c <= L'Z') c += 32;
    return s;
}

// 是否属于需要上报的可疑/可执行/脚本扩展名
static bool is_interesting(const std::wstring& name) {
    size_t dot = name.rfind(L'.');
    if (dot == std::wstring::npos) return false;
    std::wstring ext = ws_lower(name.substr(dot));
    static const wchar_t* kExts[] = {
        L".exe", L".dll", L".bat", L".cmd", L".ps1", L".vbs", L".js",
        L".scr", L".msi", L".com", L".pif", L".lnk", L".jar", L".vbe",
        L".jse", L".wsf", L".hta", L".py", L".sh"
    };
    for (auto* e : kExts) if (ext == e) return true;
    return false;
}

// 当前时间戳（epoch 秒）
static long long now_epoch() {
    return (long long)time(nullptr);
}

// 追加一条事件（JSONL，UTF-8）
static void append_event(const std::wstring& wpath, const std::wstring& wtype) {
    std::lock_guard<std::mutex> lock(g_file_mutex);
    int wlen = (int)wpath.size();
    int need = WideCharToMultiByte(CP_UTF8, 0, wpath.c_str(), wlen, nullptr, 0, nullptr, nullptr);
    std::string path_utf8(need, '\0');
    if (need > 0)
        WideCharToMultiByte(CP_UTF8, 0, wpath.c_str(), wlen, &path_utf8[0], need, nullptr, nullptr);
    int tlen = (int)wtype.size();
    int tneed = WideCharToMultiByte(CP_UTF8, 0, wtype.c_str(), tlen, nullptr, 0, nullptr, nullptr);
    std::string type_utf8(tneed, '\0');
    if (tneed > 0)
        WideCharToMultiByte(CP_UTF8, 0, wtype.c_str(), tlen, &type_utf8[0], tneed, nullptr, nullptr);

    FILE* f = _wfopen(g_events_path.c_str(), L"ab");
    if (f) {
        std::string line = "{\"t\":" + std::to_string(now_epoch()) + ",\"p\":\"";
        for (char c : path_utf8) {
            if (c == '\\') line += "\\\\";
            else if (c == '"') line += "\\\"";
            else if (c == '\n') line += "\\n";
            else if (c == '\r') line += "\\r";
            else line += c;
        }
        line += "\",\"e\":\"" + type_utf8 + "\"}\n";
        fwrite(line.data(), 1, line.size(), f);
        fclose(f);
    }
}

// ---------- 目录监控线程 ----------
static void monitor_dir(const std::wstring& dir) {
    HANDLE hDir = CreateFileW(
        dir.c_str(),
        FILE_LIST_DIRECTORY,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        nullptr, OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS,
        nullptr);
    if (hDir == INVALID_HANDLE_VALUE) {
        return; // 目录不可监控（不存在/权限），静默跳过
    }

    BYTE buf[128 * 1024];
    while (g_running.load()) {
        DWORD bytesReturned = 0;
        BOOL ok = ReadDirectoryChangesW(
            hDir, buf, sizeof(buf), TRUE,
            FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME |
            FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
            &bytesReturned, nullptr, nullptr);
        if (!ok) break; // 监控失败退出

        FILE_NOTIFY_INFORMATION* info = (FILE_NOTIFY_INFORMATION*)buf;
        while (true) {
            std::wstring name(info->FileName, info->FileNameLength / sizeof(WCHAR));
            std::wstring wtype;
            switch (info->Action) {
                case FILE_ACTION_ADDED:            wtype = L"added";    break;
                case FILE_ACTION_REMOVED:          wtype = L"removed";  break;
                case FILE_ACTION_MODIFIED:         wtype = L"modified"; break;
                case FILE_ACTION_RENAMED_OLD_NAME: wtype = L"renamed";  break;
                case FILE_ACTION_RENAMED_NEW_NAME: wtype = L"renamed";  break;
                default: wtype = L"other"; break;
            }
            if (is_interesting(name)) {
                std::wstring full = dir + L"\\" + name;
                std::wstring low = ws_lower(full);
                if (low.find(L"dg_monitor.exe") == std::wstring::npos &&
                    low.find(L"monitor_events") == std::wstring::npos &&
                    low.find(L"monitor_heartbeat") == std::wstring::npos) {
                    append_event(full, wtype);
                }
            }
            if (info->NextEntryOffset == 0) break;
            info = (FILE_NOTIFY_INFORMATION*)((BYTE*)info + info->NextEntryOffset);
        }
    }
    CloseHandle(hDir);
}

// ---------- 心跳线程 ----------
static void write_heartbeat() {
    std::lock_guard<std::mutex> lock(g_file_mutex);
    FILE* f = _wfopen(g_heartbeat_path.c_str(), L"wb");
    if (f) {
        std::string ts = std::to_string(now_epoch());
        fwrite(ts.data(), 1, ts.size(), f);
        fclose(f);
    }
}

static void heartbeat_loop() {
    while (g_running.load()) {
        write_heartbeat();
        Sleep(3000);
    }
}

// ---------- 3.3.2 守护 dg_guard（双向互守） ----------
// guard 心跳文件最后修改时间；文件不存在返回 -1
static long long guard_heartbeat_age() {
    if (g_guard_hb.empty()) return -1;
    HANDLE h = CreateFileW(g_guard_hb.c_str(), GENERIC_READ,
                           FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return -1;
    FILETIME ft{};
    GetFileTime(h, nullptr, nullptr, &ft);
    CloseHandle(h);
    ULARGE_INTEGER ui;
    ui.LowPart = ft.dwLowDateTime;
    ui.HighPart = ft.dwHighDateTime;
    long long ft_unix = (long long)((ui.QuadPart - 116444736000000000ULL) / 10000000ULL);
    return now_epoch() - ft_unix;
}

// 重建 dg_guard.exe（只守护 dg_monitor 自身，保证脱离主程序时 guard/monitor 双向互守）
static void respawn_guard(const std::wstring& monitor_args) {
    if (g_guard_exe.empty() || GetFileAttributesW(g_guard_exe.c_str()) == INVALID_FILE_ATTRIBUTES) {
        return; // guard exe 不存在（被删）→ 不拉起（恢复由主程序/备份完成）
    }
    // 删除 stop flag，否则 guard 启动后立即退出
    if (!g_guard_stop.empty()) DeleteFileW(g_guard_stop.c_str());
    // targets: 单目标 dg_monitor.exe@@<dirs>|<events>|<heartbeat>|<pid>
    std::wstring targets = g_self_exe + L"@@" + monitor_args;
    CreateDirectoryW(g_guard_backup.c_str(), nullptr);
    std::wstring cmd = L"\"" + g_guard_exe + L"\" \"" + targets + L"\" \"" +
                       g_guard_backup + L"\" \"" + g_guard_hb + L"\" \"" + g_guard_stop + L"\"";
    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    if (CreateProcessW(g_guard_exe.c_str(), &cmd[0], NULL, NULL, FALSE, CREATE_NO_WINDOW,
                       NULL, NULL, &si, &pi)) {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        g_last_guard_restart = now_epoch();
    }
}

static void guard_watch_loop(const std::wstring& monitor_args) {
    while (g_running.load()) {
        Sleep(5000);
        if (!g_running.load()) break;
        long long age = guard_heartbeat_age();
        bool stale = (age < 0 || age > 18); // 心跳缺失或 18 秒未更新
        if (stale) {
            long long now = now_epoch();
            if (now - g_last_guard_restart >= 20) { // 20 秒冷却防抖
                respawn_guard(monitor_args);
            }
        }
    }
}

// ---------- 3.5.1 守护主程序 pythonw（三方互守第三环：C=monitor 守 A=pythonw） ----------
// 进程是否存活
static bool process_alive(DWORD pid) {
    if (pid == 0) return false;
    HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!h) return false;
    DWORD code = 0;
    GetExitCodeProcess(h, &code);
    CloseHandle(h);
    return code == STILL_ACTIVE;
}

// 心跳文件最后修改时间；文件不存在返回 -1
static long long app_heartbeat_age() {
    if (g_app_hb.empty()) return -1;
    HANDLE h = CreateFileW(g_app_hb.c_str(), GENERIC_READ,
                           FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return -1;
    FILETIME ft{};
    GetFileTime(h, nullptr, nullptr, &ft);
    CloseHandle(h);
    ULARGE_INTEGER ui;
    ui.LowPart = ft.dwLowDateTime;
    ui.HighPart = ft.dwHighDateTime;
    long long ft_unix = (long long)((ui.QuadPart - 116444736000000000ULL) / 10000000ULL);
    return now_epoch() - ft_unix;
}

// 重建主程序 pythonw main.py --tray（后台守护模式）
static void respawn_app() {
    if (g_pyw_exe.empty() || g_main_py.empty() || g_base_dir_app.empty()) return;
    // 用户正常退出标记存在 → 不拉起
    if (!g_app_exit.empty() &&
        GetFileAttributesW(g_app_exit.c_str()) != INVALID_FILE_ATTRIBUTES) {
        return;
    }
    // 心跳新鲜（< 20 秒）→ 已有其他实例活着（被 guard 拉回），不重复拉
    long long hb_age = app_heartbeat_age();
    if (hb_age >= 0 && hb_age < 20) return;
    std::wstring cmd = L"\"" + g_pyw_exe + L"\" \"" + g_main_py + L"\" --tray";
    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    if (CreateProcessW(g_pyw_exe.c_str(), &cmd[0], NULL, NULL, FALSE, CREATE_NO_WINDOW,
                       NULL, g_base_dir_app.c_str(), &si, &pi)) {
        g_app_pid = pi.dwProcessId; // 更新为被本进程拉起的 PID
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        g_last_app_restart = now_epoch();
    }
}

static void app_watch_loop() {
    while (g_running.load()) {
        Sleep(6000);
        if (!g_running.load()) break;
        // 主程序被外部终止 → 拉回（exit flag / 心跳新鲜则跳过）
        if (!process_alive(g_app_pid)) {
            long long now = now_epoch();
            if (now - g_last_app_restart >= 30) { // 30 秒冷却防抖
                respawn_app();
            }
        }
    }
}

// ---------- 主函数 ----------
int wmain(int argc, wchar_t** argv) {
    if (argc < 4) return 1;
    // 参数1: 目录（; 分隔，避免与 dg_guard targets 的 | 冲突）
    std::vector<std::wstring> dirs;
    {
        std::wstringstream ss(argv[1]);
        std::wstring item;
        while (std::getline(ss, item, L';')) {
            if (!item.empty()) dirs.push_back(item);
        }
    }
    g_events_path = argv[2];
    g_heartbeat_path = argv[3];
    g_dirs = argv[1];

    if (dirs.empty()) return 1;

    // ---- 3.3.2 初始化 guard 守护参数 ----
    {
        wchar_t buf[MAX_PATH] = {0};
        GetModuleFileNameW(NULL, buf, MAX_PATH);
        g_self_exe = buf;
        size_t slash = g_self_exe.find_last_of(L'\\');
        std::wstring base = (slash == std::wstring::npos) ? g_self_exe : g_self_exe.substr(0, slash + 1);
        g_guard_exe = base + L"dg_guard.exe";
        // DATA_DIR = heartbeat 文件所在目录（monitor_heartbeat.txt 同目录）
        std::wstring hb_dir = g_heartbeat_path;
        size_t hs = hb_dir.find_last_of(L'\\');
        if (hs != std::wstring::npos) {
            std::wstring data_dir = hb_dir.substr(0, hs + 1);
            g_guard_hb = data_dir + L"guard_heartbeat.txt";
            g_guard_stop = data_dir + L"guard_stop.flag";
            g_guard_backup = data_dir + L"guard_backup";
            g_app_hb = data_dir + L"app_heartbeat.txt"; // 3.5.1 主程序心跳
        }
    }

    // ---- 3.5.1 初始化主程序守护参数 ----
    if (argc >= 8) {
        g_app_pid = (DWORD)_wtoi(argv[4]);
        g_pyw_exe = argv[5];
        g_main_py = argv[6];
        g_app_exit = argv[7];
        size_t ls = g_main_py.find_last_of(L'\\');
        g_base_dir_app = (ls == std::wstring::npos) ? L"" : g_main_py.substr(0, ls + 1);
    }

    // 立即写一次心跳（消除启动竞态窗口，避免被 RTP 误判超时）
    write_heartbeat();

    // 启动心跳线程
    std::thread hb(heartbeat_loop);
    hb.detach();

    // 每个目录一个监控线程
    std::vector<std::thread> threads;
    for (auto& d : dirs) {
        threads.emplace_back(monitor_dir, d);
    }

    // ---- 3.3.2 守护 dg_guard 线程 ----
    std::wstring monitor_args = g_dirs + L"|" + g_events_path + L"|" + g_heartbeat_path;
    if (argc >= 5) monitor_args += L"|" + std::wstring(argv[4]);
    std::thread gw(guard_watch_loop, monitor_args);
    gw.detach();

    // ---- 3.5.1 守护主程序线程（三方互守第三环） ----
    if (argc >= 8) {
        std::thread aw(app_watch_loop);
        aw.detach();
    }

    // 主线程等待；参数4（父进程 PID）存在时轮询父进程存活。
    // 3.3.2 说明：不再因父进程退出而自杀 —— monitor 由 guard/主程序统一管理，
    // 停止由 RTP.stop 的 taskkill 完成；父进程被强杀时 guard 会拉起主程序，monitor 无需自杀。
    if (argc >= 5) {
        DWORD parentPid = (DWORD)_wtoi(argv[4]);
        HANDLE hParent = OpenProcess(SYNCHRONIZE, FALSE, parentPid);
        while (g_running.load()) {
            if (hParent) {
                DWORD waitRes = WaitForSingleObject(hParent, 1000);
                if (waitRes == WAIT_OBJECT_0) {
                    // 父进程已退出：不自杀，继续监控（由 guard/主程序决定去留）
                    // 但若 guard 也不在（心跳超时）且无守护者，自我保护退出避免无限残留
                    long long age = guard_heartbeat_age();
                    if (age < 0 || age > 25) {
                        // 父进程死 + guard 也死 → 留在这里无意义，退出（避免孤儿残留）
                        // 冷却期除外（可能刚拉起 guard）
                        long long now = now_epoch();
                        if (now - g_last_guard_restart >= 20) {
                            g_running.store(false);
                            break;
                        }
                    }
                }
            } else {
                Sleep(1000);
            }
        }
        if (hParent) CloseHandle(hParent);
    } else {
        while (g_running.load()) Sleep(1000);
    }

    for (auto& t : threads) if (t.joinable()) t.join();
    return 0;
}
