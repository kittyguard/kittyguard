# -*- coding: utf-8 -*-
"""发布 5.0.0：快照 + 重建防篡改清单 + version.json（统一裁决层 Verdict Engine 2.0）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "5.0.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

# 重建防篡改清单（当前安装态 = 受信任态）
sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

# 更新 version.json（更新服务器读取）
notes = {
    "latest_version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "5.0.0 大版本：统一裁决层 Verdict Engine 2.0——多证据风险评分制（0-100 五档安全/低危/中危/高危/严重）接入扫描判定链作为最终权威；哈希黑名单/EICAR/云端已判恶意直接定罪 100 分（白名单降权无效）；单条弱特征不足 3 条不计分（高熵/加壳误报大幅下降）；白名单=降分器非免死金牌（-100~-20，强证据存在时降分封顶 -40 且保底可疑）；AI 仅辅助（恶意需本地证据+10，良性 -12）；新增风险解释页（双击/风险详情按钮：综合评分+命中证据列表+判定理由+建议动作+一键白名单）；hits/tags 证据双计修复（伪装样本不再虚高）。全程纯用户态、零驱动。",
    "features": [
        "统一裁决层：扫描判定升级为多证据加权评分（0-100），engine 判定尾部接入为最终权威",
        "直接定罪：黑名单哈希 / EICAR / 云端已判恶意 100 分（任何降权无效）",
        "降误报：单条弱特征（高熵/加壳）不足 3 条不计分，实测高熵单条 0 分安全",
        "白名单降分器：白名单 -100 / 签名 -40 / 系统目录 -30 / 可信软件目录 -25 / 开发目录 -20",
        "强证据保底：勒索/远控/伪装 exe 存在时白名单降分封顶 -40，最终分不低于 41（不漏真毒）",
        "AI 仅辅助：AI 判恶意需本地证据（+10），判良性降分（-12），不单独定罪",
        "风险解释页：双击扫描结果 /「风险详情」按钮 → 综合评分 + 证据列表 + 判定理由 + 建议动作",
        "证据去重：hits 与 tags 双计修复，伪装样本 75 高危而非虚高 100"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
