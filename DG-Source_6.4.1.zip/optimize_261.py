# -*- coding: utf-8 -*-
"""2.6.1 性能优化：扫描引擎优化 + UI响应优化 + 启动速度优化"""

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 1. 版本号升级到2.6.1
c = c.replace('VERSION = "2.6.0"', 'VERSION = "2.6.1"')
print("1. 版本号升级到 2.6.1")

# 2. UI优化：扫描结果批量插入Treeview，减少更新频率
old_result_insert = '''                        tree.insert("", "end", values=(
                            r.name, r.level, r.category,
                            f"{r.size/1024:.1f} KB" if r.size < 1024*1024 else f"{r.size/1024/1024:.1f} MB",
                            r.path
                        ), tags=(tag,))'''

new_result_insert = '''                        # 批量插入优化：先收集，每50个批量插入
                        if not hasattr(self, '_pending_inserts'):
                            self._pending_inserts = []
                        self._pending_inserts.append((
                            r.name, r.level, r.category,
                            f"{r.size/1024:.1f} KB" if r.size < 1024*1024 else f"{r.size/1024/1024:.1f} MB",
                            r.path
                        ))
                        if len(self._pending_inserts) >= 50:
                            for vals in self._pending_inserts:
                                tree.insert("", "end", values=vals, tags=(tag,))
                            self._pending_inserts = []'''

if old_result_insert in c:
    c = c.replace(old_result_insert, new_result_insert, 1)
    print("2. 扫描结果批量插入优化完成")
else:
    print("2. 未找到扫描结果插入代码，跳过")

# 3. 扫描完成后插入剩余的批量结果
old_scan_done = '''        self.scanning = False
        self.stop_flag = False
        self._set_status(f"扫描完成：共{self.scanned_count}个文件，发现{len(threats)}个威胁，{len(junk)}个垃圾", C_GREEN)'''

new_scan_done = '''        self.scanning = False
        self.stop_flag = False
        # 插入剩余的批量结果
        if hasattr(self, '_pending_inserts') and self._pending_inserts:
            for vals in self._pending_inserts:
                tree.insert("", "end", values=vals, tags=(tag,))
            self._pending_inserts = []
        self._set_status(f"扫描完成：共{self.scanned_count}个文件，发现{len(threats)}个威胁，{len(junk)}个垃圾", C_GREEN)'''

if old_scan_done in c:
    c = c.replace(old_scan_done, new_scan_done, 1)
    print("3. 扫描完成后批量插入剩余结果完成")
else:
    print("3. 未找到扫描完成代码，跳过")

# 4. 启动优化：延迟加载realtime_protection（不阻塞启动）
old_rtp_init = '''        # 实时防护
        self._rtp_alert_queue = queue.Queue()
        self._rtp = realtime_protection.RealTimeProtector(alert_queue=self._rtp_alert_queue)
        self._rtp_running = False'''

new_rtp_init = '''        # 实时防护（延迟初始化，不阻塞启动）
        self._rtp_alert_queue = queue.Queue()
        self._rtp = None
        self._rtp_running = False
        self._rtp_initialized = False'''

if old_rtp_init in c:
    c = c.replace(old_rtp_init, new_rtp_init, 1)
    print("4. 实时防护延迟初始化优化完成")
else:
    print("4. 未找到实时防护初始化代码，跳过")

# 5. 启动后延迟初始化实时防护（在_build_ui之后）
old_after_ui = '''        self._build_styles()
        self._build_ui()
        self._poll_queue()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)'''

new_after_ui = '''        self._build_styles()
        self._build_ui()
        self._poll_queue()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        # 启动后延迟2秒初始化实时防护（不阻塞启动）
        self.root.after(2000, self._init_rtp_lazy)'''

if old_after_ui in c:
    c = c.replace(old_after_ui, new_after_ui, 1)
    print("5. 启动后延迟初始化实时防护完成")
else:
    print("5. 未找到_build_ui之后代码，跳过")

# 6. 添加_init_rtp_lazy方法
lazy_init_method = '''
    def _init_rtp_lazy(self):
        """延迟初始化实时防护，不阻塞启动。"""
        try:
            if not self._rtp_initialized:
                self._rtp = realtime_protection.RealTimeProtector(alert_queue=self._rtp_alert_queue)
                self._rtp_initialized = True
                # 根据配置启动
                if self._rtp.config.get("enabled", True):
                    self._rtp.start()
                    self._rtp_running = True
        except Exception:
            pass
    
'''

if 'def _init_rtp_lazy' not in c:
    c = c.replace('    def _process_rtp_alerts(self):', lazy_init_method + '    def _process_rtp_alerts(self):', 1)
    print("6. 添加_init_rtp_lazy方法完成")

# 7. 优化_process_rtp_alerts，处理_rtp为None的情况
old_rtp_alert = '''    def _process_rtp_alerts(self):
        """处理实时防护告警队列。"""
        try:
            while True:
                try:
                    alert = self._rtp_alert_queue.get_nowait()
                except queue.Empty:
                    break
                if alert.get("type") == "process_alert":
                    self._show_process_alert(alert)
        except Exception:
            pass'''

new_rtp_alert = '''    def _process_rtp_alerts(self):
        """处理实时防护告警队列。"""
        if not self._rtp_initialized:
            return
        try:
            while True:
                try:
                    alert = self._rtp_alert_queue.get_nowait()
                except queue.Empty:
                    break
                if alert.get("type") == "process_alert":
                    self._show_process_alert(alert)
        except Exception:
            pass'''

if old_rtp_alert in c:
    c = c.replace(old_rtp_alert, new_rtp_alert, 1)
    print("7. _process_rtp_alerts优化完成")

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print("\n2.6.1 性能优化完成！")
