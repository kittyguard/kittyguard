# -*- coding: utf-8 -*-
"""发布 5.2.0：快照 + 重建防篡改清单 + version.json（规则中心·检测资产总览）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "5.2.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

# 重建防篡改清单（当前安装态 = 受信任态）
sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

# 更新 version.json（更新服务器读取）
notes = {
    "latest_version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "5.2.0 内容更新：规则中心——DG 全部检测资产总览（黑名单/白名单/YARA/ClamAV/ML）+ 一键更新病毒库 + 快捷目录。",
    "features": [
        "洪流冲刷：五段流水线（预检→垃圾冲洗→病毒冲洗→残骸冲洗→冲刷报告），主界面新入口+阶段指示器+独立停止+免打扰联动",
        "垃圾冲洗只清可再生缓存（TEMP/更新缓存/缩略图/浏览器缓存/着色器），绝不碰个人文件",
        "病毒冲洗：全盘扫描走统一裁决层，高危/严重自动隔离（XOR 隔离可还原）",
        "残骸冲洗：注册表无效启动项（先导出 .reg 备份）/启动目录孤儿/隔离区残留记录清理（修复恢复报隔离文件不存在）",
        "裁决层 AI 良性降分对称化：-12→-5 且仅无行为证据时生效，AI 不抵消行为证据",
        "裁决层弱证据组合计分：不足 3 条但存在强/中证据时按 60% 计分，堵住低噪声绕过区",
        "裁决层白名单行为证据封顶收紧：行为证据存在时白名单最多压 20 分，防可信进程劫持漏报",
        "裁决层开发者上下文加强：编译产物/构建/测试目录降权（编译器/PyInstaller 产物不再误报）",
        "扫描提速：任务队列 1000→4096、IPC 批次 64→128，12 核吃满更充分",
        "进度条平滑：缓动系数 0.25→0.18、跳变阈值收窄，真进度条不再一卡一卡"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
