# -*- coding: utf-8 -*-
"""
DG 进程管理器 4.16.1（DG 特色版，不照抄任何第三方）
左侧进程列表 + 右侧实时详情面板：
  · 可疑度规则引擎（乱码进程名 / 临时目录启动 / 未知签名路径）→ 自动标红"可疑"
  · 右键菜单（终止 / 白名单 / 打开文件位置 / 复制路径 / 查看详情）
  · 一键清理全部可疑进程（带确认）
  · 自动刷新开关（默认手动，开启后每 3 秒刷新）
  · 选中进程详情：命令行 / 父进程 / 线程数 / CPU时间 / 创建时间 / 网络连接(远端IP:端口)
  · 三重保护：系统关键进程(黄) / 白名单(绿) / DG 自身进程 拒绝终止
深色科技风主题对齐 DG 4.0.0。
"""

import os
import sys
import json
import time
import re
import subprocess
import threading
import ctypes

try:
    import psutil
except ImportError:
    ctypes.windll.user32.MessageBoxW(0, "缺少 psutil 库，请执行：pip install psutil", "DG 进程管理器", 0x10)
    sys.exit(1)

# ============ 深色主题（对齐 DG 4.0.0） ============
BG      = "#0d1520"
FG      = "#d8e6f2"
DIM     = "#7fa3c0"
ACCENT  = "#00d4ff"
WARN    = "#ffb648"
DANGER  = "#ff5c5c"
CARD    = "#14202e"
CARD2   = "#1b2b3d"
BORDER  = "#22303f"
GREEN   = "#3ddc84"
SUSPECT = "#ff7d5c"

FONT     = ("Microsoft YaHei UI", 9)
FONT_B   = ("Microsoft YaHei UI", 10, "bold")
FONT_T   = ("Microsoft YaHei UI", 14, "bold")
FONT_S   = ("Microsoft YaHei UI", 8)

APP_DIR = os.path.dirname(os.path.abspath(__file__))
WL_FILE = os.path.join(APP_DIR, "whitelist_proc.json")

SYSTEM_PROTECTED_NAMES = {
    "system", "smss", "csrss", "wininit", "winlogon", "services",
    "lsass", "svchost", "wininit", "fontdrvhost", "dwm", "explorer",
    "taskhostw", "ctfmon", "conhost", "dllhost", "registry", "memory compression",
}
DG_SELF_PREFIX = ("pythonw", "python", "dg_", "scan_core")

# 乱码进程名：可打印 ASCII 字母数字占比低于 60% 视为乱码
_GARBLE_RE = re.compile(r"[A-Za-z0-9._\-\s]")


def is_garble_name(name):
    """进程名看起来是乱码（大量生僻 Unicode / 特殊字符）"""
    if not name:
        return False
    total = len(name)
    if total < 4:
        return False
    ok = len(_GARBLE_RE.findall(name))
    return ok / total < 0.6


def is_temp_dir(exe):
    """exe 位于临时目录（典型释放即跑的样本行为）"""
    if not exe:
        return False
    e = exe.lower()
    return "\\temp\\" in e or "\\appdata\\local\\temp\\" in e or e.startswith("c:\\windows\\temp")


def risk_level(name, exe):
    """DG 规则引擎：返回 ('high'|'mid'|'low', 标签)"""
    if is_garble_name(name):
        return "high", "乱码名"
    if is_temp_dir(exe):
        return "high", "临时目录"
    if exe and "\\program files" not in exe.lower() and "\\windows\\system32" not in exe.lower() \
       and "\\windows\\systemapps" not in exe.lower() and "\\windows\\syswow64" not in exe.lower():
        return "mid", "非系统目录"
    return "low", ""


_tk = None


def _init_ttk_style():
    global _tk
    try:
        import tkinter.ttk as ttk
        s = ttk.Style(_tk)
        s.theme_use("clam")
        s.configure("Treeview", background=CARD2, fieldbackground=CARD2,
                    foreground=FG, borderwidth=0, rowheight=24, font=FONT)
        s.configure("Treeview.Heading", background="#24384f", foreground=FG,
                    font=FONT_B, borderwidth=0, relief="flat")
        s.map("Treeview", background=[("selected", ACCENT)],
              foreground=[("selected", "#001018")])
        s.map("Treeview.Heading", background=[("active", "#2c4a66")])
    except Exception:
        pass


def load_whitelist():
    try:
        if os.path.exists(WL_FILE):
            with open(WL_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def save_whitelist(wl):
    try:
        with open(WL_FILE, "w", encoding="utf-8") as f:
            json.dump(wl, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def collect_processes():
    """两次采样 CPU。返回进程信息 dict 列表，含父进程 pid、创建时间、线程数、命令行"""
    procs = []
    try:
        for p in psutil.process_iter(["pid", "name", "exe", "status"]):
            procs.append(p)
    except Exception:
        pass
    for p in procs:
        try:
            p.cpu_percent(None)
        except Exception:
            pass
    time.sleep(0.15)
    rows = []
    for p in procs:
        try:
            info = p.info
            pid = info.get("pid") or 0
            name = info.get("name") or ""
            exe = info.get("exe") or ""
            status = info.get("status") or "?"
            cpu = p.cpu_percent(None)
            mem = (p.memory_info().rss or 0) / (1024 * 1024)
            try:
                ppid = p.ppid()
            except Exception:
                ppid = 0
            try:
                ct = p.create_time()
            except Exception:
                ct = 0
            try:
                nthreads = p.num_threads()
            except Exception:
                nthreads = 0
            try:
                cpu_times = p.cpu_times()
                cput = (cpu_times.user or 0) + (cpu_times.system or 0)
            except Exception:
                cput = 0
            try:
                cmdline = " ".join(p.cmdline() or [])
            except Exception:
                cmdline = ""
            rows.append({"pid": pid, "name": name, "exe": exe, "status": status,
                         "cpu": cpu, "mem": mem, "ppid": ppid, "ct": ct,
                         "threads": nthreads, "cput": cput, "cmdline": cmdline})
        except Exception:
            continue
    rows.sort(key=lambda r: r["pid"])
    return rows


class ProcessManagerWin:
    def __init__(self, root):
        self.root = root
        self.wl = load_whitelist()
        self.filter_var = tk.StringVar()
        self.auto_refresh = False
        self._net_cache = {}      # pid -> [(remote, status)]
        self._net_loading = set()
        self._build()
        self.refresh()
        self._poll_auto()

    # ---------- UI ----------
    def _build(self):
        self.root.title("DG 进程管理器")
        self.root.configure(bg=BG)
        self.root.geometry("980x660")
        try:
            self.root.iconbitmap(os.path.join(APP_DIR, "shield.ico"))
        except Exception:
            pass

        head = tk.Frame(self.root, bg=BG)
        head.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(head, text="进程管理器", bg=BG, fg=ACCENT, font=FONT_T).pack(side="left")
        tk.Label(head, text="DG 规则引擎实时标记可疑进程 · 右键操作 · 右侧详情与网络连接",
                 bg=BG, fg=DIM, font=FONT).pack(side="left", padx=(12, 0), pady=(4, 0))

        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=14, pady=2)
        tk.Label(bar, text="过滤:", bg=BG, fg=DIM, font=FONT).pack(side="left")
        self.filter_entry = tk.Entry(bar, bg=CARD2, fg=FG, insertbackground=FG,
                                     relief="flat", font=FONT, width=16)
        self.filter_entry.pack(side="left", padx=(4, 6))
        self.filter_entry.bind("<Return>", lambda e: self.refresh())
        tk.Button(bar, text="过滤", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=self.refresh).pack(side="left")
        tk.Button(bar, text="刷新", bg=ACCENT, fg="#001018", activebackground="#33e0ff",
                  relief="flat", font=FONT_B, command=self.refresh).pack(side="left", padx=(6, 0))
        self.auto_var = tk.StringVar(value="自动刷新:关")
        tk.Button(bar, textvariable=self.auto_var, bg=CARD2, fg=WARN,
                  activebackground="#24384f", relief="flat", font=FONT,
                  command=self.toggle_auto).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="按CPU↓", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=lambda: self.set_sort("cpu")).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="按内存↓", bg=CARD2, fg=FG, activebackground="#24384f",
                  relief="flat", font=FONT, command=lambda: self.set_sort("mem")).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="终止选中", bg=DANGER, fg="#ffffff", activebackground="#ff7d7d",
                  relief="flat", font=FONT_B, command=self.kill_selected).pack(side="left", padx=(6, 0))
        tk.Button(bar, text="一键清理可疑", bg="#c23b22", fg="#ffffff", activebackground="#e04a2e",
                  relief="flat", font=FONT_B, command=self.kill_suspects).pack(side="left", padx=(6, 0))

        self.info_var = tk.StringVar(value=" ")
        tk.Label(self.root, textvariable=self.info_var, bg=BG, fg=DIM,
                 font=FONT, anchor="w").pack(fill="x", padx=14, pady=(2, 4))

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=14, pady=(0, 4))

        # ---- 左：进程列表 ----
        left = tk.Frame(body, bg=BG)
        left.pack(side="left", fill="both", expand=True)
        wrap = tk.Frame(left, bg=BORDER)
        wrap.pack(fill="both", expand=True)
        cols = ("pid", "name", "cpu", "mem", "risk", "exe")
        heads = ("PID", "名称", "CPU%", "内存(MB)", "标记", "路径")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings",
                                 selectmode="browse", height=22)
        for c, h in zip(cols, heads):
            wd = 60 if c == "pid" else (55 if c in ("cpu", "mem") else (90 if c == "risk" else (180 if c == "name" else 320)))
            self.tree.heading(c, text=h)
            self.tree.column(c, width=wd, anchor="w", stretch=(c == "exe"))
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.tag_configure("sys", foreground=WARN)
        self.tree.tag_configure("wl", foreground=GREEN)
        self.tree.tag_configure("high", foreground=SUSPECT)
        self.tree.tag_configure("mid", foreground=WARN)
        self.tree.bind("<Button-3>", self._ctx_menu)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_detail())

        # ---- 右：详情面板 ----
        right = tk.Frame(body, bg=CARD, width=300)
        right.pack(side="right", fill="y")
        right.pack_propagate(False)
        tk.Label(right, text="进程详情", bg=CARD, fg=ACCENT, font=FONT_B).pack(anchor="w", padx=10, pady=(8, 2))
        self.detail_text = tk.Text(right, bg=CARD, fg=FG, font=FONT_S, relief="flat",
                                   wrap="word", state="disabled", height=14)
        self.detail_text.pack(fill="x", padx=10, pady=(0, 4))
        tk.Label(right, text="网络连接（外联地址）", bg=CARD, fg=ACCENT, font=FONT_B).pack(anchor="w", padx=10, pady=(2, 2))
        self.net_text = tk.Text(right, bg=CARD, fg=FG, font=FONT_S, relief="flat",
                                wrap="word", state="disabled", height=10)
        self.net_text.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        foot = tk.Frame(self.root, bg=BG)
        foot.pack(fill="x", padx=14, pady=(0, 10))
        tk.Label(foot, text="黄=系统关键进程(拒杀) · 绿=白名单(拒杀) · 橙/红=DG规则引擎可疑标记 · 右键进程可 终止/白名单/打开位置/复制路径",
                 bg=BG, fg=DIM, font=FONT).pack(side="left")

    # ---------- 数据 ----------
    def set_sort(self, key):
        self.sort_key = key
        self.refresh()

    def toggle_auto(self):
        self.auto_refresh = not self.auto_refresh
        self.auto_var.set("自动刷新:开" if self.auto_refresh else "自动刷新:关")
        if self.auto_refresh:
            self.refresh()

    def _poll_auto(self):
        if self.auto_refresh:
            self.refresh()
        self.root.after(3000, self._poll_auto)

    def refresh(self):
        rows = collect_processes()
        kw = (self.filter_var.get() or "").strip().lower()
        if kw:
            rows = [r for r in rows
                    if kw in (r["name"] or "").lower()
                    or kw in str(r["pid"])
                    or kw in (r["exe"] or "").lower()]
        key = getattr(self, "sort_key", None)
        if key in ("cpu", "mem"):
            rows.sort(key=lambda r: r[key], reverse=True)
        self.rows = rows
        self.tree.delete(*self.tree.get_children())
        n_high = 0
        for r in rows:
            rl, tag_txt = risk_level(r["name"], r["exe"])
            if rl == "high":
                n_high += 1
            tags = []
            if self._is_system_protected(r["name"], r["exe"]):
                tags.append("sys")
                tag_txt = "系统保护"
            elif self._is_whitelisted(r["exe"]):
                tags.append("wl")
                tag_txt = "白名单"
            elif rl == "high":
                tags.append("high")
                tag_txt = "可疑·" + tag_txt
            elif rl == "mid":
                tags.append("mid")
                tag_txt = "留意·" + tag_txt
            self.tree.insert("", "end", iid=str(r["pid"]),
                             values=(r["pid"], r["name"], round(r["cpu"], 1),
                                     round(r["mem"], 1), tag_txt, r["exe"] or ""),
                             tags=tuple(tags))
        self.info_var.set(f"共 {len(rows)} 个进程 ｜ 可疑 {n_high} 个"
                          + (f"（过滤：{kw}）" if kw else "")
                          + (" ｜ 自动刷新开启" if self.auto_refresh else ""))
        # 清空网络连接缓存（进程可能已变）
        self._net_cache = {}

    def _is_system_protected(self, name, exe):
        return (name or "").lower() in SYSTEM_PROTECTED_NAMES

    def _is_whitelisted(self, exe):
        return bool(exe) and exe.lower() in self.wl

    # ---------- 详情 ----------
    def _selected_row(self):
        sel = self.tree.selection()
        if not sel:
            return None
        pid = int(sel[0])
        for r in getattr(self, "rows", []):
            if r["pid"] == pid:
                return r
        return None

    def show_detail(self):
        r = self._selected_row()
        if r is None:
            return
        lines = [
            f"名称     {r['name']}",
            f"PID      {r['pid']}（父进程 {r['ppid']}）",
            f"状态     {r['status']}",
            f"CPU      {r['cpu']:.1f}% ｜ 累计 {r['cput']:.1f}s",
            f"内存     {r['mem']:.1f} MB ｜ 线程 {r['threads']}",
            f"路径     {r['exe'] or '(系统/无路径)'}",
        ]
        rl, tag = risk_level(r["name"], r["exe"])
        if self._is_system_protected(r["name"], r["exe"]):
            lines.append("标记     系统关键进程（受保护）")
        elif self._is_whitelisted(r["exe"]):
            lines.append("标记     白名单（受保护）")
        elif rl == "high":
            lines.append(f"标记     可疑（{tag}）—— 建议立即处理")
        elif rl == "mid":
            lines.append(f"标记     留意（{tag}）")
        else:
            lines.append("标记     正常")
        if r["ct"]:
            lines.append(f"启动     {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(r['ct']))}")
        if r["cmdline"]:
            cl = r["cmdline"]
            lines.append("命令行   " + (cl if len(cl) <= 120 else cl[:117] + "..."))
        self._set_text(self.detail_text, "\n".join(lines))
        self._load_net(r["pid"])

    def _load_net(self, pid):
        if pid in self._net_loading:
            return
        self._net_loading.add(pid)
        self._set_text(self.net_text, "查询网络连接中…")
        threading.Thread(target=self._net_worker, args=(pid,), daemon=True).start()

    def _net_worker(self, pid):
        try:
            conns = [c for c in psutil.net_connections(kind="inet") if c.pid == pid]
            outs = []
            for c in conns:
                if c.status == "ESTABLISHED" and c.raddr:
                    outs.append(f"{c.raddr.ip}:{c.raddr.port}  ESTABLISHED")
                elif c.raddr:
                    outs.append(f"{c.raddr.ip}:{c.raddr.port}  {c.status}")
            if not outs:
                outs = ["（无外联连接 / 权限不足）"]
            self._net_cache[pid] = outs
        except Exception:
            self._net_cache[pid] = ["（查询失败）"]
        self._net_loading.discard(pid)
        try:
            self.root.after(0, self._show_net, pid)
        except Exception:
            pass

    def _show_net(self, pid):
        if self._selected_row() and self._selected_row()["pid"] == pid:
            self._set_text(self.net_text, "\n".join(self._net_cache.get(pid, ["（无）"])))

    def _set_text(self, w, s):
        try:
            w.configure(state="normal")
            w.delete("1.0", "end")
            w.insert("1.0", s)
            w.configure(state="disabled")
        except Exception:
            pass

    # ---------- 右键菜单 ----------
    def _ctx_menu(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        self.tree.selection_set(iid)
        r = self._selected_row()
        if r is None:
            return
        m = tk.Menu(self.root, tearoff=0, bg=CARD2, fg=FG, activebackground=ACCENT,
                    activeforeground="#001018", font=FONT)
        m.add_command(label=f"终止进程  {r['name']}", command=self.kill_selected)
        m.add_command(label="加入/查看白名单", command=self.add_whitelist)
        if r["exe"]:
            m.add_command(label="打开文件位置", command=lambda: self._open_location(r["exe"]))
            m.add_command(label="复制路径", command=lambda: self._copy_text(r["exe"]))
        m.add_command(label="复制名称", command=lambda: self._copy_text(r["name"]))
        m.tk_popup(event.x_root, event.y_root)

    def _open_location(self, exe):
        try:
            subprocess.Popen(["explorer", "/select,", exe])
        except Exception:
            pass

    def _copy_text(self, t):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(t)
            self.info_var.set(f"已复制：{t[:60]}")
        except Exception:
            pass

    # ---------- 终止 ----------
    def kill_selected(self):
        r = self._selected_row()
        if r is None:
            messagebox.showinfo("终止进程", "请先在列表中选择一个进程。", parent=self.root)
            return
        name, exe, pid = r["name"], r["exe"], r["pid"]
        if self._is_system_protected(name, exe):
            messagebox.showwarning("终止进程", f"「{name}」是系统关键进程，已保护，拒绝终止。", parent=self.root)
            return
        if self._is_whitelisted(exe):
            messagebox.showwarning("终止进程", f"「{name}」在白名单中，拒绝终止。", parent=self.root)
            return
        if name.lower().startswith(DG_SELF_PREFIX):
            messagebox.showwarning("终止进程", "这是 DG 安全自身的进程，受守护自愈保护，不在本工具终止范围内。", parent=self.root)
            return
        if not messagebox.askyesno("终止进程",
                                   f"确认终止？\n\n名称：{name}\nPID：{pid}\n路径：{exe}\n\n先优雅退出，超时后强制结束（含子进程）。",
                                   parent=self.root):
            return
        threading.Thread(target=self._kill_worker, args=(pid, name), daemon=True).start()

    def kill_suspects(self):
        suspects = []
        for r in getattr(self, "rows", []):
            rl, tag = risk_level(r["name"], r["exe"])
            if rl == "high" and not self._is_system_protected(r["name"], r["exe"]) \
               and not self._is_whitelisted(r["exe"]) \
               and not r["name"].lower().startswith(DG_SELF_PREFIX):
                suspects.append(r)
        if not suspects:
            messagebox.showinfo("一键清理", "当前没有检测到可疑进程。", parent=self.root)
            return
        txt = "\n".join(f"  {r['pid']}  {r['name']}（{risk_level(r['name'], r['exe'])[1]}）" for r in suspects[:15])
        if len(suspects) > 15:
            txt += f"\n  …另有 {len(suspects) - 15} 个"
        if not messagebox.askyesno("一键清理可疑",
                                   f"DG 规则引擎检测到 {len(suspects)} 个可疑进程（乱码名/临时目录释放）：\n\n{txt}\n\n确认全部终止？",
                                   parent=self.root):
            return
        threading.Thread(target=self._kill_many, args=([r["pid"] for r in suspects],), daemon=True).start()

    def _kill_many(self, pids):
        ok = fail = 0
        for pid in pids:
            try:
                p = psutil.Process(pid)
                try:
                    p.terminate()
                    p.wait(timeout=2)
                    ok += 1
                    continue
                except Exception:
                    pass
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                               capture_output=True, timeout=6)
                ok += 1
            except Exception:
                fail += 1
        self._ui_done(f"一键清理完成：成功 {ok}，失败 {fail}")
        self.root.after(300, self.refresh)

    def _kill_worker(self, pid, name):
        try:
            p = psutil.Process(pid)
            try:
                p.terminate()
                p.wait(timeout=3)
                self._ui_done(f"已优雅终止「{name}」(PID {pid})")
                return
            except Exception:
                pass
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                               capture_output=True, timeout=8)
                self._ui_done(f"已强制终止「{name}」(PID {pid})")
            except Exception:
                self._ui_done(f"终止「{name}」失败：进程可能已退出或权限不足")
        except Exception:
            self._ui_done(f"「{name}」(PID {pid}) 已不存在")
        self.root.after(300, self.refresh)

    def _ui_done(self, msg):
        try:
            self.root.after(0, lambda: self.info_var.set(msg))
        except Exception:
            pass

    def add_whitelist(self):
        r = self._selected_row()
        if r is None:
            messagebox.showinfo("加入白名单", "请先在列表中选择一个进程。", parent=self.root)
            return
        exe, name = r["exe"], r["name"]
        if not exe:
            messagebox.showerror("加入白名单", "该进程没有可执行文件路径，无法加入白名单。", parent=self.root)
            return
        if self._is_whitelisted(exe):
            messagebox.showinfo("加入白名单", f"「{name}」已在白名单中。", parent=self.root)
            return
        if not messagebox.askyesno("加入白名单",
                                   f"将「{name}」加入白名单后，DG 将拒绝终止它。\n\n路径：{exe}\n\n确认？",
                                   parent=self.root):
            return
        self.wl[exe.lower()] = name
        save_whitelist(self.wl)
        self.info_var.set(f"已加入白名单：{name}")
        self.refresh()


def main():
    global tk, messagebox, ttk
    import tkinter as tk
    import tkinter.messagebox as messagebox
    import tkinter.ttk as ttk
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def cb(h, l):
        if ctypes.windll.user32.IsWindowVisible(h):
            buf = ctypes.create_unicode_buffer(256)
            ctypes.windll.user32.GetWindowTextW(h, buf, 256)
            if "DG 进程管理器" in buf.value:
                found.append(h)
        return True
    try:
        ctypes.windll.user32.EnumWindows(cb, 0)
    except Exception:
        pass
    if found:
        try:
            ctypes.windll.user32.ShowWindow(found[0], 9)
            ctypes.windll.user32.SetForegroundWindow(found[0])
        except Exception:
            pass
        return

    root = tk.Tk()
    _tk = root
    _init_ttk_style()
    app = ProcessManagerWin(root)
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.mainloop()


if __name__ == "__main__":
    main()
