# -*- coding: utf-8 -*-
"""git commit + push 6.4.2 到 kittyguard Pages（走代理 + PAT）"""
import os, subprocess, sys

SITE = r"F:\桌面保护\kittyguard_site"
PAT = "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"
REMOTE = "https://x-access-token:%s@github.com/kittyguard/kittyguard.git" % PAT
PROXY = "http://127.0.0.1:33210"

env = dict(os.environ)
env["HTTPS_PROXY"] = PROXY
env["HTTP_PROXY"] = PROXY
# 凭据不要进入 git 历史/日志
env.pop("GIT_ASKPASS", None)

def run(cmd, timeout=180):
    r = subprocess.run(cmd, cwd=SITE, env=env, capture_output=True, text=True,
                       encoding="utf-8", errors="ignore", timeout=timeout)
    out = (r.stdout or "") + (r.stderr or "")
    print("$", " ".join(cmd))
    print(out[-1500:])
    print("rc:", r.returncode)
    return r.returncode

# 更新 remote（用 token）
run(["git", "remote", "set-url", "origin", REMOTE])
# add 6.4.2 新文件 + 修改
run(["git", "add", "-A"])
run(["git", "status", "--short"])
r = run(["git", "commit", "-m", "release 6.4.2: fix self-quarantine of portable _internal DLLs", "--allow-empty"])
if r != 0:
    print("commit failed")
    sys.exit(1)
r = run(["git", "push", "origin", "HEAD"])
print("PUSH_DONE rc=", r)
