# -*- coding: utf-8 -*-
with open('main.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# 找到第945-947行（索引944-946），修复f-string换行
# 第945行: msg = f"【实时防护告警】
# 第946行: (空行)
# 第947行: "

for i in range(len(lines)):
    if 'msg = f"【实时防护告警】' in lines[i]:
        print(f"找到问题行 {i+1}: {repr(lines[i])}")
        # 替换这三行
        lines[i] = '            msg = "【实时防护告警】\\n\\n"\n'
        # 删除后面两行（空行和引号行）
        if i+1 < len(lines) and lines[i+1].strip() == '':
            del lines[i+1]
        if i+1 < len(lines) and lines[i+1].strip() == '"':
            del lines[i+1]
        print("已修复")
        break

with open('main.py', 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("修复完成")
