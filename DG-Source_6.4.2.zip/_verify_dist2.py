# -*- coding: utf-8 -*-
import os, json, py_compile

DG = r"F:\桌面保护\desktopguard"

# 1) 修复版 main.py 可编译
try:
    py_compile.compile(os.path.join(DG, "main.py"), doraise=True)
    print("[OK] main.py 语法编译通过")
except py_compile.PyCompileError as e:
    print("[FAIL] main.py 编译失败:", e)

# 2) dist 内 version.json 是否为修复版
vj_path = os.path.join(DG, "dist", "DG安全", "_internal", "version.json")
with open(vj_path, "r", encoding="utf-8") as f:
    vj = json.load(f)
print("[OK] dist _internal/version.json:")
print("  latest_version:", vj.get("latest_version"))
print("  pkg:", vj.get("pkg", "")[:60], "...")
print("  sha256:", vj.get("sha256"))

# 3) exe 内搜索 update_source 的 pyc 变体（UTF-16 或直接字符串，再兜底搜 'github.io'）
for probe in [b"kittyguard.github.io", b"github.io", b"update_source"]:
    with open(os.path.join(DG, "dist", "DG安全", "DG安全.exe"), "rb") as f:
        data = f.read()
    print("exe contains %r: %s" % (probe, probe in data))
