@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   DG 安全 — 应急恢复（恢复到最新版 3.3.2）
echo ============================================
"C:\Users\Administrator\AppData\Local\Doubao\User Data\sandbox_runtime\bases\c98c5042338ed152c6f10ecd8591889f\python\python.exe" restore_latest.py
