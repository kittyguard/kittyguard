# -*- coding: utf-8 -*-
"""DG 数据目录统一配置（6.4.3 起：不再写死本机路径，多级自适应）。
候选顺序（第一个可创建的即生效）：
  1. 环境变量 DG_DATA_DIR（用户/管理员显式指定）
  2. 程序目录内 dgdata（打包向导版：{app}/_internal/dgdata，随包携带）
  3. 程序目录上一级 dgdata（开发：F:/桌面保护/dgdata；安装版：{app}/dgdata）
  4. 历史兼容：F:/桌面保护/dgdata（旧版安装遗留）
  5. %APPDATA%\DGDesktopGuard（任意电脑兜底）
保证在任何电脑（虚拟机/他人电脑/U 盘便携）上都能定位到完整数据目录。"""
import os


def _resolve_data_dir():
    _here = os.path.dirname(os.path.abspath(__file__))
    cands = []
    env = os.environ.get("DG_DATA_DIR")
    if env:
        cands.append(env)
    cands.append(os.path.join(_here, "dgdata"))                          # 打包: {app}\_internal\dgdata
    cands.append(os.path.abspath(os.path.join(_here, "..", "dgdata")))   # 开发: F:\桌面保护\dgdata；安装版: {app}\dgdata
    cands.append(r"F:\桌面保护\dgdata")                                  # 历史兼容
    cands.append(os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "DGDesktopGuard"))
    for c in cands:
        try:
            os.makedirs(c, exist_ok=True)
            return c
        except Exception:
            continue
    return os.path.expanduser("~")


DATA_DIR = _resolve_data_dir()


def ensure_data_dir():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        return DATA_DIR
    except Exception:
        return DATA_DIR
