# -*- coding: utf-8 -*-
"""发布 4.21.0：快照 + 重建防篡改清单 + version.json（稳定版 P0 修复）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "4.21.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

# 重建防篡改清单（当前安装态 = 受信任态）
sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

# 更新 version.json（更新服务器读取）
notes = {
    "latest_version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "4.21.0 稳定版：P0 稳定性修复 + 组件健康检查——设置页构建异常不再静默吞掉（自动写 settings_error.log + 弹窗）；扫描预统计加 3 秒超时/5 万上限根治'正在初始化扫描引擎'长时间卡死；新增 component_health.json 组件健康检查（9 个 C++ 组件 + clamd 存在性/哈希/状态）；停止按钮 2 秒看门狗强制终止进程池；开机自启强制 pythonw.exe 根治启动黑框（含历史注册自动修复）",
    "features": [
        "设置页开关消失根治（安全渲染包装 + 异常日志）",
        "扫描初始化卡死修复（预统计超时 + 实时进度回退）",
        "组件健康检查 component_health.json",
        "停止按钮 2 秒看门狗（强制终止进程池）",
        "启动黑框根治（自启强制 pythonw.exe）"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
