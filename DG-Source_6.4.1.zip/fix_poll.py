# -*- coding: utf-8 -*-
with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 在 _poll_queue 方法开头添加处理rtp告警
old = '''    def _poll_queue(self):
        try:
            while True:
                item = self.msg_q.get_nowait()'''

new = '''    def _poll_queue(self):
        # 处理实时防护告警
        self._process_rtp_alerts()
        try:
            while True:
                item = self.msg_q.get_nowait()'''

if old in c:
    c = c.replace(old, new, 1)
    print('_poll_queue 添加处理rtp告警成功')
else:
    print('未找到匹配，尝试其他方式...')
    idx = c.find('    def _poll_queue(self):')
    if idx > 0:
        # 找到下一个 try:
        try_idx = c.find('try:', idx)
        if try_idx > 0:
            c = c[:try_idx] + '        # 处理实时防护告警\n        self._process_rtp_alerts()\n' + c[try_idx:]
            print('通过位置插入成功')

# 在设置页面的启动设置前面添加实时防护设置
old_settings = '''        # ---- 启动设置 ----
        box = section("启动设置")'''

new_settings = '''        # ---- 实时防护设置 ----
        box = section("实时防护")
        rtp_frame = tk.Frame(box, bg=C_CARD2)
        rtp_frame.pack(fill="x", pady=4)
        
        rtp_switch_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        rtp_switch_frame.pack(fill="x", pady=2)
        tk.Label(rtp_switch_frame, text="启用实时防护（后台监控进程）", bg=C_CARD2, fg=C_TEXT,
                font=("Microsoft YaHei UI", 10)).pack(side="left")
        
        rtp_enabled = self._rtp.config.get("enabled", True)
        rtp_switch_var = StringVar(value="开" if rtp_enabled else "关")
        rtp_switch_btn = tk.Button(rtp_switch_frame, textvariable=rtp_switch_var, width=6,
                                   bg=(C_GREEN if rtp_enabled else C_SUB), fg="white",
                                   activebackground=(C_GREEN if rtp_enabled else C_SUB),
                                   activeforeground="white", font=("Microsoft YaHei UI", 9, "bold"),
                                   relief="flat", cursor="hand2")
        rtp_switch_btn.pack(side="right")
        
        def toggle_rtp():
            current = rtp_switch_var.get()
            if current == "开":
                rtp_switch_var.set("关")
                rtp_switch_btn.config(bg=C_SUB, activebackground=C_SUB)
                self._rtp.config["enabled"] = False
                self._rtp.save_config()
                if self._rtp.running:
                    self._rtp.stop()
            else:
                rtp_switch_var.set("开")
                rtp_switch_btn.config(bg=C_GREEN, activebackground=C_GREEN)
                self._rtp.config["enabled"] = True
                self._rtp.save_config()
                if not self._rtp.running:
                    self._rtp.start()
        rtp_switch_btn.config(command=toggle_rtp)
        
        interval_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        interval_frame.pack(fill="x", pady=2)
        tk.Label(interval_frame, text="进程扫描间隔（秒）", bg=C_CARD2, fg=C_TEXT,
                font=("Microsoft YaHei UI", 10)).pack(side="left")
        interval_var = StringVar(value=str(self._rtp.config.get("scan_interval", 5)))
        interval_spin = tk.Spinbox(interval_frame, from_=3, to=30, width=8,
                                   textvariable=interval_var, font=("Microsoft YaHei UI", 10),
                                   bg=C_CARD, fg=C_TEXT, relief="flat")
        interval_spin.pack(side="right")
        
        def save_interval(*args):
            try:
                val = int(interval_var.get())
                if 3 <= val <= 30:
                    self._rtp.config["scan_interval"] = val
                    self._rtp.save_config()
            except Exception:
                pass
        interval_var.trace_add("write", save_interval)
        
        auto_kill_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        auto_kill_frame.pack(fill="x", pady=2)
        tk.Label(auto_kill_frame, text="自动结束高危进程（谨慎开启）", bg=C_CARD2, fg=C_TEXT,
                font=("Microsoft YaHei UI", 10)).pack(side="left")
        
        auto_kill_enabled = self._rtp.config.get("auto_kill_high_risk", False)
        auto_kill_var = StringVar(value="开" if auto_kill_enabled else "关")
        auto_kill_btn = tk.Button(auto_kill_frame, textvariable=auto_kill_var, width=6,
                                  bg=(C_RED if auto_kill_enabled else C_SUB), fg="white",
                                  activebackground=(C_RED if auto_kill_enabled else C_SUB),
                                  activeforeground="white", font=("Microsoft YaHei UI", 9, "bold"),
                                  relief="flat", cursor="hand2")
        auto_kill_btn.pack(side="right")
        
        def toggle_auto_kill():
            current = auto_kill_var.get()
            if current == "开":
                auto_kill_var.set("关")
                auto_kill_btn.config(bg=C_SUB, activebackground=C_SUB)
                self._rtp.config["auto_kill_high_risk"] = False
            else:
                auto_kill_var.set("开")
                auto_kill_btn.config(bg=C_RED, activebackground=C_RED)
                self._rtp.config["auto_kill_high_risk"] = True
            self._rtp.save_config()
        auto_kill_btn.config(command=toggle_auto_kill)
        
        rtp_status_frame = tk.Frame(rtp_frame, bg=C_CARD2)
        rtp_status_frame.pack(fill="x", pady=(8, 0))
        self._rtp_status_label = tk.Label(rtp_status_frame, text="", bg=C_CARD2, fg=C_SUB,
                                          font=("Microsoft YaHei UI", 9), justify="left", anchor="w")
        self._rtp_status_label.pack(fill="x")
        self._update_rtp_status()
        
        # ---- 启动设置 ----
        box = section("启动设置")'''

if old_settings in c:
    c = c.replace(old_settings, new_settings, 1)
    print('设置页面添加实时防护设置成功')
else:
    print('未找到设置页面匹配')

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print('修复完成')
