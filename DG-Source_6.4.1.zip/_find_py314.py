# -*- coding: utf-8 -*-
import os, glob

# 搜所有盘 python.exe 与 python314.dll
roots = [chr(c) + ':\\' for c in range(ord('C'), ord('F') + 1)]
hits = []
for root in roots:
    if not os.path.exists(root):
        continue
    for base in ['Program Files', 'Program Files (x86)', 'ProgramData', 'Users', 'Python', 'Python314', 'tools', 'Anaconda', 'anaconda3']:
        p = os.path.join(root, base)
        if not os.path.isdir(p):
            continue
        for pat in ['python.exe', 'python314.dll']:
            for f in glob.glob(os.path.join(p, '**', pat), recursive=True):
                hits.append(f)

for h in sorted(set(hits)):
    try:
        sz = os.path.getsize(h)
        print("%10d  %s" % (sz, h))
    except OSError:
        print("       ?  %s" % h)
