# -*- coding: utf-8 -*-
"""发布 4.19.0：快照（含 ML 模型文件）+ 重建防篡改清单"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "4.19.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件（含模型 %s/%s）" % (
    NEW_VER, copied,
    "ml_model.joblib" if os.path.isfile(os.path.join(DG, "ml_model.joblib")) else "缺joblib",
    "ml_model.onnx" if os.path.isfile(os.path.join(DG, "ml_model.onnx")) else "缺onnx"))

# 重建防篡改清单（当前安装态 = 受信任态）
sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")
