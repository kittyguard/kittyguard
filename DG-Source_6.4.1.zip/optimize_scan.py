# -*- coding: utf-8 -*-
"""
扫描性能全面优化 + AI实时辅助
1. 减少线程数（深度2线程，快速/高级3线程）
2. 消费者线程添加sleep，让CPU喘息
3. 限制大文件读取（>10MB只读头尾各1MB）
4. 优化GUI更新频率（每500个文件更新一次）
5. AI实时辅助：高危/严重文件自动AI分析
"""

with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# ===== 1. 优化线程数：根据扫描模式动态调整 =====
old_worker_count = '''        # ===== 真正的算法优化：4线程并行扫描 =====
        import threading
        import queue as _queue
        WORKER_COUNT = 4
        task_q = _queue.Queue(maxsize=2000)'''

new_worker_count = '''        # ===== 算法优化：动态线程数（深度2线程防卡顿，快速/高级3线程）=====
        import threading
        import queue as _queue
        if mode == "deep":
            WORKER_COUNT = 2  # 深度扫描用2线程，避免CPU/IO占满导致未响应
        elif mode == "quick":
            WORKER_COUNT = 3  # 快速扫描用3线程，兼顾速度
        else:
            WORKER_COUNT = 3  # 高级扫描用3线程
        task_q = _queue.Queue(maxsize=1000)  # 减小队列，避免内存占用'''

c = c.replace(old_worker_count, new_worker_count, 1)
print('1. 动态线程数优化完成')

# ===== 2. 消费者线程添加sleep =====
old_consumer = '''        # 消费者线程：从任务队列取出文件路径，扫描，把结果放入结果队列
        def _consumer():
            while True:
                p = task_q.get()
                if p is None:
                    break
                if stop_event.is_set() or self.stop_flag:
                    continue
                try:
                    r = scanner.scan_file(p)
                except Exception:
                    r = engine.ScanResult(path=p, name=os.path.basename(p),
                                          ext=os.path.splitext(p)[1].lower(),
                                          category="普通文件", size=0, sha256="")
                result_q.put(("result", r))'''

new_consumer = '''        # 消费者线程：从任务队列取出文件路径，扫描，把结果放入结果队列
        def _consumer():
            _processed = 0
            while True:
                p = task_q.get()
                if p is None:
                    break
                if stop_event.is_set() or self.stop_flag:
                    continue
                try:
                    r = scanner.scan_file(p)
                except Exception:
                    r = engine.ScanResult(path=p, name=os.path.basename(p),
                                          ext=os.path.splitext(p)[1].lower(),
                                          category="普通文件", size=0, sha256="")
                result_q.put(("result", r))
                _processed += 1
                # 每处理50个文件sleep 5ms，让CPU喘息，避免占满导致未响应
                if _processed % 50 == 0:
                    time.sleep(0.005)'''

c = c.replace(old_consumer, new_consumer, 1)
print('2. 消费者线程sleep优化完成')

# ===== 3. 优化GUI更新频率：从200改为500 =====
old_progress = '''            if self.scanned_count - last_progress >= 200 or self.stop_flag:
                last_progress = self.scanned_count
                self.msg_q.put(("progress", self.scanned_count, len(threats), len(junk), "", r.path))'''

new_progress = '''            if self.scanned_count - last_progress >= 500 or self.stop_flag:
                last_progress = self.scanned_count
                self.msg_q.put(("progress", self.scanned_count, len(threats), len(junk), "", r.path))'''

c = c.replace(old_progress, new_progress, 1)
print('3. GUI更新频率优化完成（200->500）')

# ===== 4. 限制大文件读取：修改Scanner的max_hash_size =====
old_scanner = '''        scanner = engine.Scanner(deep_strings=(mode == "deep"),
                                 hash_all=(mode != "quick"),
                                 max_hash_size=(50 * 1024 * 1024 if mode == "strong"
                                                else 200 * 1024 * 1024))'''

new_scanner = '''        # 限制大文件读取：深度扫描最多读50MB，高级最多读20MB，快速最多读10MB
        # 避免大文件读取占满IO导致未响应
        if mode == "deep":
            _max_hash = 50 * 1024 * 1024  # 50MB
        elif mode == "strong":
            _max_hash = 20 * 1024 * 1024  # 20MB
        else:
            _max_hash = 10 * 1024 * 1024  # 10MB
        scanner = engine.Scanner(deep_strings=(mode == "deep"),
                                 hash_all=(mode != "quick"),
                                 max_hash_size=_max_hash)'''

c = c.replace(old_scanner, new_scanner, 1)
print('4. 大文件读取限制优化完成')

# ===== 5. 跳过大文件阈值：从500MB改为200MB =====
old_skip = '''        # 跳过大文件的阈值（MB），0 表示不跳过
        skip_size = self.config.get("skip_larger_than_mb", 500)'''

new_skip = '''        # 跳过大文件的阈值（MB），0 表示不跳过
        skip_size = self.config.get("skip_larger_than_mb", 200)'''

c = c.replace(old_skip, new_skip, 1)
print('5. 大文件跳过阈值优化完成（500MB->200MB）')

# ===== 6. AI实时辅助：扫描完成后，对高危/严重文件自动AI分析 =====
# 在扫描完成后（self.msg_q.put(("done", ...)) 之前）添加AI分析
old_done = '''        self.msg_q.put(("done", self.scanned_count, len(threats), len(junk)))'''

new_done = '''        # ===== AI实时辅助：对高危/严重文件自动AI分析（后台线程，不阻塞UI）=====
        if not self.stop_flag and threats:
            _high_risk = [r for r in threats if r.level in (engine.LEVEL_CRITICAL, engine.LEVEL_HIGH)]
            if _high_risk:
                self.msg_q.put(("status", f"AI正在分析 {len(_high_risk)} 个高危文件…", C_PRIMARY))
                # 启动AI分析线程（最多同时分析5个，避免API费用过高）
                def _ai_analyze_batch():
                    try:
                        from engine import _ai_check as _ai_check_fn
                        _analyzed = 0
                        for r in _high_risk[:10]:  # 最多分析10个高危文件
                            if self.stop_flag:
                                break
                            try:
                                _ai_result = _ai_check_fn(r)
                                if _ai_result:
                                    r.ai_verdict = _ai_result.get("verdict", "")
                                    r.ai_reason = _ai_result.get("reason", "")
                                    r.ai_confidence = _ai_result.get("confidence", 0)
                                    _analyzed += 1
                            except Exception:
                                pass
                            time.sleep(0.2)  # 避免API调用过快
                        self.msg_q.put(("ai_done", _analyzed))
                    except Exception:
                        self.msg_q.put(("ai_done", 0))
                threading.Thread(target=_ai_analyze_batch, daemon=True).start()
        
        self.msg_q.put(("done", self.scanned_count, len(threats), len(junk)))'''

c = c.replace(old_done, new_done, 1)
print('6. AI实时辅助功能添加完成')

# ===== 7. 在_poll_queue里处理ai_done消息 =====
old_poll_done = '''                elif kind == "done":
                    _, n, t, j = item
                    self.scanning = False
                    self.progress.stop()
                    self.btn_start.config(state="normal")
                    self.btn_stop.config(state="disabled")
                    self.btn_del_sel.config(state="normal")
                    self.btn_del_all.config(state="normal")
                    self.btn_clean_junk.config(state="normal")
                    self._set_status(f"扫描完成：共 {n} 个文件，发现 {t} 个威胁，{j} 个垃圾", C_GREEN)
                    self._flush_refresh(force=True)'''

new_poll_done = '''                elif kind == "ai_done":
                    _ai_count = item[1]
                    if _ai_count > 0:
                        self._set_status(f"AI分析完成：已分析 {_ai_count} 个高危文件", C_PRIMARY)
                        self._flush_refresh(force=True)
                elif kind == "done":
                    _, n, t, j = item
                    self.scanning = False
                    self.progress.stop()
                    self.btn_start.config(state="normal")
                    self.btn_stop.config(state="disabled")
                    self.btn_del_sel.config(state="normal")
                    self.btn_del_all.config(state="normal")
                    self.btn_clean_junk.config(state="normal")
                    self._set_status(f"扫描完成：共 {n} 个文件，发现 {t} 个威胁，{j} 个垃圾", C_GREEN)
                    self._flush_refresh(force=True)'''

if old_poll_done in c:
    c = c.replace(old_poll_done, new_poll_done, 1)
    print('7. _poll_queue处理ai_done消息完成')
else:
    print('7. 未找到_poll_done匹配，跳过')

# ===== 8. 升级版本号到2.5.0（内容更新：扫描性能优化+AI实时辅助）=====
c = c.replace('APP_VERSION = "2.4.2"', 'APP_VERSION = "2.5.0"', 1)
c = c.replace(
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2", "2.4.0", "2.4.1", "2.4.2"]',
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2", "2.4.0", "2.4.1", "2.4.2", "2.5.0"]'
)

old_history = '''VERSION_HISTORY = [
    ("2.4.2"'''
new_history = '''VERSION_HISTORY = [
    ("2.5.0", "内容更新：扫描性能全面优化+AI实时辅助。1.动态线程数（深度2线程防卡顿，快速/高级3线程）；2.消费者线程每50个文件sleep 5ms，让CPU喘息；3.限制大文件读取（深度50MB/高级20MB/快速10MB）；4.大文件跳过阈值从500MB降到200MB；5.GUI更新频率从200个文件改为500个；6.AI实时辅助：扫描完成后自动对高危/严重文件调用AI分析（最多10个），AI结果实时显示；7.任务队列maxsize从2000降到1000，减少内存占用"),
    ("2.4.2"'''
c = c.replace(old_history, new_history, 1)
print('8. 版本号升级到2.5.0完成')

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)

print('\n扫描性能优化+AI实时辅助完成！')
