# -*- coding: utf-8 -*-
"""
DG 右键菜单集成工具 (dg_context.py)
用法:
  dg_context.py panel   <file>   -> 完整操作面板(默认, 右键入口)
  dg_context.py verdict <file>   -> C++ 判定引擎快速判定
  dg_context.py scan    <file>   -> 深度扫描(scan_core)
  dg_context.py isolate <file>   -> 移入隔离区
  dg_context.py openloc <file>   -> 打开所在位置
  dg_context.py install          -> 安装/更新右键菜单(单入口)
注册表右键菜单挂载点: HKCU\\Software\\Classes\\*\\shell\\DG安全
"""
import sys
import os
import json
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, messagebox

BASE = os.path.dirname(os.path.abspath(__file__))
V4 = os.path.join(BASE, "versions", "4.1.0")
VERDICT = os.path.join(BASE, "dg_verdict.exe")
SCAN = os.path.join(BASE, "scan_core.exe")
QUAR = os.path.join(BASE, "dg_quarantine.exe")
QUAR_DIR = os.path.join(V4, "quarantine")
QUAR_META = os.path.join(QUAR_DIR, "_meta")

ACCENT = "#1f6feb"
BG = "#f5f6fa"
CARD = "#ffffff"


def run(exe, args, timeout=60):
    """运行外部程序, 返回 (code, stdout, stderr)"""
    try:
        p = subprocess.run([exe] + args, capture_output=True, timeout=timeout,
                           creationflags=subprocess.CREATE_NO_WINDOW)
        return p.returncode, p.stdout.decode("utf-8", "ignore"), p.stderr.decode("utf-8", "ignore")
    except Exception as e:
        return -1, "", str(e)


def verdict_text(path):
    code, out, err = run(VERDICT, [path])
    if code != 0:
        return {"level": "错误", "score": 0, "raw": err or out}
    try:
        return json.loads(out)
    except Exception:
        return {"level": "错误", "score": 0, "raw": out[:500]}


class DgPanel:
    def __init__(self, path):
        self.path = path
        self.root = tk.Tk()
        self.root.title("DG 安全 - 右键操作")
        self.root.configure(bg=BG)
        self.root.geometry("560x440")
        self.root.resizable(False, False)
        self._build()
        self.root.after(200, self._auto_verdict)

    def _build(self):
        name = os.path.basename(self.path)
        try:
            size = os.path.getsize(self.path)
        except OSError:
            size = 0
        size_txt = f"{size/1024:.1f} KB" if size < 1024*1024 else f"{size/1024/1024:.2f} MB"

        tk.Label(self.root, text="DG 安全  ·  文件操作", font=("Microsoft YaHei UI", 15, "bold"),
                 bg=BG, fg="#111").pack(anchor="w", padx=18, pady=(16, 2))
        tk.Label(self.root, text=f"{name}   ·   {size_txt}", font=("Microsoft YaHei UI", 9),
                 bg=BG, fg="#666").pack(anchor="w", padx=18)

        # 判定结果卡
        card = tk.Frame(self.root, bg=CARD, highlightthickness=1, highlightbackground="#e3e6ea")
        card.pack(fill="x", padx=18, pady=12)
        self.lv = tk.Label(card, text="正在判定…", font=("Microsoft YaHei UI", 12, "bold"),
                           bg=CARD, fg="#666")
        self.lv.pack(anchor="w", padx=14, pady=(10, 2))
        self.lh = tk.Label(card, text="", font=("Microsoft YaHei UI", 9), bg=CARD, fg="#888",
                           justify="left", anchor="w")
        self.lh.pack(anchor="w", padx=14, pady=(0, 10))

        # 路径显示
        tk.Label(self.root, text="完整路径:", font=("Microsoft YaHei UI", 9),
                 bg=BG, fg="#999").pack(anchor="w", padx=18)
        tk.Label(self.root, text=self.path, font=("Consolas", 8), bg=BG, fg="#555",
                 justify="left", anchor="w", wraplength=520).pack(anchor="w", padx=18)

        # 按钮
        btns = tk.Frame(self.root, bg=BG)
        btns.pack(fill="x", padx=18, pady=14)
        self._btn(btns, "移入隔离区", self._isolate, "#d93025")
        self._btn(btns, "深度扫描", self._scan, ACCENT)
        self._btn(btns, "打开所在位置", self._openloc, "#333")
        self._btn(btns, "关闭", self.root.destroy, "#999")

    def _btn(self, parent, text, cmd, color):
        b = tk.Button(parent, text=text, command=cmd, bg=color, fg="white",
                      font=("Microsoft YaHei UI", 10, "bold"), relief="flat",
                      activebackground=color, activeforeground="white", cursor="hand2",
                      padx=12, pady=7)
        b.pack(side="left", padx=(0, 8))

    def _auto_verdict(self):
        def work():
            r = verdict_text(self.path)
            self.root.after(0, lambda: self._show_result(r))
        threading.Thread(target=work, daemon=True).start()

    def _show_result(self, r):
        level = r.get("level", "?")
        score = r.get("score", 0)
        colors = {"严重": "#d93025", "高危": "#e8710a", "中危": "#d9a406",
                  "低危": "#1f6feb", "安全": "#188038", "未知": "#666", "错误": "#666",
                  "critical": "#d93025", "high": "#e8710a", "medium": "#d9a406",
                  "low": "#1f6feb", "safe": "#188038", "unknown": "#666"}
        self.lv.config(text=f"{level}  ·  风险评分 {score} / 100", fg=colors.get(level, "#666"))
        hits = r.get("hits", [])
        if hits:
            lines = [f"  ·  {h.get('title','')}" for h in hits[:5]]
            self.lh.config(text="\n".join(lines))
        elif r.get("raw"):
            self.lh.config(text=r["raw"][:300])

    def _isolate(self):
        if not messagebox.askyesno("确认", f"将文件移入隔离区？\n\n{self.path}\n\n移入后原文件将被删除（可从隔离区恢复）"):
            return
        code, out, err = run(QUAR, ["isolate", self.path, QUAR_DIR, QUAR_META])
        try:
            j = json.loads(out)
            ok = j.get("success")
        except Exception:
            ok = False
        if ok:
            messagebox.showinfo("完成", "已移入隔离区（XOR 编码防运行，可从 DG 隔离区恢复）")
        else:
            messagebox.showerror("失败", f"隔离失败: {err or out[:300]}")

    def _scan(self):
        self.lv.config(text="深度扫描中…", fg="#666")
        def work():
            code, out, err = run(SCAN, ["deep", self.path])
            self.root.after(0, lambda: self._scan_done(code, out, err))
        threading.Thread(target=work, daemon=True).start()

    def _scan_done(self, code, out, err):
        if code == 0 and out.strip():
            try:
                j = json.loads(out)
                total = j.get("total", len(j.get("results", [])))
                risks = [r for r in j.get("results", []) if r.get("level") in ("严重", "高危", "中危")]
                self.lh.config(text=f"扫描完成: 共 {total} 项, 风险 {len(risks)} 项")
                self.lv.config(text="扫描完成", fg=ACCENT)
            except Exception:
                self.lh.config(text=out[:300])
        else:
            self.lh.config(text=f"扫描结束 (code={code})")

    def _openloc(self):
        subprocess.Popen(["explorer", "/select,", self.path])


def show_simple(path, title, detail):
    root = tk.Tk()
    root.title("DG 安全")
    root.configure(bg=BG)
    root.geometry("480x260")
    tk.Label(root, text=os.path.basename(path), font=("Microsoft YaHei UI", 11, "bold"),
             bg=BG, fg="#111").pack(anchor="w", padx=18, pady=(18, 6))
    tk.Label(root, text=title, font=("Microsoft YaHei UI", 14, "bold"),
             bg=BG, fg=ACCENT).pack(anchor="w", padx=18)
    tk.Label(root, text=detail, font=("Microsoft YaHei UI", 9), bg=BG, fg="#555",
             justify="left", wraplength=440).pack(anchor="w", padx=18, pady=8)
    tk.Button(root, text="关闭", command=root.destroy, bg=ACCENT, fg="white",
              relief="flat", padx=16, pady=5).pack(anchor="e", padx=18, pady=10)
    root.mainloop()


def main():
    args = sys.argv[1:]
    if not args:
        print("usage: dg_context.py <panel|verdict|scan|isolate|openloc|install> [file]")
        return
    mode = args[0]
    if mode == "install":
        install_menu()
        return
    path = args[1] if len(args) > 1 else None
    if not path or not os.path.exists(path):
        print("file not found")
        return
    path = os.path.abspath(path)
    if mode == "verdict":
        r = verdict_text(path)
        show_simple(path, f"{r.get('level','?')}  ·  评分 {r.get('score',0)}",
                    "\n".join(h.get('title', '') for h in r.get('hits', [])) or r.get('raw', ''))
    elif mode == "scan":
        code, out, err = run(SCAN, ["deep", path])
        show_simple(path, f"深度扫描完成 (code={code})", (out or err)[:400])
    elif mode == "isolate":
        code, out, err = run(QUAR, ["isolate", path, QUAR_DIR, QUAR_META])
        try:
            ok = json.loads(out).get("success")
        except Exception:
            ok = False
        show_simple(path, "已移入隔离区" if ok else "隔离失败", "" if ok else (err or out)[:300])
    elif mode == "openloc":
        subprocess.Popen(["explorer", "/select,", path])
    else:
        DgPanel(path).root.mainloop()


def install_menu():
    """注册右键菜单 (HKCU, 无需管理员) — 单个"DG 安全"入口, 点击弹出操作面板"""
    import winreg
    # 清理旧的 4 项独立菜单
    old = ["DG快速判定", "DG深度扫描", "DG移入隔离区", "DG打开位置"]
    base = r"Software\Classes\*\shell"
    for key in old:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, rf"{base}\{key}\command")
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, rf"{base}\{key}")
        except OSError:
            pass
    # 注册单个入口: DG 安全 -> panel 操作面板
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if not os.path.isfile(pyw):
        pyw = sys.executable
    script = os.path.abspath(__file__)
    k = rf"{base}\DG安全"
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, rf"{k}\command")
    except OSError:
        pass
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, k) as kk:
        winreg.SetValueEx(kk, "", 0, winreg.REG_SZ, "DG 安全")
        winreg.SetValueEx(kk, "Icon", 0, winreg.REG_SZ,
                          rf'"{QUAR}"' if os.path.isfile(QUAR) else "shell32.dll,44")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"{k}\command") as kk:
        cmd = f'"{pyw}" "{script}" panel "%1"'
        winreg.SetValueEx(kk, "", 0, winreg.REG_SZ, cmd)
    print("右键菜单已安装: DG 安全 (单入口面板)")


if __name__ == "__main__":
    main()
