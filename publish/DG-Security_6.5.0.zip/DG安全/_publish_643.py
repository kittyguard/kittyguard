# -*- coding: utf-8 -*-
"""6.4.3 发布：便携zip + 源码zip + version.json 全量同步 + 官网 publish 就绪"""
import io, os, zipfile, json, hashlib, shutil

DG = r"F:\桌面保护\desktopguard"
OFF = os.path.join(DG, "官网")
PUB = os.path.join(OFF, "publish")
DIST = os.path.join(DG, "dist", "DG安全")
STAGING = r"F:\桌面保护\vmware\dg_staging\DG安全"
NEW_VER = "6.4.3"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

def make_zip(src_dir, out_zip):
    if os.path.exists(out_zip):
        os.remove(out_zip)
    total = 0
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(src_dir):
            for f in files:
                fp = os.path.join(root, f)
                arc = os.path.relpath(fp, src_dir)
                z.write(fp, arc)
                total += 1
    return total

if not os.path.isdir(DIST):
    raise SystemExit("dist 不存在")

# ---- 1) 便携 zip ----
portable = os.path.join(PUB, "DG-Security_%s.zip" % NEW_VER)
n = make_zip(DIST, portable)
portable_sha = sha256(portable)
print("[OK] portable zip: %d files, %d B, sha256 %s" % (n, os.path.getsize(portable), portable_sha[:16]))
shutil.copy2(portable, os.path.join(OFF, os.path.basename(portable)))

# ---- 2) 源码 zip（与 6.4.2 相同清单策略）----
SRC_SKIP = {".gitignore"}
src_files = set()
old_src = os.path.join(PUB, "DG-Source_%s.zip" % NEW_VER)
if os.path.isfile(old_src):
    with zipfile.ZipFile(old_src) as z:
        src_files = set(n for n in z.namelist() if "/" not in n)
root_files = set(f for f in os.listdir(DG) if os.path.isfile(os.path.join(DG, f)))
include = sorted((src_files | root_files) - SRC_SKIP)
src_zip = os.path.join(PUB, "DG-Source_%s.zip" % NEW_VER)
if os.path.exists(src_zip):
    os.remove(src_zip)
with zipfile.ZipFile(src_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for fn in include:
        p = os.path.join(DG, fn)
        if os.path.isfile(p):
            z.write(p, fn)
src_sha = sha256(src_zip)
print("[OK] source zip: %d files, %d B, sha256 %s" % (len(include), os.path.getsize(src_zip), src_sha[:16]))
shutil.copy2(src_zip, os.path.join(OFF, os.path.basename(src_zip)))

# ---- 3) version.json 全量同步 ----
rel_gh = "https://github.com/kittyguard/kittyguard/releases/download/v%s" % NEW_VER
rel_gt = "https://gitee.com/kittyguard/kittyguard/releases/download/v%s" % NEW_VER
notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": "2026-10-11",
    "release_notes": "6.4.3 发行修复版（向导版三大 bug + 开机动画分离）：1.【ClamAV 开箱即用】病毒库一键更新脚本与 freshclam.conf 不再写死本机路径与代理——改为相对路径多级自适应 + 国内镜像直连（代理留注释开关），任何电脑装完即可更新病毒库，不再依赖本机代理通道；2.【卸载彻底零残留】安装向导卸载时先写退出标记（守护链不再拉回），杀干净全部 DG 进程（主程序/三方互守/乱码观察者/EMA 组件/扫描核心），再删除开机自启与右键菜单注册表项，最后清除配置/病毒库/隔离区/备份/APPDATA 全部数据目录；3.【向导版 7 工具可用】性能悬浮窗/进程管理/网络工具箱/网络监控/自防护中心/启动项管理/误报回归工具全部随安装包内置编译版 exe（onefile 无窗口），不再依赖 Python 环境；4.【开机动画分离】开机自启（--tray）不播动画直接后台进托盘，手动双击启动保留完整开启动画；5.全程纯用户态、零驱动、不服务化、CPU≈0。",
    "features": [
        "修复：ClamAV 病毒库更新不再依赖本机代理（freshclam.conf + 更新 bat 相对路径/多级自适应/国内镜像直连）",
        "修复：安装向导卸载零残留（退出标记 + 全进程清理 + 注册表清理 + 数据目录清理）",
        "修复：向导版 7 个工具全部可用（内置编译版 exe）",
        "新增：开机自启不播动画、手动启动播动画（启动动画分离）",
        "随包内置 ClamAV 引擎 + 病毒库 + YARA 引擎 + 内置规则（任何电脑开箱即用）",
        "保持纯用户态、零驱动、不服务化、CPU≈0"
    ],
    "pkg_gh": "%s/DG-Security_%s.zip" % (rel_gh, NEW_VER),
    "pkg_gt": "%s/DG-Security_%s.zip" % (rel_gt, NEW_VER),
    "setup_gh": "%s/DG-Security-Setup-%s.exe" % (rel_gh, NEW_VER),
    "setup_gt": "%s/DG-Security-Setup-%s.exe" % (rel_gt, NEW_VER),
    "sha256": portable_sha,
}
for d in (OFF, PUB, r"F:\桌面保护\kittyguard_site", r"F:\桌面保护\kittyguard_site\publish"):
    os.makedirs(d, exist_ok=True)
    with io.open(os.path.join(d, "version.json"), "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)
for d in (os.path.join(DIST, "_internal"), os.path.join(STAGING, "_internal")):
    if os.path.isdir(d):
        with io.open(os.path.join(d, "version.json"), "w", encoding="utf-8") as f:
            json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 全量同步 (%s)" % NEW_VER)
print("PORTABLE_SHA=%s" % portable_sha)
print("SRC_SHA=%s" % src_sha)
print("PUBLISH_643_DONE")
