# -*- coding: utf-8 -*-
# 验证 jsDelivr CDN 是否能为 kittyguard 仓库提供国内加速
import urllib.request, time, socket

socket.setdefaulttimeout(20)

def try_url(url, limit=4096):
    t0 = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as r:
            total = 0
            while total < limit:
                chunk = r.read(65536)
                if not chunk:
                    break
                total += len(chunk)
        return total, time.time() - t0, None
    except Exception as e:
        return 0, 0, str(e)[:100]

tests = [
    ("jsDelivr-version.json", "https://cdn.jsdelivr.net/gh/kittyguard/kittyguard@main/version.json"),
    ("jsDelivr-源码zip(7.4MB)", "https://cdn.jsdelivr.net/gh/kittyguard/kittyguard@main/DG-Source_6.4.2.zip"),
    ("jsDelivr-官网index", "https://cdn.jsdelivr.net/gh/kittyguard/kittyguard@main/index.html"),
]

for name, url in tests:
    b, d, err = try_url(url)
    if err:
        print("%-22s FAIL  %s" % (name, err))
    else:
        print("%-22s OK    %dB %.2fs" % (name, b, d))
