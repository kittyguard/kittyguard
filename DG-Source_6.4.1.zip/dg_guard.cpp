// dg_guard.cpp — DG 守护进程（C++ 看门狗）
// 功能：
//   1. 监视目标进程（如 dg_monitor.exe）：被杀/崩溃 → 毫秒级重新拉起
//   2. 目标 exe 文件被删 → 从备份目录自动还原
//   3. 自身 exe 被删 → 从备份副本自动恢复
//   4. 心跳文件（供 Python 侧检查存活）
//   5. stop flag 文件存在时优雅退出（配合 RTP 停止）
// 用法: dg_guard.exe <targets> <backup_dir> <heartbeat> <stop_flag>
//   targets 格式: exe1|args1@@exe2|args2（args 可空）
// 编译: g++ -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -municode dg_guard.cpp -o dg_guard.exe -mwindows
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <mutex>
#include <sstream>
#include <ctime>

static std::atomic<bool> g_running{true};
static std::mutex g_lock;
static std::wstring g_backup_dir;
static std::wstring g_heartbeat_path;
static std::wstring g_stop_flag;
static std::wstring g_self_exe;
static std::wstring g_self_backup;
static std::wstring g_debug_log;

static void dbg_log(const std::wstring& msg) {
    std::lock_guard<std::mutex> lock(g_lock);
    FILE* f = _wfopen(g_debug_log.c_str(), L"ab");
    if (f) {
        std::string mb;
        int n = WideCharToMultiByte(CP_UTF8, 0, msg.c_str(), (int)msg.size(), nullptr, 0, nullptr, nullptr);
        mb.resize(n > 0 ? n : 0);
        if (n > 0) WideCharToMultiByte(CP_UTF8, 0, msg.c_str(), (int)msg.size(), &mb[0], n, nullptr, nullptr);
        std::string line = "[" + std::to_string((long long)time(nullptr)) + "] " + mb + "\n";
        fwrite(line.data(), 1, line.size(), f);
        fclose(f);
    }
}

// ---------- 工具 ----------
static bool stop_flag_exists() {
    return !g_stop_flag.empty() &&
           GetFileAttributesW(g_stop_flag.c_str()) != INVALID_FILE_ATTRIBUTES;
}

static bool copy_file_wide(const std::wstring& src, const std::wstring& dst) {
    return CopyFileW(src.c_str(), dst.c_str(), FALSE) != 0;
}

static std::wstring get_self_path() {
    wchar_t buf[MAX_PATH] = {0};
    GetModuleFileNameW(NULL, buf, MAX_PATH);
    return buf;
}

// 按 exe 完整路径查找进程 PID（QueryFullProcessImageName 精确匹配）
static DWORD find_pid_by_path(const std::wstring& exe_path) {
    std::wstring target = exe_path;
    for (auto& c : target) if (c >= L'A' && c <= L'Z') c += 32;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(pe);
    DWORD found = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
            if (h) {
                wchar_t buf[MAX_PATH] = {0};
                DWORD sz = MAX_PATH;
                if (QueryFullProcessImageNameW(h, 0, buf, &sz)) {
                    std::wstring p = buf;
                    for (auto& c : p) if (c >= L'A' && c <= L'Z') c += 32;
                    if (p == target) found = pe.th32ProcessID;
                }
                CloseHandle(h);
            }
            if (found) break;
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

// 确保目标进程在跑，返回进程句柄（不成功返回 NULL）
// args 为多个独立参数（每个会加引号后拼入命令行）
static HANDLE ensure_running(const std::wstring& exe, const std::vector<std::wstring>& args, const std::wstring& cwd) {
    // 已有进程 → 拿句柄
    DWORD pid = find_pid_by_path(exe);
    if (pid) {
        HANDLE h = OpenProcess(SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if (h) return h;
    }
    // 启动（每个参数单独加引号，防止含空格路径被命令行拆分）
    if (stop_flag_exists()) {
        dbg_log(L"stop flag 存在，不启动: " + exe);
        return NULL;
    }
    std::wstring cmd = L"\"" + exe + L"\"";
    for (const auto& a : args) {
        cmd += L" \"";
        cmd += a;
        cmd += L"\"";
    }
    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    LPCWSTR cur_dir = cwd.empty() ? NULL : cwd.c_str();
    if (CreateProcessW(exe.c_str(), &cmd[0], NULL, NULL, FALSE, CREATE_NO_WINDOW,
                       NULL, cur_dir, &si, &pi)) {
        CloseHandle(pi.hThread);
        dbg_log(L"启动成功: " + exe + L" (pid=" + std::to_wstring(pi.dwProcessId) + L")");
        return pi.hProcess;
    }
    DWORD err = GetLastError();
    dbg_log(L"启动失败: " + exe + L" err=" + std::to_wstring(err));
    return NULL;
}

static bool exit_flag_exists(const std::wstring& flag) {
    return !flag.empty() &&
           GetFileAttributesW(flag.c_str()) != INVALID_FILE_ATTRIBUTES;
}

// 监控单个目标：退出→恢复文件→重启
// exit_flag 非空时：该文件存在表示"正常退出"，不主动拉起（区分用户手动关闭 vs 被杀/崩溃）
static void monitor_target(const std::wstring& exe, const std::vector<std::wstring>& args,
                           const std::wstring& backup, const std::wstring& cwd,
                           const std::wstring& exit_flag) {
    while (g_running.load()) {
        if (stop_flag_exists()) break;
        // 正常退出标记存在 → 不拉起，等待用户重新打开（打开时会删标记）
        if (exit_flag_exists(exit_flag)) {
            Sleep(2000);
            continue;
        }
        HANDLE h = ensure_running(exe, args, cwd);
        if (!h) {
            // 启动失败（可能文件被删）→ 从备份还原后重试
            if (!backup.empty() && !stop_flag_exists()) {
                if (GetFileAttributesW(exe.c_str()) == INVALID_FILE_ATTRIBUTES &&
                    GetFileAttributesW(backup.c_str()) != INVALID_FILE_ATTRIBUTES) {
                    copy_file_wide(backup, exe);
                }
            }
            Sleep(2000);
            continue;
        }
        DWORD wait = WaitForSingleObject(h, 2000);
        if (wait == WAIT_OBJECT_0) {
            DWORD code = 0;
            GetExitCodeProcess(h, &code);
            CloseHandle(h);
            if (stop_flag_exists()) break;  // 主动停止
            // exe 被删 → 从备份还原
            if (!backup.empty()) {
                if (GetFileAttributesW(exe.c_str()) == INVALID_FILE_ATTRIBUTES &&
                    GetFileAttributesW(backup.c_str()) != INVALID_FILE_ATTRIBUTES) {
                    copy_file_wide(backup, exe);
                }
            }
            // 正常退出（有标记）→ 不拉回；否则视为异常，立即拉起
            if (exit_flag_exists(exit_flag)) {
                dbg_log(L"正常退出（exit flag），不拉回: " + exe);
                Sleep(1000);
                continue;
            }
            Sleep(500);  // 稳定后重启
        } else {
            CloseHandle(h);
        }
    }
}

// 心跳：每 3 秒写时间戳
static void heartbeat_loop() {
    while (g_running.load()) {
        {
            std::lock_guard<std::mutex> lock(g_lock);
            FILE* f = _wfopen(g_heartbeat_path.c_str(), L"wb");
            if (f) {
                std::string ts = std::to_string((long long)time(nullptr));
                fwrite(ts.data(), 1, ts.size(), f);
                fclose(f);
            }
        }
        Sleep(3000);
    }
}

// 自身防删 + stop flag 检测
static void self_guard_loop() {
    while (g_running.load()) {
        // 自身 exe 被删 → 从备份恢复
        if (GetFileAttributesW(g_self_exe.c_str()) == INVALID_FILE_ATTRIBUTES) {
            if (!g_self_backup.empty() &&
                GetFileAttributesW(g_self_backup.c_str()) != INVALID_FILE_ATTRIBUTES) {
                copy_file_wide(g_self_backup, g_self_exe);
            }
        }
        if (stop_flag_exists()) {
            g_running.store(false);
            break;
        }
        Sleep(2000);
    }
}

// ---------- 主函数 ----------
int wmain(int argc, wchar_t** argv) {
    if (argc < 5) return 1;
    std::wstring targets_arg = argv[1];
    g_backup_dir = argv[2];
    g_heartbeat_path = argv[3];
    g_stop_flag = argv[4];
    g_self_exe = get_self_path();
    g_self_backup = g_backup_dir + L"\\dg_guard_backup.exe";
    g_debug_log = g_backup_dir + L"\\dg_guard_debug.log";
    dbg_log(L"dg_guard 启动, targets=" + targets_arg);
    dbg_log(L"备份目录=" + g_backup_dir + L" | 心跳=" + g_heartbeat_path);

    // 备份自己
    CreateDirectoryW(g_backup_dir.c_str(), NULL);
    copy_file_wide(g_self_exe, g_self_backup);

    // 解析 targets（多目标用 || 分隔；单目标时无 ||。args 内参数用 | 分隔）
    struct Target { std::wstring exe; std::vector<std::wstring> args; std::wstring backup;
                    std::wstring cwd; std::wstring exit_flag; };
    std::vector<Target> targets;
    {
        size_t pos = 0;
        while (pos < targets_arg.size()) {
            size_t sep = targets_arg.find(L"||", pos);
            std::wstring item = targets_arg.substr(pos, (sep == std::wstring::npos) ? std::wstring::npos : sep - pos);
            if (!item.empty()) {
                Target t;
                size_t at = item.find(L"@@");
                if (at != std::wstring::npos) {
                    t.exe = item.substr(0, at);
                    std::wstring rest = item.substr(at + 2);
                    // 第二个 @@ 之后是 cwd，第三个 @@ 之后是 exit_flag
                    size_t at2 = rest.find(L"@@");
                    std::wstring args_str = (at2 == std::wstring::npos) ? rest : rest.substr(0, at2);
                    if (at2 != std::wstring::npos) {
                        std::wstring rest2 = rest.substr(at2 + 2);
                        size_t at3 = rest2.find(L"@@");
                        t.cwd = (at3 == std::wstring::npos) ? rest2 : rest2.substr(0, at3);
                        if (at3 != std::wstring::npos) t.exit_flag = rest2.substr(at3 + 2);
                    }
                    // args 内参数用 | 分隔
                    std::wstringstream as(args_str);
                    std::wstring a;
                    while (std::getline(as, a, L'|')) {
                        if (!a.empty()) t.args.push_back(a);
                    }
                } else {
                    t.exe = item;
                }
                size_t slash = t.exe.find_last_of(L'\\');
                std::wstring fname = (slash == std::wstring::npos) ? t.exe : t.exe.substr(slash + 1);
                t.backup = g_backup_dir + L"\\" + fname;
                targets.push_back(t);
            }
            if (sep == std::wstring::npos) break;
            pos = sep + 2;
        }
    }
    if (targets.empty()) return 1;

    // 备份每个目标文件（exe 存在时）
    for (auto& t : targets) {
        if (GetFileAttributesW(t.exe.c_str()) != INVALID_FILE_ATTRIBUTES) {
            copy_file_wide(t.exe, t.backup);
            dbg_log(L"已备份目标: " + t.exe + L" -> " + t.backup);
        } else {
            dbg_log(L"目标不存在，跳过备份: " + t.exe);
        }
    }

    std::thread hb(heartbeat_loop);
    hb.detach();
    std::thread sg(self_guard_loop);
    sg.detach();

    std::vector<std::thread> threads;
    for (auto& t : targets) {
        threads.emplace_back(monitor_target, t.exe, t.args, t.backup, t.cwd, t.exit_flag);
    }
    for (auto& t : threads) if (t.joinable()) t.join();
    return 0;
}
