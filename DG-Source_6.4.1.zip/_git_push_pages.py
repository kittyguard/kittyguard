# -*- coding: utf-8 -*-
"""GitHub Pages 一键发布：建仓 kittyguard.github.io → 推送官网 publish 目录 → 开启 Pages。

用法（需用户提供含 repo+read:org 的新 PAT）：
    set GITHUB_PAT=ghp_xxx
    python _git_push_pages.py

全程走红海代理（HTTP 127.0.0.1:33210），令牌只从环境变量读取，不落盘、不硬编码。
"""
import os, sys, json, io, time, subprocess, urllib.request

PROXY = "http://127.0.0.1:33210"
REPO = "kittyguard.github.io"
PUB = r"F:\桌面保护\desktopguard\官网\publish"

def _opener():
    pat = os.environ.get("GITHUB_PAT", "").strip()
    if not pat:
        print("[FAIL] 未设置 GITHUB_PAT 环境变量（需用户重新生成含 repo+read:org 的 PAT）")
        sys.exit(2)
    handler = urllib.request.ProxyHandler({"http": PROXY, "https": PROXY})
    opener = urllib.request.build_opener(handler)
    opener.addheaders = [("Authorization", "token " + pat), ("User-Agent", "kittyguard-dg")]
    return opener, pat

def api(url, method="GET", data=None):
    opener, _ = _opener()
    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(url, data=body, method=method)
    try:
        with opener.open(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode("utf-8", "ignore"))
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode("utf-8", "ignore"))
        except Exception:
            err = {}
        return e.code, err

def run(cmd, cwd=None):
    env = dict(os.environ)
    env["HTTPS_PROXY"] = PROXY
    env["HTTP_PROXY"] = PROXY
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r

def main():
    opener, pat = _opener()
    # 1. 验证令牌
    st, me = api("https://api.github.com/user")
    if st != 200:
        print("[FAIL] 令牌校验失败 code=%s msg=%s" % (st, me.get("message", me)))
        sys.exit(1)
    login = me.get("login", "kittyguard")
    print("[OK] 令牌有效，账号:", login)

    # 2. 建仓库（已存在则跳过）
    url = "https://api.github.com/repos/%s/%s" % (login, REPO)
    st, repo = api(url)
    if st == 404:
        st, repo = api("https://api.github.com/user/repos", "POST",
                       {"name": REPO, "description": "DG 安全 · 纯用户态桌面防护官网",
                        "auto_init": False, "has_wiki": False})
        if st not in (200, 201):
            print("[FAIL] 建仓库失败 code=%s msg=%s" % (st, repo.get("message", repo)))
            sys.exit(1)
        print("[OK] 已创建仓库", REPO)
    elif st == 200:
        print("[OK] 仓库已存在:", repo.get("html_url", REPO))
    else:
        print("[FAIL] 查询仓库异常 code=%s" % st)
        sys.exit(1)

    # 3. 本地 git 推送 publish 目录
    if not os.path.isdir(PUB):
        print("[FAIL] publish 目录不存在:", PUB)
        sys.exit(1)
    git_url = "https://x-access-token:%s@github.com/%s/%s.git" % (pat, login, REPO)
    if not os.path.isdir(os.path.join(PUB, ".git")):
        r = run(["git", "init"], cwd=PUB)
        if r.returncode != 0:
            print("[FAIL] git init:", r.stderr[-300:])
            sys.exit(1)
    r = run(["git", "remote", "set-url", "origin", git_url], cwd=PUB)
    if r.returncode != 0:
        r = run(["git", "remote", "add", "origin", git_url], cwd=PUB)
    run(["git", "add", "-A"], cwd=PUB)
    r = run(["git", "commit", "-m", "DG 6.0.0 官网发布（勒索守护/误报闭环/签名缓存）"], cwd=PUB)
    if r.returncode != 0 and "nothing to commit" not in r.stderr:
        pass  # 无改动也继续 push
    run(["git", "branch", "-M", "main"], cwd=PUB)
    r = run(["git", "push", "-u", "origin", "main", "--force"], cwd=PUB)
    if r.returncode != 0:
        print("[FAIL] push 失败:", r.stderr[-400:])
        sys.exit(1)
    print("[OK] 已推送 publish 到", login + "/" + REPO)

    # 4. 开启 GitHub Pages（main 分支根目录）
    st, pg = api("https://api.github.com/repos/%s/%s/pages" % (login, REPO), "POST",
                 {"source": {"branch": "main", "path": "/"}})
    if st not in (200, 201):
        if st == 409 and pg.get("message") == "Pages has already been enabled.":
            print("[OK] Pages 已开启")
        else:
            print("[WARN] 开 Pages 返回 %s: %s（可稍后在仓库 Settings 手动开）" % (st, pg.get("message", pg)))
    else:
        print("[OK] GitHub Pages 已开启")
    print("[DONE] 网址: https://%s.github.io/" % login)

if __name__ == "__main__":
    main()
