# -*- coding: utf-8 -*-
"""HEAD/Range 快速验证 Pages 线上 6.4.2 三件套可达性（不下载全文）"""
import urllib.request, ssl, json, sys

BASE = "https://kittyguard.github.io/kittyguard"
ctx = ssl.create_default_context()

def head(url):
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
            return resp.status, dict(resp.headers)
    except Exception as e:
        return None, str(e)

for f in ["version.json", "DG-Security-Setup-6.4.2.exe", "DG-Security_6.4.2.zip", "DG-Source_6.4.2.zip"]:
    url = BASE + "/" + f
    st, info = head(url)
    if st:
        cl = info.get("Content-Length", "?")
        ct = info.get("Content-Type", "?")
        print(f, "-> HTTP", st, "| bytes:", cl, "| type:", ct)
    else:
        print(f, "-> FAIL:", info)

# version.json 内容单独拉取
try:
    req = urllib.request.Request(BASE + "/version.json", headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
        v = json.loads(resp.read().decode("utf-8"))
    print("version.json: latest_version =", v.get("latest_version"), "| sha256 =", str(v.get("sha256"))[:16])
except Exception as e:
    print("version.json fetch FAIL:", e)
