# -*- coding: utf-8 -*-
import zipfile

old = r"F:\桌面保护\desktopguard\官网\publish\DG-Security_6.1.0.zip"  # 旧 45MB 包
new = r"F:\桌面保护\desktopguard\官网\publish\DG-Security_6.4.1.zip"  # 新 20MB 包

with zipfile.ZipFile(old) as z:
    old_names = set(z.namelist())
    old_sizes = {i.filename: i.file_size for i in z.infolist()}
with zipfile.ZipFile(new) as z:
    new_names = set(z.namelist())
    new_sizes = {i.filename: i.file_size for i in z.infolist()}

missing = sorted(old_names - new_names)
added = sorted(new_names - old_names)
print("old files:", len(old_names), "new files:", len(new_names))
print("MISSING in new (%d):" % len(missing))
for f in missing:
    print("  %10d  %s" % (old_sizes.get(f, 0), f))
print("ADDED in new (%d):" % len(added))
for f in added[:20]:
    print("  %10d  %s" % (new_sizes.get(f, 0), f))
