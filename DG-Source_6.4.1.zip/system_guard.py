# -*- coding: utf-8 -*-
"""3.7.0 系统文件守护：防御「删除 System32 文件导致系统无法运行」型病毒。
- 启动时备份 Windows 核心文件到 dgdata\\sys_backup
- 每 5 秒轮询核心文件是否存在（纯本地、断网可用）
- 发现缺失 → 立即尝试还原 + 紧急告警（提示断网）
- 批量缺失 ≥3 → 判定为系统破坏攻击，直接结束攻击载体进程
3.7.0 变更（防御核心强化）：
  1. 杀进程改为 ctypes 直调 Windows API（OpenProcess/TerminateProcess）——
     不再依赖 taskkill.exe。taskkill 位于 System32，删除系统文件攻击会把
     System32 DLL 删光，导致 taskkill 无法加载而失效；ctypes 调用的是
     Python 已加载进内存的 kernel32.dll 函数，文件被删也不受影响。
  2. 还原逻辑修复：不再只还原"新增缺失"，改为还原"全部当前缺失"，
     还原失败的文件会在下一轮自动重试（原逻辑只还原新增，失败即永久放弃）。
  3. 告警入队改 put_nowait，避免 GUI 卡死拖垮守护线程。
"""
import os
import time
import shutil
import threading

SYS_KEY_FILES = [
    # 核心 EXE（删除/替换即导致系统无法登录/运行）
    # root\ = Windows 根目录（explorer.exe 位于 C:\Windows\ 而非 System32）
    "root\\explorer.exe", "winlogon.exe", "wininit.exe", "services.exe",
    "lsass.exe", "smss.exe", "csrss.exe", "svchost.exe", "conhost.exe",
    "notepad.exe", "cmd.exe", "fontdrvhost.exe", "logonui.exe",
    "taskhostw.exe", "dwm.exe",
    # System32 核心 DLL（系统运行必需）
    "kernel32.dll", "ntdll.dll", "user32.dll", "gdi32.dll",
    "advapi32.dll", "shell32.dll", "ole32.dll", "comdlg32.dll",
    "shlwapi.dll", "msvcrt.dll", "version.dll", "setupapi.dll",
    "winmm.dll", "ws2_32.dll", "crypt32.dll", "bcrypt.dll",
    "secur32.dll", "wininet.dll", "winhttp.dll", "imm32.dll",
    "uxtheme.dll", "dwmapi.dll", "hal.dll",
    # System32\\drivers 关键驱动（删了即无法启动/蓝屏）
    "drivers\\ntfs.sys", "drivers\\tcpip.sys", "drivers\\disk.sys",
    "drivers\\partmgr.sys", "drivers\\mountmgr.sys", "drivers\\fltmgr.sys",
    "drivers\\volmgr.sys", "drivers\\ksecdd.sys", "drivers\\cng.sys",
    "drivers\\clfs.sys", "drivers\\wdf01000.sys", "drivers\\ndis.sys",
    "drivers\\afd.sys", "drivers\\http.sys",
]


def sys_backup_dir():
    from paths import DATA_DIR
    return os.path.join(DATA_DIR, "sys_backup")


def _resolve(rel):
    """把清单相对路径解析为真实系统路径（root\\ → Windows 根目录，其余 → System32）。"""
    win = os.environ.get("WINDIR", r"C:\Windows")
    if rel.startswith("root\\"):
        return os.path.join(win, rel[len("root\\"):])
    return os.path.join(win, "System32", rel)


def _bpath(rel):
    """备份目录内路径：root\\xxx → xxx"""
    if rel.startswith("root\\"):
        return rel[len("root\\"):]
    return rel


def backup_critical_sys_files():
    """把核心系统文件备份到 dgdata\\sys_backup（仅首次或缺失时复制）。"""
    bdir = sys_backup_dir()
    saved = 0
    try:
        os.makedirs(bdir, exist_ok=True)
        for rel in SYS_KEY_FILES:
            src = _resolve(rel)
            dst = os.path.join(bdir, _bpath(rel))
            try:
                if os.path.exists(src) and not os.path.exists(dst):
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(src, dst)
                    saved += 1
            except Exception:
                continue
    except Exception:
        pass
    return saved


def check_critical_sys_files():
    """返回缺失的核心系统文件列表（相对路径）。"""
    missing = []
    for rel in SYS_KEY_FILES:
        if not os.path.exists(_resolve(rel)):
            missing.append(rel)
    return missing


def restore_critical_sys_files(missing):
    """从备份还原缺失的系统文件。返回 (已还原数, 失败列表)。"""
    bdir = sys_backup_dir()
    restored = 0
    failed = []
    for rel in missing:
        src = os.path.join(bdir, _bpath(rel))
        dst = _resolve(rel)
        try:
            if os.path.exists(src):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                restored += 1
            else:
                failed.append(rel)
        except Exception:
            failed.append(rel)
    return restored, failed


def _kill_attack_processes():
    """ctypes 直调 Windows API 结束系统文件破坏攻击载体进程（3.7.0）。

    目标：cmd/wscript/cscript/mshta（此类病毒最常用的执行载体）。
    不杀 powershell/explorer/用户程序，避免误杀正常使用。

    为什么不用 taskkill：taskkill.exe 位于 System32，删除系统文件攻击会把
    System32 DLL 删光，导致 taskkill 无法加载自身依赖而失效。这里用 ctypes
    调用 Python 进程已加载进内存的 kernel32.dll 函数（CreateToolhelp32Snapshot/
    OpenProcess/TerminateProcess），磁盘文件缺失完全不影响，攻击载体必死。

    返回：成功结束的进程 PID 列表。
    """
    import ctypes
    from ctypes import wintypes
    kernel32 = ctypes.windll.kernel32
    TH32CS_SNAPPROCESS = 0x00000002
    PROCESS_TERMINATE = 0x0001
    INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.POINTER(wintypes.ULONG)),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", ctypes.c_wchar * 260),
        ]

    targets = {"cmd.exe", "wscript.exe", "cscript.exe", "mshta.exe"}
    killed = []
    try:
        snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if not snap or snap == INVALID_HANDLE_VALUE:
            return killed
        try:
            pe = PROCESSENTRY32W()
            pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            if kernel32.Process32FirstW(snap, ctypes.byref(pe)):
                while True:
                    try:
                        name = (pe.szExeFile or "").lower()
                        pid = int(pe.th32ProcessID)
                    except Exception:
                        name, pid = "", 0
                    if name in targets and pid and pid != os.getpid():
                        h = kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
                        if h:
                            if kernel32.TerminateProcess(h, 1):
                                killed.append(pid)
                            kernel32.CloseHandle(h)
                    if not kernel32.Process32NextW(snap, ctypes.byref(pe)):
                        break
        finally:
            try:
                kernel32.CloseHandle(snap)
            except Exception:
                pass
    except Exception:
        pass
    return killed


def start_system_guard(alert_queue, stop_event, log_fn=None, interval=5):
    """启动系统文件守护线程（纯本地、断网可用）。"""
    def _log(msg):
        try:
            if log_fn:
                log_fn(msg)
        except Exception:
            pass

    def _loop():
        # 首次备份
        try:
            n = backup_critical_sys_files()
            if n:
                _log(f"系统文件守护：已备份 {n} 个核心系统文件")
        except Exception:
            pass
        _log("系统文件守护已启动（防御系统文件破坏型病毒，断网可用）")
        prev_missing = set()
        while not stop_event.is_set():
            try:
                missing = check_critical_sys_files()
                ms = set(missing)
                newly = ms - prev_missing
                prev_missing = ms
                # 3.7.0：还原全部当前缺失（含上一轮失败的），失败自动重试
                if ms and not stop_event.is_set():
                    restored, failed = restore_critical_sys_files(list(ms))
                    if newly:
                        _log(f"系统文件守护：检测到 {len(newly)} 个系统文件被删除（{', '.join(sorted(newly)[:5])}），已还原 {restored} 个")
                    elif failed:
                        _log(f"系统文件守护：重试还原失败项（剩余 {len(ms)} 个缺失），已还原 {restored} 个")
                    try:
                        alert_queue.put_nowait({
                            "type": "system_critical",
                            "missing": sorted(ms),
                            "restored": restored,
                            "failed": failed,
                        })
                    except Exception:
                        pass
                # 批量缺失（≥3 且持续）→ 疑似系统破坏攻击进行中
                if len(ms) >= 3 and not stop_event.is_set():
                    try:
                        alert_queue.put_nowait({
                            "type": "system_critical",
                            "missing": sorted(ms),
                            "restored": 0,
                            "failed": [],
                            "attack": True,
                        })
                        # 3.7.0：ctypes 直杀攻击载体（不依赖 taskkill）
                        try:
                            _killed = _kill_attack_processes()
                            if _killed:
                                _log(f"系统文件守护：已结束 {len(_killed)} 个可疑攻击进程（{', '.join(_killed[:6])}）")
                        except Exception:
                            pass
                        # 攻击进行中：加快检查
                        time.sleep(2)
                        continue
                    except Exception:
                        pass
            except Exception:
                pass
            time.sleep(interval)

    t = threading.Thread(target=_loop, daemon=True, name="DG-SysGuard")
    t.start()
    return t
