# -*- coding: utf-8 -*-
"""DG 4.7.0 补丁：工具页新增「网络工具」卡片 + _open_net_tools 方法 + 版本号升级"""
import io, sys

P = r"F:\桌面保护\desktopguard\main.py"
src = io.open(P, "r", encoding="utf-8").read()

# ---------- 1. 版本号 ----------
old_ver = 'APP_VERSION = "4.6.2"'
new_ver = 'APP_VERSION = "4.7.0"'
assert old_ver in src, "version not found"
src = src.replace(old_ver, new_ver, 1)

# ---------- 2. 工具页卡片 ----------
old_card = ('        ttk.Button(t4, text="打开性能悬浮窗", style="Accent.TButton", command=self._open_perf_overlay).pack(anchor="w", pady=(6, 0))\n')
new_card = old_card + (
    '        t5 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)\n'
    '        t5.pack(fill="x", pady=4)\n'
    '        tk.Label(t5, text="网络工具", bg=C_CARD2, fg=C_PRIMARY,\n'
    '                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")\n'
    '        tk.Label(t5, text="国内多节点测速（延迟/抖动/丢包/带宽）+ 一键网络加速（结束后台大户可恢复、TCP 优化可回滚）+ 游戏模式一键清场，纯用户态不花钱",\n'
    '                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))\n'
    '        ttk.Button(t5, text="打开网络工具箱", style="Accent.TButton", command=self._open_net_tools).pack(anchor="w", pady=(6, 0))\n'
)
assert old_card in src, "card anchor not found"
src = src.replace(old_card, new_card, 1)

# ---------- 3. 方法：在 _open_perf_overlay 方法结束后插入 ----------
anchor = """            messagebox.showerror("性能悬浮窗", f"启动失败：{e}")

    def _open_ai_chat(self):"""
assert anchor in src, "method anchor not found"
new_method = """            messagebox.showerror("性能悬浮窗", f"启动失败：{e}")

    def _open_net_tools(self):
        \"\"\"打开网络工具箱（独立进程，防重复启动）\"\"\"
        import ctypes
        found = []
        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def cb(h, l):
            if ctypes.windll.user32.IsWindowVisible(h):
                buf = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetWindowTextW(h, buf, 256)
                if "网络工具箱" in buf.value:
                    found.append(h)
            return True
        try:
            ctypes.windll.user32.EnumWindows(cb, 0)
        except Exception:
            pass
        if found:
            messagebox.showinfo("网络工具箱", "网络工具箱已在运行。")
            return
        script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "net_tools.py")
        if not os.path.exists(script):
            messagebox.showerror("网络工具箱", "未找到 net_tools.py（应位于 DG 程序目录）。")
            return
        try:
            exe = sys.executable
            if exe and exe.lower().endswith("python.exe"):
                exe = exe[:-len("python.exe")] + "pythonw.exe"
            if not exe or not os.path.exists(exe):
                exe = sys.executable
            subprocess.Popen([exe, script],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            messagebox.showinfo("网络工具箱", "网络工具箱已打开（测速 / 加速 / 游戏模式，全部操作可回滚）。")
        except Exception as e:
            messagebox.showerror("网络工具箱", f"启动失败：{e}")

    def _open_ai_chat(self):"""
src = src.replace(anchor, new_method, 1)

# ---------- 4. 历史版本记录（VERSION_LIST 顶部插入 4.7.0） ----------
old_vlist = '    ("4.6.2", "4.6.1", '
new_vlist = (
    '    ("4.7.0", "4.6.2", "内容更新（网络工具箱 v1）：1.工具页新增「网络工具」卡片——独立进程窗口不阻塞主程序、防重复启动；2.【一键测速】国内四节点（阿里/腾讯/114/百度 DNS）延迟·抖动·丢包实测 + 国内镜像尽力下载带宽测速（免费不花钱）；3.【一键加速·可回滚】扫描后台大户（系统/DG/游戏进程自动豁免）→ 一键结束后记录原进程可恢复；4.【TCP 优化·可回滚】一键应用接收窗口自动调谐 normal + RSS，原值记录支持一键回滚；5.【游戏模式】针对 FPS 对局（如 ACE 扫盘场景）一键清场，全部操作纯用户态、可回滚",),\n'
    '    ("4.6.2", "4.6.1", '
)
assert old_vlist in src, "vlist anchor not found"
src = src.replace(old_vlist, new_vlist, 1)

io.open(P, "w", encoding="utf-8").write(src)
print("PATCH OK, version now 4.7.0, size:", len(src))
