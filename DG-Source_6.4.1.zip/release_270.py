# -*- coding: utf-8 -*-
"""发布 2.7.0 正式版：从内测版同步，改版本号/配置路径，创建快照"""
import os, shutil, json

src = r'F:\桌面保护\desktopguard-beta'
dst = r'F:\桌面保护\desktopguard'

# 1. 同步代码文件
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp', 'build_core.sh']:
    s = os.path.join(src, fname)
    d = os.path.join(dst, fname)
    if os.path.exists(s):
        shutil.copy2(s, d)
        print(f'已同步 {fname}')

# 2. 改版本号 + 配置路径（beta -> 正式）
def fix(p, ver):
    with open(p, 'r', encoding='utf-8') as f:
        c = f.read()
    c = c.replace('2.7.0-beta', ver)
    c = c.replace('.desktopguard-beta', '.desktopguard')
    with open(p, 'w', encoding='utf-8') as f:
        f.write(c)

fix(os.path.join(dst, 'main.py'), '2.7.0')
fix(os.path.join(dst, 'engine.py'), '2.7.0')
fix(os.path.join(dst, 'database.py'), '2.7.0')
fix(os.path.join(dst, 'logger.py'), '2.7.0')
fix(os.path.join(dst, 'realtime_protection.py'), '2.7.0')
fix(os.path.join(dst, 'scan_core_bridge.py'), '2.7.0')
print('版本号 -> 2.7.0，配置路径 -> .desktopguard')

# 3. 更新 version.json
version_data = {
    "latest_version": "2.7.0",
    "release_date": "2026-09-08",
    "release_notes": "2.7.0 正式版：Python+C++混合引擎，C++加速扫描核心，自动刷新修复",
    "features": [
        "C++ 扫描加速核心（8线程并行遍历 + BCrypt SHA256哈希）",
        "深度扫描速度大幅提升（55万文件6.5分钟完成，不卡GUI）",
        "扫描结果自动刷新（不再需要手动点显示全部）",
        "Python侧复用C++哈希，不重复计算",
        "C++核心不可用时自动回退纯Python",
        "1.3.7快照异常已记录（实为1.1.1代码）"
    ]
}
with open(os.path.join(dst, 'version.json'), 'w', encoding='utf-8') as f:
    json.dump(version_data, f, ensure_ascii=False, indent=2)
print('version.json 已更新')

# 4. 创建版本快照
snap = os.path.join(dst, 'versions', '2.7.0')
os.makedirs(snap, exist_ok=True)
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp']:
    s = os.path.join(dst, fname)
    if os.path.exists(s):
        shutil.copy2(s, os.path.join(snap, fname))
print(f'快照已创建: versions/2.7.0')

print('\n2.7.0 正式版发布完成！')
