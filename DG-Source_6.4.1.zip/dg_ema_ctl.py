# -*- coding: utf-8 -*-
"""
dg_ema_ctl.py — EMA 组件 Python 控制侧（DG 安全 3.x 的轻量 AI 实时防护配套）
职责:
  1. 启动 dg_ema_watch.exe（ETW 进程监控 C++ 组件）
  2. 读取 jsonl 事件流（进程创建/退出）
  3. 提供 stop() 停止接口（写退出 flag）
  4. 提供 get_events() 消费接口（供 AI 分析层调用）
用法示例见 __main__。
"""
import json
import os
import subprocess
import sys
import time

DEFAULT_MAX_SEC = 86400


class EMAController:
    def __init__(self, workdir, exe_path=None, max_sec=DEFAULT_MAX_SEC):
        self.workdir = workdir
        self.jsonl = os.path.join(workdir, "dg_ema_events.jsonl")
        self.hb = os.path.join(workdir, "dg_ema_hb.txt")
        self.flag = os.path.join(workdir, "dg_ema_exit.flag")
        self.exe = exe_path or os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_ema_watch.exe")
        self.max_sec = max_sec
        self.proc = None

    def start(self):
        # 清理上次残留
        for f in (self.jsonl, self.hb, self.flag):
            try:
                if os.path.exists(f):
                    os.remove(f)
            except OSError:
                pass
        cmd = [self.exe, self.jsonl, self.hb, self.flag, str(self.max_sec)]
        CREATE_NO_WINDOW = 0x08000000
        self.proc = subprocess.Popen(
            cmd,
            creationflags=CREATE_NO_WINDOW,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return self.proc.pid

    def is_alive(self):
        if not self.proc:
            return False
        return self.proc.poll() is None

    def get_events(self, last_pos=0):
        """读取事件文件，返回 (事件列表, 新文件偏移)。"""
        events = []
        pos = last_pos
        try:
            with open(self.jsonl, "r", encoding="utf-8", errors="ignore") as f:
                f.seek(pos)
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
                pos = f.tell()
        except FileNotFoundError:
            pass
        return events, pos

    def get_heartbeat(self):
        try:
            with open(self.hb, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.read().strip().splitlines()
            if lines:
                parts = lines[-1].split()
                return {"tick": int(parts[0]), "pid_ev": int(parts[1]) if len(parts) > 1 else 0}
        except Exception:
            pass
        return None

    def stop(self):
        """写退出 flag 并等待组件退出。"""
        try:
            with open(self.flag, "w", encoding="utf-8") as f:
                f.write("stop")
        except OSError:
            pass
        if self.proc:
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
            self.proc = None

    def wait_finished(self, timeout=10):
        if self.proc:
            try:
                self.proc.wait(timeout=timeout)
                return True
            except subprocess.TimeoutExpired:
                return False
        return True


if __name__ == "__main__":
    workdir = sys.argv[1] if len(sys.argv) > 1 else r"C:\etwtest"
    ctl = EMAController(workdir)
    print("启动 EMA 组件...")
    pid = ctl.start()
    print("PID:", pid)
    time.sleep(6)
    pos = 0
    for _ in range(3):
        evs, pos = ctl.get_events(pos)
        print("本轮事件:", evs[:5], "共", len(evs))
        time.sleep(2)
    print("心跳:", ctl.get_heartbeat())
    print("存活:", ctl.is_alive())
    print("停止组件...")
    ctl.stop()
    evs, pos = ctl.get_events(pos)
    print("final 行:", [e for e in evs if "final" in e])
    print("OK")
