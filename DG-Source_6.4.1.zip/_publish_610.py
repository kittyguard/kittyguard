# -*- coding: utf-8 -*-
"""发布 6.1.0：快照 + 重建防篡改清单 + version.json（定时自动扫描 + 勒索守护历史 + 版本更新公告）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.1.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.1.0 内容更新：定时自动扫描 + 勒索守护历史 + 版本更新公告（含 6.0.0-6.0.5 版本列表补全）。",
    "features": [
        "定时自动扫描：设置-扫描设置新增每天指定时间（HH:MM）+ 模式（快速/高级/深度），到点自动后台查杀、当天只触发一次，免打扰模式下完成提示只写日志不弹窗",
        "勒索守护历史：保护页新增「守护历史」窗口，告警/冻结/备份/用户处置事件全部留痕回看（时间/等级/文件/详情），一键刷新",
        "版本更新公告：更新/切换版本后首次启动自动弹出本次更新内容（取版本历史最新条目，已看过不再打扰）",
        "版本列表补全：历史版本列表补上 6.0.0-6.0.5（此前停在 5.5.0，版本切换缺少 6.x 旧版）",
        "database.py 新增 get_security_events(source, limit) 接口",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
