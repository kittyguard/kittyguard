# -*- coding: utf-8 -*-
import re

with open(r'F:\桌面保护\desktopguard\versions\2.3.2\main.py', 'r', encoding='utf-8') as f:
    c = f.read()

print('2.3.2 行数:', len(c.split('\n')))
m = re.search(r'def (_open_ai\w+)', c)
print('AI助手方法:', m.group(1) if m else '未找到')

start = c.find('def _open_ai_chat')
if start > 0:
    end = c.find('def _open_security_checkup', start)
    print('AI助手代码长度:', end - start if end > 0 else '未找到结束位置')
else:
    print('未找到 _open_ai_chat 方法')
    # 搜索所有以_open开头的方法
    methods = re.findall(r'def (_\w+)', c)
    ai_methods = [m for m in methods if 'ai' in m.lower() or 'chat' in m.lower()]
    print('包含ai/chat的方法:', ai_methods)
