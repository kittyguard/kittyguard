# -*- coding: utf-8 -*-
"""
DG安全 3.0 云查模块
==================================
对文件 SHA256 做多通道云查杀：
  本地病毒库  ->  本地缓存  ->  微步在线(ThreatBook)  ->  VirusTotal

设计原则：
  - 零第三方依赖，仅用标准库（urllib / json / sqlite3 / os / time）
  - API Key 全部来自 ~/.desktopguard/cloud_query_config.json，绝不硬编码
  - 任何通道失败、超时、无 Key、断网均静默降级，最终返回 unknown，绝不抛异常
  - 3 秒超时，结果按 TTL 缓存到 dg_data.db 的 cloud_query_cache 表
"""

from paths import DATA_DIR
import os
import json
import time
import sqlite3
import hashlib
import urllib.parse
import urllib.request
import urllib.error

# ---- 项目内模块（导入失败时降级，保证本模块可独立导入） ----
try:
    from logger import app_logger
except Exception:  # pragma: no cover
    import logging as _logging
    app_logger = _logging.getLogger("dg_cloud")

try:
    from database import check_virus_hash
except Exception:  # pragma: no cover
    check_virus_hash = None

try:
    from engine import sha256_of as _engine_sha256_of
except Exception:  # pragma: no cover
    _engine_sha256_of = None


# ============================================================
# 路径与常量
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "dg_data.db")

CONFIG_DIR = DATA_DIR
CONFIG_PATH = os.path.join(CONFIG_DIR, "cloud_query_config.json")

# 云端 API 端点
THREATBOOK_URL = "https://api.threatbook.cn/v3/file/report"
VIRUSTOTAL_URL = "https://www.virustotal.com/api/v3/files/{sha256}"

# 默认配置（Key 为空表示未配置对应通道）
DEFAULT_CONFIG = {
    "threatbook_api_key": "",
    "virustotal_api_key": "",
    "enabled": True,          # 云查总开关
    "timeout": 3,             # 单次网络超时（秒）
    "cache_ttl_days": 7,      # 缓存有效期（天）
}


# ============================================================
# 1. 配置管理
# ============================================================

def load_config():
    """读取云查配置，文件不存在或损坏时返回默认配置（合并补齐缺省字段）。"""
    cfg = dict(DEFAULT_CONFIG)
    try:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                user_cfg = json.load(f)
            if isinstance(user_cfg, dict):
                for k in DEFAULT_CONFIG:
                    if k in user_cfg:
                        cfg[k] = user_cfg[k]
    except Exception as e:
        try:
            app_logger.warning(f"[云查] 配置读取失败，使用默认配置: {e}")
        except Exception:
            pass
    return cfg


def save_config(cfg):
    """保存云查配置到 ~/.desktopguard/cloud_query_config.json。"""
    merged = dict(DEFAULT_CONFIG)
    if isinstance(cfg, dict):
        for k in DEFAULT_CONFIG:
            if k in cfg:
                merged[k] = cfg[k]
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        try:
            app_logger.error(f"[云查] 配置保存失败: {e}")
        except Exception:
            pass
        return False


# ============================================================
# 2. 本地缓存表（cloud_query_cache）
# ============================================================

def _get_conn():
    """获取 dg_data.db 连接（row_factory=Row）。"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """在现有 dg_data.db 中创建 cloud_query_cache 表（IF NOT EXISTS，不破坏现有表）。"""
    conn = _get_conn()
    try:
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS cloud_query_cache (
                sha256 TEXT PRIMARY KEY,
                source TEXT,
                verdict TEXT,
                threat_name TEXT,
                threat_type TEXT,
                detections INTEGER,
                total_engines INTEGER,
                first_seen INTEGER,
                last_checked INTEGER,
                raw_json TEXT
            )
        """)
        conn.commit()
        return True
    except Exception as e:
        try:
            app_logger.error(f"[云查] 初始化缓存表失败: {e}")
        except Exception:
            pass
        return False
    finally:
        conn.close()


def _cache_lookup(sha256, ttl_days):
    """查询未过期缓存，命中返回统一结果 dict，否则返回 None。"""
    if not sha256:
        return None
    try:
        conn = _get_conn()
        try:
            row = conn.execute(
                "SELECT * FROM cloud_query_cache WHERE sha256 = ?", (sha256,)
            ).fetchone()
        finally:
            conn.close()
        if not row:
            return None
        # TTL 判定：超过 cache_ttl_days 视为过期
        now = int(time.time())
        ttl_sec = int(ttl_days) * 86400
        if (now - int(row["last_checked"] or now)) > ttl_sec:
            return None
        return {
            "sha256": row["sha256"],
            "verdict": row["verdict"] or "unknown",
            "threat_name": row["threat_name"] or "",
            "threat_type": row["threat_type"] or "",
            "source": row["source"] or "unknown",
            "detections": row["detections"],
            "total_engines": row["total_engines"],
            "reason": f"缓存命中（来源={row['source']}）",
        }
    except Exception as e:
        try:
            app_logger.warning(f"[云查] 读缓存失败: {e}")
        except Exception:
            pass
        return None


def _cache_store(result, raw_json=""):
    """把云查结果写入缓存（INSERT OR REPLACE）。本地库命中不写缓存。"""
    try:
        now = int(time.time())
        conn = _get_conn()
        try:
            conn.execute(
                """INSERT OR REPLACE INTO cloud_query_cache
                   (sha256, source, verdict, threat_name, threat_type,
                    detections, total_engines, first_seen, last_checked, raw_json)
                   VALUES (?, ?, ?, ?, ?, ?, ?,
                           COALESCE((SELECT first_seen FROM cloud_query_cache WHERE sha256 = ?), ?),
                           ?, ?)""",
                (
                    result.get("sha256", ""),
                    result.get("source", "unknown"),
                    result.get("verdict", "unknown"),
                    result.get("threat_name", ""),
                    result.get("threat_type", ""),
                    result.get("detections"),
                    result.get("total_engines"),
                    result.get("sha256", ""), now,
                    now,
                    raw_json or "",
                )
            )
            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        try:
            app_logger.warning(f"[云查] 写缓存失败: {e}")
        except Exception:
            pass


# ============================================================
# 工具：计算文件 SHA256（优先用 engine.sha256_of，失败则本地 hashlib 兜底）
# ============================================================

def _file_sha256(path):
    """计算文件 SHA256，失败返回空串。"""
    try:
        if _engine_sha256_of is not None:
            digest = _engine_sha256_of(path)
            if digest:
                return digest.lower()
    except Exception:
        pass
    # 兜底：标准库 hashlib
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                b = f.read(1024 * 1024)
                if not b:
                    break
                h.update(b)
        return h.hexdigest()
    except Exception:
        return ""


def _empty_result(sha256, verdict="unknown", source="unknown", reason=""):
    """统一返回格式构造。"""
    return {
        "sha256": sha256 or "",
        "verdict": verdict,
        "threat_name": "",
        "threat_type": "",
        "source": source,
        "detections": None,
        "total_engines": None,
        "reason": reason,
    }


# ============================================================
# 4. 微步在线（ThreatBook）API
# ============================================================

def _query_threatbook(sha256, api_key, timeout):
    """查询微步在线。成功解析返回统一结果 dict；未收录/失败/配额耗尽返回 None（降级到下一通道）。"""
    if not api_key or not sha256:
        return None
    try:
        params = urllib.parse.urlencode({
            "apikey": api_key,
            "sample": sha256,
            "sandbox_type": "win",
        })
        req = urllib.request.Request(
            THREATBOOK_URL,
            data=params.encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="ignore")
        data = json.loads(body)
    except urllib.error.HTTPError as e:
        try:
            app_logger.warning(f"[云查] 微步 HTTP {e.code}，降级")
        except Exception:
            pass
        return None
    except Exception as e:
        try:
            app_logger.warning(f"[云查] 微步请求异常: {e}")
        except Exception:
            pass
        return None

    # code 非 0（配额耗尽/Key 无效/参数错误等）→ 降级
    try:
        code = data.get("code", data.get("response_code", 0))
        if code not in (0, "0", None):
            try:
                app_logger.info(f"[云查] 微步返回 code={code}，降级")
            except Exception:
                pass
            return None
    except Exception:
        pass

    payload = data.get("data") or {}
    summary = payload.get("summary") or {}
    malware_type = (summary.get("malware_type")
                    or payload.get("malware_type")
                    or payload.get("malware_family") or "")
    threat_level = (summary.get("threat_level")
                    or payload.get("threat_level") or "")
    # 没有任何恶意标签 → 视为未收录，降级到 VT
    if not malware_type and not threat_level:
        return None

    # 判定威胁等级
    level_str = str(threat_level).lower()
    if level_str in ("high", "critical", "severe"):
        verdict = "malicious"
    elif level_str in ("medium", "low", "suspicious"):
        verdict = "suspicious"
    else:
        # 有 malware_type 但无明确等级，按可疑处理
        verdict = "malicious" if malware_type else "unknown"

    result = {
        "sha256": sha256,
        "verdict": verdict,
        "threat_name": payload.get("malware_family") or summary.get("malware_family") or malware_type,
        "threat_type": malware_type,
        "source": "threatbook",
        "detections": 1 if verdict == "malicious" else 0,
        "total_engines": None,
        "reason": f"微步在线判定: {malware_type or threat_level}",
    }
    _cache_store(result, raw_json=body)
    return result


# ============================================================
# 5. VirusTotal API v3
# ============================================================

def _query_virustotal(sha256, api_key, timeout):
    """查询 VirusTotal。成功返回统一结果 dict；404 未收录/429 限流/失败返回 None。"""
    if not api_key or not sha256:
        return None
    url = VIRUSTOTAL_URL.format(sha256=sha256)
    req = urllib.request.Request(url, headers={"x-apikey": api_key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="ignore")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            # VT 未收录该样本 → 视为未命中，继续走兜底
            return None
        try:
            app_logger.warning(f"[云查] VirusTotal HTTP {e.code}，降级")
        except Exception:
            pass
        return None
    except Exception as e:
        try:
            app_logger.warning(f"[云查] VirusTotal 请求异常: {e}")
        except Exception:
            pass
        return None

    try:
        data = json.loads(body)
        attrs = (data.get("data") or {}).get("attributes") or {}
        stats = attrs.get("last_analysis_stats") or {}
        malicious = int(stats.get("malicious", 0) or 0)
        suspicious = int(stats.get("suspicious", 0) or 0)
        total = sum(int(v or 0) for v in stats.values())
        detections = malicious + suspicious

        if malicious > 0:
            verdict = "malicious"
        elif suspicious > 0:
            verdict = "suspicious"
        else:
            verdict = "clean"

        # 威胁名：优先 meaningful_name / 文件名
        threat_name = attrs.get("meaningful_name") or ""
        if not threat_name:
            names = attrs.get("names") or []
            if names:
                threat_name = names[0]

        result = {
            "sha256": sha256,
            "verdict": verdict,
            "threat_name": threat_name,
            "threat_type": "VirusTotal" if verdict != "clean" else "",
            "source": "virustotal",
            "detections": detections,
            "total_engines": total,
            "reason": f"VirusTotal: {malicious} 恶意 / {suspicious} 可疑，共 {total} 引擎",
        }
        _cache_store(result, raw_json=body)
        return result
    except Exception as e:
        try:
            app_logger.warning(f"[云查] VirusTotal 解析失败: {e}")
        except Exception:
            pass
        return None


# ============================================================
# 3. 查询链路（核心）
# ============================================================

def query_hash(sha256):
    """
    直接按 SHA256 查询（不计算文件）。
    链路：本地病毒库 → 本地缓存 → 微步在线 → VirusTotal → 离线兜底。
    任何环节失败都不抛异常，最终返回 {"verdict":"unknown","source":"offline"}。
    """
    if not sha256:
        return _empty_result("", reason="空哈希")
    sha256 = sha256.strip().lower()
    cfg = load_config()

    # 总开关
    if not cfg.get("enabled", True):
        return _empty_result(sha256, verdict="unknown", source="unknown",
                            reason="云查已在配置中关闭")

    timeout = float(cfg.get("timeout", 3) or 3)
    ttl_days = cfg.get("cache_ttl_days", 7)

    # (1) 本地病毒库命中 → 直接返回
    try:
        if check_virus_hash is not None:
            hit, name, threat_type, desc = check_virus_hash(sha256)
            if hit:
                return {
                    "sha256": sha256,
                    "verdict": "malicious",
                    "threat_name": name or "",
                    "threat_type": threat_type or "",
                    "source": "local",
                    "detections": None,
                    "total_engines": None,
                    "reason": f"本地病毒库命中: {name or threat_type or desc}",
                }
    except Exception as e:
        try:
            app_logger.warning(f"[云查] 本地病毒库查询异常: {e}")
        except Exception:
            pass

    # (2) 本地缓存未过期 → 直接返回
    try:
        cached = _cache_lookup(sha256, ttl_days)
        if cached is not None:
            return cached
    except Exception:
        pass

    # (3) 微步在线（无 Key 自动跳过）
    tb_key = cfg.get("threatbook_api_key", "")
    if tb_key:
        try:
            r = _query_threatbook(sha256, tb_key, timeout)
            if r is not None:
                return r
        except Exception:
            pass

    # (4) VirusTotal（无 Key 自动跳过）
    vt_key = cfg.get("virustotal_api_key", "")
    if vt_key:
        try:
            r = _query_virustotal(sha256, vt_key, timeout)
            if r is not None:
                return r
        except Exception:
            pass

    # (5) 全通道失败 / 无 Key / 断网 → 离线兜底
    return _empty_result(sha256, verdict="unknown", source="offline",
                        reason="无可用云端通道或网络不可达")


def query_file(file_path):
    """
    对文件做云查：先算 SHA256，再走 query_hash 链路。
    文件不存在/哈希计算失败时返回 unknown，不抛异常。
    """
    try:
        sha256 = _file_sha256(file_path)
        if not sha256:
            return _empty_result("", verdict="unknown", source="unknown",
                                reason=f"无法计算文件哈希: {file_path}")
        result = query_hash(sha256)
        if not result.get("reason"):
            result["reason"] = f"文件: {file_path}"
        return result
    except Exception as e:
        try:
            app_logger.error(f"[云查] query_file 异常: {e}")
        except Exception:
            pass
        return _empty_result("", verdict="unknown", source="offline",
                            reason=f"云查异常: {e}")


# ============================================================
# 7. 便捷函数
# ============================================================

def get_cache_stats():
    """返回缓存统计：总数、恶意数、可疑数、未过期数。"""
    stats = {"total": 0, "malicious": 0, "suspicious": 0, "fresh": 0}
    try:
        cfg = load_config()
        ttl_sec = int(cfg.get("cache_ttl_days", 7)) * 86400
        now = int(time.time())
        conn = _get_conn()
        try:
            row = conn.execute("SELECT COUNT(*) AS c FROM cloud_query_cache").fetchone()
            stats["total"] = row["c"] if row else 0
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM cloud_query_cache WHERE verdict = 'malicious'"
            ).fetchone()
            stats["malicious"] = row["c"] if row else 0
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM cloud_query_cache WHERE verdict = 'suspicious'"
            ).fetchone()
            stats["suspicious"] = row["c"] if row else 0
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM cloud_query_cache WHERE (?-last_checked) < ?",
                (now, ttl_sec)
            ).fetchone()
            stats["fresh"] = row["c"] if row else 0
        finally:
            conn.close()
    except Exception as e:
        try:
            app_logger.warning(f"[云查] 缓存统计失败: {e}")
        except Exception:
            pass
    return stats


def clear_expired_cache():
    """清理超过 cache_ttl_days 的缓存，返回清理条数。"""
    removed = 0
    try:
        cfg = load_config()
        ttl_sec = int(cfg.get("cache_ttl_days", 7)) * 86400
        cutoff = int(time.time()) - ttl_sec
        conn = _get_conn()
        try:
            cur = conn.execute(
                "DELETE FROM cloud_query_cache WHERE last_checked < ?", (cutoff,)
            )
            removed = cur.rowcount or 0
            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        try:
            app_logger.warning(f"[云查] 清理过期缓存失败: {e}")
        except Exception:
            pass
    return removed


# ============================================================
# 自测块：打印配置状态、缓存统计，不发起任何网络请求
# ============================================================
if __name__ == "__main__":
    print("=" * 50)
    print("DG安全 3.0 云查模块 self-test")
    print("=" * 50)

    # 初始化缓存表
    ok = init_db()
    print(f"[1] init_db() 创建 cloud_query_cache: {'OK' if ok else 'FAIL'}")

    # 配置状态（Key 脱敏）
    cfg = load_config()
    def _mask(k):
        return ("****" + k[-4:]) if k else "(未配置)"
    print(f"[2] 配置: enabled={cfg.get('enabled')}, timeout={cfg.get('timeout')}s, "
          f"ttl={cfg.get('cache_ttl_days')}天")
    print(f"    微步Key: {_mask(cfg.get('threatbook_api_key',''))}")
    print(f"    VT Key : {_mask(cfg.get('virustotal_api_key',''))}")

    # 缓存统计
    st = get_cache_stats()
    print(f"[3] 缓存统计: 总数={st['total']}, 恶意={st['malicious']}, "
          f"可疑={st['suspicious']}, 未过期={st['fresh']}")

    # 清理过期缓存
    removed = clear_expired_cache()
    print(f"[4] 清理过期缓存: 删除 {removed} 条")

    # 无 Key 场景下的兜底验证（不发网络请求，纯本地链路）
    fake_hash = "0" * 64
    r = query_hash(fake_hash)
    print(f"[5] query_hash(全零哈希) -> verdict={r['verdict']}, source={r['source']}, "
          f"reason={r['reason']}")

    print("=" * 50)
    print("自测完成：模块可安全导入，无网络请求已发出。")
