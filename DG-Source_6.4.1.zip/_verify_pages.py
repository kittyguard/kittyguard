# -*- coding: utf-8 -*-
import urllib.request, json, ssl, io

ctx = ssl.create_default_context()
handler = urllib.request.ProxyHandler({
    'http': 'http://127.0.0.1:33210',
    'https': 'http://127.0.0.1:33210',
})
opener = urllib.request.build_opener(handler)

# 1) version.json on Pages
r = opener.open('https://kittyguard.github.io/kittyguard/version.json', timeout=30)
d = json.load(r)
print('version.json latest_version =', d.get('latest_version'))
print('pkg =', d.get('pkg', '<MISSING>'))
print('sha256 =', d.get('sha256', '<MISSING>')[:16] if d.get('sha256') else '<MISSING>')

# 2) 官网 HTML 下载链接
r = opener.open('https://kittyguard.github.io/kittyguard/', timeout=30)
s = r.read().decode('utf-8', 'ignore')
import re
links = re.findall(r'href="([^"]*(?:DG-Security[^"]*|releases[^"]*))"', s)
seen = []
for l in links:
    if l not in seen:
        seen.append(l)
for l in seen:
    print('HTML link:', l)
