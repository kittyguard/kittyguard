# -*- coding: utf-8 -*-
import subprocess, hashlib, os, tempfile

tmp = os.path.join(tempfile.gettempdir(), "dg_dl_test2")
os.makedirs(tmp, exist_ok=True)
expected = {
    "DG-Security-Setup-6.4.1.exe": ("9D10465B", 30898197),
    "DG-Security_6.4.1.zip": ("D8283EF3", 44518921),
}
for name, (prefix, want_size) in expected.items():
    u = "https://kittyguard.github.io/kittyguard/" + name
    out = os.path.join(tmp, name)
    if os.path.exists(out):
        os.remove(out)
    # 走代理下载（红海代理）
    r = subprocess.run(["curl", "-s", "-L", "--max-time", "420",
                        "-x", "http://127.0.0.1:33210", "-o", out, u],
                       capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=450)
    if os.path.exists(out):
        size = os.path.getsize(out)
        h = hashlib.sha256()
        with open(out, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        sha = h.hexdigest().upper()
        print("%s: size=%d (期望 %d) sha256=%s... 完整=%s 哈希匹配=%s" %
              (name, size, want_size, sha[:8], size == want_size, sha.startswith(prefix)))
    else:
        print("%s: 下载失败" % name)
