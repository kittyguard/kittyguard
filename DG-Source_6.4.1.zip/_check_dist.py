# -*- coding: utf-8 -*-
import os

DIST = r"F:\桌面保护\desktopguard\dist\DG安全"
total = 0
files = []
for root, dirs, fs in os.walk(DIST):
    for f in fs:
        p = os.path.join(root, f)
        sz = os.path.getsize(p)
        total += sz
        files.append((sz, p))

files.sort(reverse=True)
print("total files:", len(files))
print("total size: %.1f MB" % (total / 1048576))
print("--- top 20 by size ---")
for sz, p in files[:20]:
    print("%10d  %s" % (sz, p.replace(DIST, ".")))
