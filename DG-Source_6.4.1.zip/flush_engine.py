# -*- coding: utf-8 -*-
"""DG 5.1.0 洪流冲刷引擎 —— 像水一样冲走垃圾、病毒、残骸

阶段流水线（线程化、可停止、进度回调、免打扰联动）：
  1. 预检       —— 磁盘/系统概况快照
  2. 垃圾冲洗   —— 可再生缓存清理（白名单清单，绝不碰个人文件；回收站默认不动）
  3. 病毒冲洗   —— 全盘快速扫描 + 统一裁决层判定 → 高危/严重自动隔离（可还原）
  4. 残骸冲洗   —— 注册表 Run 无效项（先备份后清理）/启动目录孤儿/隔离区残留记录清理
  5. 冲刷报告   —— 释放空间/扫描数/威胁数/隔离数/残骸数统计 + 日志落盘

原则：
  - 只清理可再生缓存，不碰个人文件；
  - 病毒走 database.quarantine_file（XOR 隔离，可还原）；
  - 注册表清理前导出 .reg 备份（可回滚）；
  - 免打扰模式下不弹任何确认框，自动执行安全动作；
  - 全程可停止（cancel_event）。
"""
import os
import re
import time
import glob
import json
import shutil
import winreg
import threading
import traceback

# ============ 路径与常量 ============
FLUSH_PHASES = ["预检", "垃圾冲洗", "病毒冲洗", "残骸冲洗", "冲刷报告"]

# 垃圾清理白名单（与 doubao-pc-optimizer win_clean 同清单：只删可再生缓存）
def _junk_targets():
    la = os.environ.get("LOCALAPPDATA", "")
    return [
        ("用户临时文件", os.environ.get("TEMP", "")),
        ("系统临时文件", r"C:\Windows\Temp"),
        ("Windows 更新缓存", r"C:\Windows\SoftwareDistribution\Download"),
        ("DirectX 着色器缓存", os.path.join(la, "D3DSCache") if la else ""),
        ("NVIDIA 着色器缓存", os.path.join(la, "NVIDIA", "DXCache") if la else ""),
        ("NVIDIA GL 缓存", os.path.join(la, "NVIDIA", "GLCache") if la else ""),
        ("缩略图缓存", os.path.join(la, "Microsoft", "Windows", "Explorer") if la else ""),
        ("Chrome 缓存", os.path.join(la, "Google", "Chrome", "User Data") if la else ""),
        ("Edge 缓存", os.path.join(la, "Microsoft", "Edge", "User Data") if la else ""),
    ]


def _dir_size(path):
    """只统计大小（清理前后对比用），异常容错。"""
    total = 0
    try:
        for root, _dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except Exception:
                    pass
    except Exception:
        pass
    return total


def _clean_dir_contents(label, path, progress_cb, cancel_evt, log):
    """清理目录内容（只删文件与子目录内容，不删目录本身；被占用自动跳过）。"""
    if not path or not os.path.isdir(path):
        return 0, 0
    before = _dir_size(path)
    freed = 0
    try:
        for entry in os.listdir(path):
            if cancel_evt and cancel_evt.is_set():
                break
            full = os.path.join(path, entry)
            try:
                if os.path.isdir(full) and not os.path.islink(full):
                    shutil.rmtree(full, ignore_errors=True)
                else:
                    os.remove(full)
            except Exception:
                pass
    except Exception:
        pass
    after = _dir_size(path)
    freed = max(0, before - after)
    if freed > 0:
        log(f"  ✓ {label}：释放 {_fmt_mb(freed)}")
    return before, freed


def _clean_thumbcache(progress_cb, cancel_evt, log):
    """缩略图缓存：只删 thumbcache_* 文件，同目录其他文件不动。"""
    path = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Explorer")
    if not os.path.isdir(path):
        return 0
    before = sum(os.path.getsize(os.path.join(path, f)) for f in os.listdir(path)
                 if f.startswith("thumbcache_") and os.path.isfile(os.path.join(path, f)))
    for f in os.listdir(path):
        if cancel_evt and cancel_evt.is_set():
            break
        if f.startswith("thumbcache_"):
            try:
                os.remove(os.path.join(path, f))
            except Exception:
                pass
    after = sum(os.path.getsize(os.path.join(path, f)) for f in os.listdir(path)
                if f.startswith("thumbcache_") and os.path.isfile(os.path.join(path, f)))
    freed = max(0, before - after)
    if freed > 0:
        log(f"  ✓ 缩略图缓存：释放 {_fmt_mb(freed)}")
    return freed


def _clean_browser_profiles(browser_dir, progress_cb, cancel_evt, log):
    """浏览器缓存：每个 profile 只清 Cache / Code Cache 目录。"""
    if not browser_dir or not os.path.isdir(browser_dir):
        return 0
    freed = 0
    try:
        for prof in os.listdir(browser_dir):
            if cancel_evt and cancel_evt.is_set():
                break
            prof_dir = os.path.join(browser_dir, prof)
            if not os.path.isdir(prof_dir) or (prof != "Default" and not prof.startswith("Profile ")):
                continue
            for sub in ("Cache", "Code Cache"):
                _b, _f = _clean_dir_contents(f"{prof}\\{sub}", os.path.join(prof_dir, sub),
                                              progress_cb, cancel_evt, log)
                freed += _f
    except Exception:
        pass
    return freed


def _fmt_mb(n):
    return f"{n / 1024 / 1024:.1f} MB"


# ============ 残骸扫描（注册表/启动目录） ============
RUN_ROOTS = [
    (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
    (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
    (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
    (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
]


def _value_points_to_missing(value):
    """判断注册表 Run 值指向的目标是否已不存在（残骸）。
    保守原则：路径解析不可靠的场景（无引号且含空格）一律不判残骸，宁漏勿误删。"""
    v = (value or "").strip()
    if not v:
        return False
    # 去掉引号与命令行参数
    m = re.match(r'^"([^"]+)"', v)
    if m:
        exe = m.group(1)
    else:
        if " " in v:
            # 无引号且整体含空格：可能是带参数命令或路径含空格，
            # Windows 解析不可靠——不判残骸（宁漏勿误删）
            return False
        exe = v
    if not exe:
        return False
    if exe.lower().startswith(("http://", "https://", "ms-", "shell:", "rundll32 ")):
        return False  # 协议/系统命令，不判定
    # 含环境变量则展开
    exe = os.path.expandvars(exe)
    if os.path.isabs(exe):
        if os.path.exists(exe):
            return False
        # 无扩展名 → 补常见可执行扩展名再试（注册表常省略 .exe）
        if not os.path.splitext(exe)[1]:
            for ext in (".exe", ".com", ".bat", ".cmd", ".scr"):
                if os.path.exists(exe + ext):
                    return False
        return not os.path.exists(exe)
    # 相对路径：按 System32 与 PATH 解析
    sys32 = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32")
    if os.path.exists(os.path.join(sys32, exe)):
        return False
    for d in os.environ.get("PATH", "").split(";"):
        if d and os.path.exists(os.path.join(d, exe)):
            return False
    return not os.path.exists(exe)


def scan_registry_debris(cancel_evt, log):
    """扫描注册表 Run/RunOnce 无效项。返回 [(root, key, name, value)]。"""
    debris = []
    for hive, subkey in RUN_ROOTS:
        try:
            with winreg.OpenKey(hive, subkey) as k:
                idx = 0
                while True:
                    try:
                        name, value, _t = winreg.EnumValue(k, idx)
                    except OSError:
                        break
                    idx += 1
                    if cancel_evt and cancel_evt.is_set():
                        return debris
                    if _value_points_to_missing(value):
                        debris.append((hive, subkey, name, value))
                        log(f"  ! 注册表残骸：{name} = {value}")
        except OSError:
            continue
    return debris


def export_run_backup(debris, backup_dir):
    """把待清理的 Run 项导出为 .reg 备份（可回滚）。返回备份文件路径。"""
    if not debris:
        return ""
    os.makedirs(backup_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    out = os.path.join(backup_dir, f"run_backup_{ts}.reg")
    lines = ["Windows Registry Editor Version 5.00", ""]
    # 按 (hive, key) 分组
    groups = {}
    for hive, subkey, name, value in debris:
        groups.setdefault((hive, subkey), []).append((name, value))
    for (hive, subkey), items in groups.items():
        hive_name = "HKEY_CURRENT_USER" if hive == winreg.HKEY_CURRENT_USER else "HKEY_LOCAL_MACHINE"
        lines.append(f"[{hive_name}\\{subkey}]")
        for name, value in items:
            lines.append(f'"{name}"="{value}"')
        lines.append("")
    try:
        with open(out, "w", encoding="utf-16") as f:  # .reg 用 UTF-16
            f.write("\n".join(lines))
        return out
    except Exception:
        return ""


def delete_run_values(debris):
    """删除无效 Run 项。返回成功删除数。"""
    removed = 0
    for hive, subkey, name, _value in debris:
        try:
            with winreg.OpenKey(hive, subkey, 0, winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, name)
                removed += 1
        except Exception:
            pass
    return removed


def scan_startup_debris(cancel_evt, log):
    """扫描启动目录：快捷方式目标不存在 → 孤儿。返回 [path, ...]。"""
    roots = [
        os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu",
                     "Programs", "Startup"),
        os.path.join(os.environ.get("ProgramData", "C:\\ProgramData"), "Microsoft", "Windows",
                     "Start Menu", "Programs", "Startup"),
    ]
    orphans = []
    for root in roots:
        if not os.path.isdir(root):
            continue
        for f in os.listdir(root):
            if cancel_evt and cancel_evt.is_set():
                return orphans
            full = os.path.join(root, f)
            if f.lower().endswith(".lnk") and os.path.isfile(full):
                target = _resolve_lnk_target(full)
                if target and not os.path.exists(target):
                    orphans.append(full)
                    log(f"  ! 启动目录孤儿：{f} → {target}（目标不存在）")
            elif os.path.isfile(full) and not f.lower().endswith((".ini", ".txt", ".log", ".md")):
                # 非快捷方式的孤立脚本/程序（保守：仅报告）
                log(f"  ? 启动目录非常规文件（仅报告）：{f}")
    return orphans


def _resolve_lnk_target(lnk_path):
    try:
        import win32com.client  # 可选依赖，缺失则跳过解析
        sh = win32com.client.Dispatch("WScript.Shell")
        return str(sh.CreateShortcut(lnk_path).Targetpath)
    except Exception:
        return ""


def cleanup_quarantine_records(log):
    """清理隔离区残留记录：数据库 status=quarantined 但隔离文件已不存在。
    修复用户遇到的「恢复时报隔离文件不存在」历史问题。返回清理条数。"""
    removed = 0
    try:
        import database
        conn = database.get_db()
        rows = conn.execute("SELECT id, quarantined_name FROM quarantine WHERE status='quarantined'").fetchall()
        for row in rows:
            qname = row["quarantined_name"] or ""
            qpath = os.path.join(database.QUARANTINE_DIR, qname)
            if not os.path.exists(qpath):
                conn.execute("UPDATE quarantine SET status='missing_cleared', "
                             "reason=COALESCE(reason,'')||' | 洪流冲刷清理残留记录' WHERE id=?", (row["id"],))
                removed += 1
        conn.commit()
        conn.close()
        if removed:
            log(f"  ✓ 隔离区残留记录清理：{removed} 条（文件已不在隔离库）")
    except Exception as e:
        log(f"  - 隔离区记录检查跳过：{e}")
    return removed


# ============ 洪流冲刷主引擎 ============
class FlushEngine:
    def __init__(self, cancel_evt=None, progress_cb=None, log_cb=None,
                 dnd=False, clean_invalid_run=True, clean_startup_orphan=True):
        self.cancel_evt = cancel_evt or threading.Event()
        self.progress_cb = progress_cb or (lambda *a: None)   # (phase, done, total, msg)
        self.log_cb = log_cb or (lambda m: None)
        self.dnd = dnd
        self.clean_invalid_run = clean_invalid_run
        self.clean_startup_orphan = clean_startup_orphan
        self.stats = {
            "started": time.strftime("%Y-%m-%d %H:%M:%S"),
            "junk_freed": 0, "junk_items": 0,
            "scanned": 0, "threats": 0, "quarantined": 0,
            "debris_run": 0, "debris_orphan": 0, "debris_records": 0,
            "phases": [], "log_lines": [],
        }

    # ---- 工具 ----
    def _log(self, msg):
        self.stats["log_lines"].append(msg)
        try:
            self.log_cb(msg)
        except Exception:
            pass

    def _prog(self, phase, done, total, msg=""):
        try:
            self.progress_cb(phase, done, total, msg)
        except Exception:
            pass

    def _cancelled(self):
        return self.cancel_evt and self.cancel_evt.is_set()

    # ---- 阶段 1：垃圾冲洗 ----
    def _flush_junk(self):
        self._log("【垃圾冲洗】只清理可再生缓存，不触碰个人文件")
        total_freed = 0
        steps = []
        for label, path in _junk_targets():
            if self._cancelled():
                break
            if "thumbcache" in label:
                total_freed += _clean_thumbcache(self.progress_cb, self.cancel_evt, self._log)
            elif "Chrome" in label or "Edge" in label:
                total_freed += _clean_browser_profiles(path, self.progress_cb, self.cancel_evt, self._log)
            else:
                _b, _f = _clean_dir_contents(label, path, self.progress_cb, self.cancel_evt, self._log)
                total_freed += _f
            steps.append(label)
        # 回收站：默认不自动清（用户误删文件的恢复渠道），仅在报告中提示
        try:
            import ctypes
            _rb = ctypes.windll.shell32.SHQueryRecycleBinW(None, None, None)
        except Exception:
            pass
        self.stats["junk_freed"] = total_freed
        self.stats["junk_items"] = len(steps)
        self._log(f"垃圾冲洗完成：共释放 {_fmt_mb(total_freed)}（回收站未动，可在系统回收站单独清理）")

    # ---- 阶段 2：病毒冲洗 ----
    def _flush_virus(self):
        self._log("【病毒冲洗】全盘快速扫描 + 统一裁决层判定")
        try:
            import engine
            import verdict_engine
        except Exception as e:
            self._log(f"病毒冲洗跳过（引擎加载失败：{e}）")
            return
        scanner = engine.Scanner(deep_strings=False, hash_all=False, max_hash_size=10 * 1024 * 1024)
        targets = []
        for p, _rec in engine.quick_scan_targets():
            targets.append(p)
        # 补：其他盘根（跳过系统目录，控制时长）
        for d in engine.list_all_drives():
            if d and d not in targets and os.path.isdir(d):
                targets.append(d)
        total_files = 0
        checked = 0
        threats = []
        try:
            for tgt in targets:
                if self._cancelled():
                    break
                for f in engine.enum_files(tgt, recursive=True, skip_system=True,
                                           skip_bulk=True, skip_harmless=True):
                    if self._cancelled():
                        break
                    total_files += 1
                    if total_files % 200 == 0:
                        self._prog(2, total_files, 0, f"正在扫描：{f}")
                    try:
                        r = scanner.scan_file(f)
                        if r is None or getattr(r, "level", "") == engine.LEVEL_SAFE:
                            continue
                        # 统一裁决层最终权威
                        v = verdict_engine.assess(
                            path=f, name=os.path.basename(f),
                            category=getattr(r, "category", ""),
                            sha256=getattr(r, "sha256", ""),
                            res_tags=getattr(r, "tags", None),
                            res_hits=getattr(r, "hits", None),
                            res_score=getattr(r, "score", 0),
                            res_level=getattr(r, "level", ""),
                            whitelisted=getattr(r, "whitelisted", False),
                            blacklisted=getattr(r, "blacklisted", False),
                            cloud_malicious=getattr(r, "cloud_malicious", False),
                            eicar=getattr(r, "eicar", False),
                            clamav_hit=getattr(r, "clamav_hit", False),
                            yara_hit=getattr(r, "yara_hit", False),
                            signed_valid=getattr(r, "signed_valid", False),
                        )
                        lvl = v["level"]
                        if lvl in ("高危", "严重"):
                            threats.append((f, lvl, v["final_score"]))
                            self._log(f"  ⚠ 威胁：{f} [{lvl} {v['final_score']}分]")
                            if not self.dnd:
                                pass  # 由 UI 层弹窗确认（默认自动隔离，见下）
                    except Exception:
                        continue
        finally:
            scanner.close() if hasattr(scanner, "close") else None
        self.stats["scanned"] = total_files
        self.stats["threats"] = len(threats)
        # 隔离：免打扰自动隔离；否则也自动隔离（高危/严重已过裁决层，属强证据）
        import database
        for f, lvl, score in threats:
            if self._cancelled():
                break
            try:
                ok, msg = database.quarantine_file(f, sha256="", threat_level=lvl,
                                                   reason=f"洪流冲刷自动隔离（裁决 {score} 分）")
                if ok:
                    self.stats["quarantined"] += 1
                    self._log(f"  ✓ 已隔离：{os.path.basename(f)}（{msg}）")
                else:
                    self._log(f"  ✗ 隔离失败：{f}（{msg}）")
            except Exception as e:
                self._log(f"  ✗ 隔离异常：{f}（{e}）")
        self._log(f"病毒冲洗完成：扫描 {total_files} 个文件，发现威胁 {len(threats)}，隔离 {self.stats['quarantined']}")

    # ---- 阶段 3：残骸冲洗 ----
    def _flush_debris(self):
        self._log("【残骸冲洗】注册表无效项（先备份）·启动目录孤儿·隔离区残留记录")
        # 注册表 Run
        debris = scan_registry_debris(self.cancel_evt, self._log)
        self.stats["debris_run"] = len(debris)
        if debris and self.clean_invalid_run:
            backup_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                      "dgdata", "backup")
            bak = export_run_backup(debris, backup_dir)
            removed = delete_run_values(debris)
            self.stats["debris_run"] = removed
            if bak:
                self._log(f"  备份已导出（可回滚）：{bak}")
            self._log(f"  已清理无效注册表项 {removed} 条")
        elif debris:
            self._log(f"  （仅报告）发现无效注册表项 {len(debris)} 条，未自动清理")
        # 启动目录孤儿
        orphans = scan_startup_debris(self.cancel_evt, self._log)
        if orphans and self.clean_startup_orphan:
            removed = 0
            for p in orphans:
                try:
                    os.remove(p)
                    removed += 1
                except Exception:
                    pass
            self.stats["debris_orphan"] = removed
            self._log(f"  已清理启动目录孤儿 {removed} 个")
        else:
            self.stats["debris_orphan"] = 0
            if orphans:
                self._log(f"  （仅报告）发现启动目录孤儿 {len(orphans)} 个")
        # 隔离区残留记录
        self.stats["debris_records"] = cleanup_quarantine_records(self._log)
        self._log("残骸冲洗完成")

    # ---- 主流程 ----
    def run(self):
        try:
            self._log(f"洪流冲刷开始（{'免打扰模式' if self.dnd else '标准模式'}）")
            phases = [
                ("预检", lambda: self._log("预检完成：已就绪")),
                ("垃圾冲洗", self._flush_junk),
                ("病毒冲洗", self._flush_virus),
                ("残骸冲洗", self._flush_debris),
                ("冲刷报告", self._finalize),
            ]
            for i, (name, fn) in enumerate(phases):
                if self._cancelled():
                    self._log("洪流冲刷被用户停止")
                    break
                self._prog(i, 0, len(phases), name)
                self.stats["phases"].append(name)
                try:
                    fn()
                except Exception:
                    self._log(f"阶段 {name} 异常：{traceback.format_exc()}")
                self._prog(i, 1, len(phases), name + " 完成")
        except Exception:
            self._log("洪流冲刷异常：" + traceback.format_exc())
        finally:
            self.stats["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")
            self._save_report()
            self._prog(4, 1, 1, "冲刷报告已生成")

    def _finalize(self):
        s = self.stats
        self._log("【冲刷报告】")
        self._log(f"  垃圾释放：{_fmt_mb(s['junk_freed'])}")
        self._log(f"  病毒扫描：{s['scanned']} 文件 / 威胁 {s['threats']} / 隔离 {s['quarantined']}")
        self._log(f"  残骸清理：注册表 {s['debris_run']} / 启动孤儿 {s['debris_orphan']} / 隔离记录 {s['debris_records']}")

    def _save_report(self):
        try:
            logs_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dgdata", "logs")
            os.makedirs(logs_dir, exist_ok=True)
            ts = time.strftime("%Y%m%d_%H%M%S")
            p = os.path.join(logs_dir, f"flush_{ts}.log")
            with open(p, "w", encoding="utf-8") as f:
                f.write("\n".join(self.stats["log_lines"]))
            self.stats["report_path"] = p
            self._log(f"报告已保存：{p}")
        except Exception:
            pass


if __name__ == "__main__":
    # 引擎自测：只跑垃圾冲洗+残骸扫描（不自动清理，纯报告），不跑全盘病毒扫描
    import sys
    evt = threading.Event()
    eng = FlushEngine(cancel_evt=evt, clean_invalid_run=False, clean_startup_orphan=False)
    eng._flush_junk()
    eng._flush_debris()
    print("\n".join(eng.stats["log_lines"][-8:]))
    print("自测完成")
