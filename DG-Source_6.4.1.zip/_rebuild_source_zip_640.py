﻿# -*- coding: utf-8 -*-
"""重建官网源码更新包 DG-Source_6.4.0.zip + 同步 version.json 两副本"""
import io, os, zipfile, json, hashlib, time

DG = r"F:\桌面保护\desktopguard"
OFF = os.path.join(DG, "官网")
NEW_VER = "6.4.0"

# 1) 以 6.2.0 旧包文件列表为基准 + 根目录新增文件，保证集合不漂移
old_zip = os.path.join(OFF, "DG-Source_6.2.0.zip")
base = set()
if os.path.isfile(old_zip):
    with zipfile.ZipFile(old_zip) as z:
        base = set(n for n in z.namelist() if "/" not in n)

root_files = set(f for f in os.listdir(DG) if os.path.isfile(os.path.join(DG, f)))
include = sorted(base | root_files)
skip = {".gitignore"}
include = [f for f in include if f not in skip]

out_zip = os.path.join(OFF, "DG-Source_%s.zip" % NEW_VER)
with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for fn in include:
        p = os.path.join(DG, fn)
        if os.path.isfile(p):
            z.write(p, fn)
size = os.path.getsize(out_zip)
sha = hashlib.sha256()
with open(out_zip, "rb") as f:
    for chunk in iter(lambda: f.read(65536), b""):
        sha.update(chunk)
sha256 = sha.hexdigest().upper()
print("[OK] %s: %d 文件 / %d B / SHA256 %s" % (out_zip, len(include), size, sha256))

notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "pkg": "DG-Source_%s.zip" % NEW_VER,
    "download_url": "DG-Security_%s.zip" % NEW_VER,
    "sha256": sha256,
    "size_bytes": size,
    "release_notes": "6.4.0 内容更新：自启动实时监控 + 扫描 IO 节流。",
}
for sub in ("", "publish"):
    d = OFF if not sub else os.path.join(OFF, sub)
    os.makedirs(d, exist_ok=True)
    with io.open(os.path.join(d, "version.json"), "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 两副本已同步为 %s" % NEW_VER)
