# -*- coding: utf-8 -*-
"""
DesktopGuard 轻量数据库（SQLite）
==================================
零依赖（Python 内置 sqlite3），单文件数据库，存储：
- 病毒哈希库（已知危险文件 SHA256）
- 垃圾文件规则
- 扫描历史记录
- 白名单/黑名单
- 隔离区记录
"""

from paths import DATA_DIR
import os
import sqlite3
import time
import json
import subprocess
import re
import threading
# PostgreSQL 驱动为可选依赖：未安装时自动降级 SQLite（_pg_available 返回 False）
try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    _PSYCOPG2_OK = True
except Exception:
    psycopg2 = None
    RealDictCursor = None
    _PSYCOPG2_OK = False

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_data.db")


class _NoCloseConn:
    """包装 sqlite3 连接：close() 变为 no-op，保证线程本地复用不被调用方关闭。"""

    def __init__(self, conn):
        self._c = conn

    def __getattr__(self, item):
        return getattr(self._c, item)

    def execute(self, sql, params=None):
        return self._c.execute(sql, params or ())

    def executemany(self, sql, seq):
        return self._c.executemany(sql, seq)

    def commit(self):
        self._c.commit()

    def close(self):
        pass  # no-op：线程本地复用，进程退出自动断开


def get_db():
    """获取数据库连接（线程本地复用，仅首次建表）。
    PG 可用 → PostgreSQL 适配器（每线程 1 个，close 为 no-op）；否则 SQLite 兜底。"""
    if _pg_available():
        ad = getattr(_tls, "adapter", None)
        if ad is None:
            ad = _PgAdapter()
            try:
                _init_tables(ad)
            except Exception:
                pass
            _tls.adapter = ad
        return ad
    conn = getattr(_tls, "sqlite", None)
    if conn is None:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        _init_tables(conn)
        _tls.sqlite = _NoCloseConn(conn)
    return _tls.sqlite



# ============================================================
# PostgreSQL 双后端（4.6.0：本机部署 DGPostgreSQL 服务为主数据库，SQLite 离线兜底）
# ============================================================

PG_PASSWORD = "OvopaVFxu3v8kIk590Q9"
_PG_CFG = {
    "host": "127.0.0.1",
    "port": 5432,
    "dbname": "dgdb",
    "user": "dguser",
    "password": PG_PASSWORD,
    "connect_timeout": 3,
}
_PG_PK = {  # INSERT OR REPLACE 表 → 主键列
    "file_cache": "path", "cloud_cache": "sha256",
    "virus_hashes": "sha256", "whitelist": "path", "blacklist": "path",
}
_tls = threading.local()
_PG_FAIL_UNTIL = 0.0  # 连接失败冷却（秒），避免每次调用都重试拖慢
_LAST_PG_OK = 0.0   # 最近一次 PG 连接成功时间戳（成功冷却 10 秒，避免每文件建连测试）


def _pg_available():
    """PG 服务是否可用（失败冷却 60 秒；成功冷却 10 秒，避免高频建连测试拖慢扫描）。
    psycopg2 未安装时直接判定不可用（降级 SQLite）。"""
    global _PG_FAIL_UNTIL, _LAST_PG_OK
    if not _PSYCOPG2_OK:
        return False
    now = time.time()
    if now < _PG_FAIL_UNTIL:
        return False
    if now - _LAST_PG_OK < 10:
        return True
    try:
        conn = psycopg2.connect(**_PG_CFG, cursor_factory=RealDictCursor)
        conn.close()
        _LAST_PG_OK = now
        return True
    except Exception:
        _PG_FAIL_UNTIL = now + 60
        return False


def _pg_get_conn():
    """取当前线程的 PG 连接（每线程复用，避免高频建连）。"""
    c = getattr(_tls, "pg", None)
    if c is None or c.closed:
        c = psycopg2.connect(**_PG_CFG, cursor_factory=RealDictCursor)
        _tls.pg = c
    return c


def _translate_sql(sql):
    """SQLite SQL → PostgreSQL 方言（本库用到的有限模式）。"""
    # 建表：AUTOINCREMENT → BIGSERIAL
    if sql.strip().upper().startswith("CREATE TABLE"):
        return sql.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
    # INSERT OR REPLACE → ON CONFLICT DO UPDATE
    m = re.match(r"INSERT OR REPLACE INTO (\w+)\s*\(([^)]+)\)\s*VALUES", sql, re.I)
    if m:
        table, cols_str = m.group(1), m.group(2)
        cols = [c.strip() for c in cols_str.split(",")]
        pk = _PG_PK.get(table)
        ph = ", ".join(["%s"] * len(cols))
        if pk:
            updates = ", ".join("%s=EXCLUDED.%s" % (c, c) for c in cols if c != pk)
            return ("INSERT INTO %s (%s) VALUES (%s) ON CONFLICT (%s) DO UPDATE SET %s"
                    % (table, cols_str, ph, pk, updates))
        return "INSERT INTO %s (%s) VALUES (%s)" % (table, cols_str, ph)
    # 占位符 ? → %s
    return sql.replace("?", "%s")


class _RowCursor:
    """极简 cursor 代理（供 last_insert_rowid 特判返回）。"""
    def __init__(self, rows):
        self._rows = rows
        self._i = 0

    def fetchone(self):
        if self._i < len(self._rows):
            r = self._rows[self._i]
            self._i += 1
            return r
        return None

    def fetchall(self):
        return self._rows


class _PgAdapter:
    """psycopg2 适配器：接口对齐 sqlite3.Connection（execute/executemany/commit/close）。
    - 行对象支持 row["col"]（RealDictRow）与 dict(row)
    - 线程本地连接复用；close() 为 no-op（进程退出自动断开）
    - PG 异常自动降级 SQLite（连接冷却 60 秒，随后 get_db 直接走 SQLite）
    """

    def __init__(self):
        self._last_id = None
        self._sqlite_fb = None

    def _fallback_sqlite(self):
        global _PG_FAIL_UNTIL
        _PG_FAIL_UNTIL = time.time() + 60
        if self._sqlite_fb is None:
            self._sqlite_fb = sqlite3.connect(DB_PATH)
            self._sqlite_fb.row_factory = sqlite3.Row
        return self._sqlite_fb

    def execute(self, sql, params=None):
        try:
            conn = _pg_get_conn()
        except Exception:
            return self._fallback_sqlite().execute(sql, params or ())
        try:
            up = sql.strip().upper()
            # last_insert_rowid 特判（add_disabled_startup）
            if "LAST_INSERT_ROWID" in up:
                return _RowCursor([{"id": self._last_id or 0}])
            cur = conn.cursor()
            tsql = _translate_sql(sql)
            # INSERT 带主键自增 → RETURNING id 记录 last_id
            if up.startswith("INSERT INTO DISABLED_STARTUP_ITEMS"):
                tsql += " RETURNING id"
                cur.execute(tsql, params or ())
                row = cur.fetchone()
                self._last_id = row["id"] if row else None
                return cur
            cur.execute(tsql, params or ())
            return cur
        except Exception:
            fb = self._fallback_sqlite()
            return fb.execute(sql, params or ())

    def executemany(self, sql, seq):
        try:
            conn = _pg_get_conn()
        except Exception:
            return self._fallback_sqlite().executemany(sql, seq)
        try:
            cur = conn.cursor()
            cur.executemany(_translate_sql(sql), seq)
            return cur
        except Exception:
            fb = self._fallback_sqlite()
            return fb.executemany(sql, seq)

    def commit(self):
        try:
            _pg_get_conn().commit()
        except Exception:
            try:
                self._fallback_sqlite().commit()
            except Exception:
                pass

    def close(self):
        pass  # 线程本地连接复用，进程退出自动断开

    def cursor(self):
        """供 _init_tables 使用：返回 SQL 翻译代理 cursor。"""
        return _PgCursor(_pg_get_conn())


class _PgCursor:
    """代理 cursor：execute 时翻译 SQLite SQL → PG 方言（建表 AUTOINCREMENT 等）。"""

    def __init__(self, conn):
        self._cur = conn.cursor()

    def execute(self, sql, params=None):
        return self._cur.execute(_translate_sql(sql), params or ())

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()


def _init_tables(conn):
    """初始化所有表。"""
    c = conn.cursor()

    # 病毒哈希库
    c.execute("""
        CREATE TABLE IF NOT EXISTS virus_hashes (
            sha256 TEXT PRIMARY KEY,
            name TEXT,
            threat_type TEXT,
            description TEXT,
            added_at INTEGER
        )
    """)

    # 垃圾文件规则
    c.execute("""
        CREATE TABLE IF NOT EXISTS junk_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern TEXT,
            rule_type TEXT,
            description TEXT,
            enabled INTEGER DEFAULT 1
        )
    """)

    # 沙箱行为分析报告
    c.execute("""
        CREATE TABLE IF NOT EXISTS behavior_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sample_path TEXT,
            sha256 TEXT,
            work_dir TEXT,
            status TEXT,
            risk_level TEXT,
            behavior_summary TEXT,
            duration_seconds INTEGER,
            created_at INTEGER
        )
    """)

    # 安全事件日志
    c.execute("""
        CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT,
            severity TEXT,
            file_path TEXT,
            sha256 TEXT,
            details TEXT,
            created_at INTEGER
        )
    """)


    c.execute("""
        CREATE TABLE IF NOT EXISTS scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_mode TEXT,
            total_files INTEGER,
            threat_count INTEGER,
            junk_count INTEGER,
            duration REAL,
            scanned_at INTEGER
        )
    """)

    # 白名单
    c.execute("""
        CREATE TABLE IF NOT EXISTS whitelist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            path TEXT UNIQUE,
            sha256 TEXT,
            reason TEXT,
            added_at INTEGER
        )
    """)

    # 黑名单
    c.execute("""
        CREATE TABLE IF NOT EXISTS blacklist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            path TEXT UNIQUE,
            sha256 TEXT,
            threat_type TEXT,
            reason TEXT,
            added_at INTEGER
        )
    """)

    # 隔离区记录
    c.execute("""
        CREATE TABLE IF NOT EXISTS quarantine (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_path TEXT,
            quarantined_name TEXT,
            sha256 TEXT,
            file_size INTEGER,
            threat_level TEXT,
            reason TEXT,
            quarantined_at INTEGER,
            status TEXT DEFAULT 'quarantined'
        )
    """)

    # 文件指纹缓存（加速重复扫描）
    c.execute("""
        CREATE TABLE IF NOT EXISTS file_cache (
            path TEXT PRIMARY KEY,
            size INTEGER,
            mtime REAL,
            sha256 TEXT,
            last_score INTEGER,
            last_level TEXT,
            last_tags TEXT,
            last_scan_time INTEGER,
            engine_version TEXT
        )
    """)

    # 云查威胁情报缓存（3.1.0 新增）
    c.execute("""
        CREATE TABLE IF NOT EXISTS cloud_cache (
            sha256 TEXT PRIMARY KEY,
            verdict TEXT,
            name TEXT,
            severity TEXT,
            source TEXT,
            queried_at INTEGER
        )
    """)

    # 已禁用的启动项（用于恢复）
    c.execute("""
        CREATE TABLE IF NOT EXISTS disabled_startup_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_type TEXT,
            root_key TEXT,
            registry_path TEXT,
            value_name TEXT,
            value_data TEXT,
            file_path TEXT,
            original_location TEXT,
            disabled_at INTEGER,
            risk_level TEXT,
            note TEXT
        )
    """)

    # 受保护文件（备份 + 防删 + 手动还原，4.2.0 新增）
    c.execute("""
        CREATE TABLE IF NOT EXISTS protected_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT UNIQUE,
            backup_path TEXT,
            file_size INTEGER,
            added_at INTEGER,
            status TEXT DEFAULT 'active',
            note TEXT
        )
    """)

    conn.commit()


# ============================================================
# 文件指纹缓存
# ============================================================

def get_file_cache(path, size, mtime, engine_version="1.6.0"):
    """获取文件缓存。如果路径、大小、修改时间、引擎版本都匹配，返回缓存结果；否则返回None。"""
    if not path:
        return None
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM file_cache WHERE path = ? AND size = ? AND mtime = ? AND engine_version = ?",
            (path, size, mtime, engine_version)
        ).fetchone()
        if row:
            import json as _json
            tags = _json.loads(row["last_tags"]) if row["last_tags"] else []
            return {
                "sha256": row["sha256"],
                "score": row["last_score"],
                "level": row["last_level"],
                "tags": tags,
                "scan_time": row["last_scan_time"]
            }
        return None
    finally:
        conn.close()

def set_file_cache(path, size, mtime, sha256, score, level, tags, engine_version="1.6.0"):
    """写入文件缓存。"""
    if not path:
        return
    conn = get_db()
    try:
        import json as _json
        tags_json = _json.dumps(tags, ensure_ascii=False) if tags else "[]"
        conn.execute(
            "INSERT OR REPLACE INTO file_cache (path, size, mtime, sha256, last_score, last_level, last_tags, last_scan_time, engine_version) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (path, size, mtime, sha256, score, level, tags_json, int(time.time()), engine_version)
        )
        conn.commit()
    finally:
        conn.close()

def clear_file_cache():
    """清空文件缓存。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM file_cache")
        conn.commit()
    finally:
        conn.close()

def set_file_cache_batch(items, engine_version="1.6.0"):
    """批量写入文件缓存（一次事务，扫描完成时调用，加速重复扫描）。
    items: [(path, size, mtime, sha256, score, level, tags), ...]
    """
    if not items:
        return 0
    import json as _json
    conn = get_db()
    try:
        rows = []
        now = int(time.time())
        for path, size, mtime, sha256, score, level, tags in items:
            if not path or size is None or mtime is None:
                continue
            tags_json = _json.dumps(tags, ensure_ascii=False) if tags else "[]"
            rows.append((path, size, mtime, sha256, score, level, tags_json, now, engine_version))
        conn.executemany(
            "INSERT OR REPLACE INTO file_cache (path, size, mtime, sha256, last_score, last_level, last_tags, last_scan_time, engine_version) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            rows
        )
        conn.commit()
        return len(rows)
    finally:
        conn.close()


# ============================================================
# 云查威胁情报缓存（3.1.0）
# ============================================================

def get_cloud_cache(sha256):
    """读取云查缓存。未命中返回 None。"""
    if not sha256:
        return None
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM cloud_cache WHERE sha256 = ?", (sha256,)
        ).fetchone()
        if row:
            return {"verdict": row["verdict"], "name": row["name"],
                    "severity": row["severity"], "source": row["source"]}
        return None
    finally:
        conn.close()

def set_cloud_cache(sha256, verdict, name, severity, source):
    """写入云查缓存。"""
    if not sha256:
        return
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO cloud_cache (sha256, verdict, name, severity, source, queried_at) VALUES (?, ?, ?, ?, ?, ?)",
            (sha256, verdict, name, severity, source, int(time.time()))
        )
        conn.commit()
    finally:
        conn.close()

def get_cloud_cache_count():
    conn = get_db()
    try:
        return conn.execute("SELECT COUNT(*) as cnt FROM cloud_cache").fetchone()["cnt"]
    finally:
        conn.close()

def clear_cloud_cache():
    conn = get_db()
    try:
        conn.execute("DELETE FROM cloud_cache")
        conn.commit()
    finally:
        conn.close()

def get_cloud_cache_stats():
    """威胁情报摘要（5.1.1）：缓存总数 + 判定/严重度/来源分组统计。"""
    conn = get_db()
    try:
        total = conn.execute("SELECT COUNT(*) as c FROM cloud_cache").fetchone()["c"]
        verdicts = {}
        for r in conn.execute("SELECT verdict, COUNT(*) as c FROM cloud_cache GROUP BY verdict ORDER BY c DESC"):
            verdicts[r["verdict"] or "未知"] = r["c"]
        severities = {}
        for r in conn.execute("SELECT severity, COUNT(*) as c FROM cloud_cache GROUP BY severity ORDER BY c DESC"):
            severities[r["severity"] or "未知"] = r["c"]
        sources = {}
        for r in conn.execute("SELECT source, COUNT(*) as c FROM cloud_cache GROUP BY source ORDER BY c DESC"):
            sources[r["source"] or "未知"] = r["c"]
        return {"total": total, "verdicts": verdicts,
                "severities": severities, "sources": sources}
    finally:
        conn.close()

def get_cloud_cache_recent(limit=20):
    """威胁情报摘要（5.1.1）：最近 N 条云查记录（新→旧）。"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT sha256, verdict, name, severity, source, queried_at "
            "FROM cloud_cache ORDER BY queried_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [{"sha256": r["sha256"], "verdict": r["verdict"],
                 "name": r["name"], "severity": r["severity"],
                 "source": r["source"], "queried_at": r["queried_at"]}
                for r in rows]
    finally:
        conn.close()



# ============================================================
# 已禁用启动项管理
# ============================================================

def add_disabled_startup(item_type, root_key, registry_path, value_name, value_data,
                          file_path, original_location, risk_level="中", note=""):
    """添加一条已禁用启动项记录。"""
    conn = get_db()
    try:
        conn.execute(
            """INSERT INTO disabled_startup_items
               (item_type, root_key, registry_path, value_name, value_data,
                file_path, original_location, disabled_at, risk_level, note)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (item_type, root_key, registry_path, value_name, value_data,
             file_path, original_location, int(time.time()), risk_level, note)
        )
        conn.commit()
        return conn.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
    finally:
        conn.close()

def get_all_disabled_startup():
    """获取所有已禁用的启动项。"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM disabled_startup_items ORDER BY disabled_at DESC"
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()

def delete_disabled_startup(item_id):
    """删除一条已禁用启动项记录（恢复后调用）。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM disabled_startup_items WHERE id = ?", (item_id,))
        conn.commit()
    finally:
        conn.close()

def get_disabled_startup_by_location(original_location, value_name):
    """根据原始位置和值名查找已禁用启动项。"""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM disabled_startup_items WHERE original_location = ? AND value_name = ?",
            (original_location, value_name)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()




# ============================================================
# 病毒哈希库管理
# ============================================================

def add_virus_hash(sha256, name="", threat_type="", description=""):
    """添加一个病毒哈希。"""
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO virus_hashes (sha256, name, threat_type, description, added_at) VALUES (?, ?, ?, ?, ?)",
            (sha256, name, threat_type, description, int(time.time()))
        )
        conn.commit()
        return True
    finally:
        conn.close()

def delete_virus_hash(sha256):
    """删除一个病毒哈希。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM virus_hashes WHERE sha256 = ?", (sha256,))
        conn.commit()
        return True
    finally:
        conn.close()

def get_all_virus_hashes():
    """获取所有病毒哈希。"""
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM virus_hashes ORDER BY added_at DESC").fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()

def get_virus_count():
    """获取病毒哈希数量。"""
    conn = get_db()
    try:
        row = conn.execute("SELECT COUNT(*) as cnt FROM virus_hashes").fetchone()
        return row["cnt"] if row else 0
    finally:
        conn.close()

def import_virus_hashes_from_txt(filepath):
    """从TXT文件导入病毒哈希。格式：sha256,name,threat_type,description（逗号分隔，name等可选）"""
    count = 0
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(",")
            sha256 = parts[0].strip().lower()
            if len(sha256) != 64:
                continue
            name = parts[1].strip() if len(parts) > 1 else ""
            threat_type = parts[2].strip() if len(parts) > 2 else ""
            description = parts[3].strip() if len(parts) > 3 else ""
            add_virus_hash(sha256, name, threat_type, description)
            count += 1
    return count

def import_virus_hashes_from_json(filepath):
    """从JSON文件导入病毒哈希。格式：[{sha256, name, threat_type, description}, ...]"""
    import json as _json
    count = 0
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        data = _json.load(f)
    if isinstance(data, list):
        for item in data:
            sha256 = item.get("sha256", "").strip().lower()
            if len(sha256) != 64:
                continue
            name = item.get("name", "")
            threat_type = item.get("threat_type", "")
            description = item.get("description", "")
            add_virus_hash(sha256, name, threat_type, description)
            count += 1
    return count

def clear_virus_hashes():
    """清空病毒哈希库。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM virus_hashes")
        conn.commit()
        return True
    finally:
        conn.close()


def get_cache_count():
    """获取缓存条目数量。"""
    conn = get_db()
    try:
        row = conn.execute("SELECT COUNT(*) as cnt FROM file_cache").fetchone()
        return row["cnt"] if row else 0
    finally:
        conn.close()


# ============================================================
# 病毒哈希库
# ============================================================

def add_virus_hash(sha256, name="", threat_type="", description=""):
    """添加病毒哈希。"""
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO virus_hashes (sha256, name, threat_type, description, added_at) VALUES (?, ?, ?, ?, ?)",
            (sha256, name, threat_type, description, int(time.time()))
        )
        conn.commit()
    finally:
        conn.close()


def check_virus_hash(sha256):
    """检查哈希是否在病毒库中，返回 (是否命中, 名称, 类型, 描述)。"""
    if not sha256:
        return False, "", "", ""
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM virus_hashes WHERE sha256 = ?", (sha256,)).fetchone()
        if row:
            return True, row["name"], row["threat_type"], row["description"]
        return False, "", "", ""
    finally:
        conn.close()


def get_virus_hash_map():
    """获取所有病毒哈希映射 {sha256: 描述}（用于扫描引擎加载到内存）。"""
    conn = get_db()
    try:
        rows = conn.execute("SELECT sha256, name, threat_type FROM virus_hashes").fetchall()
        return {r["sha256"]: f"{r['threat_type']}（{r['name']}）" for r in rows}
    finally:
        conn.close()


# ============================================================
# 扫描历史
# ============================================================

def add_behavior_report(sample_path, sha256, work_dir, status, risk_level,
                     behavior_summary, duration_seconds):
    """添加沙箱行为分析报告。"""
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO behavior_reports (sample_path, sha256, work_dir, status, risk_level, behavior_summary, duration_seconds, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (sample_path, sha256 or "", work_dir or "", status or "unknown",
             risk_level or "info", behavior_summary or "", int(duration_seconds or 0), int(time.time()))
        )
        conn.commit()
    finally:
        conn.close()


def get_behavior_reports(limit=50):
    """获取最近的沙箱行为分析报告。"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM behavior_reports ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def add_security_event(source, severity, file_path, sha256, details):
    """添加安全事件日志（沙箱/隔离/拦截/勒索守护等）。"""
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO security_events (source, severity, file_path, sha256, details, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (source, severity, file_path or "", sha256 or "", details or "", int(time.time()))
        )
        conn.commit()
    finally:
        conn.close()


def get_security_events(source=None, limit=50):
    """获取安全事件日志（6.1.0 勒索守护历史窗口等），可按来源过滤，时间倒序。"""
    conn = get_db()
    try:
        if source:
            rows = conn.execute(
                "SELECT * FROM security_events WHERE source=? ORDER BY created_at DESC LIMIT ?",
                (source, limit)).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM security_events ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def add_scan_history(scan_mode, total_files, threat_count, junk_count, duration):
    """添加扫描历史记录。"""
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO scan_history (scan_mode, total_files, threat_count, junk_count, duration, scanned_at) VALUES (?, ?, ?, ?, ?, ?)",
            (scan_mode, total_files, threat_count, junk_count, duration, int(time.time()))
        )
        conn.commit()
    finally:
        conn.close()


def get_scan_history(limit=20):
    """获取最近的扫描历史。"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM scan_history ORDER BY scanned_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def clear_scan_history():
    """清空全部扫描历史（6.0.5）。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM scan_history")
        conn.commit()
    finally:
        conn.close()


# ============================================================
# 白名单 / 黑名单
# ============================================================

def add_whitelist(path, sha256="", reason=""):
    """添加白名单。"""
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO whitelist (path, sha256, reason, added_at) VALUES (?, ?, ?, ?)",
            (path, sha256, reason, int(time.time()))
        )
        conn.commit()
    finally:
        conn.close()


def remove_whitelist(path):
    """移除白名单。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM whitelist WHERE path = ?", (path,))
        conn.commit()
    finally:
        conn.close()


def get_whitelist():
    """获取所有白名单路径。"""
    conn = get_db()
    try:
        rows = conn.execute("SELECT path FROM whitelist").fetchall()
        return set(r["path"].lower() for r in rows)
    finally:
        conn.close()


def get_whitelist_full():
    """获取所有白名单完整信息（用于管理界面显示）。"""
    conn = get_db()
    try:
        rows = conn.execute("SELECT path, sha256, reason, added_at FROM whitelist ORDER BY added_at DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def add_blacklist(path, sha256="", threat_type="", reason=""):
    """添加黑名单。"""
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO blacklist (path, sha256, threat_type, reason, added_at) VALUES (?, ?, ?, ?, ?)",
            (path, sha256, threat_type, reason, int(time.time()))
        )
        conn.commit()
    finally:
        conn.close()


def get_blacklist():
    """获取所有黑名单。"""
    conn = get_db()
    try:
        rows = conn.execute("SELECT path, sha256, threat_type, reason FROM blacklist").fetchall()
        return {r["path"].lower(): f"{r['threat_type']}（{r['reason']}）" for r in rows}
    finally:
        conn.close()


def get_blacklist_full():
    """获取所有黑名单完整信息（用于管理界面显示）。"""
    conn = get_db()
    try:
        rows = conn.execute("SELECT path, sha256, threat_type, reason, added_at FROM blacklist ORDER BY added_at DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def remove_blacklist(path):
    """移除黑名单。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM blacklist WHERE path = ?", (path,))
        conn.commit()
    finally:
        conn.close()


# ============================================================
# 隔离区
# ============================================================

QUARANTINE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "quarantine")

# C++ 隔离引擎（dg_quarantine.exe，2.16.0 起优先使用；失败自动回退 Python）
DG_QUARANTINE_EXE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_quarantine.exe")
QUARANTINE_META = os.path.join(QUARANTINE_DIR, "_meta")


def init_quarantine():
    """初始化隔离区目录。"""
    os.makedirs(QUARANTINE_DIR, exist_ok=True)


def _is_self_protected(path):
    """检查是否是DG自保护文件（禁止隔离）。"""
    try:
        abs_path = os.path.abspath(path).lower()
        # DG程序目录
        app_dir = os.path.dirname(os.path.abspath(__file__)).lower()
        if abs_path.startswith(app_dir):
            return True
        # 隔离区目录
        if abs_path.startswith(QUARANTINE_DIR.lower()):
            return True
        # 数据库文件
        if abs_path.endswith(".db") and app_dir in abs_path:
            return True
        # 版本快照目录
        versions_dir = os.path.join(app_dir, "versions").lower()
        if abs_path.startswith(versions_dir):
            return True
        # 日志目录
        import os as _os
        log_dir = _os.path.join(DATA_DIR, "logs").lower()
        if abs_path.startswith(log_dir):
            return True
        return False
    except Exception:
        return False

def _xor_file(src_path, dest_path, key=0xA5):
    """对文件内容做XOR编码（可逆），防止隔离文件被误运行。"""
    try:
        with open(src_path, "rb") as f:
            data = f.read()
        encoded = bytes(b ^ key for b in data)
        with open(dest_path, "wb") as f:
            f.write(encoded)
        return True
    except Exception:
        return False

def _load_json_any(raw):
    """C++ 输出可能是 UTF-8 或 GBK 代码页，两种都试。"""
    if not raw:
        return {}
    for enc in ("utf-8", "gbk", "utf-16"):
        try:
            return json.loads(raw.decode(enc))
        except Exception:
            continue
    return {}


def _cxx_quarantine(original_path):
    """C++ 隔离引擎：XOR(0xA5)编码 + 移入隔离区 + 元数据(SHA256)。返回 (是否成功, 隔离文件名)。"""
    if not os.path.isfile(DG_QUARANTINE_EXE):
        return False, ""
    try:
        p = subprocess.run(
            [DG_QUARANTINE_EXE, "isolate", original_path, QUARANTINE_DIR, QUARANTINE_META],
            capture_output=True, timeout=60,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        raw = p.stdout
        data = _load_json_any(raw)
        if data.get("success"):
            dgq = data.get("dgq", "") or ""
            return True, os.path.basename(dgq) if dgq else ""
    except Exception:
        pass
    return False, ""


def _cxx_restore(src_path):
    """C++ 恢复引擎：读元数据定位原路径 + XOR解码 + SHA256校验 + 写回。返回 (是否成功, 信息)。"""
    if not os.path.isfile(DG_QUARANTINE_EXE):
        return False, "C++ 引擎缺失"
    try:
        p = subprocess.run(
            [DG_QUARANTINE_EXE, "restore", src_path, QUARANTINE_META],
            capture_output=True, timeout=60,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        data = _load_json_any(p.stdout)
        if data.get("success"):
            return True, data.get("msg", "restored")
    except Exception:
        pass
    return False, "C++ 恢复失败"


def _force_unlock_path(path):
    """B1 顽固文件强制解锁：管理员权限下 takeown + icacls 获取所有权并开放 ACL，
    用于隔离被拒绝访问（WinError 5）或只读的顽固文件。
    全程隐藏窗口、静默执行；非管理员运行会自动失败（不影响常规路径）。
    返回: bool（尽力而为，不抛异常）。
    """
    try:
        _cf = 0x08000000 if os.name == "nt" else 0
        subprocess.run(["takeown", "/f", path], capture_output=True, timeout=15,
                       creationflags=_cf)
        subprocess.run(["icacls", path, "/grant", "Administrators:F"],
                       capture_output=True, timeout=15, creationflags=_cf)
        return True
    except Exception:
        return False


def quarantine_file(original_path, sha256="", threat_level="", reason=""):
    """将文件移入隔离区（XOR编码防误运行）。返回 (是否成功, 隔离后的文件名)。"""
    if not os.path.exists(original_path):
        return False, "文件不存在"

    # 自保护检查：禁止隔离DG自己的文件
    if _is_self_protected(original_path):
        return False, "该文件是DG程序文件，已被自保护排除，禁止隔离"

    init_quarantine()

    # 生成隔离后的文件名：原文件名.virus_时间戳
    base_name = os.path.basename(original_path)
    timestamp = int(time.time())
    quarantined_name = f"{base_name}.virus_{timestamp}"
    dest_path = os.path.join(QUARANTINE_DIR, quarantined_name)

    # C++ 隔离引擎优先（XOR编码+SHA256校验+元数据），失败回退 Python
    cxx_ok, cxx_name = _cxx_quarantine(original_path)
    if cxx_ok and cxx_name:
        quarantined_name = cxx_name
        dest_path = os.path.join(QUARANTINE_DIR, quarantined_name)
    else:
        try:
            # XOR编码后写入隔离区，然后删除原文件
            success = _xor_file(original_path, dest_path)
            if success:
                os.remove(original_path)
            else:
                # XOR失败则退化为普通移动
                import shutil
                shutil.move(original_path, dest_path)
        except Exception as e:
            # B1 顽固文件增强：常规隔离失败（WinError 5 拒绝访问/只读）时，
            # 用管理员权限 takeown + icacls 强制解锁后重试移动；仍失败才报错。
            if isinstance(e, (PermissionError, OSError)):
                _force_unlock_path(original_path)
                try:
                    import shutil
                    shutil.move(original_path, dest_path)
                except Exception as e2:
                    return False, f"{e}；强制解锁后仍失败: {e2}"
            else:
                return False, str(e)

    # 记录到数据库
    file_size = 0
    try:
        file_size = os.path.getsize(dest_path)
    except Exception:
        pass

    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO quarantine (original_path, quarantined_name, sha256, file_size, threat_level, reason, quarantined_at, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (original_path, quarantined_name, sha256, file_size, threat_level, reason, timestamp, "quarantined")
        )
        conn.commit()
    finally:
        conn.close()

    return True, quarantined_name


def restore_file(quarantine_id):
    """从隔离区恢复文件（XOR还原）。返回 (是否成功, 信息)。"""
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM quarantine WHERE id = ?", (quarantine_id,)).fetchone()
        if not row:
            return False, "记录不存在"
        if row["status"] != "quarantined":
            return False, "文件已被处理"

        src_path = os.path.join(QUARANTINE_DIR, row["quarantined_name"])
        dest_path = row["original_path"]

        if not os.path.exists(src_path):
            # 容错：文件可能被其他软件改名/移动（如其他杀软清理隔离目录），
            # 在隔离目录内按原始隔离名前缀搜索，尽量找回
            try:
                _stem = str(row["quarantined_name"]).rsplit(".virus_", 1)[0]
                for _fn in os.listdir(QUARANTINE_DIR):
                    _fp = os.path.join(QUARANTINE_DIR, _fn)
                    if os.path.isfile(_fp) and (_fn == row["quarantined_name"]
                            or (_stem and _fn.startswith(_stem + ".virus_"))
                            or str(row["quarantined_name"]).startswith(str(_fn).split(".virus_")[0] + ".virus_")):
                        src_path = _fp
                        break
            except Exception:
                pass
        if not os.path.exists(src_path):
            return False, "隔离文件不存在（可能在隔离目录外被移动或已被清除）"

        # 确保目标目录存在
        dest_dir = os.path.dirname(dest_path)
        if dest_dir and not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        # C++ 恢复引擎优先（仅 .dgq 格式），失败回退 Python
        if src_path.lower().endswith(".dgq"):
            cxx_ok, cxx_msg = _cxx_restore(src_path)
            if cxx_ok:
                # 修复：C++ 恢复成功也必须更新状态并提交，否则 UI 仍显示可恢复、
                # 再次点击报"隔离文件不存在"（副本已被 C++ 引擎消费删除）
                try:
                    conn.execute("UPDATE quarantine SET status = 'restored' WHERE id = ?", (quarantine_id,))
                    conn.commit()
                except Exception:
                    pass
                conn.close()
                return True, f"已恢复（C++ 引擎）"

        try:
            # XOR还原后写入原路径，然后删除隔离文件
            success = _xor_file(src_path, dest_path)
            if success:
                os.remove(src_path)
            else:
                # XOR失败则退化为普通移动
                import shutil
                shutil.move(src_path, dest_path)
        except Exception as e:
            return False, str(e)

        conn.execute("UPDATE quarantine SET status = 'restored' WHERE id = ?", (quarantine_id,))
        conn.commit()
        return True, "已恢复到原路径"
    finally:
        conn.close()


def delete_quarantined(quarantine_id):
    """彻底删除隔离区文件。返回 (是否成功, 信息)。"""
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM quarantine WHERE id = ?", (quarantine_id,)).fetchone()
        if not row:
            return False, "记录不存在"

        src_path = os.path.join(QUARANTINE_DIR, row["quarantined_name"])
        if os.path.exists(src_path):
            try:
                os.remove(src_path)
            except Exception as e:
                return False, str(e)

        conn.execute("UPDATE quarantine SET status = 'deleted' WHERE id = ?", (quarantine_id,))
        conn.commit()
        return True, "已彻底删除"
    finally:
        conn.close()


def get_quarantine_list():
    """获取隔离区文件列表。"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM quarantine WHERE status = 'quarantined' ORDER BY quarantined_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_quarantine_count():
    """获取隔离区文件数量。"""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) as cnt FROM quarantine WHERE status = 'quarantined'"
        ).fetchone()
        return row["cnt"] if row else 0
    finally:
        conn.close()


# ============================================================
# 受保护文件（4.2.0：备份 + 防删 + 手动还原）
# ============================================================

PROTECTED_BACKUP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "protected_backup")


def _ensure_protected_dir():
    """确保受保护文件备份目录存在。"""
    os.makedirs(PROTECTED_BACKUP_DIR, exist_ok=True)
    return PROTECTED_BACKUP_DIR


def add_protected_file(file_path, note=""):
    """备份并登记一个受保护文件。返回 (是否成功, 信息)。"""
    if not file_path:
        return False, "路径为空"
    if not os.path.exists(file_path):
        return False, "文件不存在：" + str(file_path)

    # 去重：同一路径只保护一次
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id FROM protected_files WHERE file_path = ?", (file_path,)
        ).fetchone()
        if row:
            return False, "该文件已在受保护列表中"
    finally:
        conn.close()

    # 复制到备份目录（保留时间戳前缀，避免同名冲突）
    bdir = _ensure_protected_dir()
    fname = os.path.basename(file_path) or "file"
    stamp = int(time.time())
    backup_path = os.path.join(bdir, f"{stamp}_{fname}")
    try:
        import shutil
        shutil.copy2(file_path, backup_path)
    except Exception as e:
        return False, "备份失败：" + str(e)

    try:
        fsize = os.path.getsize(file_path)
    except Exception:
        fsize = 0

    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO protected_files (file_path, backup_path, file_size, added_at, status, note) VALUES (?, ?, ?, ?, ?, ?)",
            (file_path, backup_path, fsize, int(time.time()), "active", note or "")
        )
        conn.commit()
        return True, backup_path
    except Exception as e:
        return False, "登记失败：" + str(e)
    finally:
        conn.close()


def remove_protected_file(pid):
    """移除保护记录（保留备份文件）。返回 (是否成功, 信息)。"""
    conn = get_db()
    try:
        conn.execute("DELETE FROM protected_files WHERE id = ?", (pid,))
        conn.commit()
        return True, "已移除保护（备份文件保留在 protected_backup）"
    finally:
        conn.close()


def get_protected_files():
    """获取受保护文件列表（含丢失状态）。"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM protected_files ORDER BY added_at DESC"
        ).fetchall()
        result = []
        for r in rows:
            item = dict(r)
            item["exists"] = os.path.exists(r["file_path"]) if r["file_path"] else False
            item["backup_exists"] = os.path.exists(r["backup_path"]) if r["backup_path"] else False
            result.append(item)
        return result
    finally:
        conn.close()


def check_protected_files():
    """检查受保护文件，返回丢失（原文件不存在的）列表。"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM protected_files WHERE status = 'active'"
        ).fetchall()
    finally:
        conn.close()
    missing = []
    for r in rows:
        p = r["file_path"]
        if p and not os.path.exists(p):
            missing.append(dict(r))
    return missing


def restore_protected_file(pid):
    """从备份手动还原受保护文件。返回 (是否成功, 信息)。"""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM protected_files WHERE id = ?", (pid,)
        ).fetchone()
    finally:
        conn.close()
    if not row:
        return False, "记录不存在"
    backup_path = row["backup_path"]
    orig_path = row["file_path"]
    if not backup_path or not os.path.exists(backup_path):
        return False, "备份文件不存在（protected_backup 中未找到）"
    if not orig_path:
        return False, "原路径为空"
    try:
        import shutil
        dest_dir = os.path.dirname(orig_path)
        if dest_dir and not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)
        # 若原位置已有同名文件（可能是新版本），先改名保留
        if os.path.exists(orig_path):
            import datetime
            _bak = orig_path + f".old_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            try:
                os.replace(orig_path, _bak)
            except Exception:
                pass
        shutil.copy2(backup_path, orig_path)
    except Exception as e:
        return False, "还原失败：" + str(e)
    conn = get_db()
    try:
        conn.execute("UPDATE protected_files SET status = 'active' WHERE id = ?", (pid,))
        conn.commit()
    finally:
        conn.close()
    return True, orig_path


def get_protected_file_count():
    """获取受保护文件数量。"""
    conn = get_db()
    try:
        row = conn.execute("SELECT COUNT(*) as cnt FROM protected_files").fetchone()
        return row["cnt"] if row else 0
    finally:
        conn.close()

