# -*- coding: utf-8 -*-
"""selfdefense.py 4.9.1：body 包滚动容器 + Text 滚轮隔离 + 版本号"""
import io

P = r"F:\桌面保护\desktopguard\selfdefense.py"
src = io.open(P, "r", encoding="utf-8").read()

# 1. 版本号
assert 'APP_VERSION = "4.9.0"' in src
src = src.replace('APP_VERSION = "4.9.0"', 'APP_VERSION = "4.9.1"', 1)

# 2. body 滚动容器
old = """        body = tk.Frame(root, bg=BG)
        body.pack(fill="both", expand=True, padx=14, pady=8)
"""
new = """        # 滚动容器：内容再多也能上下滚动（按钮不会被窗口高度挤没）
        body_wrap = tk.Frame(root, bg=BG)
        body_wrap.pack(fill="both", expand=True, padx=14, pady=8)
        _cv = tk.Canvas(body_wrap, bg=BG, highlightthickness=0, bd=0)
        _vsb = tk.Scrollbar(body_wrap, orient="vertical", command=_cv.yview)
        _cv.configure(yscrollcommand=_vsb.set)
        _vsb.pack(side="right", fill="y")
        _cv.pack(side="left", fill="both", expand=True)
        body = tk.Frame(_cv, bg=BG)
        _win_id = _cv.create_window((0, 0), window=body, anchor="nw")

        def _on_cv_cfg(e):
            _cv.itemconfig(_win_id, width=e.width)
        _cv.bind("<Configure>", _on_cv_cfg)

        def _on_body_cfg(e):
            _cv.configure(scrollregion=_cv.bbox("all"))
        body.bind("<Configure>", _on_body_cfg)

        def _on_wheel(e):
            _cv.yview_scroll(int(-e.delta / 120), "units")
        _cv.bind("<Enter>", lambda e: root.bind_all("<MouseWheel>", _on_wheel))
        _cv.bind("<Leave>", lambda e: root.unbind_all("<MouseWheel>"))
"""
assert old in src, "body anchor"
src = src.replace(old, new, 1)

# 3. Text 滚轮隔离：阻止滚轮事件冒泡到页面滚动
txt_anchor = 'self.set_text(widget, text):'
# 在 set_text 方法前插入一个 helper：给 Text 绑定滚轮自身滚动
helper = '''    def _bind_text_wheel(self, w):
        """让 Text 内容自己滚动，避免鼠标在其上时滚到整个页面"""
        def _tw(e):
            if int(e.delta) > 0:
                w.yview_scroll(-1, "units")
            else:
                w.yview_scroll(1, "units")
            return "break"
        try:
            w.bind("<MouseWheel>", _tw)
        except Exception:
            pass

'''
anchor2 = "    def set_text(self, widget, text):\n"
assert anchor2 in src, "set_text anchor"
src = src.replace(anchor2, helper + anchor2, 1)

# 4. 创建 Text 的地方统一加 _bind_text_wheel —— 直接对已命名的几个 Text 变量处理：
#    sr_txt / snap_txt / roll_txt / int_txt / log_txt 创建后调用。用正则给每个
#    "self.XXX = tk.Text(" 之后补一行绑定（在 .pack 之前）。
import re
for var in ("sr_txt", "snap_txt", "roll_txt", "int_txt", "log_txt"):
    pat = re.compile(r"(self\.%s = tk\.Text\([^\n]*\n(?:[^\n]*\n){0,6}?)(?=\s*self\.|^\s*[a-z_])" % var, re.M)
    # 简单做法：在 pack 行前插入绑定调用
    pack_pat = re.compile(r"(self\.%s\.pack\([^\n]*\))" % var)
    def repl(m):
        return "self._bind_text_wheel(self.%s)\n        %s" % (var, m.group(1))
    src2 = pack_pat.sub(repl, src)
    if src2 != src:
        src = src2

io.open(P, "w", encoding="utf-8").write(src)
print("PATCH OK selfdefense -> 4.9.1, size:", len(src))
