// dg_warden.cpp — DG 乱码名多副本守护（C++）
// 架构（单决策者，防副本爆炸）：
//   主进程 dg_warden.exe（固定名）：
//     - 维护 N 个随机乱码名副本（难打、不重复）
//     - 副本被杀/崩溃 → 立即生成新随机名副本拉起
//     - 主 exe 被删 → 从副本恢复
//     - 写心跳
//   副本进程（随机名.exe）：
//     - 监视主进程：主进程不在 → 从自身复制回主 exe 并拉起
//     - 不拉新副本（只由主进程决策，避免指数爆炸）
// 用法: dg_warden.exe <backup_dir> <heartbeat> <stop_flag> [copies]
// 编译: cl /nologo /O2 /EHsc /std:c++17 /utf-8 /DUNICODE /D_UNICODE dg_warden.cpp /Fe:dg_warden.exe /link /SUBSYSTEM:WINDOWS /ENTRY:wmainCRTStartup
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <mutex>
#include <set>
#include <map>
#include <ctime>
#include <random>

static std::atomic<bool> g_running{true};
static std::mutex g_lock;
static std::wstring g_backup_dir;
static std::wstring g_heartbeat_path;
static std::wstring g_stop_flag;
static std::wstring g_self_exe;
static std::wstring g_main_exe;       // 主进程固定 exe 路径
static std::wstring g_list_file;      // warden_list.txt
static std::wstring g_debug_log;
static int g_copies = 3;
static bool g_is_main = true;

static const wchar_t NAME_CHARS[] =
    L"abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";

static void dbg_log(const std::wstring& msg) {
    std::lock_guard<std::mutex> lock(g_lock);
    FILE* f = _wfopen(g_debug_log.c_str(), L"ab");
    if (f) {
        std::string mb;
        int n = WideCharToMultiByte(CP_UTF8, 0, msg.c_str(), (int)msg.size(), nullptr, 0, nullptr, nullptr);
        mb.resize(n > 0 ? n : 0);
        if (n > 0) WideCharToMultiByte(CP_UTF8, 0, msg.c_str(), (int)msg.size(), &mb[0], n, nullptr, nullptr);
        std::string line = "[" + std::to_string((long long)time(nullptr)) + "] " + mb + "\n";
        fwrite(line.data(), 1, line.size(), f);
        fclose(f);
    }
}

static bool stop_flag_exists() {
    return !g_stop_flag.empty() &&
           GetFileAttributesW(g_stop_flag.c_str()) != INVALID_FILE_ATTRIBUTES;
}

static bool file_exists(const std::wstring& p) {
    return GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES;
}

static bool copy_file_wide(const std::wstring& src, const std::wstring& dst) {
    return CopyFileW(src.c_str(), dst.c_str(), FALSE) != 0;
}

static std::wstring get_self_path() {
    wchar_t buf[MAX_PATH] = {0};
    GetModuleFileNameW(NULL, buf, MAX_PATH);
    return buf;
}

static std::wstring random_name() {
    static std::mt19937 rng(GetTickCount() ^ (unsigned)time(nullptr));
    std::uniform_int_distribution<int> len_dist(10, 14);
    std::uniform_int_distribution<int> ch_dist(0, 54);
    int len = len_dist(rng);
    std::wstring s;
    s.reserve(len);
    for (int i = 0; i < len; ++i) s += NAME_CHARS[ch_dist(rng)];
    return s;
}

static std::wstring lower(std::wstring s) {
    for (auto& c : s) if (c >= L'A' && c <= L'Z') c += 32;
    return s;
}

static DWORD find_pid_by_path(const std::wstring& exe_path) {
    std::wstring target = lower(exe_path);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(pe);
    DWORD found = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
            if (h) {
                wchar_t buf[MAX_PATH] = {0};
                DWORD sz = MAX_PATH;
                if (QueryFullProcessImageNameW(h, 0, buf, &sz)) {
                    if (lower(buf) == target) found = pe.th32ProcessID;
                }
                CloseHandle(h);
            }
            if (found) break;
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

static bool process_running(const std::wstring& exe_path) {
    return find_pid_by_path(exe_path) != 0;
}

static bool spawn_process(const std::wstring& exe, const std::wstring& args, const std::wstring& cwd) {
    std::wstring cmd = L"\"" + exe + L"\"";
    if (!args.empty()) cmd += L" " + args;
    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    wchar_t* cmd_buf = &cmd[0];
    LPCWSTR cd = cwd.empty() ? NULL : cwd.c_str();
    if (CreateProcessW(exe.c_str(), cmd_buf, NULL, NULL, FALSE, CREATE_NO_WINDOW,
                       NULL, cd, &si, &pi)) {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return true;
    }
    return false;
}

// ---------- 清单 ----------
static std::vector<std::wstring> read_list() {
    std::vector<std::wstring> out;
    FILE* f = _wfopen(g_list_file.c_str(), L"rb");
    if (!f) return out;
    wchar_t line[1024];
    while (fgetws(line, 1024, f)) {
        std::wstring s = line;
        while (!s.empty() && (s.back() == L'\r' || s.back() == L'\n' || s.back() == L' ')) s.pop_back();
        if (!s.empty()) out.push_back(s);
    }
    fclose(f);
    return out;
}

static void write_list(const std::vector<std::wstring>& items) {
    FILE* f = _wfopen(g_list_file.c_str(), L"wb");
    if (!f) return;
    for (const auto& s : items) fwprintf(f, L"%s\r\n", s.c_str());
    fclose(f);
}

// 生成一个新随机名副本并启动（副本带完整参数运行）
static std::wstring spawn_new_copy() {
    for (int attempt = 0; attempt < 8; ++attempt) {
        std::wstring name = random_name();
        std::wstring path = g_backup_dir + L"\\" + name + L".exe";
        if (file_exists(path)) continue;
        if (!copy_file_wide(g_main_exe, path)) continue;
        std::wstring args = L"\"" + g_backup_dir + L"\" \"" + g_heartbeat_path + L"\" \"" +
                            g_stop_flag + L"\" " + std::to_wstring(g_copies);
        if (spawn_process(path, args, g_backup_dir)) {
            dbg_log(L"拉起新副本: " + path);
            return path;
        }
    }
    return L"";
}

// ---------- 主进程职责 ----------
static void main_warden_loop() {
    std::map<std::wstring, long long> grace;   // 副本路径 -> 拉起时间戳（宽限期）
    std::map<std::wstring, int> miss_count;    // 副本路径 -> 连续查不到次数
    while (g_running.load()) {
        if (stop_flag_exists()) { g_running.store(false); break; }
        long long now = (long long)time(nullptr);
        // 主 exe 被删 → 从副本恢复
        if (!file_exists(g_main_exe)) {
            auto items = read_list();
            for (const auto& it : items) {
                if (file_exists(it)) { copy_file_wide(it, g_main_exe); dbg_log(L"主 exe 已恢复"); break; }
            }
        }
        // 副本维护：连续两轮都查不到才判死替换（防抖动误判）
        auto items = read_list();
        std::vector<std::wstring> alive_list;
        for (const auto& it : items) {
            std::wstring key = lower(it);
            auto g = grace.find(key);
            if (g != grace.end() && (now - g->second) < 8) {
                alive_list.push_back(it);  // 刚拉起，宽限期内视为存活
                continue;
            }
            if (process_running(it)) {
                miss_count[key] = 0;
                alive_list.push_back(it);
            } else {
                miss_count[key]++;
                if (miss_count[key] >= 2) {
                    dbg_log(L"副本连续两次不在运行: " + it);
                    std::wstring np = spawn_new_copy();
                    if (!np.empty()) { alive_list.push_back(np); grace[lower(np)] = now; miss_count[key] = 0; }
                } else {
                    alive_list.push_back(it);  // 再等一轮确认
                }
            }
        }
        // 补足数量
        while ((int)alive_list.size() < g_copies && g_running.load() && !stop_flag_exists()) {
            std::wstring np = spawn_new_copy();
            if (np.empty()) break;
            alive_list.push_back(np);
            grace[lower(np)] = now;
        }
        // 清理过期记录
        for (auto it = grace.begin(); it != grace.end(); ) {
            if ((now - it->second) > 30) it = grace.erase(it); else ++it;
        }
        write_list(alive_list);
        Sleep(2000);
    }
}

// ---------- 副本职责 ----------
static void replica_guard_loop() {
    while (g_running.load()) {
        if (stop_flag_exists()) { g_running.store(false); break; }
        if (!process_running(g_main_exe)) {
            dbg_log(L"主进程不在，副本尝试拉起主进程");
            if (!file_exists(g_main_exe)) {
                copy_file_wide(g_self_exe, g_main_exe);  // 从自身副本恢复主 exe
            }
            spawn_process(g_main_exe,
                          L"\"" + g_backup_dir + L"\" \"" + g_heartbeat_path + L"\" \"" + g_stop_flag + L"\" " +
                          std::to_wstring(g_copies),
                          g_backup_dir);
        }
        Sleep(2000);
    }
}

// 心跳
static void heartbeat_loop() {
    while (g_running.load()) {
        {
            std::lock_guard<std::mutex> lock(g_lock);
            FILE* f = _wfopen(g_heartbeat_path.c_str(), L"wb");
            if (f) {
                std::string ts = std::to_string((long long)time(nullptr));
                fwrite(ts.data(), 1, ts.size(), f);
                fclose(f);
            }
        }
        Sleep(3000);
    }
}

int wmain(int argc, wchar_t** argv) {
    if (argc < 4) return 1;
    g_backup_dir = argv[1];
    g_heartbeat_path = argv[2];
    g_stop_flag = argv[3];
    if (argc >= 5) g_copies = _wtoi(argv[4]);
    if (g_copies < 2) g_copies = 2;
    if (g_copies > 8) g_copies = 8;
    g_self_exe = get_self_path();
    g_list_file = g_backup_dir + L"\\warden_list.txt";
    g_debug_log = g_backup_dir + L"\\dg_warden_debug.log";

    CreateDirectoryW(g_backup_dir.c_str(), NULL);

    // 判断主/副本：文件名是否为 dg_warden.exe
    {
        std::wstring fn = g_self_exe;
        size_t slash = fn.find_last_of(L'\\');
        if (slash != std::wstring::npos) fn = fn.substr(slash + 1);
        g_is_main = (lower(fn) == L"dg_warden.exe");
    }

    std::wstring main_path_file = g_backup_dir + L"\\warden_main_path.txt";
    if (g_is_main) {
        // 主进程：主 exe = 自己，记录主路径供副本读取
        g_main_exe = g_self_exe;
        FILE* f = _wfopen(main_path_file.c_str(), L"wb");
        if (f) { fwprintf(f, L"%s", g_main_exe.c_str()); fclose(f); }
    } else {
        // 副本：从配置文件读主进程路径，读不到就用 备份目录\dg_warden.exe
        g_main_exe = g_backup_dir + L"\\dg_warden.exe";
        FILE* f = _wfopen(main_path_file.c_str(), L"rb");
        if (f) {
            wchar_t buf[MAX_PATH] = {0};
            if (fgetws(buf, MAX_PATH, f)) {
                std::wstring s = buf;
                while (!s.empty() && (s.back() == L'\r' || s.back() == L'\n' || s.back() == L' ')) s.pop_back();
                if (!s.empty()) g_main_exe = s;
            }
            fclose(f);
        }
    }

    dbg_log(std::wstring(g_is_main ? L"主进程启动 " : L"副本启动 ") + g_self_exe + L" | main=" + g_main_exe);

    // 主 exe 不存在 → 副本模式先从自己复制出主 exe
    if (!file_exists(g_main_exe)) {
        if (!g_is_main) copy_file_wide(g_self_exe, g_main_exe);
    }

    if (g_is_main) {
        // 主进程：首次生成副本清单
        auto items = read_list();
        std::vector<std::wstring> valid;
        for (const auto& it : items) if (file_exists(it)) valid.push_back(it);
        while ((int)valid.size() < g_copies) {
            std::wstring np = spawn_new_copy();
            if (np.empty()) break;
            valid.push_back(np);
        }
        write_list(valid);
        dbg_log(L"主进程就绪，副本数=" + std::to_wstring((int)valid.size()));

        std::thread hb(heartbeat_loop);
        hb.detach();
        main_warden_loop();
    } else {
        // 副本：只监视主进程
        replica_guard_loop();
    }
    return 0;
}
