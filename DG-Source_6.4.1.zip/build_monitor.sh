#!/bin/bash
# build_monitor.sh — 编译 dg_monitor.exe（静态、无窗口）
cd /f/桌面保护/desktopguard || exit 1
g++ -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -municode \
    dg_monitor.cpp -o dg_monitor.exe \
    -mwindows 2>&1 | tee compile_monitor.log
if [ -f dg_monitor.exe ]; then
    ls -la dg_monitor.exe
    echo "BUILD_OK"
else
    echo "BUILD_FAIL"
fi
