# -*- coding: utf-8 -*-
"""DG 4.9.1 补丁：扫描页/工具页/保护页加可上下滚动容器；扫描结果表格固定高度"""
import io

P = r"F:\桌面保护\desktopguard\main.py"
src = io.open(P, "r", encoding="utf-8").read()

# ---------- 1. 版本号 4.9.0 -> 4.9.1 ----------
old_ver = 'APP_VERSION = "4.9.0"'
assert old_ver in src, "ver anchor"
src = src.replace(old_ver, 'APP_VERSION = "4.9.1"', 1)

# ---------- 2. 插入 _scroll_page 方法与滚轮 handler（在 _nav_page 定义前） ----------
anchor = "    def _nav_page(self, name):\n"
assert anchor in src, "nav anchor"
scroll_method = '''    def _scroll_page(self, parent):
        """把页面内容包进可上下滚动区域；返回内部容器（后续控件挂在它上面）。
        滚动条自动出现；滚轮仅在鼠标位于页面区域时生效，切页自动解绑。"""
        outer = tk.Frame(parent, bg=C_BG)
        outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, bg=C_BG, highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=C_BG)
        _win_id = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _on_canvas_cfg(e):
            canvas.itemconfig(_win_id, width=e.width)
        canvas.bind("<Configure>", _on_canvas_cfg)

        def _on_inner_cfg(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
        inner.bind("<Configure>", _on_inner_cfg)

        def _bind_wheel(e, cv=canvas):
            self.root.unbind_all("<MouseWheel>")
            cv.bind_all("<MouseWheel>",
                        lambda ev, c=cv: c.yview_scroll(int(-ev.delta / 120), "units"))

        def _unbind_wheel(e):
            self.root.unbind_all("<MouseWheel>")
        canvas.bind("<Enter>", _bind_wheel)
        canvas.bind("<Leave>", _unbind_wheel)
        return inner

'''
src = src.replace(anchor, scroll_method + anchor, 1)

# ---------- 3. _nav_page 切页时解绑滚轮（防串页） ----------
old_nav = """    def _nav_page(self, name):
        \"\"\"切换主界面页面（PyAS 风格左导航）。\"\"\"
        try:
            for k, b in self._nav_btns.items():"""
new_nav = """    def _nav_page(self, name):
        \"\"\"切换主界面页面（PyAS 风格左导航）。\"\"\"
        try:
            try:
                self.root.unbind_all("<MouseWheel>")
            except Exception:
                pass
            for k, b in self._nav_btns.items():"""
assert old_nav in src, "nav body anchor"
src = src.replace(old_nav, new_nav, 1)

# ---------- 4. 扫描页：包滚动容器 ----------
old_scan = """        # ============ 扫描页（4.0.0 新画面：实时状态卡片） ============
        scan = tk.Frame(self._main_area, bg=C_BG)
        self._pages["scan"] = scan"""
new_scan = """        # ============ 扫描页（4.0.0 新画面：实时状态卡片） ============
        self._pages["scan"] = tk.Frame(self._main_area, bg=C_BG)
        scan = self._scroll_page(self._pages["scan"])"""
assert old_scan in src, "scan anchor"
src = src.replace(old_scan, new_scan, 1)

# ---------- 5. 扫描结果表格固定高度（滚动容器内 expand 无效） ----------
old_tbl = """        tbl_frame = tk.Frame(scan, bg=C_BORDER)
        tbl_frame.pack(fill="both", expand=True, pady=(8, 6))"""
new_tbl = """        tbl_frame = tk.Frame(scan, bg=C_BORDER, height=280)
        tbl_frame.pack(fill="x", pady=(8, 6))
        tbl_frame.pack_propagate(False)"""
assert old_tbl in src, "tbl anchor"
src = src.replace(old_tbl, new_tbl, 1)

# ---------- 6. 工具页：包滚动容器 ----------
old_tools = """        # ============ 工具页（随新主题自动换肤） ============
        tools = tk.Frame(self._main_area, bg=C_BG)
        self._pages["tools"] = tools"""
new_tools = """        # ============ 工具页（随新主题自动换肤） ============
        self._pages["tools"] = tk.Frame(self._main_area, bg=C_BG)
        tools = self._scroll_page(self._pages["tools"])"""
assert old_tools in src, "tools anchor"
src = src.replace(old_tools, new_tools, 1)

# ---------- 7. 保护页：包滚动容器 ----------
old_prot = """        # ============ 保护页（随新主题自动换肤） ============
        protect = tk.Frame(self._main_area, bg=C_BG)
        self._pages["protect"] = protect"""
new_prot = """        # ============ 保护页（随新主题自动换肤） ============
        self._pages["protect"] = tk.Frame(self._main_area, bg=C_BG)
        protect = self._scroll_page(self._pages["protect"])"""
assert old_prot in src, "prot anchor"
src = src.replace(old_prot, new_prot, 1)

# ---------- 8. 历史版本记录 ----------
old_vlist = '    ("4.9.0", "4.8.0", '
new_vlist = (
    '    ("4.9.1", "4.9.0", "补丁（页面滚动）：1.扫描页/工具页/保护页内容改为可上下滚动容器——卡片与按钮再多也能滚到，不再受窗口高度限制；2.扫描结果表格固定高度（280px），底部操作栏（清理垃圾/删除/白名单等按钮）始终可见；3.滚轮仅鼠标在页面内生效，切换页面自动解绑不串页",),\n'
    '    ("4.9.0", "4.8.0", '
)
assert old_vlist in src, "vlist anchor"
src = src.replace(old_vlist, new_vlist, 1)

io.open(P, "w", encoding="utf-8").write(src)
print("PATCH OK, version now 4.9.1, size:", len(src))
