# -*- coding: utf-8 -*-
import subprocess

def run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=timeout)
        return r.stdout, r.stderr
    except Exception as e:
        return "", "ERR " + str(e)

out, err = run(["VBoxManage", "list", "runningvms"])
print("=== running VMs ===")
print(out.strip() or "(none)")
print()

out2, err2 = run(["VBoxManage", "list", "vms"])
print("=== all VMs ===")
print(out2.strip() or "(none)")

# 宿主机资源
out3, _ = run(["powershell", "-NoProfile", "-Command",
    "$os = Get-CimInstance Win32_OperatingSystem; $cpu = Get-CimInstance Win32_Processor; $cs = Get-CimInstance Win32_ComputerSystem; " +
    "'CPU: ' + $cpu.Name + ' / ' + $cs.NumberOfLogicalProcessors + ' logical'; " +
    "'RAM total: ' + [math]::Round($os.TotalVisibleMemorySize/1MB,1) + ' GB'; " +
    "'RAM free: ' + [math]::Round($os.FreePhysicalMemory/1MB,1) + ' GB'; " +
    "Get-CimInstance Win32_Processor | ForEach-Object { 'CPU load: ' + $_.LoadPercentage + '%' }"])
print()
print("=== host resource ===")
print(out3.strip() or err3 if False else out3.strip())
