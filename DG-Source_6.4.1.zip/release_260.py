# -*- coding: utf-8 -*-
"""发布2.6.0正式版：修改版本号、配置路径、更新version.json、创建快照"""

import os
import shutil
import json

# 1. 修改main.py的版本号和配置路径
with open('main.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 修改版本号
c = c.replace('VERSION = "2.6.0-beta"', 'VERSION = "2.6.0"')
c = c.replace('"2.6.0-beta"', '"2.6.0"')

# 修改配置路径
c = c.replace('.desktopguard-beta', '.desktopguard')

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(c)
print("1. main.py 版本号和配置路径已修改")

# 2. 修改engine.py的配置路径
with open('engine.py', 'r', encoding='utf-8') as f:
    e = f.read()
e = e.replace('.desktopguard-beta', '.desktopguard')
with open('engine.py', 'w', encoding='utf-8') as f:
    f.write(e)
print("2. engine.py 配置路径已修改")

# 3. 修改database.py的配置路径
with open('database.py', 'r', encoding='utf-8') as f:
    d = f.read()
d = d.replace('.desktopguard-beta', '.desktopguard')
with open('database.py', 'w', encoding='utf-8') as f:
    f.write(d)
print("3. database.py 配置路径已修改")

# 4. 修改realtime_protection.py的配置路径
with open('realtime_protection.py', 'r', encoding='utf-8') as f:
    r = f.read()
r = r.replace('.desktopguard-beta', '.desktopguard')
with open('realtime_protection.py', 'w', encoding='utf-8') as f:
    f.write(r)
print("4. realtime_protection.py 配置路径已修改")

# 5. 更新version.json
version_data = {
    "latest_version": "2.6.0",
    "release_date": "2026-09-06",
    "release_notes": "2.6.0 正式版：基于2.0.1完整功能重建，合并2.5.0新功能，新增轻量目录监控",
    "features": [
        "恢复所有丢失功能（安全体检/启动项管理/计划任务/病毒库/隔离区/名单管理）",
        "AI助手聊天功能",
        "轻量实时防护",
        "扫描性能优化（动态线程/sleep/大文件限制）",
        "AI实时辅助（扫描后自动AI分析）",
        "轻量目录监控（下载/桌面/启动目录新文件自动扫描）"
    ]
}
with open('version.json', 'w', encoding='utf-8') as f:
    json.dump(version_data, f, ensure_ascii=False, indent=2)
print("5. version.json 已更新")

# 6. 创建版本快照
snapshot_dir = os.path.join('versions', '2.6.0')
os.makedirs(snapshot_dir, exist_ok=True)
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py']:
    src = os.path.join('.', fname)
    dst = os.path.join(snapshot_dir, fname)
    if os.path.exists(src):
        shutil.copy2(src, dst)
print(f"6. 版本快照已创建: {snapshot_dir}")

print("\n2.6.0 正式版发布完成！")
