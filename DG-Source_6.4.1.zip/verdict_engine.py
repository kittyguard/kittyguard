# -*- coding: utf-8 -*-
"""DG 5.1.0 统一裁决层 Verdict Engine 2.1 —— 多证据风险评分制（GPT 安全专家审查修订）

从「命中即报」升级为「多证据加权评分 + 白名单降分 + 可解释输出」：

  综合分 0-20 安全 | 21-40 低风险 | 41-60 可疑 | 61-80 高危 | 81-100 恶意

核心原则（用户已确认路线，来自 5.0.0 规划）：
  1. 哈希黑名单 / EICAR / 云端已判恶意 → 直接定罪（100 恶意），任何降权无效；
  2. 单条 weak 证据（高熵/加壳/宽泛关键词）不直接报毒——纯弱证据不足 3 条不计分；
  3. 多证据叠加升档：强证据直接计分；弱证据在存在强/中证据时按 60% 组合计分
     （5.1.0：防「2 条弱证据+1 条行为证据」时弱证据白送形成低噪声绕过区）；
  4. 白名单是「降分器」不是「免死金牌」——行为类强证据（勒索/远控/注入/伪装/下载执行）
     存在时白名单降分封顶 -20（5.1.0 收紧，防可信进程劫持/DLL 劫持漏报）；
     其余强证据封顶 -40；强证据样本最终分保底 41（至少可疑档）；
  5. AI 仅解释/辅助：AI 判恶意需本地证据支撑（+10）；AI 判良性仅对无行为证据样本
     降 -5（5.1.0 对称化，AI 不抵消行为证据）；
  6. 有效数字签名 / 系统目录 / 可信软件目录 / 开发目录（含编译产物/构建/测试目录）→ 白名单降分；
  7. 云查结果进入评分（malicious 直接定罪，suspicious +30，结果缓存由调用方负责）。

输出：evidence 证据列表（source/type/score/confidence/message）+ final_score + verdict 五档
      + level（映射回 engine.LEVEL_* 保持 UI 兼容）+ explanation 可读解释。
"""

import os

LEVEL_SAFE = "安全"
LEVEL_LOW = "低危"
LEVEL_MED = "中危"
LEVEL_HIGH = "高危"
LEVEL_CRIT = "严重"

VERDICT_SAFE = "safe"
VERDICT_LOW = "low"
VERDICT_SUSPICIOUS = "suspicious"
VERDICT_HIGH = "high"
VERDICT_MALICIOUS = "malicious"

# tag 关键词 → (source, type, 基础分值, confidence, 可读说明)
# 分值设计：强证据（特异性高）45-60；中证据 25-40；弱证据 12-18
TAG_EVIDENCE = [
    # ---- 直接定罪（在 assess 中优先处理，不在此表计分）----
    # "命中黑名单哈希" / "EICAR" / "云端已判恶意" / "ClamAV:" / "YARA:"
    # ---- 强证据（特异性高，可信）----
    ("勒索",        ("tag",  "script_ransom",    55, 0.9, "勒索软件特征（如扩展名批量重命名/赎金说明）")),
    ("远控",        ("tag",  "script_remote",    40, 0.8, "远控后门特征（回连外网/远程指令）")),
    ("伪装为可执行文件", ("tag", "disguised_exe", 45, 0.85, "扩展名伪装为可执行文件（钓鱼/投放实锤）")),
    ("双扩展名",    ("tag",  "disguised_ext",    30, 0.8, "双扩展名伪装")),
    ("Unicode右向覆盖", ("tag", "unicode_override", 45, 0.85, "Unicode 右向覆盖字符隐藏真实扩展名")),
    ("大量空格",    ("tag",  "space_hide",       40, 0.8, "文件名大量空格隐藏扩展名")),
    ("网络连接+命令执行", ("tag", "net_cmd_combo", 50, 0.85, "网络连接+命令执行组合（远控/下载器核心链路）")),
    ("挖矿",        ("tag",  "script_mining",    40, 0.8, "挖矿行为特征")),
    ("进程镂空",    ("tag",  "pe_process_hollow", 45, 0.8, "PE 导入表含进程镂空 API 组合（经典注入手法）")),
    ("进程注入",    ("tag",  "pe_injection",     45, 0.8, "PE 导入表含进程注入 API 组合")),
    ("下载执行",    ("tag",  "pe_download_exec", 30, 0.7, "PE 导入表含下载执行 API")),
    ("键盘钩子",    ("tag",  "pe_keylog",        30, 0.7, "PE 导入表含键盘钩子/记录 API 组合")),
    ("宏内含可疑命令", ("tag", "macro_suspicious", 30, 0.7, "Office 宏内含可疑命令")),
    ("下载目录宏",  ("tag",  "macro_download",   35, 0.75, "下载目录下的宏文档（高风险入口）")),
    ("下载并执行",  ("tag",  "script_download_exec", 40, 0.8, "脚本含下载并执行行为")),
    ("自启动",      ("tag",  "autostart",        22, 0.65, "自启动行为（注册表/启动目录持久化）")),
    ("开机自启动项", ("tag",  "startup_item",     20, 0.6, "位于开机自启动项列表")),
    ("高风险文件类型", ("tag", "risky_ext",       18, 0.55, "高风险文件类型（.scr/.vbs/.hta 等）")),
    # ---- 弱证据（宽泛，单条不报毒，≥3 条才累计）----
    ("加壳",        ("tag",  "packed",           15, 0.5, "加壳特征（非 UPX）")),
    ("高熵",        ("tag",  "entropy",          14, 0.5, "高熵（疑似加密/加壳/混淆）")),
    ("代码混淆",    ("tag",  "obfuscated",       15, 0.5, "代码混淆/编码特征")),
    ("免杀",        ("tag",  "antivm",           16, 0.55, "免杀/反调试特征")),
    ("Office文档含宏", ("tag", "macro_present",  12, 0.4, "Office 文档含宏（可能正常）")),
    ("编译时间戳",  ("tag",  "pe_timestamp",     15, 0.5, "PE 编译时间戳异常")),
    ("入口点",      ("tag",  "pe_entrypoint",    15, 0.5, "PE 入口点异常")),
    ("可写可执行区段", ("tag", "pe_wx",          15, 0.5, "PE 可写可执行区段")),
    ("PE尾部附加数据", ("tag", "pe_overlay",     12, 0.45, "PE 尾部附加数据（overlay）")),
    ("极小的可执行文件", ("tag", "pe_tiny",      12, 0.45, "极小可执行文件")),
    ("高熵区段",    ("tag",  "pe_high_entropy",  12, 0.45, "PE 高熵区段")),
    ("无导入表",    ("tag",  "pe_no_imports",    12, 0.45, "PE 无导入表")),
    ("区段数异常",  ("tag",  "pe_sections",      12, 0.45, "PE 区段数异常")),
    ("快捷方式内嵌可疑命令", ("tag", "lnk_suspicious", 25, 0.6, "快捷方式内嵌可疑命令")),
    ("开发目录脚本", ("tag",  "dev_script",      8,  0.3, "开发目录脚本（已降权上下文）")),
    ("包依赖目录",  ("tag",  "pkg_dir",          6,  0.25, "包依赖目录（pip/site-packages 常见误报源）")),
    ("更新器",      ("tag",  "updater_ctx",      6,  0.25, "更新器/安装器上下文（常见误报源）")),
]

# 白名单降分档位（-100 压不过云端恶意/黑名单；-40 以上仅对无强证据生效）
WHITELIST_ADJUST = {
    "whitelisted":      -100,   # 用户手动信任 / 数据库白名单
    "signed_valid":     -40,    # 有效数字签名
    "system_dir":       -30,    # Windows 系统目录
    "trusted_dir":      -25,    # 可信软件目录（Steam/腾讯/网易/Microsoft 等）
    "dev_dir":          -20,    # 开发/包依赖目录
}

# verdict 五档 ↔ engine.LEVEL_* 映射
def _verdict_level(score):
    if score <= 20:
        return VERDICT_SAFE, LEVEL_SAFE
    if score <= 40:
        return VERDICT_LOW, LEVEL_LOW
    if score <= 60:
        return VERDICT_SUSPICIOUS, LEVEL_MED
    if score <= 80:
        return VERDICT_HIGH, LEVEL_HIGH
    return VERDICT_MALICIOUS, LEVEL_CRIT


def assess(path="", name="", category="", sha256="",
           res_tags=None, res_hits=None, res_score=0, res_level="",
           whitelisted=False, blacklisted=False, cloud_malicious=False,
           eicar=False, clamav_hit=False, yara_hit=False,
           signed_valid=False, ai_tags=None):
    """统一裁决：把引擎各层证据（tags/hits + 上下文）标准化为 0-100 综合分与 verdict。

    参数说明：
      res_tags   —— engine.ScanResult.tags（含各层特征文本）
      res_hits   —— engine.ScanResult.hits（RuleHit 列表，含 severity/rule_id）
      whitelisted—— 白名单命中（用户手动信任/数据库）
      blacklisted—— 本地黑名单哈希命中
      cloud_malicious —— 云端已判恶意（云查缓存）
      eicar      —— EICAR 测试样本
      clamav_hit —— ClamAV 病毒库命中
      yara_hit   —— YARA 规则命中（强规则）
      signed_valid—— 有效数字签名
      ai_tags    —— 供额外传入的 AI 结论文本（默认从 res_tags 自动识别）

    返回 dict：{evidence, final_score, verdict, level, explanation, whitelist_adjustment}
    """
    tags = list(res_tags or [])
    hits = list(res_hits or [])
    ai_tags = list(ai_tags or []) + tags

    # ===== 0. 从 tags 自动识别直接定罪信号（调用方只需传 res_tags 即可）=====
    _joined = "\n".join(tags)
    if not blacklisted and "命中黑名单哈希" in _joined:
        blacklisted = True
    if not eicar and "EICAR" in _joined:
        eicar = True
    if not cloud_malicious and "云端已判恶意" in _joined:
        cloud_malicious = True
    if not clamav_hit and _joined.startswith("ClamAV:") or "ClamAV:" in _joined:
        clamav_hit = True
    if not yara_hit and ("YARA:" in _joined or "YARA规则" in _joined):
        yara_hit = True

    evidence = []

    # ===== 1. 直接定罪（任何降权无效）=====
    if blacklisted:
        evidence.append({"source": "hash_blacklist", "type": "known_malware",
                         "score": 100, "confidence": 1.0,
                         "message": "命中本地黑名单哈希（已知恶意，直接定罪）"})
        return _build_result(evidence, 100, "命中已知恶意哈希，直接定罪。")
    if eicar:
        evidence.append({"source": "eicar", "type": "test_sample",
                         "score": 100, "confidence": 1.0,
                         "message": "EICAR 测试样本（杀软流程验证，无害）"})
        return _build_result(evidence, 100, "EICAR 测试样本（验证杀软流程）。")
    if cloud_malicious:
        evidence.append({"source": "cloud", "type": "cloud_malicious",
                         "score": 100, "confidence": 0.95,
                         "message": "云端已判恶意（云查缓存命中，无条件判危）"})
        return _build_result(evidence, 100, "云端已判恶意，本地无条件隔离。")

    # ===== 2. 分层证据计分 =====
    # 5.4.0：纯文本开发源码内容特征降权（实操发现：安全分析/正常工具源码常含
    # "下载执行/自启动/远控"等关键词，特征引擎会把正常源码判成严重；硬证据
    # （黑名单/EICAR/ClamAV/YARA/云查）命中时不受影响，真毒仍直接定罪）
    _src_exts = {".py", ".js", ".ts", ".mjs", ".cjs", ".java", ".c", ".cpp", ".h", ".hpp",
                 ".cs", ".go", ".php", ".rb", ".lua", ".html", ".htm", ".md", ".txt",
                 ".json", ".yml", ".yaml", ".xml", ".css", ".sql", ".ini", ".cfg", ".log", ".csv"}
    _is_src = os.path.splitext(str(path).lower())[1] in _src_exts
    _has_hard = blacklisted or eicar or clamav_hit or yara_hit or cloud_malicious
    _src_down = _is_src and not _has_hard

    def _adj(src, sc, conf, desc):
        if _src_down and src == "tag":
            return (max(0, int(round(sc * 0.35))),
                    round(conf * 0.7, 2),
                    desc + "（纯文本源码，内容特征降权）")
        return sc, conf, desc

    strong, medium, weak = [], [], []
    seen = set()
    for tag in tags:
        for kw, (_src, _typ, _score, _conf, _msg) in TAG_EVIDENCE:
            if kw in tag:
                key = _typ
                if key in seen:
                    continue
                seen.add(key)
                if _score >= 30:
                    strong.append((_src, _typ, _score, _conf, tag, _msg))
                elif _score >= 18:
                    medium.append((_src, _typ, _score, _conf, tag, _msg))
                else:
                    weak.append((_src, _typ, _score, _conf, tag, _msg))
                break

    # hits 补充（engine 结构化规则；severity 强/中 → 计入对应档，避免漏掉 tags 未覆盖的）
    # 去重：若该规则的证据文本已由 tags 层覆盖，跳过（否则双计虚高）
    hit_seen = set()
    for h in hits:
        rid = getattr(h, "rule_id", "") or ""
        sev = getattr(h, "severity", "") or ""
        ev = getattr(h, "evidence", None) or [""]
        msg = (ev[0] if ev else "") or getattr(h, "title", "") or rid
        key = rid
        if key in hit_seen:
            continue
        hit_seen.add(key)
        if any(msg in t or t in msg for t in tags):
            continue  # tags 层已覆盖该证据，不双计
        if sev == "strong":
            strong.append(("rule_hit", rid, 45, 0.8, msg, "强规则命中：" + msg))
        elif sev == "medium":
            medium.append(("rule_hit", rid, 25, 0.6, msg, "规则命中：" + msg))
        # weak 规则由 tags 层负责，避免双计

    for src, typ, sc, conf, raw, desc in strong:
        sc, conf, desc = _adj(src, sc, conf, desc)
        evidence.append({"source": src, "type": typ, "score": sc,
                         "confidence": conf, "message": desc})
    for src, typ, sc, conf, raw, desc in medium:
        sc, conf, desc = _adj(src, sc, conf, desc)
        evidence.append({"source": src, "type": typ, "score": sc,
                         "confidence": conf, "message": desc})
    # 弱证据计分（5.1.0 组合规则，GPT 审查 2）：
    #  - ≥3 条纯弱证据：全额计分（原规则）；
    #  - 不足 3 条但存在强/中证据：按 60% 计分——防止「2 条弱证据 + 1 条行为证据」
    #    时弱证据白送，形成低噪声绕过区；
    #  - 纯弱证据不足 3 条：不计分（单条弱特征不报毒）。
    if len(weak) >= 3:
        weak_ratio = 1.0
    elif (strong or medium) and weak:
        weak_ratio = 0.6
    else:
        weak_ratio = 0.0
    if weak_ratio > 0:
        for src, typ, sc, conf, raw_t, desc in weak:
            sc, conf, desc = _adj(src, sc, conf, desc)
            _sc = int(round(sc * weak_ratio))
            _msg = desc if weak_ratio >= 1 else desc + "（弱证据组合计分 60%）"
            evidence.append({"source": src, "type": typ, "score": _sc,
                             "confidence": conf, "message": _msg})
    else:
        for src, typ, sc, conf, raw_t, desc in weak:
            evidence.append({"source": src, "type": typ, "score": 0,
                             "confidence": conf, "message": desc + "（单条弱特征，不计分）"})

    # ClamAV / YARA 命中：直接升档（独立病毒库证据）
    if clamav_hit:
        evidence.append({"source": "clamav", "type": "clamav_hit", "score": 70,
                         "confidence": 0.9, "message": "ClamAV 病毒库命中（900万签名引擎）"})
        strong.append(("clamav", "clamav_hit", 70, 0.9, "", "ClamAV 病毒库命中"))
    if yara_hit:
        evidence.append({"source": "yara", "type": "yara_hit", "score": 60,
                         "confidence": 0.85, "message": "YARA 规则命中"})
        strong.append(("yara", "yara_hit", 60, 0.85, "", "YARA 规则命中"))

    raw = sum(e["score"] for e in evidence)

    # 行为类强证据判定（供白名单封顶与 AI 对称降分共用，须在白名单段之前计算）
    _behavior_types = {"script_ransom", "script_remote", "disguised_exe", "disguised_ext",
                       "unicode_override", "space_hide", "net_cmd_combo", "script_mining",
                       "pe_process_hollow", "pe_injection", "pe_download_exec", "pe_keylog",
                       "macro_suspicious", "macro_download", "script_download_exec",
                       "autostart", "startup_item"}
    _has_behavior = any(typ in _behavior_types for (_src, typ, _sc, _cf, _rw, _ds) in strong)

    # ===== 3. 白名单降分（降分器，不是免死金牌）=====
    adjustment = 0
    lower_path = str(path).lower()
    if whitelisted:
        adjustment += WHITELIST_ADJUST["whitelisted"]
    if signed_valid:
        adjustment += WHITELIST_ADJUST["signed_valid"]
    if lower_path.startswith(("c:\\windows\\system32", "c:\\windows\\syswow64",
                              "c:\\windows\\winsxs", "c:\\windows\\microsoft.net")):
        adjustment += WHITELIST_ADJUST["system_dir"]
    if any(d in lower_path for d in (
            "c:\\program files\\steam", "\\steamapps", "\\steam",
            "c:\\program files\\tencent", "c:\\program files (x86)\\tencent",
            "c:\\program files\\netease", "c:\\program files (x86)\\netease",
            "c:\\program files\\microsoft", "c:\\program files (x86)\\microsoft",
            "c:\\program files\\adobe", "c:\\program files (x86)\\adobe",
            "c:\\program files\\google", "c:\\program files (x86)\\google",
            "c:\\program files\\mozilla", "c:\\program files (x86)\\mozilla",
            "\\wechat", "\\qq", "\\tim", "\\钉钉")):
        adjustment += WHITELIST_ADJUST["trusted_dir"]
    if any(d in lower_path for d in (
            "\\python", "\\nodejs", "\\node_modules", "\\git", "\\vscode",
            "\\anaconda", "\\miniconda", "\\venv", "\\.venv", "\\__pycache__",
            "\\site-packages", "\\dist-packages", "\\package_cache",
            "\\monica", "\\doubao", "\\coze", "\\pip",
            # 5.1.0 扩展：编译产物/构建/测试目录（编译器生成 exe、PyInstaller/Electron
            # 打包产物、CI 输出等常见误报源，GPT 审查 4）
            "\\build\\", "\\dist\\", "\\tests\\", "\\cmake-build", "\\.gradle", "\\target\\")):
        adjustment += WHITELIST_ADJUST["dev_dir"]
    if adjustment < 0:
        evidence.append({"source": "whitelist", "type": "whitelist_adjust",
                         "score": adjustment, "confidence": 0.9,
                         "message": "白名单/可信上下文降分 %d" % adjustment})

    # 白名单封顶（5.1.0 收紧，GPT 审查 3）：
    #  - 行为类强证据（勒索/远控/注入/伪装/下载执行等）存在时，白名单降分最多压 20 分——
    #    防「可信进程被劫持/DLL 劫持」时恶意行为被白名单拉低导致漏报；
    #  - 其余强证据（ClamAV/YARA 独立引擎命中）仍按 40 分封顶；
    #  - 最终分保底 41（至少可疑档），白名单永远压不过行为证据。
    if _has_behavior and adjustment < -20:
        adjustment = -20
        evidence[-1]["score"] = -20
        evidence[-1]["message"] = "白名单/可信上下文降分 -20（存在行为证据，封顶收紧——行为证据不被白名单抵消）"
    elif strong and adjustment < -40:
        adjustment = -40
        evidence[-1]["score"] = -40
        evidence[-1]["message"] = "白名单/可信上下文降分 -40（存在强证据，封顶）"

    final = raw + adjustment

    # ===== 4. AI 结论（仅辅助：解释/小幅调整，不单独定罪）=====
    # 5.1.0（GPT 审查·不对称修复）：AI 判良性不再 -12 拉低边界样本——
    # 仅对「无行为强证据」的样本降 -5；存在行为证据时 AI 良性完全不降分（不抵消本地行为证据）。
    ai_mal = any("AI确认恶意" in t for t in ai_tags)
    ai_ben = any("AI判定良性" in t for t in ai_tags)
    if ai_mal and raw > 0:
        final += 10
        evidence.append({"source": "ai", "type": "ai_malicious", "score": 10,
                         "confidence": 0.6,
                         "message": "AI 分析倾向恶意（仅在有本地证据时 +10，不单独定罪）"})
    elif ai_ben and raw > 0 and not _has_behavior:
        final -= 5
        evidence.append({"source": "ai", "type": "ai_benign", "score": -5,
                         "confidence": 0.6,
                         "message": "AI 分析判定良性（-5，仅无行为证据时小幅降分）"})
    elif ai_ben and _has_behavior:
        evidence.append({"source": "ai", "type": "ai_benign_ignored", "score": 0,
                         "confidence": 0.6,
                         "message": "AI 判定良性（存在行为证据，不降分——AI 不抵消行为证据）"})

    final = max(0, min(100, final))
    if strong and raw >= 40 and final < 41:
        final = 41  # 强证据存在时白名单最多压到可疑档，不漏真毒

    # ===== 5. 五档 verdict =====
    verdict, level = _verdict_level(final)
    _exp = "综合评分 %d/100：%s。" % (final, {
        VERDICT_SAFE: "未发现足够证据，判定安全。",
        VERDICT_LOW: "存在轻微特征，风险较低，记录观察即可。",
        VERDICT_SUSPICIOUS: "存在可疑特征，建议人工确认或加入观察。",
        VERDICT_HIGH: "多项风险特征叠加，建议隔离。",
        VERDICT_MALICIOUS: "强证据命中，判定为恶意。",
    }[verdict])
    if evidence:
        _top = [e["message"] for e in evidence[:4]]
        _exp += "命中：" + "；".join(_top) + "。"
    return _build_result(evidence, final, _exp, verdict, level, adjustment)


def _build_result(evidence, final_score, explanation,
                  verdict=None, level=None, adjustment=0):
    if verdict is None:
        verdict, level = _verdict_level(final_score)
    return {
        "evidence": evidence,
        "final_score": final_score,
        "verdict": verdict,
        "level": level,
        "explanation": explanation,
        "whitelist_adjustment": adjustment,
    }


if __name__ == "__main__":
    # 自测样例
    def _t(tags, **kw):
        r = assess(res_tags=tags, **kw)
        print("%-46s score=%3d verdict=%-11s level=%-4s | %s" % (
            ",".join(tags[:2]), r["final_score"], r["verdict"], r["level"], r["explanation"][:60]))
    _t(["命中黑名单哈希（Trojan.A）"], blacklisted=True)
    _t(["EICAR 测试样本（用于验证杀软流程，无害）"])
    _t(["云端已判恶意（微步）"], cloud_malicious=True)
    _t(["扩展名伪装", "伪装为可执行文件(高危)"])
    _t(["高熵(疑似加壳/加密)"])
    _t(["高熵(疑似加壳/加密)", "加壳区段: UPX1", "仅弱特征(已降权2分)"])
    _t(["PE 导入表含进程注入 API 组合", "导入表含下载执行API"])
    _t(["勒索行为"], whitelisted=True)
    _t(["开发目录脚本(已降权3分)", "更新器/安装器上下文(已降权3分)"])
    _t(["ClamAV:Win.Trojan.X", "命中黑名单哈希"])
    # ---- 5.1.0 新增自测（GPT 审查回归）----
    _t(["远控行为"], whitelisted=True)                        # 白名单劫持：行为证据+白名单 → 保底 41
    _t(["导入表含下载执行API", "高熵(疑似加壳/加密)", "自启动行为"])  # 弱证据2条+中/强证据 → 60% 组合计分
    _t(["高熵(疑似加壳/加密)", "代码混淆/编码特征", "免杀/反调试特征"], whitelisted=True)  # 纯弱证据3条+白名单
    _t(["AI判定良性", "勒索行为"], ai_tags=["AI判定良性"])    # AI良性强证据 → 不降分
    _t(["AI判定良性", "高熵(疑似加壳/加密)"], ai_tags=["AI判定良性"])  # AI良性+纯弱证据 → -5
    _t(["高熵(疑似加壳/加密)"], path=r"F:\work\build\test.exe")  # 编译产物目录 → 开发降权 0 分
    _t(["高熵(疑似加壳/加密)", "代码混淆/编码特征", "免杀/反调试特征"],
        path=r"F:\work\dist\out.exe")                         # 构建目录弱证据3条+降权
