# -*- coding: utf-8 -*-
"""
YARA 规则引擎集成（yara_engine.py）
====================================
离线规则匹配（无需联网）：
- 规则目录: dgdata/rules/*.yar（用户可自行添加规则文件）
- 引擎: yara64.exe（官方 Windows 二进制，dgdata/yara/ 目录）
- 命中规则 -> 返回 [(规则名, 风险分, 级别)]，由主引擎换算

支持用户自定义规则：放入 dgdata/rules/ 下的 .yar 都会被加载；
自定义规则若未在 RULE_SCORE 映射中，默认 +4 分、中危。
"""

import os
import glob
import subprocess

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RULES_DIR = os.path.join(_ROOT, "dgdata", "rules")
YARA_DIR = os.path.join(_ROOT, "dgdata", "yara")
YARA_EXE = os.path.join(YARA_DIR, "yara64.exe")
MAX_YARA_SIZE = 20 * 1024 * 1024  # 只扫 <= 20MB 文件，避免大文件阻塞

# 内置规则名 -> (风险分, 级别) 映射
RULE_SCORE = {
    "DG_EICAR_TEST": (10, "严重"),
    "DG_RANSOMWARE_NOTE": (9, "严重"),
    "DG_RAT_C2": (8, "严重"),
    "DG_DOWNLOADER_NETLOADER": (8, "严重"),
    "DG_POWERSHELL_DOWNLOADER": (7, "高危"),
    "DG_PS_OBFUSCATED": (6, "高危"),
    "DG_MINER": (7, "高危"),
    "DG_WSCRIPT_MALWARE": (6, "高危"),
    "DG_ARCHIVE_BOMB": (6, "高危"),
    "DG_SUSPICIOUS_BINARY": (4, "中危"),
}
DEFAULT_SCORE = (4, "中危")  # 自定义规则默认值


def rules_files():
    return sorted(glob.glob(os.path.join(RULES_DIR, "*.yar")))


def yara_ready() -> bool:
    """YARA 引擎 + 规则是否就绪。"""
    try:
        return os.path.exists(YARA_EXE) and bool(rules_files())
    except Exception:
        return False


def engine_info() -> str:
    """返回 YARA 引擎信息（用于界面展示）。"""
    if not os.path.exists(YARA_EXE):
        return "未安装"
    try:
        _cf = 0x08000000 if os.name == "nt" else 0
        r = subprocess.run([YARA_EXE, "--version"], capture_output=True, timeout=5, creationflags=_cf)
        return r.stdout.decode(errors="ignore").strip() or "未知"
    except Exception:
        return "未知"


def scan_with_yara(path: str):
    """用 YARA 规则扫描单个文件。

    返回: [(rule_name, score, level)]，引擎不可用/无命中返回 []。
    """
    if not yara_ready():
        return []
    try:
        size = os.path.getsize(path)
        if size <= 0 or size > MAX_YARA_SIZE:
            return []
    except Exception:
        return []
    try:
        cmd = [YARA_EXE, "-w"] + rules_files() + [path]
        r = subprocess.run(cmd, capture_output=True, timeout=15, creationflags=_cf)
        out = r.stdout.decode(errors="ignore")
        hits = []
        for line in out.splitlines():
            line = line.strip()
            if not line or line.startswith(("warning", "error")):
                continue
            name = line.split()[0] if line.split() else ""
            if not name:
                continue
            score, level = RULE_SCORE.get(name, DEFAULT_SCORE)
            hits.append((name, score, level))
        return hits
    except Exception:
        return []


def scan_scan_result(path):
    """返回用于 engine.py 的 (总风险分增量, 命中标签, 最高级别)。

    命中标签形如 "YARA:规则名"。"""
    hits = scan_with_yara(path)
    if not hits:
        return 0, [], None
    total = 0
    tags = []
    best_level = None
    best_order = 99
    order = {"严重": 0, "高危": 1, "中危": 2, "低危": 3, "安全": 4}
    for name, score, level in hits:
        total += score
        tags.append("YARA:" + name)
        o = order.get(level, 99)
        if o < best_order:
            best_order = o
            best_level = level
    return total, tags, best_level
