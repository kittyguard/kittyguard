# -*- coding: utf-8 -*-
"""6.0.3 发布冒烟验证"""
import io, json, os, re, sys

os.chdir(r"F:\桌面保护\desktopguard")

src = io.open("main.py", encoding="utf-8").read()
m = re.search(r'APP_VERSION = "([^"]+)"', src)
print("main.py APP_VERSION =", m.group(1))
assert m.group(1) == "6.0.3", "版本号未更新为 6.0.3"

mh = re.search(r"VERSION_HISTORY = \[\('([^']+)', '([^']+)'", src)
print("VERSION_HISTORY 首条:", mh.group(1), "<-", mh.group(2))
assert mh.group(1) == "6.0.3"

sys.path.insert(0, ".")
import selfdefense as _sd
man = _sd.load_manifest() or {}
print("防篡改清单 version =", man.get("version"), "| py =", len(man.get("py", {})), "| cfg =", len(man.get("cfg", {})))
assert man.get("version") == "6.0.3", "防篡改清单版本未更新"

v = json.load(io.open("version.json", encoding="utf-8"))
print("根 version.json:", v.get("latest_version"), "| version =", v.get("version"))
assert v.get("latest_version") == "6.0.3"

ov = json.load(io.open("官网/version.json", encoding="utf-8"))
print("官网 version.json:", ov.get("latest_version"), "| version =", ov.get("version"), "| pkg =", ov.get("pkg"))
assert ov.get("latest_version") == "6.0.3"

for p in ["dist/DG安全/DG安全.exe", "官网/DG-Security_6.0.3.zip", "versions/6.0.3/manifest.json",
          "官网/publish/index.html", "官网/publish/version.json", "官网/publish/DG-Security_6.0.3.zip"]:
    if os.path.exists(p):
        extra = "%.1fMB" % (os.path.getsize(p) / 1048576) if p.endswith(("zip", "exe")) else ""
        print("OK 存在:", p, extra)
    else:
        print("缺失:", p)
        raise SystemExit("冒烟失败：缺失 " + p)

# 6.0.3 新功能代码存在性
rg_src = io.open("ransomware_guard.py", encoding="utf-8").read()
for pat, who in [("_trim_oldest_backup", "ransomware_guard.py"),
                 ("ransom_guard_dirs", "main.py"),
                 ("_ransom_dirs_add", "main.py"),
                 ("_ransom_dirs_reset", "main.py"),
                 ("_tv2", "main.py"),
                 ("set_dirs", "ransomware_guard.py")]:
    found = (pat in src) if who == "main.py" else (pat in rg_src)
    print("含「%s」(%s):" % (pat, who), found)
    assert found, "6.0.3 功能缺失：" + pat

# 配置默认
print("DEFAULT_CONFIG 含 ransom_guard_dirs:", "ransom_guard_dirs" in src)

print("[OK] 6.0.3 冒烟全部通过")
