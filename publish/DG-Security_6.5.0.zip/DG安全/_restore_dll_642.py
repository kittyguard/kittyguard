# -*- coding: utf-8 -*-
"""从 6.4.2 dist 补齐 Downloads\\DG安全 缺失的运行时 DLL，并把对应误隔离记录移入保留目录"""
import os, glob, shutil, json

DIST_INTERNAL = r"F:\桌面保护\desktopguard\dist\DG安全\_internal"
DL_INTERNAL = r"C:\Users\Administrator\Downloads\DG安全\_internal"
QM = r"F:\桌面保护\desktopguard\quarantine\_meta"
QP = r"F:\桌面保护\desktopguard\quarantine"
KEEP = r"F:\桌面保护\desktopguard\quarantine\_restored_642"

need = [
    "api-ms-win-core-console-l1-1-0.dll",
    "api-ms-win-core-datetime-l1-1-0.dll",
    "api-ms-win-core-fibers-l1-1-0.dll",
    "api-ms-win-core-errorhandling-l1-1-0.dll",
    "api-ms-win-core-debug-l1-1-0.dll",
]

os.makedirs(DL_INTERNAL, exist_ok=True)
# 1) 复制缺失 DLL（从 dist，标准 PyInstaller 产物，与 6.4.2 一致）
for n in need:
    src = os.path.join(DIST_INTERNAL, n)
    dst = os.path.join(DL_INTERNAL, n)
    if os.path.isfile(src):
        shutil.copy2(src, dst)
        print("COPIED", n, os.path.getsize(dst), "B")
    else:
        print("MISSING IN DIST:", n)

# 2) 收集这 5 个 DLL 的隔离记录（.dgq + meta），移入保留目录
os.makedirs(KEEP, exist_ok=True)
moved = 0
if os.path.isdir(QM):
    for m in glob.glob(os.path.join(QM, "*.json")) + glob.glob(os.path.join(QM, "*.meta.json")):
        try:
            with open(m, "r", encoding="utf-8") as f:
                d = json.load(f)
            op = d.get("original_path", "")
        except Exception:
            op = ""
        if "api-ms-win-core" in op and "_internal" in op:
            base = os.path.basename(m)
            # 对应 .dgq：meta 文件名去掉 .meta.json / .json 后缀
            dgq_cand = [os.path.join(QP, base.replace(".meta.json", ".dgq")),
                        os.path.join(QP, base.replace(".json", ".dgq"))]
            for dgq in dgq_cand:
                if os.path.isfile(dgq):
                    shutil.move(dgq, os.path.join(KEEP, os.path.basename(dgq)))
                    print("MOVED dgq:", os.path.basename(dgq))
            shutil.move(m, os.path.join(KEEP, base))
            print("MOVED meta:", base)
            moved += 1
print("total moved records:", moved)

# 3) 终检
print()
print("=== 终检 Downloads\\DG安全\\_internal ===")
for n in need:
    p = os.path.join(DL_INTERNAL, n)
    print("  ", n, "->", os.path.isfile(p), os.path.getsize(p) if os.path.isfile(p) else 0)
