# -*- coding: utf-8 -*-
"""
DG 文件粉碎机模块 4.17.0
纯用户态：对目标文件多次覆写（随机→0x00→0xFF）后删除，常规手段不可恢复。
仅用于普通文件/临时敏感文件，不处理系统文件、运行中占用文件（会报错并跳过）。
"""

import os


def shred_file(path, passes=3):
    """覆写并删除单个文件。passes>=1。返回 True/False（False 表示失败被跳过）"""
    try:
        size = os.path.getsize(path)
        if size == 0:
            os.remove(path)
            return True
        patterns = [os.urandom, lambda n: b"\x00" * n, lambda n: b"\xff" * n]
        with open(path, "r+b", buffering=0) as f:
            for i in range(max(1, passes)):
                gen = patterns[i % len(patterns)]
                f.seek(0)
                written = 0
                while written < size:
                    chunk = gen(min(1 << 20, size - written))
                    f.write(chunk)
                    written += len(chunk)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
        os.remove(path)
        return True
    except OSError:
        return False


def shred_files(paths, passes=3):
    """批量粉碎，返回 (成功数, 失败列表[(path, reason)])"""
    ok = 0
    fails = []
    for p in paths:
        try:
            if not os.path.isfile(p):
                fails.append((p, "不是文件或不存在"))
                continue
            if os.path.splitext(p)[1].lower() in (".sys", ".dll") and "\\windows\\" in p.lower():
                fails.append((p, "系统文件拒绝粉碎"))
                continue
            if shred_file(p, passes):
                ok += 1
            else:
                fails.append((p, "覆写/删除失败（可能被占用或无权限）"))
        except Exception as e:
            fails.append((p, str(e)))
    return ok, fails
