# -*- coding: utf-8 -*-
"""官网 HTML 同步 6.2.0：zip 链接 + 版本号 + 时间轴插入 6.2.0 当前版 / 6.1.0 已发布，6.0.5 降为已发布"""
import io

paths = [
    r"F:\桌面保护\desktopguard\官网\DG安全官网.html",
    r"F:\桌面保护\desktopguard\官网\index.html",
    r"F:\桌面保护\desktopguard\官网\publish\index.html",
]

# 1. zip 下载链接 3 处
# 2. 其余裸版本号
# 3. 时间轴：6.0.5 当前版节点前插 6.2.0 当前版 + 6.1.0 已发布，6.0.5 降为已发布

old605 = ('<div class="tl-item">\n'
          '        <div class="tl-time">6.0.5</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>恢复指定目录 · 扫描历史管理</h4><p>勒索备份可恢复到指定目录：原路径丢失、换盘或重装系统后照样找回全部文件，同名自动加序号防覆盖；新增扫描历史窗口，回看最近 20 次扫描记录（时间/模式/文件数/威胁/垃圾/耗时），支持一键清空全部历史，不影响扫描引擎与任何配置。</p></div>\n'
          '      </div>')

new620 = ('<div class="tl-item">\n'
          '        <div class="tl-time">6.2.0</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>洪流冲刷一键直达 · 组件自检修复 · 勒索立即备份</h4><p>托盘右键菜单新增「洪流冲刷」：不打开主窗口也能一键切到冲刷页并启动五段流水线，打完游戏随手冲一波；防护中心新增「一键自检修复」：核心 C++ 组件缺失或被杀软误删时，自动从最新版本快照恢复同名文件，后台执行不卡界面，完成后弹窗报告 正常/已恢复/失败；勒索守护新增「立即备份全部」：怀疑勒索或重装系统前，把监控目录全部文档办公文件手动备份到保护区（去重 + 隐藏属性 + 2GB 容量自清理），随时可用「恢复勒索备份」找回。</p></div>\n'
          '      </div>\n'
          '      <div class="tl-item">\n'
          '        <div class="tl-time">6.1.0</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">已发布</span>定时自动扫描 · 勒索守护历史</h4><p>设置指定每天时间 + 扫描模式，到点自动后台查杀、当天只触发一次，免打扰静默不打扰；勒索守护告警 / 冻结 / 备份 / 处置事件全部留痕回看；版本更新公告：更新后首次启动自动弹出本次更新内容。</p></div>\n'
          '      </div>\n'
          '      <div class="tl-item">\n'
          '        <div class="tl-time">6.0.5</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">已发布</span>恢复指定目录 · 扫描历史管理</h4><p>勒索备份可恢复到指定目录：原路径丢失、换盘或重装系统后照样找回全部文件，同名自动加序号防覆盖；新增扫描历史窗口，回看最近 20 次扫描记录（时间/模式/文件数/威胁/垃圾/耗时），支持一键清空全部历史，不影响扫描引擎与任何配置。</p></div>\n'
          '      </div>')

for p in paths:
    s = io.open(p, encoding="utf-8").read()
    s = s.replace("DG-Security_6.1.0.zip", "DG-Security_6.2.0.zip")
    s = s.replace("DG 6.1.0", "DG 6.2.0")
    s = s.replace("当前版本 6.0.5", "当前版本 6.2.0")
    assert old605 in s, "时间轴锚点未命中: %s" % p
    s = s.replace(old605, new620)
    io.open(p, "w", encoding="utf-8").write(s)
    left = s.count("6.0.5") + s.count("6.1.0")
    print("[OK] %s 已同步 6.2.0；剩余 6.0.5/6.1.0 引用（应为历史节点/版本列表）:", p)
