# -*- coding: utf-8 -*-
"""列出 desktopguard 根目录与 dist 的 exe 文件"""
import os

DG = r"F:\桌面保护\desktopguard"
print("=== root exe ===")
for f in sorted(os.listdir(DG)):
    if f.lower().endswith(".exe"):
        print(f, os.path.getsize(os.path.join(DG, f)))
print("=== dist _internal exe ===")
d = os.path.join(DG, "dist", "DG安全", "_internal")
if os.path.isdir(d):
    for f in sorted(os.listdir(d)):
        if f.lower().endswith(".exe"):
            print(f)
print("=== dist root ===")
dr = os.path.join(DG, "dist", "DG安全")
for f in sorted(os.listdir(dr)):
    print(f, "<DIR>" if os.path.isdir(os.path.join(dr, f)) else "")
