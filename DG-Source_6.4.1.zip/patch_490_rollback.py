# -*- coding: utf-8 -*-
"""DG 4.9.0 补丁：版本号 + 自防护中心描述更新（系统回滚）+ 历史记录"""
import io

P = r"F:\桌面保护\desktopguard\main.py"
src = io.open(P, "r", encoding="utf-8").read()

# 1. 版本号
old = 'APP_VERSION = "4.8.0"'
assert old in src, "version anchor"
src = src.replace(old, 'APP_VERSION = "4.9.0"', 1)

# 2. 自防护中心卡片描述更新（提及系统回滚）
old_desc = ('"回滚中心（TCP/进程/配置/数据库一键回滚）+ 防篡改（核心文件完整性自愈：哈希校验→快照恢复），纯用户态",')
new_desc = ('"系统回滚（数据快照一键回滚，本机系统还原组件缺失已自动识别）+ 回滚中心（TCP/进程/配置/数据库）+ 防篡改（核心文件哈希自愈），纯用户态",')
assert old_desc in src, "desc anchor"
src = src.replace(old_desc, new_desc, 1)

# 3. 历史版本记录
old_vlist = '    ("4.8.0", "4.7.0", '
new_vlist = (
    '    ("4.9.0", "4.8.0", "内容更新（系统回滚+自防护增强 v1）：1.【系统回滚】自防护中心新增 DG 数据快照回滚——配置/数据库/名单一键快照（可打标签），快照列表+一键恢复最新快照，纯用户态可用；自动识别本机 Windows 系统还原组件缺失（srservice 服务不存在，商家魔改系统）并如实提示，保留 rstrui 系统还原向导入口；2.【回滚中心】操作日志（进程/TCP）与快照并列展示；3.防篡改不变（核心文件哈希自愈每 60 秒）",),\n'
    '    ("4.8.0", "4.7.0", '
)
assert old_vlist in src, "vlist anchor"
src = src.replace(old_vlist, new_vlist, 1)

io.open(P, "w", encoding="utf-8").write(src)
print("PATCH OK, version now 4.9.0, size:", len(src))
