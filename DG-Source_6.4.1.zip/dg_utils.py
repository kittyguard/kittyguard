# -*- coding: utf-8 -*-
"""
DG安全 · 通用工具库（6.0.0 渐进拆分第一步：从 main.py 抽出的零依赖纯工具函数）
- send_to_recycle_bin     回收站删除（可恢复）
- verify_signatures_batch 批量 Authenticode 签名校验
- _lower_thread_priority  线程降优先级（扫描不卡 UI）
- _ver_tuple              版本号转可比较元组
- _is_installer_temp      安装器临时目录判断（防误报）
- fmt_size                字节数格式化
"""
import os
import re
import ctypes
import ctypes.wintypes
import subprocess
import tempfile


def send_to_recycle_bin(paths):
    """将文件移入回收站（可恢复），批量执行。返回 (成功数, 失败列表)。"""
    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ("hwnd", ctypes.wintypes.HWND),
            ("wFunc", ctypes.wintypes.UINT),
            ("pFrom", ctypes.wintypes.LPCWSTR),
            ("pTo", ctypes.wintypes.LPCWSTR),
            ("fFlags", ctypes.c_ushort),
            ("fAnyOperationsAborted", ctypes.wintypes.BOOL),
            ("hNameMappings", ctypes.wintypes.LPVOID),
            ("lpszProgressTitle", ctypes.wintypes.LPCWSTR),
        ]
    FO_DELETE = 3
    FOF_ALLOWUNDO = 0x40     # 允许撤销 = 进回收站
    FOF_NOCONFIRMATION = 0x10
    FOF_SILENT = 0x4
    ok, fail = 0, []
    valid = [p for p in paths if p and os.path.exists(p)]
    if not valid:
        return 0, []
    # 分批，避免单次 pFrom 过长
    for i in range(0, len(valid), 200):
        chunk = valid[i:i + 200]
        op = SHFILEOPSTRUCTW()
        op.wFunc = FO_DELETE
        op.pFrom = "\x00".join(chunk) + "\x00\x00"
        op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT
        res = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        if res == 0:
            ok += len(chunk)
        else:
            fail.extend(chunk)
    return ok, fail


# ===== 6.0.0-beta.2 签名验证缓存 =====
# PowerShell Get-AuthenticodeSignature 每次要起一个 powershell 进程，开销大。
# 同一文件在多次扫描/多轮监控里会被反复校验，按 (path, mtime_ns, size) 做内存缓存，
# 文件未变则直接命中，避免重复起进程。文件被改写（mtime/size 变化）自动失效。
_SIG_CACHE = {}          # {(path, mtime_ns, size): bool(Valid)}
_SIG_STATS = {"hit": 0, "miss": 0, "total": 0}


def sig_cache_stats():
    """签名缓存命中统计：{hit, miss, total, hit_rate}。"""
    total = _SIG_STATS.get("total", 0)
    hit = _SIG_STATS.get("hit", 0)
    return {"hit": hit, "miss": _SIG_STATS.get("miss", 0),
            "total": total, "hit_rate": (hit / total) if total else 0.0}


def _sig_stat(key):
    """取文件签名缓存键；文件不存在/不可 stat 返回 None（不缓存）。"""
    try:
        st = os.stat(key)
        return (key, st.st_mtime_ns, st.st_size)
    except Exception:
        return None


def verify_signatures_batch(paths, batch=20, use_cache=True):
    """用 PowerShell Get-AuthenticodeSignature 批量校验，返回 {path: bool(Valid)}。

    use_cache=True（默认）：按 (path, mtime, size) 内存缓存命中结果，
    文件未变则跳过真实验签（省一次 powershell 进程）；mtime/size 变化自动失效。
    """
    result = {}
    if not paths:
        return result
    need = []          # 待真实验签的路径
    need_keys = {}     # path -> 缓存键（验签后写回）
    for p in paths:
        _key = _sig_stat(p) if use_cache else None
        if _key is not None:
            if _key in _SIG_CACHE:
                result[p] = _SIG_CACHE[_key]
                _SIG_STATS["hit"] += 1
                _SIG_STATS["total"] += 1
                continue
            need_keys[p] = _key
        need.append(p)
    if need:
        _SIG_STATS["miss"] += len(need)
        _SIG_STATS["total"] += len(need)
    for i in range(0, len(need), batch):
        chunk = need[i:i + batch]
        ps = "@('" + "','".join(p.replace("'", "''") for p in chunk) + "') | Get-AuthenticodeSignature | ForEach-Object { \"$($_.Path)|$($_.Status)\" }"
        tmp = os.path.join(tempfile.gettempdir(), "dg_sig_%d.ps1" % os.getpid())
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                f.write("$ErrorActionPreference='SilentlyContinue'\n" + ps)
            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", tmp],
                capture_output=True, text=True, encoding="gbk", errors="ignore", timeout=180,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            for line in out.stdout.splitlines():
                if "|" in line:
                    p, st = line.rsplit("|", 1)
                    result[p] = (st.strip() == "Valid")
                    if use_cache and p in need_keys and need_keys[p] is not None:
                        _SIG_CACHE[need_keys[p]] = result[p]
        except Exception:
            pass
        finally:
            try:
                os.remove(tmp)
            except Exception:
                pass
    return result


def _lower_thread_priority():
    """把扫描线程设为低于正常优先级，避免扫描时电脑卡顿。"""
    try:
        ctypes.windll.kernel32.SetThreadPriority(
            ctypes.windll.kernel32.GetCurrentThread(), -1)  # THREAD_PRIORITY_BELOW_NORMAL
    except Exception:
        pass


def _set_io_priority_low():
    """把当前进程 IO 优先级降为 VERY_LOW（NtSetInformationProcess IoPriority=33）。

    6.3.0 扫描节流：全盘/大目录扫描时的磁盘读写请求排到其他程序之后，
    鼠标/系统/游戏不再被扫描 IO 拖到一卡一卡。纯用户态 API、只影响本进程、
    进程退出即恢复，无需驱动。
    """
    try:
        _ntdll = ctypes.WinDLL("ntdll", use_last_error=True)
        _fn = _ntdll.NtSetInformationProcess
        _fn.restype = ctypes.c_long
        _fn.argtypes = [ctypes.c_void_p, ctypes.c_int,
                        ctypes.c_void_p, ctypes.c_ulong]
        _PROCESS_IO_PRIORITY = 33
        _IO_PRIORITY_VERY_LOW = 0x40000000
        _val = ctypes.c_int(_IO_PRIORITY_VERY_LOW)
        _fn(ctypes.windll.kernel32.GetCurrentProcess(), _PROCESS_IO_PRIORITY,
            ctypes.byref(_val), ctypes.sizeof(_val))
    except Exception:
        pass


def _ver_tuple(v):
    """版本号转可比较元组：'4.0.0' → (4, 0, 0)。"""
    return tuple(int(x) for x in re.findall(r"\d+", str(v or "0")))


def _is_installer_temp(low_path):
    """NSIS 安装器解压目录 Temp 下 nsXXXX.tmp 与 PyInstaller 运行时释放目录 Temp 下 _MEI*。
    安装/解压软件时释放的组件不参与批量落盘判定与自动隔离，避免 WinError 5 误报。"""
    return ("\\temp\\ns" in low_path and ".tmp\\" in low_path) or ("\\temp\\_mei" in low_path)


def fmt_size(n):
    try:
        n = float(n)
    except Exception:
        return "-"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} GB"
