# -*- coding: utf-8 -*-
"""6.0.0 官网同步：dist\\DG安全 → 官网\\DG-Security_6.0.0.zip + sha256 + version.json + publish 镜像 + 清理旧包"""
import os, io, json, time, zipfile, hashlib, shutil

DG = r"F:\桌面保护\desktopguard"
SRC = os.path.join(DG, "dist", "DG安全")
ZIP = os.path.join(DG, "官网", "DG-Security_6.0.0.zip")
VER = "6.0.0"

def make_zip(src, dst):
    if os.path.exists(dst):
        os.remove(dst)
    n = 0
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for root, dirs, files in os.walk(src):
            for fn in files:
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, src)
                z.write(p, rel)
                n += 1
    return n

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

print("[1] 压缩 dist/DG安全 → zip ...")
n = make_zip(SRC, ZIP)
print("    文件数=%d 大小=%.1fMB" % (n, os.path.getsize(ZIP) / 1024 / 1024))
h = sha256(ZIP)
print("[2] sha256 =", h)

notes = {
    "latest_version": VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "pkg": "DG-Security_6.0.0.zip",
    "sha256": h,
    "release_notes": "6.0.0 用户态防护平台：勒索文档守护 + 误报回归闭环 + 签名验证缓存 + 实时签名感知。",
    "features": [
        "勒索文档守护：监控桌面/文档/图片/下载目录，批量异常改写自动冻结进程+备份改动文件，可恢复可放行（纯用户态）",
        "误报回归闭环：误报文件拖入自动提特征生成回归样本集，权重版本化、调权前全量回归验证可回滚",
        "签名验证缓存：Authenticode 验签按路径/修改时间/大小缓存，同一文件跨扫描只验签一次，扫描收尾显示命中统计",
        "实时防护签名感知：下载保护对 PE 自动验签，有效签名+无强特征直接放行，商业软件误报大幅下降",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "官网", "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[3] 官网 version.json 已更新为", VER)

# publish 镜像同步（供 GitHub Pages 推送）
pub = os.path.join(DG, "官网", "publish")
os.makedirs(pub, exist_ok=True)
shutil.copy2(os.path.join(DG, "官网", "DG安全官网.html"), os.path.join(pub, "index.html"))
shutil.copy2(ZIP, os.path.join(pub, "DG-Security_6.0.0.zip"))
shutil.copy2(os.path.join(DG, "官网", "version.json"), os.path.join(pub, "version.json"))
# 清理 publish 里的旧 zip
for fn in os.listdir(pub):
    if fn.startswith("DG-Security_") and fn != "DG-Security_6.0.0.zip":
        os.remove(os.path.join(pub, fn))
        print("    publish 清理旧包", fn)
print("[4] publish 镜像已同步（index.html + 新zip + version.json）")

# 清理官网旧 zip（只放最新版）
old = os.path.join(DG, "官网", "DG-Security_5.5.0.zip")
if os.path.exists(old):
    os.remove(old)
    print("[5] 已删除旧分发包 DG-Security_5.5.0.zip（官网只放最新版）")
print("[OK] 6.0.0 官网同步完成")
