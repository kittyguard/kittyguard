# -*- coding: utf-8 -*-
"""DG 数据目录统一配置：默认 F 盘（重装 C 盘不丢），可用环境变量 DG_DATA_DIR 覆盖。
便携/客户端版自适应：默认目录不可用（无 F 盘/无权限）时自动回退到 %APPDATA%\\DGDesktopGuard，
保证在任何电脑（如拷贝到 U 盘给他人使用）上都能正常运行。"""
import os

_DEFAULT = os.environ.get("DG_DATA_DIR", r"F:\桌面保护\dgdata")


def _resolve_data_dir():
    try:
        os.makedirs(_DEFAULT, exist_ok=True)
        return _DEFAULT
    except Exception:
        fb = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "DGDesktopGuard")
        try:
            os.makedirs(fb, exist_ok=True)
            return fb
        except Exception:
            return os.path.expanduser("~")


DATA_DIR = _resolve_data_dir()


def ensure_data_dir():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        return DATA_DIR
    except Exception:
        return DATA_DIR
