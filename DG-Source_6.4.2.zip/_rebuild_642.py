# -*- coding: utf-8 -*-
"""6.4.2 完整发布：便携zip + 源码zip + staging 同步 + ISCC 安装包 + version.json"""
import io, os, zipfile, json, hashlib, shutil, subprocess

DG = r"F:\桌面保护\desktopguard"
OFF = os.path.join(DG, "官网")
PUB = os.path.join(OFF, "publish")
DIST = os.path.join(DG, "dist", "DG安全")
STAGING = r"F:\桌面保护\vmware\dg_staging\DG安全"
ISCC = r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
ISS = r"F:\桌面保护\vmware\dg_setup.iss"
NEW_VER = "6.4.2"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

def make_zip(src_dir, out_zip):
    if os.path.exists(out_zip):
        os.remove(out_zip)
    total = 0
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(src_dir):
            for f in files:
                fp = os.path.join(root, f)
                arc = os.path.relpath(fp, src_dir)
                z.write(fp, arc)
                total += 1
    return total

if not os.path.isdir(DIST):
    raise SystemExit("dist 不存在，请先运行 PyInstaller 打包")

# ---- 1) 便携 zip ----
portable = os.path.join(PUB, "DG-Security_%s.zip" % NEW_VER)
n = make_zip(DIST, portable)
portable_sha = sha256(portable)
print("[OK] portable zip: %d files, %d B, sha256 %s" % (n, os.path.getsize(portable), portable_sha[:16]))
shutil.copy2(portable, os.path.join(OFF, os.path.basename(portable)))

# ---- 2) 源码 zip ----
SRC_SKIP = {".gitignore"}
src_files = set()
old_src = os.path.join(PUB, "DG-Source_%s.zip" % NEW_VER)
if os.path.isfile(old_src):
    with zipfile.ZipFile(old_src) as z:
        src_files = set(n for n in z.namelist() if "/" not in n)
root_files = set(f for f in os.listdir(DG) if os.path.isfile(os.path.join(DG, f)))
include = sorted((src_files | root_files) - SRC_SKIP)
src_zip = os.path.join(PUB, "DG-Source_%s.zip" % NEW_VER)
if os.path.exists(src_zip):
    os.remove(src_zip)
with zipfile.ZipFile(src_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for fn in include:
        p = os.path.join(DG, fn)
        if os.path.isfile(p):
            z.write(p, fn)
src_sha = sha256(src_zip)
print("[OK] source zip: %d files, %d B, sha256 %s" % (len(include), os.path.getsize(src_zip), src_sha[:16]))
shutil.copy2(src_zip, os.path.join(OFF, os.path.basename(src_zip)))

# ---- 3) staging 同步 ----
if os.path.exists(STAGING):
    shutil.rmtree(STAGING)
os.makedirs(STAGING, exist_ok=True)
shutil.copytree(DIST, STAGING, dirs_exist_ok=True)
print("[OK] staging synced: %d top items" % len(os.listdir(STAGING)))

# ---- 4) ISCC 安装包 ----
setup_out = os.path.join(OFF, "DG-Security-Setup-%s.exe" % NEW_VER)
if os.path.exists(setup_out):
    os.remove(setup_out)
if os.path.isfile(ISCC):
    r = subprocess.run([ISCC, ISS], capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=300)
    print("ISCC exit:", r.returncode)
    if r.returncode == 0 and os.path.isfile(setup_out):
        setup_sha = sha256(setup_out)
        print("[OK] setup: %d B, sha256 %s" % (os.path.getsize(setup_out), setup_sha[:16]))
        shutil.copy2(setup_out, os.path.join(PUB, os.path.basename(setup_out)))
    else:
        print("ISCC failed:", (r.stdout or "")[-800:], (r.stderr or "")[-800:])
else:
    print("[skip] ISCC not found")

# ---- 5) version.json ----
rel = "https://github.com/kittyguard/kittyguard/releases/download/v%s" % NEW_VER
notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": "2026-10-11",
    "release_notes": "6.4.2 修复版：修复实时防护误隔离便携版 _internal 运行时 DLL（api-ms-win-core-*）导致便携版启动闪退的问题，DG 自身目录全面豁免（任意安装位置的 DG安全/desktopguard/kittyguard 目录不再参与实时防护与目录监控）。",
    "features": [
        "修复：实时防护不再隔离 DG 自身文件——_is_self_path 扩展识别任意 DG安全/desktopguard/kittyguard 便携目录，文件事件入口（单文件告警/批量落盘告警/目录监控）统一豁免自身文件",
        "修复：被误隔离的 5 个 api-ms-win-core-*.dll 运行时 DLL 已还原到便携版 _internal 目录",
        "保持纯用户态、零驱动、不服务化、CPU≈0"
    ],
    "pkg": "%s/DG-Security_%s.zip" % (rel, NEW_VER),
    "sha256": portable_sha,
}
for d in (OFF, PUB, r"F:\桌面保护\kittyguard_site", r"F:\桌面保护\kittyguard_site\publish"):
    os.makedirs(d, exist_ok=True)
    with io.open(os.path.join(d, "version.json"), "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)
for d in (os.path.join(DIST, "_internal"), os.path.join(STAGING, "_internal")):
    if os.path.isdir(d):
        with io.open(os.path.join(d, "version.json"), "w", encoding="utf-8") as f:
            json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 全量同步")
print("PORTABLE_SHA=%s" % portable_sha)
print("SRC_SHA=%s" % src_sha)
