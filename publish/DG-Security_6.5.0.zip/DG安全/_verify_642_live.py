# -*- coding: utf-8 -*-
"""验证 GitHub Pages 线上 6.4.2 三件套 + version.json 可达性（走代理）"""
import os, json, urllib.request, ssl

PROXY = "http://127.0.0.1:33210"
BASE = "https://kittyguard.github.io/kittyguard"

handler = urllib.request.ProxyHandler({"https": PROXY, "http": PROXY})
opener = urllib.request.build_opener(handler)
ctx = ssl.create_default_context()

files = [
    "DG-Security-Setup-6.4.2.exe",
    "DG-Security_6.4.2.zip",
    "DG-Source_6.4.2.zip",
    "version.json",
]

for f in files:
    url = BASE + "/" + f
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with opener.open(req, timeout=60) as resp:
            data = resp.read()
            print(f, "HTTP", resp.status, "bytes", len(data))
            if f == "version.json":
                try:
                    v = json.loads(data.decode("utf-8"))
                    print("  version.json:", v.get("latest_version"), "pkg:", v.get("pkg"))
                except Exception as e:
                    print("  version.json parse err:", e)
    except Exception as e:
        print(f, "FAIL:", e)
