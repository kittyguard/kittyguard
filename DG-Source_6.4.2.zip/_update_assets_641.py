# -*- coding: utf-8 -*-
"""6.4.1 修复版：替换 GitHub Release 3 资产 + 同步 site 并 push Pages"""
import os, io, sys, json, time, subprocess, urllib.request, urllib.error, urllib.parse

DG = r"F:\桌面保护\desktopguard"
SITE = r"F:\桌面保护\kittyguard_site"
REPO = "kittyguard/kittyguard"
PAT = os.environ.get("DG_GITHUB_TOKEN", "").strip()
if not PAT:
    print("[FAIL] 未设置 DG_GITHUB_TOKEN")
    sys.exit(2)

API = "https://api.github.com/repos/%s" % REPO
UPL = "https://uploads.github.com/repos/%s" % REPO
PROXY = "http://127.0.0.1:33210"
HDRS = [("Authorization", "token " + PAT), ("User-Agent", "kittyguard-dg"), ("Accept", "application/vnd.github+json")]

def api(url, method="GET", data=None, raw=False, timeout=60):
    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(url, data=body, method=method)
    for h in HDRS:
        req.add_header(*h)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": PROXY, "https": PROXY}))
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        print("[WARN] 代理请求失败，回退直连:", e)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e2:
            return e2.code, e2.read()

# 1. 同步官网文件到 kittyguard_site（version.json 更新为带 pkg/sha256 的修复版）
pairs = [
    (DG + r"\官网\DG安全官网.html", SITE + r"\DG安全官网.html"),
    (DG + r"\官网\index.html", SITE + r"\index.html"),
    (DG + r"\官网\publish\index.html", SITE + r"\publish\index.html"),
    (DG + r"\官网\version.json", SITE + r"\version.json"),
]
for src, dst in pairs:
    with open(src, "rb") as f:
        with open(dst, "wb") as g:
            g.write(f.read())
print("[OK] 官网文件已同步到 kittyguard_site")

# 2. 查 Release v6.4.1 与现有资产
st, body = api(API + "/releases/tags/v6.4.1")
if st != 200:
    print("[FAIL] 查询 Release:", st, body[:500])
    sys.exit(1)
rel = json.loads(body)
rel_id = rel["id"]
print("[OK] Release v6.4.1 id=%s" % rel_id)

st, body = api(API + "/releases/%s/assets?per_page=100" % rel_id)
existing = json.loads(body) if st == 200 else []
print("[OK] 现有资产:", [a["name"] for a in existing])

# 3. 删除同名旧资产
targets = ["DG-Security-Setup-6.4.1.exe", "DG-Security_6.4.1.zip", "DG-Source_6.4.1.zip"]
for a in existing:
    if a["name"] in targets:
        st2, _ = api(API + "/releases/assets/%s" % a["id"], "DELETE")
        print("[OK] 已删除旧资产:", a["name"], a["id"], "status", st2)
        time.sleep(1)

# 4. 上传新资产
assets = [
    (DG + r"\官网\DG-Security-Setup-6.4.1.exe", "DG-Security-Setup-6.4.1.exe"),
    (DG + r"\官网\DG-Security_6.4.1.zip", "DG-Security_6.4.1.zip"),
    (DG + r"\官网\DG-Source_6.4.1.zip", "DG-Source_6.4.1.zip"),
]
for path, name in assets:
    size = os.path.getsize(path)
    url = "%s/releases/%s/assets?name=%s" % (UPL, rel_id, urllib.parse.quote(name))
    with open(path, "rb") as f:
        data = f.read()
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", "token " + PAT)
    req.add_header("User-Agent", "kittyguard-dg")
    req.add_header("Content-Type", "application/octet-stream")
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": PROXY, "https": PROXY}))
    try:
        with opener.open(req, timeout=900) as r:
            st2 = r.status
            out = r.read()
    except urllib.error.HTTPError as e:
        st2, out = e.code, e.read()
    if st2 not in (200, 201):
        print("[FAIL] 上传 %s:", name, st2, out[:400])
        sys.exit(1)
    print("[OK] 已上传 %s: %d B" % (name, size))

print("[DONE] Release v6.4.1 资产已替换")
