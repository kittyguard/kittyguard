# -*- coding: utf-8 -*-
import subprocess, os

VBM = r"C:\Program Files\Oracle\VirtualBox\VBoxManage.exe"
VM = "DG-VM"

def run(cmd, timeout=40):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=timeout)
        return r.stdout, r.stderr
    except Exception as e:
        return "", "ERR " + str(e)

for prop in ["name", "ostype", "cpus", "memory", "vram",
             "firmware", "nested-hw-virt",
             "nic1", "macaddress1", "cableconnected1", "natnetwork1"]:
    out, _ = run([VBM, "showvminfo", VM, "--machinereadable"])
    # 从 machinereadable 输出里提取该属性
    val = None
    for line in out.splitlines():
        if line.startswith(prop + "="):
            val = line.split("=", 1)[1].strip('"')
    print(prop, "=", val)

print()
print("=== disk info ===")
out, _ = run([VBM, "showvminfo", VM, "--machinereadable"])
for line in out.splitlines():
    if line.startswith("SATA") or line.startswith("IDE") or "vdi" in line.lower():
        print(line)

print()
print("=== guest metrics (CPU/RAM usage in VM) ===")
out, _ = run([VBM, "metrics", "query", VM, "CPU/Load/RAM", "--list"])
print(out.strip() or "(no metrics)")
