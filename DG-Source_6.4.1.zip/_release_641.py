# -*- coding: utf-8 -*-
"""发布 6.4.1 到 GitHub：同步官网 HTML/version.json -> kittyguard_site -> push Pages，创建 Release v6.4.1 + 上传 3 资产，验证线上。
PAT 从环境变量 DG_GITHUB_TOKEN 读取，不落盘。"""
import os, io, sys, json, time, subprocess, urllib.request, urllib.error

DG = r"F:\桌面保护\desktopguard"
SITE = r"F:\桌面保护\kittyguard_site"
REPO = "kittyguard/kittyguard"
PAT = os.environ.get("DG_GITHUB_TOKEN", "").strip()
if not PAT:
    print("[FAIL] 未设置 DG_GITHUB_TOKEN")
    sys.exit(2)

API = "https://api.github.com/repos/%s" % REPO
UPL = "https://uploads.github.com/repos/%s" % REPO
PROXY = "http://127.0.0.1:33210"
HDRS = [("Authorization", "token " + PAT), ("User-Agent", "kittyguard-dg"), ("Accept", "application/vnd.github+json")]

def api(url, method="GET", data=None, raw=False):
    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(url, data=body, method=method)
    for h in HDRS:
        req.add_header(*h)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": PROXY, "https": PROXY}))
    try:
        with opener.open(req, timeout=60) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        print("[WARN] API 代理请求失败，回退直连:", e)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e2:
            return e2.code, e2.read()

# 1. 同步官网文件到 kittyguard_site
pairs = [
    (DG + r"\官网\DG安全官网.html", SITE + r"\DG安全官网.html"),
    (DG + r"\官网\index.html", SITE + r"\index.html"),
    (DG + r"\官网\publish\index.html", SITE + r"\publish\index.html"),
    (DG + r"\官网\version.json", SITE + r"\version.json"),
]
for src, dst in pairs:
    with open(src, "rb") as f:
        with open(dst, "wb") as g:
            g.write(f.read())
print("[OK] 官网文件已同步到 kittyguard_site")

# 2. git push（走代理）
env = dict(os.environ)
env["GIT_TERMINAL_PROMPT"] = "0"
env["HTTPS_PROXY"] = PROXY
env["HTTP_PROXY"] = PROXY
git_url = "https://x-access-token:%s@github.com/%s.git" % (PAT, REPO)

def run(cmd, cwd=SITE):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), env=env)
    return r

r = run(["git", "remote", "set-url", "origin", git_url])
if r.returncode != 0:
    run(["git", "remote", "add", "origin", git_url])
run(["git", "add", "-A"])
r = run(["git", "commit", "-m", "DG 6.4.1 官网发布（移除 AI 助手聊天，保留 AI 实时辅助）"])
if r.returncode != 0 and "nothing to commit" not in r.stderr:
    print("[WARN] commit:", r.stderr[-300:])
r = run(["git", "push", "-u", "origin", "main", "--force"])
if r.returncode != 0:
    print("[FAIL] push:", r.stderr[-500:])
    sys.exit(1)
print("[OK] 已 push 到", REPO)

# 3. 创建 Release v6.4.1（先查是否已存在）
st, body = api(API + "/releases/tags/v6.4.1")
if st == 200:
    rel = json.loads(body)
    rel_id = rel["id"]
    print("[OK] Release v6.4.1 已存在 id=%s" % rel_id)
elif st == 404:
    payload = {
        "tag_name": "v6.4.1",
        "name": "DG 桌面安全卫士 6.4.1",
        "body": "**6.4.1 内容更新（移除 AI 助手聊天）**\n\n- 移除 AI 助手聊天：工具页「AI 助手」卡片、托盘「打开 AI 聊天」入口、AI 助手聊天窗口与 AI 动作执行器全部移除——作为一个杀毒软件，对话式 AI 助手没必要保留，入口更干净\n- 保留 AI 实时辅助：扫描后对高危/严重文件自动 AI 二次判断（AI 智能检查）与设置页隐藏 AI 配置区完整保留，杀毒判断能力不减\n- 全程纯用户态、零驱动、不服务化、CPU≈0\n\n免责声明：不可用于主力杀毒软件；用户态防护能力弱于内核态（Ring 0）方案。",
        "draft": False,
        "prerelease": False,
    }
    st, body = api(API + "/releases", "POST", payload)
    if st not in (200, 201):
        print("[FAIL] 创建 Release:", st, body[:500])
        sys.exit(1)
    rel = json.loads(body)
    rel_id = rel["id"]
    print("[OK] Release v6.4.1 已创建 id=%s" % rel_id)
else:
    print("[FAIL] 查询 Release:", st, body[:500])
    sys.exit(1)

# 4. 上传 3 个资产
assets = [
    (DG + r"\官网\DG-Security-Setup-6.4.1.exe", "DG-Security-Setup-6.4.1.exe"),
    (DG + r"\官网\DG-Security_6.4.1.zip", "DG-Security_6.4.1.zip"),
    (DG + r"\官网\DG-Source_6.4.1.zip", "DG-Source_6.4.1.zip"),
]
for path, name in assets:
    size = os.path.getsize(path)
    # 查是否已上传
    st, body = api(API + "/releases/%s/assets?per_page=100" % rel_id)
    existing = []
    if st == 200:
        for a in json.loads(body):
            if a["name"] == name:
                existing.append(a)
    if existing:
        print("[OK] 资产已存在（跳过上传）:", name, size, "B")
        continue
    url = "%s/releases/%s/assets?name=%s" % (UPL, rel_id, urllib.parse.quote(name))
    with open(path, "rb") as f:
        data = f.read()
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", "token " + PAT)
    req.add_header("User-Agent", "kittyguard-dg")
    req.add_header("Content-Type", "application/octet-stream")
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": PROXY, "https": PROXY}))
    try:
        with opener.open(req, timeout=600) as r:
            st2 = r.status
            out = r.read()
    except urllib.error.HTTPError as e:
        st2, out = e.code, e.read()
    if st2 not in (200, 201):
        print("[FAIL] 上传 %s:", name, st2, out[:400])
        sys.exit(1)
    print("[OK] 已上传 %s: %d B" % (name, size))

print("[DONE] Release v6.4.1 全资产上传完成")
