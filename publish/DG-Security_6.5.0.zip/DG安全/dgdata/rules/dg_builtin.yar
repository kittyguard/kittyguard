// DG Security - Built-in YARA rules v1
// Core malware detection rules (offline)
// Rule dir: dgdata/rules/

rule DG_EICAR_TEST {
    meta:
        description = "EICAR standard test file (harmless, validates AV pipeline)"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
    condition:
        $eicar
}

rule DG_POWERSHELL_DOWNLOADER {
    meta:
        description = "PowerShell download-execute (remote payload)"
        author = "DG Security"
        level = "HIGH"
    strings:
        $d1 = "Invoke-WebRequest" ascii nocase
        $d2 = "DownloadString" ascii nocase
        $d3 = "IEX(" ascii nocase
        $d4 = "Invoke-Expression" ascii nocase
        $d5 = "http://" ascii nocase
        $d6 = "https://" ascii nocase
        $d7 = "FromBase64String" ascii nocase
    condition:
        (uint16(0) == 0x5A4D or (2 of ($d1, $d2, $d3, $d4))) and (1 of ($d5, $d6)) or ($d3 and $d7)
}

rule DG_PS_OBFUSCATED {
    meta:
        description = "Obfuscated PowerShell script"
        author = "DG Security"
        level = "HIGH"
    strings:
        $s1 = "-join" ascii nocase
        $s2 = "-split" ascii nocase
        $s3 = "[char]" ascii nocase
        $s4 = "[Convert]::" ascii nocase
        $s5 = "replace(" ascii nocase
        $s6 = "xor" ascii nocase
        $s7 = "Base64" ascii nocase
        $s8 = "::-1" ascii nocase
    condition:
        (uint16(0) == 0x5A4D or filesize < 2MB) and (3 of them)
}

rule DG_MINER {
    meta:
        description = "Cryptocurrency miner (pool/tool strings)"
        author = "DG Security"
        level = "HIGH"
    strings:
        $m1 = "stratum+tcp://" ascii nocase
        $m2 = "xmrig" ascii nocase
        $m3 = "minerd" ascii nocase
        $m4 = "cryptonight" ascii nocase
        $m5 = "ethash" ascii nocase
        $m6 = "nicehash" ascii nocase
        $m7 = "hashrate" ascii nocase
        $m8 = "donate-level" ascii nocase
    condition:
        2 of them
}

rule DG_RANSOMWARE_NOTE {
    meta:
        description = "Ransomware note/ransomware indicators"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $r1 = "your files have been encrypted" ascii nocase
        $r2 = "your data has been encrypted" ascii nocase
        $r3 = "bitcoin" ascii nocase
        $r4 = "decrypt" ascii nocase
        $r5 = "ransom" ascii nocase
        $r6 = ".locked" ascii nocase
        $r7 = "wallet" ascii nocase
        $r8 = "tor2pay" ascii nocase
    condition:
        2 of them
}

rule DG_RAT_C2 {
    meta:
        description = "Remote Access Trojan C2 indicators"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $c1 = "GetAsyncKeyState" ascii
        $c2 = "keybd_event" ascii
        $c3 = "SetWindowsHookEx" ascii
        $c4 = "GetClipboardData" ascii
        $c5 = "CreateRemoteThread" ascii
        $c6 = "VirtualAllocEx" ascii
        $c7 = "WriteProcessMemory" ascii
        $c8 = "cmd.exe /c" ascii nocase
        $c9 = "reverse" ascii nocase
        $c10 = "listen" ascii nocase
    condition:
        (3 of ($c1, $c2, $c3, $c4)) or (2 of ($c5, $c6, $c7)) or ($c8 and 2 of ($c9, $c10, $c1))
}

rule DG_DOWNLOADER_NETLOADER {
    meta:
        description = "Downloader trojan (NetLoader class)"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $n1 = "NetLoader" ascii nocase
        $n2 = "WebClient" ascii
        $n3 = "DownloadFile" ascii
        $n4 = "Assembly.Load" ascii
        $n5 = "byte[]" ascii
        $n6 = "Convert.FromBase64String" ascii
    condition:
        (2 of ($n1, $n2, $n3, $n4)) and ($n5 or $n6)
}

rule DG_WSCRIPT_MALWARE {
    meta:
        description = "VBS/JS malicious script (download-execute/obfuscate)"
        author = "DG Security"
        level = "HIGH"
    strings:
        $v1 = "CreateObject" ascii nocase
        $v2 = "WScript.Shell" ascii nocase
        $v3 = "Shell.Application" ascii nocase
        $v4 = "MSXML2.XMLHTTP" ascii nocase
        $v5 = ".Run" ascii
        $v6 = "Exec" ascii
        $v7 = "eval(" ascii nocase
        $v8 = "unescape" ascii nocase
    condition:
        (2 of ($v1, $v2, $v3, $v4)) and (1 of ($v5, $v6, $v7, $v8))
}

rule DG_ARCHIVE_BOMB {
    meta:
        description = "Zip bomb indicators"
        author = "DG Security"
        level = "HIGH"
    strings:
        $a1 = "zip-bomb" ascii nocase
        $a2 = "42.zip" ascii nocase
        $a3 = { 50 4B 03 04 }
    condition:
        $a1 or ($a3 and filesize < 4KB and $a2)
}

rule DG_SUSPICIOUS_BINARY {
    meta:
        description = "Suspicious PE (debug/process injection imports)"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $p1 = "IsDebuggerPresent" ascii
        $p2 = "CheckRemoteDebuggerPresent" ascii
        $p3 = "VirtualAlloc" ascii
        $p4 = "WriteProcessMemory" ascii
        $p5 = "CreateRemoteThread" ascii
        $p6 = "SetWindowsHookExA" ascii
        $p7 = "RegSetValueEx" ascii
        $p8 = "WinExec" ascii
        $p9 = "ShellExecute" ascii
    condition:
        uint16(0) == 0x5A4D and (3 of them)
}
