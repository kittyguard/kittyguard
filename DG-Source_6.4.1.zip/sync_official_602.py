# -*- coding: utf-8 -*-
"""6.0.2 官网同步：dist\\DG安全 → 官网\\DG-Security_6.0.2.zip + sha256 + version.json + publish 镜像 + 清理旧包"""
import os, io, json, time, zipfile, hashlib, shutil

DG = r"F:\桌面保护\desktopguard"
SRC = os.path.join(DG, "dist", "DG安全")
ZIP = os.path.join(DG, "官网", "DG-Security_6.0.2.zip")
VER = "6.0.2"

def make_zip(src, dst):
    if os.path.exists(dst):
        os.remove(dst)
    n = 0
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for root, dirs, files in os.walk(src):
            for fn in files:
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, src)
                z.write(p, rel)
                n += 1
    return n

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

print("[1] 压缩 dist/DG安全 → zip ...")
n = make_zip(SRC, ZIP)
print("    文件数=%d 大小=%.1fMB" % (n, os.path.getsize(ZIP) / 1024 / 1024))
h = sha256(ZIP)
print("[2] sha256 =", h)

notes = {
    "latest_version": VER,
    "version": VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "pkg": "DG-Security_6.0.2.zip",
    "sha256": h,
    "release_notes": "6.0.2 内容更新：勒索守护防误伤（试运行模式只记录不冻结 + 排除目录管理即时生效）。",
    "features": [
        "试运行模式：勒索守护可切换「只记录+备份、不冻结进程」，先观察防误伤，状态行实时显示",
        "排除目录管理：编译输出/游戏/虚拟机镜像等目录内批量改写不再冻结告警，添加移除即时生效",
        "配置持久化：ransom_guard_dryrun / ransom_guard_excludes 保存至 config.json",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "官网", "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[3] 官网 version.json 已更新为", VER)

# publish 镜像同步（供 GitHub Pages 推送）
pub = os.path.join(DG, "官网", "publish")
os.makedirs(pub, exist_ok=True)
shutil.copy2(os.path.join(DG, "官网", "DG安全官网.html"), os.path.join(pub, "index.html"))
shutil.copy2(ZIP, os.path.join(pub, "DG-Security_6.0.2.zip"))
shutil.copy2(os.path.join(DG, "官网", "version.json"), os.path.join(pub, "version.json"))
for fn in os.listdir(pub):
    if fn.startswith("DG-Security_") and fn != "DG-Security_6.0.2.zip":
        os.remove(os.path.join(pub, fn))
        print("    publish 清理旧包", fn)
print("[4] publish 镜像已同步（index.html + 新zip + version.json）")

old = os.path.join(DG, "官网", "DG-Security_6.0.1.zip")
if os.path.exists(old):
    os.remove(old)
    print("[5] 已删除旧分发包 DG-Security_6.0.1.zip（官网只放最新版）")
print("[OK] 6.0.2 官网同步完成")
