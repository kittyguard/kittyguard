# -*- coding: utf-8 -*-
import os
for d in (r"F:\桌面保护\desktopguard\官网", r"F:\桌面保护\desktopguard\官网\publish"):
    print("=== %s ===" % d)
    if os.path.isdir(d):
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            if os.path.isfile(p):
                print("  %s  %d B" % (f, os.path.getsize(p)))
