# -*- coding: utf-8 -*-
import os, subprocess
SITE = r"F:\桌面保护\kittyguard_site"
print("=== site top ===")
if os.path.isdir(SITE):
    for f in sorted(os.listdir(SITE)):
        p = os.path.join(SITE, f)
        print(" ", f, "<DIR>" if os.path.isdir(p) else os.path.getsize(p))
r = subprocess.run(["git", "-C", SITE, "status", "--short"], capture_output=True, text=True, encoding="utf-8", errors="ignore")
print("=== git status ===")
print((r.stdout or "")[:1500] or (r.stderr or "")[:500])
