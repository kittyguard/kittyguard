# -*- coding: utf-8 -*-
"""归档隔离区中所有 __init__.py 误报记录（qwen-agent / pip-install 临时安装文件）"""
import os, glob, json, shutil

QM = r"F:\桌面保护\desktopguard\quarantine\_meta"
QP = r"F:\桌面保护\desktopguard\quarantine"
KEEP = r"F:\桌面保护\desktopguard\quarantine\_restored_642"

os.makedirs(KEEP, exist_ok=True)
seen = set()
moved = 0

if os.path.isdir(QM):
    metas = sorted(glob.glob(os.path.join(QM, "*.json")) + glob.glob(os.path.join(QM, "*.meta.json")))
    for m in metas:
        try:
            with open(m, "r", encoding="utf-8") as f:
                d = json.load(f)
            op = d.get("original_path", "")
        except Exception:
            op = ""
        if "__init__" in op:
            base = os.path.basename(m)
            if base in seen:
                continue
            seen.add(base)
            # 找对应 .dgq
            for cand in [os.path.join(QP, base.replace(".meta.json", ".dgq")),
                         os.path.join(QP, base.replace(".json", ".dgq"))]:
                if os.path.isfile(cand):
                    shutil.move(cand, os.path.join(KEEP, os.path.basename(cand)))
                    print("MOVED dgq:", os.path.basename(cand))
            shutil.move(m, os.path.join(KEEP, base))
            print("MOVED meta:", base, "|", op.split("\\Temp\\")[-1] if "\\Temp\\" in op else op)
            moved += 1

print("total moved:", moved)
