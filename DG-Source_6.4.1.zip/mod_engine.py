# -*- coding: utf-8 -*-
"""engine.py: scan_file 支持 C++ 预计算哈希"""

with open('engine.py', 'r', encoding='utf-8') as f:
    c = f.read()

old_sig = '''    def scan_file(self, path: str) -> ScanResult:
        name = os.path.basename(path)'''
new_sig = '''    def scan_file(self, path: str, sha256_pre: str = "") -> ScanResult:
        """扫描单个文件，返回ScanResult。sha256_pre 为 C++ 核心预计算的哈希（加速）。"""
        name = os.path.basename(path)'''

if old_sig in c:
    c = c.replace(old_sig, new_sig, 1)
    print("1. scan_file 签名已修改")
else:
    print("1. 未找到 scan_file 签名，跳过")

# 修改哈希计算部分：优先使用预计算哈希
old_hash = '''        # 哈希：快速模式只对可疑候选算哈希
        sha256 = ""
        if self.hash_all or interesting:
            limit = self.max_hash_size if self.hash_all else 20 * 1024 * 1024
            sha256 = self._cached_hash(path, size, limit)'''

new_hash = '''        # 哈希：优先使用 C++ 核心预计算哈希（跳过 Python 重复计算）
        sha256 = ""
        if sha256_pre:
            sha256 = sha256_pre
        elif self.hash_all or interesting:
            limit = self.max_hash_size if self.hash_all else 20 * 1024 * 1024
            sha256 = self._cached_hash(path, size, limit)'''

if old_hash in c:
    c = c.replace(old_hash, new_hash, 1)
    print("2. 哈希计算优先使用预计算哈希完成")
else:
    print("2. 未找到哈希计算代码，跳过")

with open('engine.py', 'w', encoding='utf-8') as f:
    f.write(c)

print("\nengine.py 修改完成")
