# -*- coding: utf-8 -*-
"""6.4.1 冒烟：版本号 / 首条历史 / 清单 / 产物 / 删除 AI 聊天 / 官网 / 打包"""
import io, json, os, sys

DG = r"F:\桌面保护\desktopguard"
ok = 0
bad = []

def chk(name, cond):
    global ok
    if cond:
        ok += 1
        print("  [PASS]", name)
    else:
        bad.append(name)
        print("  [FAIL]", name)

main = io.open(os.path.join(DG, "main.py"), encoding="utf-8").read()
chk("APP_VERSION=6.4.1", 'APP_VERSION = "6.4.1"' in main)
chk("VERSION_LIST 含 6.4.1", "'6.4.1'" in main)
chk("VERSION_HISTORY 首条 6.4.1", main.index("VERSION_HISTORY = [('6.4.1'") < main.index("('6.4.0', '6.3.0'"))
# 删除 AI 聊天验证（剥离 VERSION_HISTORY 历史记录块再查，历史正文允许含这些词）
vi = main.index("VERSION_HISTORY = [")
ve = main.index("])", vi) + 2
body = main[:vi] + main[ve:]
for m in ["_open_ai_chat", "_ai_exec_action"]:
    chk("main 已删除 " + m, ("def " + m) not in body)
chk("main 无 DG_ACTION 提示注入", "[DG_ACTION]" not in body)
chk("main 托盘无 打开 AI 聊天", "打开 AI 聊天" not in body)
chk("main 工具页无 AI 助手卡片标题", "AI 助手" not in body)
# 保留 AI 实时辅助
for m in ["_ai_analyze_batch", "ai_max_analyze", "ai_done"]:
    chk("main 保留 " + m, m in main)

sd = io.open(os.path.join(DG, "selfdefense.py"), encoding="utf-8").read()
chk("selfdefense APP_VERSION=6.4.1", 'APP_VERSION = "6.4.1"' in sd)

sys.path.insert(0, DG)
import selfdefense as sdmod
man = json.load(io.open(sdmod.MANIFEST, encoding="utf-8"))
chk("防篡改清单 version=6.4.1", man.get("version") == "6.4.1")

vj = json.load(io.open(os.path.join(DG, "version.json"), encoding="utf-8"))
chk("根 version.json=6.4.1", vj.get("version") == "6.4.1")

wj = json.load(io.open(os.path.join(DG, "官网", "version.json"), encoding="utf-8"))
pj = json.load(io.open(os.path.join(DG, "官网", "publish", "version.json"), encoding="utf-8"))
chk("官网 version.json=6.4.1", wj.get("version") == "6.4.1")
chk("publish version.json=6.4.1", pj.get("version") == "6.4.1")
chk("官网 version.json pkg=DG-Source_6.4.1.zip", wj.get("pkg") == "DG-Source_6.4.1.zip")

sz = os.path.join(DG, "官网", "DG-Source_6.4.1.zip")
chk("官网 DG-Source_6.4.1.zip 存在", os.path.exists(sz))
zp = os.path.join(DG, "官网", "DG-Security_6.4.1.zip")
chk("官网 DG-Security_6.4.1.zip 存在", os.path.exists(zp))
zold = [x for x in os.listdir(os.path.join(DG, "官网")) if x.startswith("DG-Security_") and x.endswith(".zip") and x != "DG-Security_6.4.1.zip"]
chk("官网无旧版 DG-Security zip", not zold)
sold = [x for x in os.listdir(os.path.join(DG, "官网")) if x.startswith("DG-Source_") and x.endswith(".zip") and x != "DG-Source_6.4.1.zip"]
chk("官网无旧版 DG-Source zip", not sold)

exe = os.path.join(DG, "dist", "DG安全", "DG安全.exe")
chk("dist DG安全.exe 存在", os.path.exists(exe))
txt = io.open(os.path.join(DG, "dist", "DG安全", "_internal", "使用说明.txt"), encoding="utf-8").read()
chk("dist 使用说明 6.4.1", "6.4.1 便携版" in txt and "6.4.0 便携版" not in txt)
chk("dist 使用说明含免责声明", "不可将其用于主力杀毒软件" in txt)

vm = json.load(io.open(os.path.join(DG, "versions", "6.4.1", "manifest.json"), encoding="utf-8"))
chk("快照 6.4.1 manifest", vm.get("version") == "6.4.1" and len(vm.get("files", [])) > 100)

h = io.open(os.path.join(DG, "官网", "DG安全官网.html"), encoding="utf-8").read()
chk("官网 HTML 含 6.4.1 当前版节点", "当前版</span>移除 AI 助手聊天" in h)
chk("官网 HTML 含 6.4.0 已发布节点", "已发布</span>自启动监控增强" in h)
chk("官网 HTML zip 链接 6.4.1", "DG-Security_6.4.1.zip" in h)
chk("官网 HTML cta 当前版本 6.4.1", "当前版本 6.4.1" in h)
hp = io.open(os.path.join(DG, "官网", "publish", "index.html"), encoding="utf-8").read()
chk("publish/index.html 含 6.4.1 节点", "当前版</span>移除 AI 助手聊天" in hp and "DG-Security_6.4.1.zip" in hp)

print("----")
print("冒烟结果: %d/%d 通过" % (ok, ok + len(bad)))
if bad:
    print("未通过:", bad)
    sys.exit(1)
