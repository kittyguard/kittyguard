# -*- coding: utf-8 -*-
"""DG 4.2.0 补丁：受保护文件功能（备份+防删+手动还原）
修改 main.py：版本号升级、工具窗口入口、管理窗口方法、后台检查。
"""
import io, sys, shutil, time, os

SRC = r"F:\桌面保护\desktopguard\main.py"
BAK = r"F:\桌面保护\desktopguard\main.py.bak_420"

with io.open(SRC, "r", encoding="utf-8") as f:
    code = f.read()

orig = code
ops = []

def rep(old, new, tag):
    global code
    if old not in code:
        print("[FAIL] %s: pattern not found" % tag)
        ops.append(False)
        return
    if code.count(old) > 1:
        print("[WARN] %s: multiple occurrences, replacing first" % tag)
    code = code.replace(old, new, 1)
    ops.append(True)
    print("[OK] %s" % tag)

# 1) 版本号 4.1.0 -> 4.2.0
rep('APP_VERSION = "4.1.0"',
    'APP_VERSION = "4.2.0"',
    "APP_VERSION")

# 2) VERSION_LIST 追加 4.2.0
rep("'3.8.0', '4.0.0', '4.1.0']",
    "'3.8.0', '4.0.0', '4.1.0', '4.2.0']",
    "VERSION_LIST")

# 3) VERSION_HISTORY 加 4.2.0 条目（插在 4.1.0 之前）
old_vh = '    ("4.1.0", "内容更新（下载目录·远程自动更新·快速查杀极速初始化）'
new_vh = ('    ("4.2.0", "内容更新（受保护文件·防删备份·手动还原）：1.新增「受保护文件」功能——工具页→常用工具→受保护文件：可手动添加任意重要文件（如证件PDF/作业资料），添加时自动备份一份到 DG 程序目录 protected_backup（独立副本，不依赖原文件）；2.后台每 30 秒自动检查受保护文件是否被删/被移走，发现丢失立即弹出提示并支持一键从备份手动还原（原路径若有同名新文件会自动改名保留，不覆盖）；3.受保护列表持久化到数据库，重启不丢失；4.移除保护只解除监控，备份文件仍保留在 protected_backup 供随时找回"),\n'
            '    ("4.1.0", "内容更新（下载目录·远程自动更新·快速查杀极速初始化）')
rep(old_vh, new_vh, "VERSION_HISTORY")

# 4) 工具窗口「常用工具」区：row2 之后加 row3 受保护文件入口
old_tool = '''        ttk.Button(row2, text="导出扫描报告", command=self._export_report).pack(side="left")
        ttk.Button(row2, text="打开程序目录", command=_open_program_dir).pack(side="left", padx=(8, 0))
        ttk.Button(row2, text="完整设置", command=self._open_settings).pack(side="left", padx=(8, 0))
'''
new_tool = '''        ttk.Button(row2, text="导出扫描报告", command=self._export_report).pack(side="left")
        ttk.Button(row2, text="打开程序目录", command=_open_program_dir).pack(side="left", padx=(8, 0))
        ttk.Button(row2, text="完整设置", command=self._open_settings).pack(side="left", padx=(8, 0))
        row3 = tk.Frame(box, bg=C_CARD2)
        row3.pack(fill="x", pady=(4, 2))
        ttk.Button(row3, text="受保护文件（防删备份）", style="Accent.TButton", command=self._open_protected_window).pack(side="left")
'''
rep(old_tool, new_tool, "tools window button")

# 5) 在 _open_program_dir_tool 方法定义之后插入 _open_protected_window 方法
anchor = '''    def _open_program_dir_tool(self):
'''
new_method = '''    def _open_program_dir_tool(self):
'''
# 找到 _open_program_dir_tool 方法体结尾：下一个顶格 def 之前的行。用占位方式插入到 _on_mode_change 之前。
# 更稳妥：在 "    def _on_mode_change(self):" 之前插入整个新方法。
anchor2 = "    def _on_mode_change(self):\n"
protected_method = '''    def _open_protected_window(self):
        """受保护文件管理窗口（4.2.0）：列表 / 添加 / 还原 / 移除。"""
        if getattr(self, "_prot_win", None) is not None and self._prot_win.winfo_exists():
            self._prot_win.lift()
            return
        try:
            import database as _db
        except Exception as _e:
            self._append_log("受保护文件：数据库模块加载失败 %s" % _e)
            return
        win = tk.Toplevel(self.root)
        win.title("受保护文件")
        win.configure(bg=C_BG)
        win.geometry("760x480")
        win.transient(self.root)
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        self._prot_win = win

        top = tk.Frame(win, bg=C_BG, padx=14, pady=10)
        top.pack(fill="x")
        tk.Label(top, text="受保护文件（自动备份，丢失可手动还原）", bg=C_BG, fg=C_TEXT,
                 font=("Microsoft YaHei UI", 12, "bold")).pack(side="left")
        ttk.Button(top, text="＋ 添加文件", style="Accent.TButton",
                   command=lambda: self._prot_add_file(_db, refresh_list)).pack(side="right")

        body = tk.Frame(win, bg=C_BG, padx=14)
        body.pack(fill="both", expand=True)
        cols = ("path", "size", "added", "status")
        tree = ttk.Treeview(body, columns=cols, show="headings", height=14)
        tree.heading("path", text="文件路径")
        tree.heading("size", text="大小")
        tree.heading("added", text="添加时间")
        tree.heading("status", text="状态")
        tree.column("path", width=400, anchor="w")
        tree.column("size", width=90, anchor="center")
        tree.column("added", width=140, anchor="center")
        tree.column("status", width=90, anchor="center")
        vsb = ttk.Scrollbar(body, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        btns = tk.Frame(win, bg=C_BG, padx=14, pady=8)
        btns.pack(fill="x")
        def _do_restore():
            sel = tree.selection()
            if not sel:
                self._append_log("受保护文件：请先选中要还原的文件")
                return
            pid = tree.set(sel[0], "path").split("|")[0]
            try:
                pid = int(pid)
            except Exception:
                for item in _rows:
                    if str(item["id"]) == pid or tree.set(sel[0], "path").endswith(item["file_path"] or ""):
                        pid = item["id"]
                        break
            ok, msg = _db.restore_protected_file(pid)
            self._append_log("受保护文件还原：%s" % msg)
            if ok:
                self._show_notice("还原成功", "文件已恢复到：\n%s" % msg)
                refresh_list()
            else:
                self._show_notice("还原失败", msg)
        def _do_remove():
            sel = tree.selection()
            if not sel:
                self._append_log("受保护文件：请先选中要移除的文件")
                return
            pid = None
            for item in _rows:
                if str(item["id"]) == tree.set(sel[0], "path").split("|")[0] or \
                   (item["file_path"] or "").endswith(tree.set(sel[0], "path").split("|")[-1]):
                    pid = item["id"]
                    break
            if pid is None:
                try:
                    pid = int(tree.set(sel[0], "path").split("|")[0])
                except Exception:
                    pid = _rows[0]["id"] if _rows else None
            ok, msg = _db.remove_protected_file(pid)
            self._append_log("受保护文件移除：%s" % msg)
            refresh_list()
        ttk.Button(btns, text="还原选中", style="Accent.TButton", command=_do_restore).pack(side="left")
        ttk.Button(btns, text="移除保护", command=_do_remove).pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="打开备份目录", command=lambda: _open_prot_backup()).pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="刷新", command=refresh_list).pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="关闭", command=win.destroy).pack(side="right")

        _rows = []
        def refresh_list():
            nonlocal _rows
            try:
                _rows = _db.get_protected_files()
            except Exception as _e:
                _rows = []
                self._append_log("受保护文件：读取列表失败 %s" % _e)
            tree.delete(*tree.get_children())
            if not _rows:
                tree.insert("", "end", values=("（暂无受保护文件，点右上角添加）", "", "", ""))
                return
            for r in _rows:
                st = "正常" if r.get("exists") else "丢失！"
                sz = ""
                try:
                    sz = "%.1f KB" % (r["file_size"] / 1024.0)
                except Exception:
                    pass
                ts = time.strftime("%m-%d %H:%M", time.localtime(r.get("added_at") or 0))
                tree.insert("", "end",
                            values=("%s|%s" % (r["id"], r["file_path"] or ""), sz, ts, st),
                            tags=("missing",) if not r.get("exists") else ())
            tree.tag_configure("missing", foreground="#ff5252")

        def _open_prot_backup():
            try:
                bdir = _db.PROTECTED_BACKUP_DIR
                os.makedirs(bdir, exist_ok=True)
                import subprocess as _sp
                _sp.Popen(["explorer", bdir], creationflags=0x08000000)
            except Exception:
                pass

        refresh_list()

    def _prot_add_file(self, _db, refresh_cb):
        """选择文件加入受保护列表。"""
        try:
            from tkinter import filedialog
            p = filedialog.askopenfilename(title="选择要保护的文件",
                                           parent=getattr(self, "_prot_win", None))
        except Exception:
            p = ""
        if not p:
            return
        ok, msg = _db.add_protected_file(p)
        self._append_log("受保护文件添加：%s -> %s" % (p, msg))
        if not ok:
            self._show_notice("添加失败", msg)
        else:
            self._show_notice("已保护", "文件已备份并加入保护：\n%s\n\n备份位置：\n%s" % (p, msg))
        try:
            refresh_cb()
        except Exception:
            pass

    def _check_protected_loop(self):
        """后台检查受保护文件是否丢失（每 30 秒一次，发现丢失弹提示）。"""
        now = time.time()
        if now - getattr(self, "_last_prot_check", 0) < 30:
            return
        self._last_prot_check = now
        try:
            import database as _db
            missing = _db.check_protected_files()
        except Exception:
            return
        if missing and not getattr(self, "_prot_alert_shown", False):
            self._prot_alert_shown = True
            try:
                self._show_notice("受保护文件丢失！",
                                  "检测到 %d 个受保护文件被删除或移走：\n\n%s\n\n请到 工具→受保护文件 中一键手动还原。" % (
                                      len(missing),
                                      "\n".join(m.get("file_path") or "?" for m in missing[:5])
                                  ))
            except Exception:
                pass
        elif not missing:
            self._prot_alert_shown = False

    def _on_mode_change(self):
'''
if anchor2 not in code:
    print("[FAIL] anchor _on_mode_change not found")
else:
    code = code.replace(anchor2, protected_method, 1)
    print("[OK] insert _open_protected_window / _prot_add_file / _check_protected_loop")

# 6) _poll_queue 末尾接入受保护文件检查
old_poll = """        if self.scanning:
            self._schedule_refresh()
        self.root.after(120, self._poll_queue)"""
new_poll = """        if self.scanning:
            self._schedule_refresh()
        self._check_protected_loop()
        self.root.after(120, self._poll_queue)"""
rep(old_poll, new_poll, "poll queue hook")

if all(ops) or True:
    shutil.copyfile(SRC, BAK)
    with io.open(SRC, "w", encoding="utf-8", newline="") as f:
        f.write(code)
    print("BACKUP:", BAK)
    print("DONE. changed bytes:", len(orig) - len(code))
