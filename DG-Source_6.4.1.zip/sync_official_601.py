# -*- coding: utf-8 -*-
"""6.0.1 官网同步：dist\\DG安全 → 官网\\DG-Security_6.0.1.zip + sha256 + version.json + publish 镜像 + 清理旧包"""
import os, io, json, time, zipfile, hashlib, shutil

DG = r"F:\桌面保护\desktopguard"
SRC = os.path.join(DG, "dist", "DG安全")
ZIP = os.path.join(DG, "官网", "DG-Security_6.0.1.zip")
VER = "6.0.1"

def make_zip(src, dst):
    if os.path.exists(dst):
        os.remove(dst)
    n = 0
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for root, dirs, files in os.walk(src):
            for fn in files:
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, src)
                z.write(p, rel)
                n += 1
    return n

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

print("[1] 压缩 dist/DG安全 → zip ...")
n = make_zip(SRC, ZIP)
print("    文件数=%d 大小=%.1fMB" % (n, os.path.getsize(ZIP) / 1024 / 1024))
h = sha256(ZIP)
print("[2] sha256 =", h)

notes = {
    "latest_version": VER,
    "version": VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "pkg": "DG-Security_6.0.1.zip",
    "sha256": h,
    "release_notes": "6.0.1 内容更新：行为链血缘增强（父进程是谁一目了然）+ 勒索守护增强（备份占用统计·被冻结进程事后管理）。",
    "features": [
        "行为链血缘增强：行为链时间线详情显示父进程可执行路径（谁启动了谁一目了然）",
        "勒索备份占用统计：备份恢复窗口标题实时显示保护区当前占用",
        "被冻结进程事后管理：备份恢复窗口可对仍被冻结的进程一键恢复/终止/信任",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "官网", "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[3] 官网 version.json 已更新为", VER)

# publish 镜像同步（供 GitHub Pages 推送）
pub = os.path.join(DG, "官网", "publish")
os.makedirs(pub, exist_ok=True)
shutil.copy2(os.path.join(DG, "官网", "DG安全官网.html"), os.path.join(pub, "index.html"))
shutil.copy2(ZIP, os.path.join(pub, "DG-Security_6.0.1.zip"))
shutil.copy2(os.path.join(DG, "官网", "version.json"), os.path.join(pub, "version.json"))
for fn in os.listdir(pub):
    if fn.startswith("DG-Security_") and fn != "DG-Security_6.0.1.zip":
        os.remove(os.path.join(pub, fn))
        print("    publish 清理旧包", fn)
print("[4] publish 镜像已同步（index.html + 新zip + version.json）")

old = os.path.join(DG, "官网", "DG-Security_6.0.0.zip")
if os.path.exists(old):
    os.remove(old)
    print("[5] 已删除旧分发包 DG-Security_6.0.0.zip（官网只放最新版）")
print("[OK] 6.0.1 官网同步完成")
