# -*- coding: utf-8 -*-
"""
DesktopGuard P0-2 沙箱自动化（自研 Native 沙盒优先）
====================================================
一键把可疑样本丢进自研 C++ 沙盒（sandbox_runner.exe）自动运行并回收行为报告：
  - 受限令牌 + Job Object（进程数/内存/CPU 时间/KILL_ON_CLOSE + UI 限制）
  - 行为监控：文件创建/修改（ReadDirectoryChangesW + 快照兜底）、
    子进程创建（Job 枚举）、网络连接（IPHLPAPI）、注册表自启项（基线对比）
  - 系统目录（System32/Program Files/启动目录）可执行文件投放审计
  - 工作目录隔离：output 目录设 Low 完整性标签 + Everyone 可写（样本可正常写）

Windows Sandbox 已在本机确认无法启用（DISM 14003，精简系统），
因此 native 沙盒是默认路径；Windows Sandbox 检测保留为 fallback 提示。

安全红线：
  - 样本复制进隔离工作目录运行，不触碰宿主原文件
  - 工作目录位于 DATA_DIR/sandbox_work 下，用完可 cleanup 删除
  - 仅使用标准库；纯用户态，不修改系统设置
"""

from paths import DATA_DIR
import os
import json
import time
import shutil
import subprocess

from logger import app_logger, security_logger

# CREATE_NO_WINDOW，避免调用外部命令时弹出黑窗
CREATE_NO_WINDOW = 0x08000000

# 自研 native 沙盒可执行文件（与 main.py 同目录）
NATIVE_SANDBOX_EXE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "sandbox_runner.exe")

# Windows Sandbox 可执行文件（fallback 检测用）
SANDBOX_EXE = r"C:\Windows\System32\WindowsSandbox.exe"

# 沙箱工作根目录：DATA_DIR/sandbox_work/
SANDBOX_ROOT = os.path.join(DATA_DIR, "sandbox_work")


# ---------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------
def _empty_behavior() -> dict:
    """返回空行为结构。"""
    return {
        "files_created": [],
        "files_modified": [],
        "registry_writes": [],
        "network_connections": [],
        "processes_created": [],
    }


def get_behavior_report(work_dir: str) -> dict:
    """读取并解析 output\\behavior_log.json，返回结构化行为报告。"""
    report = _empty_behavior()
    log_path = os.path.join(work_dir, "output", "behavior_log.json")
    if not os.path.isfile(log_path):
        return report
    try:
        with open(log_path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        for key in report:
            if isinstance(data.get(key), list):
                report[key] = data[key]
        # 附带沙盒元信息（若有）
        for meta_key in ("sandbox", "token"):
            if data.get(meta_key):
                report[meta_key] = data[meta_key]
    except Exception as e:  # noqa: BLE001
        report["parse_error"] = f"{type(e).__name__}: {e}"
    return report


def cleanup(work_dir: str):
    """清理沙箱工作目录（忽略占用错误）。"""
    try:
        if work_dir and os.path.isdir(work_dir):
            shutil.rmtree(work_dir, ignore_errors=True)
            app_logger.info(f"[sandbox] 已清理工作目录: {work_dir}")
        return True
    except Exception as e:  # noqa: BLE001
        app_logger.error(f"[sandbox] 清理工作目录失败: {work_dir} | {e}", exc_info=True)
        return False


def _windows_sandbox_available() -> bool:
    """检测 Windows Sandbox 是否可用（仅作 fallback）。"""
    try:
        from system_check import check_windows_sandbox
        info = check_windows_sandbox()
        return bool(info.get("available"))
    except Exception:  # noqa: BLE001
        return os.path.isfile(SANDBOX_EXE)


# ---------------------------------------------------------------------
# 对外接口
# ---------------------------------------------------------------------
def is_sandbox_available() -> bool:
    """沙盒是否可用：自研 native 沙盒优先，Windows Sandbox 兜底。"""
    if os.path.isfile(NATIVE_SANDBOX_EXE):
        return True
    return _windows_sandbox_available()


def run_sample_in_sandbox(sample_path: str, timeout: int = 120) -> dict:
    """
    一键把样本丢进沙盒自动运行并回收行为报告（native 沙盒优先）。

    :param sample_path: 宿主上样本文件的绝对路径
    :param timeout: 样本观察时长（秒），最长不超过 300
    :return: 见模块文档头部的返回格式
    """
    start_ts = time.time()
    result = {
        "status": "failed",
        "sample_name": os.path.basename(sample_path) if sample_path else "",
        "work_dir": "",
        "behavior": _empty_behavior(),
        "duration_seconds": 0,
        "error": "",
    }

    try:
        # ---- 前置检查 ----
        if not sample_path or not os.path.isfile(sample_path):
            result["error"] = f"样本不存在: {sample_path}"
            app_logger.error(f"[sandbox] 样本不存在: {sample_path}")
            return result
        if not is_sandbox_available():
            result["error"] = "沙盒不可用（sandbox_runner.exe 缺失，Windows Sandbox 也未启用）"
            app_logger.error("[sandbox] 沙盒不可用，中止")
            return result

        # ---- 准备工作目录 ----
        stamp = time.strftime("%Y%m%d_%H%M%S")
        work_dir = os.path.join(SANDBOX_ROOT, stamp)
        input_dir = os.path.join(work_dir, "input")
        output_dir = os.path.join(work_dir, "output")
        os.makedirs(input_dir, exist_ok=True)
        os.makedirs(output_dir, exist_ok=True)
        result["work_dir"] = work_dir

        # ---- 复制样本到 input（保留原文件名，保证可执行扩展名）----
        safe_name = os.path.basename(sample_path)
        dst_sample = os.path.join(input_dir, safe_name)
        shutil.copy2(sample_path, dst_sample)
        security_logger.warning(f"[沙箱投递] 样本={sample_path} -> {work_dir}")

        inner_timeout = max(10, min(int(timeout), 300))

        if os.path.isfile(NATIVE_SANDBOX_EXE):
            # ================= 自研 native 沙盒 =================
            app_logger.info(f"[sandbox] 使用自研 native 沙盒运行样本，观察 {inner_timeout}s")
            proc = subprocess.run(
                [NATIVE_SANDBOX_EXE, dst_sample, work_dir, str(inner_timeout)],
                creationflags=CREATE_NO_WINDOW,
                timeout=inner_timeout + 60,
            )
            log_path = os.path.join(output_dir, "behavior_log.json")
            if proc.returncode == 0 and os.path.isfile(log_path):
                result["behavior"] = get_behavior_report(work_dir)
                result["status"] = "completed"
                app_logger.info(
                    f"[sandbox] 行为回收完成: files={len(result['behavior'].get('files_created', []))}"
                    f" procs={len(result['behavior'].get('processes_created', []))}"
                    f" net={len(result['behavior'].get('network_connections', []))}"
                )
            else:
                result["status"] = "failed"
                result["error"] = (f"沙盒运行异常（exit={proc.returncode}），"
                                   "未生成行为日志；请查看 work_dir/output/sandbox_log.txt")
                app_logger.error(f"[sandbox] native 沙盒运行异常: exit={proc.returncode} | {work_dir}")
        else:
            # ================= Windows Sandbox fallback =================
            result["error"] = "Windows Sandbox 在本机不可用，且缺少 sandbox_runner.exe"
            result["status"] = "failed"
            app_logger.error("[sandbox] 无可用沙盒引擎")

    except subprocess.TimeoutExpired:
        result["status"] = "timeout"
        result["error"] = f"沙盒运行超过 {timeout + 60}s 被强制结束"
        app_logger.error(f"[sandbox] 沙盒运行超时: {work_dir}")
    except Exception as e:  # noqa: BLE001
        result["status"] = "failed"
        result["error"] = f"{type(e).__name__}: {e}"
        app_logger.error(f"[sandbox] 运行失败: {e}", exc_info=True)
    finally:
        result["duration_seconds"] = round(time.time() - start_ts, 1)
    return result


# =====================================================================
# 自测块：只做检测与干跑，不实际启动沙盒
# =====================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("DesktopGuard 沙箱自动化 自测")
    print("=" * 60)
    print(f"自研 native 沙盒: {os.path.isfile(NATIVE_SANDBOX_EXE)}")
    print(f"Windows Sandbox exe 存在: {os.path.isfile(SANDBOX_EXE)}")
    print(f"沙盒可用: {is_sandbox_available()}")
    print(f"工作根目录: {SANDBOX_ROOT}")
