# -*- coding: utf-8 -*-
"""
DG 系统托盘模块（纯 ctypes 实现，无第三方依赖）
================================================
- Shell_NotifyIcon 创建托盘图标（用 shield.ico，兜底系统盾牌图标）
- 隐藏消息窗口 + 独立消息循环线程
- 事件通过 queue 交给 tkinter 主线程（after 轮询）
- 支持气泡提示 / 左键双击显示 / 右键菜单坐标
"""
import ctypes
import os
import queue
import threading
from ctypes import wintypes

WM_USER = 0x0400
WM_TRAYICON = WM_USER + 20
NIM_ADD = 0
NIM_MODIFY = 1
NIM_DELETE = 2
NIF_MESSAGE = 0x00000001
NIF_ICON = 0x00000002
NIF_TIP = 0x00000004
NIF_INFO = 0x00000010
WM_LBUTTONUP = 0x0202
WM_LBUTTONDBLCLK = 0x0203
WM_RBUTTONUP = 0x0205
IDI_SHIELD = 32518
IMAGE_ICON = 1
LR_LOADFROMFILE = 0x00000010


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("hWnd", wintypes.HWND),
        ("uID", wintypes.UINT),
        ("uFlags", wintypes.UINT),
        ("uCallbackMessage", wintypes.UINT),
        ("hIcon", wintypes.HANDLE),
        ("szTip", wintypes.WCHAR * 128),
        ("dwState", wintypes.DWORD),
        ("dwStateMask", wintypes.DWORD),
        ("szInfo", wintypes.WCHAR * 256),
        ("uVersion", wintypes.UINT),
        ("szInfoTitle", wintypes.WCHAR * 64),
        ("dwInfoFlags", wintypes.DWORD),
        ("guidItem", ctypes.c_byte * 16),
        ("hBalloonIcon", wintypes.HANDLE),
    ]


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT),
        ("style", wintypes.UINT),
        ("lpfnWndProc", ctypes.c_void_p),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HANDLE),
        ("hIcon", wintypes.HANDLE),
        ("hCursor", wintypes.HANDLE),
        ("hbrBackground", wintypes.HANDLE),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", wintypes.HANDLE),
    ]


class TrayIcon:
    """系统托盘图标。事件类型：("show",) 左键双击/单击、"menu",x,y 右键菜单。"""

    def __init__(self, icon_path=None, tooltip="DG 安全"):
        self.events = queue.Queue()
        self._nid = None
        self._hWnd = None
        self._wndproc_ref = None
        self._thread = None
        self._icon_path = icon_path or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "shield.ico")
        self._tooltip = (tooltip or "DG 安全")[:127]
        self._active = False

    # ---------------- Win32 内部 ----------------
    def _register_window_class(self):
        user32 = ctypes.windll.user32
        user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT,
                                          wintypes.WPARAM, wintypes.LPARAM]
        user32.DefWindowProcW.restype = ctypes.c_longlong
        WNDPROC = ctypes.WINFUNCTYPE(
            ctypes.c_longlong, wintypes.HWND, wintypes.UINT,
            wintypes.WPARAM, wintypes.LPARAM)

        def wnd_proc(hWnd, uMsg, wParam, lParam):
            if uMsg == WM_TRAYICON:
                if lParam == WM_LBUTTONDBLCLK or lParam == WM_LBUTTONUP:
                    try:
                        self.events.put(("show",))
                    except Exception:
                        pass
                elif lParam == WM_RBUTTONUP:
                    try:
                        pt = wintypes.POINT()
                        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
                        self.events.put(("menu", int(pt.x), int(pt.y)))
                    except Exception:
                        pass
            return user32.DefWindowProcW(hWnd, uMsg, wParam, lParam)

        self._wndproc_ref = WNDPROC(wnd_proc)  # 保持引用防 GC
        hInst = ctypes.windll.kernel32.GetModuleHandleW(None)
        cls_name = "DGTrayMsgWindow"
        wc = WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(wc)
        wc.lpfnWndProc = ctypes.cast(self._wndproc_ref, ctypes.c_void_p)
        wc.hInstance = hInst
        wc.lpszClassName = cls_name
        if not user32.RegisterClassExW(ctypes.byref(wc)):
            return None
        return user32.CreateWindowExW(0, cls_name, "DGTray", 0, 0, 0, 0, 0,
                                      None, None, hInst, None)

    def _load_icon(self):
        user32 = ctypes.windll.user32
        try:
            if self._icon_path and os.path.exists(self._icon_path):
                h = user32.LoadImageW(None, self._icon_path, IMAGE_ICON, 32, 32,
                                      LR_LOADFROMFILE)
                if h:
                    return h
        except Exception:
            pass
        return user32.LoadIconW(None, IDI_SHIELD)

    def _message_loop(self):
        user32 = ctypes.windll.user32
        msg = wintypes.MSG()
        while self._active:
            r = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if r == 0:  # WM_QUIT
                break
            if r == -1:
                break
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))

    # ---------------- 公共 API ----------------
    def start(self):
        """创建托盘图标并启动消息循环线程。"""
        if self._active:
            return True
        hwnd = self._register_window_class()
        if not hwnd:
            return False
        self._hWnd = hwnd
        hIcon = self._load_icon()
        nid = NOTIFYICONDATAW()
        nid.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        nid.hWnd = hwnd
        nid.uID = 1
        nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
        nid.uCallbackMessage = WM_TRAYICON
        nid.hIcon = hIcon
        nid.szTip = self._tooltip
        ok = ctypes.windll.shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid))
        if not ok:
            return False
        self._nid = nid
        self._active = True
        self._thread = threading.Thread(target=self._message_loop,
                                        daemon=True, name="DG-TRAY")
        self._thread.start()
        return True

    def set_tooltip(self, tooltip):
        try:
            if self._nid is None:
                return
            self._nid.uFlags = NIF_TIP
            self._nid.szTip = (tooltip or "DG 安全")[:127]
            ctypes.windll.shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(self._nid))
        except Exception:
            pass

    def show_balloon(self, title, text, timeout=4):
        """气泡提示。"""
        try:
            if self._nid is None:
                return
            self._nid.uFlags = NIF_INFO
            self._nid.szInfoTitle = (title or "")[:63]
            self._nid.szInfo = (text or "")[:255]
            self._nid.dwInfoFlags = 1
            ctypes.windll.shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(self._nid))
        except Exception:
            pass

    def stop(self):
        """删除托盘图标并退出消息循环。"""
        self._active = False
        try:
            if self._nid is not None:
                ctypes.windll.shell32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(self._nid))
                self._nid = None
        except Exception:
            pass
        try:
            if self._hWnd:
                ctypes.windll.user32.PostMessageW(self._hWnd, 0x0012, 0, 0)  # WM_QUIT
        except Exception:
            pass
