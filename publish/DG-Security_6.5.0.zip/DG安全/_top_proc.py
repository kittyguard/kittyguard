# -*- coding: utf-8 -*-
import subprocess
r = subprocess.run(["tasklist", "/fo", "csv", "/nh"], capture_output=True, text=True, encoding="gbk", errors="ignore")
lines = r.stdout.splitlines()
print("lines:", len(lines))
# 按内存排序
import re
rows = []
for line in lines:
    parts = line.split('","')
    if len(parts) >= 5:
        try:
            name = parts[0].strip('"')
            mems = parts[4].strip('"').replace(',', '')
            mem = int(mems) if mems.isdigit() else 0
            rows.append((name, mem))
        except Exception:
            pass
rows.sort(key=lambda x: -x[1])
for name, mem in rows[:14]:
    print("%-30s %d MB" % (name, mem // 1024))
