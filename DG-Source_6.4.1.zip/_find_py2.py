# -*- coding: utf-8 -*-
import os, subprocess, sys

print("sys.executable:", sys.executable)
print("sys.version:", sys.version)

# py launcher 可用版本
try:
    out = subprocess.run(["py", "-0p"], capture_output=True, text=True, timeout=20)
    print("py -0p:", out.stdout, out.stderr)
except Exception as e:
    print("py -0p err:", e)

# 注册表已安装 python
try:
    import winreg
    for hive, path in [(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Python\PythonCore"),
                        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Python\PythonCore"),
                        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Python\PythonCore")]:
        try:
            k = winreg.OpenKey(hive, path)
            i = 0
            while True:
                try:
                    name = winreg.EnumKey(k, i)
                    k2 = winreg.OpenKey(hive, path + "\\" + name + "\\InstallPath")
                    val, _ = winreg.QueryValueEx(k2, "")
                    print("REG:", hive, path, name, "->", val)
                    i += 1
                except OSError:
                    break
        except OSError:
            pass
except Exception as e:
    print("winreg err:", e)
