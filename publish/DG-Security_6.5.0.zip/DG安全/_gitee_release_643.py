# -*- coding: utf-8 -*-
"""Gitee 创建 v6.4.3 release"""
import json, urllib.request, urllib.parse

TOKEN = "964d5ca1cfc09792719272c1260170a8"
BASE = "https://gitee.com/api/v5/repos/kittyguard/kittyguard"

body_text = ("6.4.3 发行修复版（向导版三大 bug + 开机动画分离）\n"
             "1. ClamAV 病毒库更新不再依赖本机代理（相对路径多级自适应 + 国内镜像直连）\n"
             "2. 安装向导卸载零残留（退出标记 + 全进程清理 + 注册表清理 + 数据目录清理）\n"
             "3. 向导版 7 个工具全部可用（内置编译版 exe，不依赖 Python 环境）\n"
             "4. 开机自启不播动画、手动启动播动画\n"
             "5. 随包内置 ClamAV 引擎+病毒库 + YARA 引擎+内置规则，任何电脑开箱即用\n"
             "6. 全程纯用户态、零驱动、不服务化、CPU≈0")

data = urllib.parse.urlencode({
    "access_token": TOKEN,
    "tag_name": "v6.4.3",
    "target_branch": "main",
    "name": "DG 安全 6.4.3 发行修复版",
    "body": body_text,
}).encode("utf-8")
req = urllib.request.Request(BASE + "/releases", data=data, method="POST",
                             headers={"User-Agent": "kittyguard", "Content-Type": "application/x-www-form-urlencoded"})
try:
    with urllib.request.urlopen(req, timeout=60) as r:
        j = json.loads(r.read().decode("utf-8"))
        print("RELEASE_ID=", j.get("id"), "tag=", j.get("tag_name"), "html=", j.get("html_url"))
except urllib.error.HTTPError as e:
    print("HTTP", e.code, e.read().decode("utf-8", "ignore")[:500])
