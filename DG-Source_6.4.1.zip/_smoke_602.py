# -*- coding: utf-8 -*-
"""6.0.2 发布冒烟验证"""
import io, json, os, re, sys

os.chdir(r"F:\桌面保护\desktopguard")

src = io.open("main.py", encoding="utf-8").read()
m = re.search(r'APP_VERSION = "([^"]+)"', src)
print("main.py APP_VERSION =", m.group(1))

mh = re.search(r"VERSION_HISTORY = \[\('([^']+)', '([^']+)'", src)
print("VERSION_HISTORY 首条:", mh.group(1), "<-", mh.group(2))

sys.path.insert(0, ".")
import selfdefense as _sd
man = _sd.load_manifest() or {}
print("防篡改清单 version =", man.get("version"), "| py =", len(man.get("py", {})), "| cfg =", len(man.get("cfg", {})))

v = json.load(io.open("version.json", encoding="utf-8"))
print("根 version.json:", v.get("latest_version"), "| version =", v.get("version"))

ov = json.load(io.open("官网/version.json", encoding="utf-8"))
print("官网 version.json:", ov.get("latest_version"), "| version =", ov.get("version"), "| pkg =", ov.get("pkg"))

for p in ["dist/DG安全/DG安全.exe", "官网/DG-Security_6.0.2.zip", "versions/6.0.2/manifest.json",
          "官网/publish/index.html", "官网/publish/version.json", "官网/publish/DG-Security_6.0.2.zip"]:
    if os.path.exists(p):
        extra = "%.1fMB" % (os.path.getsize(p) / 1048576) if p.endswith(("zip", "exe")) else ""
        print("OK 存在:", p, extra)
    else:
        print("缺失:", p)

# 新功能代码存在性
rg_src = io.open("ransomware_guard.py", encoding="utf-8").read()
for pat, who in [("dry_run", "main.py"), ("_open_ransom_excludes_ui", "main.py"),
                 ("试运行·不冻结", "main.py"), ("dry_run", "ransomware_guard.py"),
                 ("_in_exclude", "ransomware_guard.py")]:
    print("含「%s」(%s):" % (pat, who), (pat in src) if who == "main.py" else (pat in rg_src))

# 配置默认
print("DEFAULT_CONFIG 含 dryrun/excludes:", "ransom_guard_dryrun" in src and "ransom_guard_excludes" in src)
