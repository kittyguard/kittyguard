# -*- coding: utf-8 -*-
"""发布 6.3.0：快照 + 重建防篡改清单 + version.json（自启动监控 + 扫描 IO 节流）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.3.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx", "sandbox_runner.exe",
           "dg_warden.exe", "dg_watcher_tpl.exe"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.3.0 内容更新：自启动实时监控 + 扫描 IO 节流。",
    "features": [
        "自启动实时监控：独立实时防线——每 5 秒快照对比 注册表 Run/RunOnce（HKCU+HKLM）+ 用户/全局启动文件夹，发现新增自启动项立即写入防护日志；可疑项（命令含 PowerShell/mshta/rundll32/certutil/bitsadmin 等脚本宿主或下载执行链、从 Temp/AppData/Downloads/Public 可写目录启动、双扩展名伪装）自动弹窗告警，可一键去「工具 → 启动项管理」处理；免打扰模式下静默记录不弹窗",
        "设置-实时防护新增「自启动监控」开关（默认开启），纯轮询轻量线程、CPU≈0、无需驱动",
        "扫描 IO 节流：扫描线程降优先级之外新增进程级 IO 优先级 VERY_LOW（NtSetInformationProcess IoPriority）——全盘/大目录扫描时 DG 的磁盘读写请求自动排到其他程序之后，鼠标/系统/游戏不再被扫描 IO 拖到一卡一卡，扫描结束进程退出即恢复",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
