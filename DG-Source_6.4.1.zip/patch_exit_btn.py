# -*- coding: utf-8 -*-
"""放大悬浮窗 ✕ 关闭按钮点击区"""
import io
import ast

p = r'F:\桌面保护\desktopguard\perf_overlay.py'
src = io.open(p, encoding='utf-8').read()

old = '        btn_exit = tk.Label(head, text="✕", bg=BG, fg=DIM, font=("Segoe UI", 10),\n                            cursor="hand2")\n        btn_exit.pack(side="right")'
new = ('        btn_exit = tk.Label(head, text="✕", bg=BG, fg="#ff8080",\n'
       '                            font=("Segoe UI", 12, "bold"), cursor="hand2",\n'
       '                            padx=8, pady=2)\n'
       '        btn_exit.pack(side="right")')

assert src.count(old) == 1, 'anchor not found'
src = src.replace(old, new)
io.open(p, 'w', encoding='utf-8').write(src)
ast.parse(src)
print('patched + syntax OK')
