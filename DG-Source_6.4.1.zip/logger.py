# -*- coding: utf-8 -*-
"""
DesktopGuard 日志系统
======================
三类日志：
  - app.log      程序运行、异常、启动关闭
  - scan.log     扫描过程、文件统计、耗时
  - security.log 删除、隔离、恢复、白名单变更等安全操作（审计日志）

使用标准库 logging，自动轮转，单文件最大 5MB，保留 3 个备份。
"""

from paths import DATA_DIR
import os
import logging
from logging.handlers import RotatingFileHandler

# 日志目录：用户目录下 .desktopguard/logs/
LOG_DIR = os.path.join(DATA_DIR, "logs")
try:
    os.makedirs(LOG_DIR, exist_ok=True)
except Exception:
    pass

# 日志格式
LOG_FORMAT = "%(asctime)s [%(levelname)s] %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# 单文件最大 5MB，保留 3 个备份
MAX_BYTES = 5 * 1024 * 1024
BACKUP_COUNT = 3


def _get_logger(name: str, filename: str, level=logging.INFO) -> logging.Logger:
    """创建或获取一个 logger，配置文件输出。"""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # 已配置，避免重复添加 handler

    logger.setLevel(level)
    filepath = os.path.join(LOG_DIR, filename)
    handler = RotatingFileHandler(
        filepath, maxBytes=MAX_BYTES, backupCount=BACKUP_COUNT,
        encoding="utf-8"
    )
    handler.setFormatter(logging.Formatter(LOG_FORMAT, DATE_FORMAT))
    logger.addHandler(handler)
    logger.propagate = False  # 不传播到根 logger，避免控制台输出
    return logger


# 三个 logger 实例
app_logger = _get_logger("dg_app", "app.log")
scan_logger = _get_logger("dg_scan", "scan.log")
security_logger = _get_logger("dg_security", "security.log")


# ===== 便捷函数 =====

def app_info(msg: str):
    """程序运行信息。"""
    app_logger.info(msg)

def app_warning(msg: str):
    """程序警告。"""
    app_logger.warning(msg)

def app_error(msg: str):
    """程序错误。"""
    app_logger.error(msg, exc_info=True)

def app_startup(version: str):
    """记录程序启动。"""
    app_logger.info(f"===== DesktopGuard v{version} 启动 =====")

def app_shutdown():
    """记录程序关闭。"""
    app_logger.info("===== DesktopGuard 关闭 =====")


def scan_start(mode: str):
    """记录扫描开始。"""
    scan_logger.info(f"----- 扫描开始 [{mode}] -----")

def scan_progress(scanned: int, threats: int, junk: int):
    """记录扫描进度（每500个文件记录一次，避免日志过大）。"""
    if scanned % 500 == 0:
        scan_logger.info(f"进度: 已扫描 {scanned} 文件, 威胁 {threats}, 垃圾 {junk}")

def scan_threat(path: str, level: str, score: int, tags: list):
    """记录发现的威胁文件。"""
    tag_str = ", ".join(tags[:5]) if tags else ""
    scan_logger.warning(f"威胁 [{level}] 分数={score} {path} | {tag_str}")

def scan_finish(mode: str, scanned: int, threats: int, junk: int, duration: float):
    """记录扫描完成。"""
    scan_logger.info(
        f"----- 扫描完成 [{mode}] ----- "
        f"文件数={scanned}, 威胁={threats}, 垃圾={junk}, 耗时={duration:.1f}秒"
    )


def security_quarantine(path: str, reason: str, level: str):
    """记录文件隔离操作（审计）。"""
    security_logger.warning(f"[隔离] {path} | 等级={level} | 原因={reason}")

def security_restore(path: str, quarantine_id: int):
    """记录文件恢复操作（审计）。"""
    security_logger.info(f"[恢复] {path} | 隔离ID={quarantine_id}")

def security_delete(path: str, source: str):
    """记录彻底删除操作（审计）。"""
    security_logger.warning(f"[彻底删除] {path} | 来源={source}")

def security_whitelist_add(path: str, sha256: str = ""):
    """记录添加白名单操作（审计）。"""
    security_logger.info(f"[白名单-添加] {path} | 哈希={sha256[:16] if sha256 else 'N/A'}...")

def security_whitelist_remove(path: str):
    """记录移除白名单操作（审计）。"""
    security_logger.info(f"[白名单-移除] {path}")

def security_blacklist_add(sha256: str, name: str):
    """记录添加黑名单操作（审计）。"""
    security_logger.warning(f"[黑名单-添加] {sha256[:16]}... | 名称={name}")


def get_log_files() -> dict:
    """获取日志文件路径列表。"""
    return {
        "app": os.path.join(LOG_DIR, "app.log"),
        "scan": os.path.join(LOG_DIR, "scan.log"),
        "security": os.path.join(LOG_DIR, "security.log"),
    }

def get_log_dir() -> str:
    """获取日志目录。"""
    return LOG_DIR
