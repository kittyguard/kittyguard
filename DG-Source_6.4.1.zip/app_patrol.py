# -*- coding: utf-8 -*-
"""
app_patrol.py — 应用巡检（3.3.0 新增）
火绒式「快捷方式巡检 + 进程巡检 + 应用包体扫描」：
1. 扫描桌面/开始菜单/启动目录所有快捷方式，解析目标；
2. 对目标程序做单文件分析 + 对整个应用包体（目录内可执行/脚本）递归扫描；
3. 巡检当前运行进程，对可疑路径（Temp/AppData/下载目录等）的进程文件做风险分析。
零第三方依赖：快捷方式解析复用 engine.resolve_lnk_targets（PowerShell COM），
进程枚举用 PowerShell（UTF-8 + CREATE_NO_WINDOW 防黑窗闪烁）。
"""
import os
import subprocess

EXEC_EXTS = (".exe", ".dll", ".scr", ".sys", ".com",
             ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar", ".msi", ".lnk")
SUSPECT_DIRS = ("temp", "appdata", "downloads", "\\tmp", "$recycle", "\\cache")


def _no_window():
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)


def collect_shortcut_dirs():
    """桌面 + 开始菜单 + 启动目录（当前用户 + 公共用户）。"""
    dirs = []
    user = os.environ.get("USERPROFILE", "")
    if user:
        dirs += [
            os.path.join(user, "Desktop"),
            os.path.join(user, "AppData", "Roaming", "Microsoft", "Windows",
                         "Start Menu", "Programs"),
            os.path.join(user, "AppData", "Roaming", "Microsoft", "Windows",
                         "Start Menu", "Programs", "Startup"),
        ]
    pub = os.environ.get("PUBLIC", r"C:\Users\Public")
    dirs += [os.path.join(pub, "Desktop")]
    prog = os.environ.get("ProgramData", r"C:\ProgramData")
    dirs += [os.path.join(prog, "Microsoft", "Windows", "Start Menu", "Programs"),
             os.path.join(prog, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")]
    return [d for d in dirs if os.path.isdir(d)]


def collect_all_lnks(dirs):
    """返回所有 .lnk 文件路径（含开始菜单子目录，深度≤3）。"""
    out = []
    seen = set()
    for d in dirs:
        for root, dirs2, files in os.walk(d):
            depth = root[len(d):].count(os.sep)
            if depth > 3:
                dirs2[:] = []
                continue
            for fn in files:
                if fn.lower().endswith(".lnk"):
                    p = os.path.join(root, fn)
                    if p not in seen:
                        seen.add(p)
                        out.append(p)
            if len(out) >= 600:
                return out
    return out


def get_running_processes(limit=250):
    """枚举运行进程，返回 [(pid, name, path), ...]。失败返回 []。"""
    try:
        ps = (
            "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
            "Get-Process | Where-Object { $_.Path } | ForEach-Object "
            "{ \"$($_.Id)|$($_.ProcessName)|$($_.Path)\" }"
        )
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                           capture_output=True, timeout=15, encoding="utf-8", errors="ignore",
                           creationflags=_no_window())
        rows = []
        for line in (r.stdout or "").splitlines():
            parts = line.split("|")
            if len(parts) >= 3 and parts[0].strip().isdigit():
                rows.append((int(parts[0].strip()), parts[1].strip(), "|".join(parts[2:]).strip()))
        return rows[:limit]
    except Exception:
        return []


def path_suspect(path):
    """进程/目标路径是否位于可疑目录（Temp/AppData/下载等）。"""
    low = path.lower().replace("/", "\\")
    return any(k in low for k in SUSPECT_DIRS)


def collect_package_files(target, limit=150):
    """应用包体扫描：目标程序所在目录递归收集可执行/脚本文件。
    跳过 DG 自身目录、系统目录、常见开发/缓存目录（降低误报）。"""
    base = os.path.dirname(target) if os.path.isfile(target) else target
    if not base or not os.path.isdir(base):
        return []
    out = []
    for root, dirs2, files in os.walk(base):
        low = root.lower().replace("/", "\\")
        if any(x in low for x in ("\\windows\\", "\\system32", "\\syswow64",
                                  "desktopguard", "\\dg_data", "\\quarantine",
                                  "\\isolated", "\\node_modules", "\\__pycache__",
                                  "\\venv", "\\site-packages", "\\git\\")):
            dirs2[:] = []
            continue
        depth = root[len(base):].count(os.sep)
        if depth > 3:
            dirs2[:] = []
            continue
        for fn in files:
            if fn.lower().endswith(EXEC_EXTS):
                p = os.path.join(root, fn)
                if p not in out:
                    out.append(p)
                if len(out) >= limit:
                    return out
    return out
