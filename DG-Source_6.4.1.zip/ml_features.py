# -*- coding: utf-8 -*-
"""
ml_features.py — 机器学习特征提取（本地 ML 模型输入）
=====================================================
从 PE 文件提取 40 维固定特征向量，供随机森林训练与推理。
纯用户态、纯标准库；静态解析（头部+区段表+导入表），不执行任何样本。
特征设计参考 PyAS 本地分类器的特征工程思路，并扩展了更细的区段/导入维度。
"""

import os
import struct
import math

# ---- 可疑 API 分类（静态导入匹配）----
SUSPICIOUS_API = {
    "injection": ["virtualallocex", "writeprocessmemory", "createremotethread",
                  "ntcreatethreadex", "setthreadcontext", "queueuserapc",
                  "ntwritevirtualmemory", "ntprotectvirtualmemory", "rtlinitializectxt"],
    "socket": ["wsastartup", "socket", "connect", "send", "recv", "internetopen",
               "internetopenurl", "urldownloadtofile", "winhttpopen", "httpopenrequest",
               "ws2_32", "wininet"],
    "persistence": ["regsetvalueex", "regcreatekeyex", "createservice",
                    "startservicectrldispatcher", "regopenkeyex", "regcreatekey",
                    "impersonatelogonuser"],
    "crypto": ["cryptencrypt", "cryptdecrypt", "bcryptencrypt", "bcryptdecrypt",
               "rtlencryptmemory", "cryptacquirecontext", "cryptprotectdata"],
    "evasion": ["isdebuggerpresent", "checkremotedebuggerpresent",
                "ntqueryinformationprocess", "virtualprotect", "virtualprotectex",
                "ntqueryvirtualmemory", "getmodulehandlew"],
    "keylog": ["getasynckeystate", "setwindowshookex", "getforegroundwindow",
               "getkeystate", "registerhotkey"],
    "exec": ["shellexecute", "winexec", "createprocess", "createprocessw",
             "processstart", "ntcreateprocess"],
    "memory": ["virtualalloc", "virtualalloc2", "ntallocatevirtualmemory",
               "mapviewoffile", "createtoolhelp32snapshot"],
}

KNOWN_SECTION_NAMES = {b".text", b".data", b".rdata", b".pdata", b".rsrc", b".reloc",
                       b".bss", b".idata", b".edata", b".tls", b".debug", b".eh_fr",
                       b".xdata", b".gfids", b".00cfg", b".buildid", b".note", b".ctors",
                       b".dtors", b".sdata", b".srdata", b".didat", b".bndata"}


def _entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    ent = 0.0
    for c in counts:
        if c:
            p = c / n
            ent -= p * math.log2(p)
    return ent


def _sample_entropy(path, off, size, cap=48 * 1024):
    try:
        with open(path, "rb") as f:
            f.seek(max(off, 0))
            return _entropy(f.read(min(max(size, 0), cap)))
    except Exception:
        return 0.0


def extract(path: str, head: bytes = b"", size: int = 0):
    """返回 48 维特征列表 + 可读标签字典。解析失败返回全 0（48 维）。"""
    f = [0.0] * 48
    if not head:
        try:
            with open(path, "rb") as fh:
                head = fh.read(65536)
        except Exception:
            return f, {}
    if len(head) < 64 or head[:2] != b"MZ":
        return f, {}

    pe_off = struct.unpack_from("<I", head, 0x3C)[0]
    if pe_off + 24 > len(head) or head[pe_off:pe_off + 4] != b"PE\x00\x00":
        return f, {}

    if size <= 0:
        try:
            size = os.path.getsize(path)
        except Exception:
            size = 0

    feat = {}
    try:
        opt_off = pe_off + 24
        opt_magic = struct.unpack_from("<H", head, opt_off)[0]
        is_pe32plus = (opt_magic == 0x20B)
        num_sec = struct.unpack_from("<H", head, pe_off + 6)[0]
        size_opt = struct.unpack_from("<H", head, pe_off + 20)[0]
        ts = struct.unpack_from("<I", head, pe_off + 8)[0]
        entry_rva = struct.unpack_from("<I", head, opt_off + 16)[0]
        subsystem = struct.unpack_from("<H", head, opt_off + 68)[0] if opt_off + 70 <= len(head) else 0

        # 数据目录（TLS=第9项 index8, 导入=第1项 index0, 资源=第2项 index1, 异常=第6项 index5, 调试=第10项 index9, 重定位=第5项 index4）
        dd_off = opt_off + (112 if is_pe32plus else 96)
        ddirs = []
        for i in range(16):
            o = dd_off + i * 8
            if o + 8 <= len(head):
                rva, sz = struct.unpack_from("<II", head, o)
                ddirs.append((rva, sz))
            else:
                ddirs.append((0, 0))
        imp_rva, imp_size = ddirs[0] if ddirs else (0, 0)
        res_rva, res_size = ddirs[2] if len(ddirs) > 2 else (0, 0)
        reloc_rva, reloc_size = ddirs[5] if len(ddirs) > 5 else (0, 0)
        tls_rva, tls_size = ddirs[9] if len(ddirs) > 9 else (0, 0)
        debug_rva, debug_size = ddirs[6] if len(ddirs) > 6 else (0, 0)
        exc_rva, exc_size = ddirs[3] if len(ddirs) > 3 else (0, 0)

        # 区段表
        sec_off = opt_off + size_opt
        sections = []
        for i in range(num_sec):
            o = sec_off + i * 40
            if o + 40 > len(head):
                break
            name = head[o:o + 8].rstrip(b"\x00")
            vsize, vaddr = struct.unpack_from("<II", head, o + 8)
            rawsize, rawptr = struct.unpack_from("<II", head, o + 16)
            chars = struct.unpack_from("<I", head, o + 36)[0]
            sections.append((name, vaddr, vsize, rawptr, rawsize, chars))
        if not sections:
            return f, {}

        W = 0x80000000; E = 0x20000000; R = 0x40000000
        wx_count = 0
        rwx_count = 0
        entry_sec_idx = -1
        entry_wx = 0
        entry_in_last = 0
        ent_list = []
        has_upx0 = 0
        has_packer = 0
        unusual_names = 0
        text_size = 0.0
        data_size = 0.0
        max_end = 0
        res_size_real = 0.0
        for idx, (name, vaddr, vsize, rawptr, rawsize, chars) in enumerate(sections):
            is_wx = bool((chars & W) and (chars & E))
            is_rwx = bool((chars & R) and (chars & W) and (chars & E))
            if is_wx:
                wx_count += 1
            if is_rwx:
                rwx_count += 1
            if name in (b"UPX0", b"UPX1"):
                has_upx0 = 1
            if name in (b".vmp", b".themida", b".aspack", b".petite", b".nsp0",
                        b".mpress", b".enigma", b".vmprotect", b".y0da", b".cryptor",
                        b".bambam", b".pecompact", b".kkrunchy"):
                has_packer = 1
            if name and name not in KNOWN_SECTION_NAMES:
                unusual_names += 1
            if rawsize > 0:
                ent_list.append(_sample_entropy(path, rawptr, rawsize))
                max_end = max(max_end, rawptr + rawsize)
            if vaddr <= entry_rva < vaddr + max(vsize, rawsize):
                entry_sec_idx = idx
                entry_wx = 1 if is_wx else 0
            if name == b".text":
                text_size = max(vsize, rawsize) / 1024.0
            if name == b".data":
                data_size = max(vsize, rawsize) / 1024.0
            if vaddr == res_rva or (res_rva and vaddr <= res_rva < vaddr + max(vsize, rawsize)):
                res_size_real = max(vsize, rawsize) / 1024.0

        if sections and entry_sec_idx == len(sections) - 1:
            entry_in_last = 1

        # 导入表解析（RVA → 文件偏移；抽样读导入描述符）
        dlls = []
        apis = []
        if imp_rva and imp_size and size > 0:
            try:
                # 用简单线性映射：多数 PE 区段 rva→raw 相同或相近，这里直接读头内/文件
                imp_data = b""
                if imp_rva < 65536 and imp_rva + 4096 <= len(head):
                    imp_data = head[imp_rva:imp_rva + 4096]
                else:
                    with open(path, "rb") as fh:
                        fh.seek(min(imp_rva, max(0, size - 1)))
                        imp_data = fh.read(8192)
                if imp_data:
                    # 导入描述符数组：20 字节/项，Name RVA 在 offset+12
                    off = 0
                    while off + 20 <= len(imp_data):
                        name_rva = struct.unpack_from("<I", imp_data, off + 12)[0]
                        if name_rva == 0:
                            break
                        # 读 DLL 名
                        try:
                            dname = ""
                            if name_rva < 65536 and name_rva < len(head):
                                end = head.find(b"\x00", name_rva)
                                dname = head[name_rva:end].decode("ascii", "ignore").lower()
                            dlls.append(dname)
                        except Exception:
                            pass
                        off += 20
            except Exception:
                pass

        # 可疑 API 统计
        sus = {k: 0 for k in SUSPICIOUS_API}
        import sys
        # 无法从导入表精确取 API 名（需解析 thunk），退而求其次：用全文件字符串扫描轻量替代
        try:
            with open(path, "rb") as fh:
                chunk = fh.read(min(size, 256 * 1024))
            low = chunk.lower()
            for cat, names in SUSPICIOUS_API.items():
                for nm in names:
                    if nm.encode() in low:
                        sus[cat] += 1
        except Exception:
            pass

        import time as _time
        now = int(_time.time())

        # ---- 组装 40 维特征 ----
        avg_ent = sum(ent_list) / len(ent_list) if ent_list else 0.0
        max_ent = max(ent_list) if ent_list else 0.0
        ent_var = (sum((e - avg_ent) ** 2 for e in ent_list) / len(ent_list)) if len(ent_list) > 1 else 0.0
        overlay_mb = (size - max_end) / 1048576.0 if max_end > 0 and size > 0 else 0.0
        f = [
            math.log2(size + 1) / 40.0,                 # 0 文件大小归一化
            1.0 if is_pe32plus else 0.0,               # 1 PE32+
            float(min(num_sec, 16)),                   # 2 区段数
            float(entry_in_last),                      # 3 入口在末区段
            float(entry_wx),                           # 4 入口区段W+X
            float(min(wx_count, 8)),                   # 5 W+X区段数
            float(min(rwx_count, 8)),                  # 6 RWX区段数
            float(has_upx0),                           # 7 UPX
            float(has_packer),                         # 8 其他壳
            1.0 if 0 <= ts < 315532800 else 0.0,       # 9 1970时间戳
            1.0 if ts > now + 180 * 86400 else 0.0,    # 10 未来时间戳
            round(avg_ent, 4),                         # 11 平均熵
            round(max_ent, 4),                         # 12 最大熵
            round(min(overlay_mb, 20.0), 4),           # 13 overlay MB
            1.0 if tls_rva and tls_size else 0.0,      # 14 TLS回调
            float(min(len(dlls), 40)),                 # 15 导入DLL数
            float(min(sus["injection"] + sus["memory"] + sus["exec"], 30)),  # 16 注入/执行API
            float(min(sus["socket"], 20)),             # 17 网络API
            float(min(sus["crypto"], 20)),             # 18 加密API
            float(min(sus["persistence"], 20)),        # 19 持久化API
            float(min(sus["evasion"], 20)),            # 20 反调试API
            float(min(sus["keylog"], 20)),             # 21 键盘记录API
            1.0 if sus["socket"] else 0.0,             # 22 网络标志
            1.0 if sus["crypto"] else 0.0,             # 23 加密标志
            1.0 if sus["injection"] else 0.0,          # 24 注入标志
            1.0 if sus["persistence"] else 0.0,        # 25 持久化标志
            1.0 if sus["evasion"] else 0.0,            # 26 反调试标志
            1.0 if imp_rva == 0 or imp_size == 0 else 0.0,  # 27 无导入目录
            1.0 if res_rva and res_size else 0.0,      # 28 有资源
            round(min(res_size_real, 50.0), 4),        # 29 资源大小KB
            1.0 if reloc_rva and reloc_size else 0.0,  # 30 重定位
            1.0 if debug_rva and debug_size else 0.0,  # 31 调试目录
            1.0 if exc_rva and exc_size else 0.0,      # 32 异常目录
            round(min(text_size, 1024.0), 3),          # 33 .text KB
            round(min(data_size, 1024.0), 3),          # 34 .data KB
            1.0 if entry_rva == 0 else 0.0,            # 35 入口=0
            1.0 if subsystem == 2 else 0.0,            # 36 GUI子系统
            1.0 if entry_rva > 0x10000 else 0.0,       # 37 高入口点
            float(min(unusual_names, 10)),             # 38 非常规区段名数
            1.0 if 0 < size < 30 * 1024 else 0.0,      # 39 极小文件
        ]
        # 补：第 36 号 GUI 子系统换掉——用 exe/dll 区分放最后
        # （保持 40 维；36 位保留为"exe 非 dll"）
        is_exe = path.lower().endswith(".exe") or path.lower().endswith(".scr")
        f[36] = 1.0 if is_exe else 0.0

        # ---- 升级 40→48 维：Rich头 / DOS stub / 证书 / 字符串统计 / 加载配置 / 导出表 ----
        rich_exist = 1.0 if b"Rich" in head[:pe_off] else 0.0
        stub_big = 1.0 if pe_off > 0x400 else 0.0
        cert_rva, cert_size = ddirs[4] if len(ddirs) > 4 else (0, 0)
        lcfg_rva, lcfg_size = ddirs[10] if len(ddirs) > 10 else (0, 0)
        exp_rva, exp_size = ddirs[0] if ddirs else (0, 0)
        # 字符串统计（chunk 已读 256KB）
        printable = 0.0
        long_strs = 0
        url_ips = 0
        if chunk:
            printable = sum(1 for b in chunk if 32 <= b < 127) / float(len(chunk))
            run = 0
            for _b in chunk:
                if 32 <= _b < 127:
                    run += 1
                else:
                    if run >= 30:
                        long_strs += 1
                    run = 0
            if run >= 30:
                long_strs += 1
            low = chunk.lower()
            url_ips = low.count(b"http://") + low.count(b"https://") + low.count(b"ftp://")
            import re as _re
            url_ips += len(_re.findall(rb"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", low))
        f += [
            float(rich_exist),                        # 40 Rich 头存在
            float(stub_big),                          # 41 DOS stub 过大（>1KB，加壳常见）
            1.0 if cert_rva and cert_size else 0.0,   # 42 证书目录存在（有签名）
            round(printable, 4),                      # 43 可打印字符串比例
            float(min(long_strs, 500)),               # 44 长字符串数（>=30）
            float(min(url_ips, 200)),                 # 45 URL/IP 串数
            1.0 if lcfg_rva and lcfg_size else 0.0,   # 46 加载配置目录（CFG）
            1.0 if exp_rva and exp_size else 0.0,     # 47 导出表存在
        ]

        feat = {
            "size": size, "sections": num_sec, "entry_wx": entry_wx,
            "wx_count": wx_count, "avg_ent": round(avg_ent, 3),
            "max_ent": round(max_ent, 3), "overlay_mb": round(overlay_mb, 2),
            "has_upx": has_upx0, "has_packer": has_packer,
            "ts_1970": 1 if 0 <= ts < 315532800 else 0,
            "ts_future": 1 if ts > now + 180 * 86400 else 0,
            "dlls": len(dlls), "sus_apis": sum(sus.values()),
        }
        return f, feat
    except Exception:
        return f, feat if 'feat' in dir() else {}


FEATURE_NAMES = [
    "size_norm", "pe32plus", "num_sections", "entry_in_last", "entry_wx",
    "wx_count", "rwx_count", "has_upx", "has_packer", "ts_1970",
    "ts_future", "avg_entropy", "max_entropy", "overlay_mb", "has_tls",
    "num_dlls", "inj_exec_api", "net_api", "crypto_api", "persist_api",
    "evasion_api", "keylog_api", "flag_net", "flag_crypto", "flag_inject",
    "flag_persist", "flag_evasion", "no_imports", "has_resource", "res_size_kb",
    "has_reloc", "has_debug", "has_except", "text_kb", "data_kb",
    "is_exe", "entry_zero", "high_entry", "unusual_sections", "tiny_file",
    "rich_exist", "stub_big", "has_cert", "printable_ratio", "long_strings",
    "url_ip_count", "has_lcfg", "has_export",
]
