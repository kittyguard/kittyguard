# -*- coding: utf-8 -*-
"""发布 6.2.0：快照 + 重建防篡改清单 + version.json（托盘洪流冲刷入口 + 组件一键自检修复 + 勒索守护立即备份全部）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.2.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx", "sandbox_runner.exe",
           "dg_warden.exe", "dg_watcher_tpl.exe"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.2.0 内容更新：托盘洪流冲刷入口 + 组件一键自检修复 + 勒索守护立即备份全部。",
    "features": [
        "托盘洪流冲刷入口：托盘右键菜单新增「🌊 洪流冲刷」——不打开主窗口也能一键直达冲刷（自动切到冲刷页并启动五段流水线），打完游戏/日常收尾随手冲一波",
        "组件一键自检修复：防护中心新增「一键自检修复」——核心 C++ 组件缺失/被杀软误删时自动从最新版本快照恢复同名文件到根目录，后台执行不卡界面，完成后弹窗报告 正常/已恢复/失败 并刷新防护中心",
        "勒索守护立即备份全部：保护页勒索守护新增「立即备份全部」——怀疑勒索/重装前手动把监控目录全部文档办公文件备份到保护区（去重+隐藏属性+2GB 容量自清理），可随时用「恢复勒索备份」找回",
        "ransomware_guard.py 新增 backup_all_now()：遍历监控目录、跳过排除目录、文档办公扩展名名单、单文件 >200MB 跳过、每 50 个一批复用 _backup_changed 去重备份流程",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
