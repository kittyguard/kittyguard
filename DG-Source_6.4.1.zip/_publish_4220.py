# -*- coding: utf-8 -*-
"""发布 4.22.0：快照 + 重建防篡改清单 + version.json（防护中心·诊断报告·日志分模块·版本跳转）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "4.22.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

# 重建防篡改清单（当前安装态 = 受信任态）
sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

# 更新 version.json（更新服务器读取）
notes = {
    "latest_version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "4.22.0 内容更新：防护中心（保护页新增 6 大模块状态 + 10 组件健康明细 + 一键刷新）· 诊断报告一键导出 zip（配置 API Key 打码去敏感）· 日志分模块（scan/rtp/ema 独立 log 文件，500KB 自动截断）· 工具页与设置页历史版本新增快速跳转下拉（全部版本一键直达）",
    "features": [
        "防护中心：文件监控/EMA/守护链/乱码观察者/自保清单/云查 6 模块状态 + 组件健康",
        "诊断报告导出：DG_Diagnostic_Report_时间戳.zip（配置打码 + 组件健康 + 日志 + 进程/系统概况）",
        "日志分模块：dgdata/logs/scan.log、rtp.log、ema.log（单文件 500KB 截断）",
        "版本快速跳转下拉（工具页 + 设置页历史版本区）"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
