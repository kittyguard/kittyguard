# -*- coding: utf-8 -*-
import os, glob, re
# 1) git 凭据配置
print("=== git credential config ===")
for scope in ("--global", "--system"):
    import subprocess
    r = subprocess.run(["git", "config", scope, "--get", "credential.helper"], capture_output=True, text=True, encoding="utf-8", errors="ignore")
    print(scope, "helper:", (r.stdout or r.stderr or "").strip())
# 2) 重要文件里的 token 存档
print("=== 重要文件 token 存档 ===")
imp = r"F:\桌面保护\desktopguard\重要文件"
if os.path.isdir(imp):
    for f in sorted(os.listdir(imp)):
        p = os.path.join(imp, f)
        if os.path.isfile(p) and (f.endswith(".md") or f.endswith(".txt")):
            try:
                txt = open(p, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            for m in re.finditer(r"gh[pous]_[A-Za-z0-9]{20,}", txt):
                print(f, "->", m.group(0))
# 3) git-credentials 文件
print("=== credential store ===")
cred = os.path.expanduser(r"~\.git-credentials")
if os.path.isfile(cred):
    for line in open(cred, encoding="utf-8", errors="ignore"):
        if "github" in line:
            print(line.strip()[:80])
