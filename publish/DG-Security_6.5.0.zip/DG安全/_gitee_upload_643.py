# -*- coding: utf-8 -*-
"""Gitee v6.4.3 上传附件（便携 zip + 源码 zip；安装包 327MB 超 Gitee 100MB 限制跳过）"""
import os, json, uuid, urllib.request

LOG = r"F:\桌面保护\desktopguard\_gitee_upload.log"
TOKEN = "964d5ca1cfc09792719272c1260170a8"
RELEASE_ID = "1197635"
BASE = "https://gitee.com/api/v5/repos/kittyguard/kittyguard/releases/%s/attach_files" % RELEASE_ID
OFF = r"F:\桌面保护\desktopguard\官网"

def log(msg):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")

def upload(path):
    fn = os.path.basename(path)
    size = os.path.getsize(path)
    log("upload %s (%d B)" % (fn, size))
    boundary = "----dg643" + uuid.uuid4().hex
    with open(path, "rb") as f:
        data = f.read()
    head = ("--%s\r\nContent-Disposition: form-data; name=\"access_token\"\r\n\r\n%s\r\n"
            "--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n"
            "Content-Type: application/octet-stream\r\n\r\n" % (boundary, TOKEN, boundary, fn)).encode("utf-8")
    tail = ("\r\n--%s--\r\n" % boundary).encode("utf-8")
    body = head + data + tail
    req = urllib.request.Request(BASE, data=body, method="POST",
                                 headers={"User-Agent": "kittyguard",
                                          "Content-Type": "multipart/form-data; boundary=%s" % boundary})
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            j = json.loads(r.read().decode("utf-8"))
            log("OK %s -> name=%s url=%s" % (fn, j.get("name"), j.get("browser_download_url")))
    except Exception as e:
        if hasattr(e, "read"):
            log("HTTP %s %s BODY=%s" % (fn, getattr(e, "code", "?"), e.read().decode("utf-8", "ignore")[:800]))
        else:
            log("ERR %s %s" % (fn, e))

for f in ("DG-Security_6.4.3.zip", "DG-Source_6.4.3.zip"):
    p = os.path.join(OFF, f)
    if os.path.isfile(p):
        upload(p)
