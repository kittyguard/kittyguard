# -*- coding: utf-8 -*-
"""官网同步 6.0.4：更新 zip + 镜像 version.json（只保留最新版 zip）"""
import io, os, shutil, zipfile, time, json, hashlib

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.0.4"
web = os.path.join(DG, "官网")
pub = os.path.join(web, "publish")
os.makedirs(pub, exist_ok=True)

# 1. 打 zip（含 DG安全 便携目录内容）
dist = os.path.join(DG, "dist", "DG安全")
zpath = os.path.join(web, "DG-Security_%s.zip" % NEW_VER)
if os.path.exists(zpath):
    os.remove(zpath)
with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(dist):
        for fn in files:
            fp = os.path.join(root, fn)
            rel = os.path.relpath(fp, dist)
            if rel.lower() == "dg安全.exe":
                rel = "DG安全.exe"
            z.write(fp, os.path.join("DG安全", rel))
# 2. 删旧 zip（只留最新）
for old in os.listdir(web):
    if old.startswith("DG-Security_") and old.endswith(".zip") and old != os.path.basename(zpath):
        os.remove(os.path.join(web, old))
# 3. 哈希 + 镜像
sha = hashlib.sha256(open(zpath, "rb").read()).hexdigest().upper()
notes = {"latest_version": NEW_VER, "version": NEW_VER,
         "release_date": time.strftime("%Y-%m-%d"),
         "download_url": "DG-Security_%s.zip" % NEW_VER,
         "sha256": sha, "size_bytes": os.path.getsize(zpath)}
for p in (os.path.join(web, "version.json"), os.path.join(pub, "version.json")):
    with io.open(p, "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)
# 4. 镜像 zip
zpub = os.path.join(pub, os.path.basename(zpath))
shutil.copy2(zpath, zpub)
for old in os.listdir(pub):
    if old.startswith("DG-Security_") and old.endswith(".zip") and old != os.path.basename(zpub):
        os.remove(os.path.join(pub, old))
print("[OK] 官网 zip: %s" % os.path.basename(zpath))
print("[OK] SHA256=%s" % sha)
print("[OK] version.json 双镜像已更新为 %s" % NEW_VER)
