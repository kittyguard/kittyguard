# -*- coding: utf-8 -*-
import urllib.request, json, ssl

ctx = ssl.create_default_context()
handler = urllib.request.ProxyHandler({
    'http': 'http://127.0.0.1:33210',
    'https': 'http://127.0.0.1:33210',
})
opener = urllib.request.build_opener(handler)
r = opener.open('https://api.github.com/repos/kittyguard/kittyguard/commits?per_page=3', timeout=30)
d = json.load(r)
for c in d:
    print(c['sha'][:10], c['commit']['message'][:60])
