# -*- coding: utf-8 -*-
"""6.4.0 真实启动验证：启动便携版 -> 存活检查 -> 正常退出(app_exit.flag) -> 进程清理 LEFT=0"""
import os, subprocess, time, glob, ctypes

DG = r"F:\桌面保护\desktopguard"
EXE = os.path.join(DG, "dist", "DG安全", "DG安全.exe")
DATA_DIR = r"F:\桌面保护\dgdata"
FLAG = os.path.join(DATA_DIR, "app_exit.flag")

ok = 0
bad = []

def chk(name, cond, detail=""):
    global ok
    if cond:
        ok += 1
        print("[PASS]", name, ("(" + detail + ")" if detail else ""))
    else:
        bad.append(name)
        print("[FAIL]", name, ("(" + detail + ")" if detail else ""))

def running_names():
    out = subprocess.run(["powershell", "-NoProfile", "-Command",
        "Get-Process | Where-Object { $_.Path -like '*DG安全*' } | Select-Object -ExpandProperty ProcessName"],
        capture_output=True, text=True).stdout or ""
    return [l.strip() for l in out.splitlines() if l.strip()]

# 确保没有残留 DG 进程
for p in running_names():
    subprocess.run(["taskkill", "/IM", p, "/F"], capture_output=True)

# 启动便携版
proc = subprocess.Popen([EXE], cwd=os.path.dirname(EXE))
time.sleep(8)
procs = running_names()
chk("便携版启动后进程存活", len(procs) > 0, "进程: %s" % procs[:6])

# 正常退出：写 app_exit.flag（三方互守约定：存在此文件则守护链不再拉起）
try:
    with open(FLAG, "w") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S"))
    chk("app_exit.flag 写入", True)
except Exception as e:
    chk("app_exit.flag 写入", False, str(e))

time.sleep(2)
for p in running_names():
    subprocess.run(["taskkill", "/IM", p, "/F"], capture_output=True)
time.sleep(3)
left = running_names()
chk("退出后无 DG 残留进程 (LEFT=0)", not left, "残留: %s" % left)

# 清理退出标记（下次启动正常）
try:
    os.remove(FLAG)
except OSError:
    pass

print("----")
print("启动验证结果: %d/%d 通过" % (ok, ok + len(bad)))
if bad:
    print("未通过:", bad)
    raise SystemExit(1)
