# -*- coding: utf-8 -*-
"""真实桌面截图 PNG（PIL ImageGrab，抓 WinSta0\\Default）。"""
from PIL import ImageGrab
import os
img = ImageGrab.grab()
out = r"F:\桌面保护\新建文件夹\real_desktop.png"
img.save(out, "PNG")
print("SNAPPED", img.size, os.path.getsize(out))
