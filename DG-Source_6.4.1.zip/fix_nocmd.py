# -*- coding: utf-8 -*-
"""修复实时防护的cmd窗口闪烁问题：给所有subprocess调用加CREATE_NO_WINDOW"""

with open('realtime_protection.py', 'r', encoding='utf-8') as f:
    c = f.read()

# 1. 在import部分添加 CREATE_NO_WINDOW 常量
old_import = '''import os
import re
import json
import time
import threading
import subprocess
import queue
from datetime import datetime'''

new_import = '''import os
import re
import json
import time
import threading
import subprocess
import queue
from datetime import datetime

# 隐藏命令行窗口标志（避免wmic/tasklist弹出黑窗闪烁）
CREATE_NO_WINDOW = 0x08000000'''

c = c.replace(old_import, new_import, 1)
print('1. 添加 CREATE_NO_WINDOW 常量完成')

# 2. 给所有 subprocess.run 调用添加 creationflags=CREATE_NO_WINDOW
# wmic 调用
c = c.replace(
    '''            result = subprocess.run(
                ["wmic", "process", "get", "ProcessId,Name,ExecutablePath,CommandLine", "/format:csv"],
                capture_output=True, text=True, encoding="gbk", errors="ignore",
                timeout=10
            )''',
    '''            result = subprocess.run(
                ["wmic", "process", "get", "ProcessId,Name,ExecutablePath,CommandLine", "/format:csv"],
                capture_output=True, text=True, encoding="gbk", errors="ignore",
                timeout=10, creationflags=CREATE_NO_WINDOW
            )'''
)
print('2. wmic 调用添加 CREATE_NO_WINDOW 完成')

# tasklist 调用
c = c.replace(
    '''                result = subprocess.run(
                    ["tasklist", "/FO", "CSV", "/NH"],
                    capture_output=True, text=True, encoding="gbk", errors="ignore",
                    timeout=10
                )''',
    '''                result = subprocess.run(
                    ["tasklist", "/FO", "CSV", "/NH"],
                    capture_output=True, text=True, encoding="gbk", errors="ignore",
                    timeout=10, creationflags=CREATE_NO_WINDOW
                )'''
)
print('3. tasklist 调用添加 CREATE_NO_WINDOW 完成')

# taskkill 调用（自动结束进程）
c = c.replace(
    '''                subprocess.run(["taskkill", "/F", "/PID", str(proc["pid"])], 
                             capture_output=True, timeout=5)''',
    '''                subprocess.run(["taskkill", "/F", "/PID", str(proc["pid"])], 
                             capture_output=True, timeout=5, creationflags=CREATE_NO_WINDOW)'''
)
print('4. 自动结束进程 taskkill 添加 CREATE_NO_WINDOW 完成')

# kill_process 方法里的 taskkill
c = c.replace(
    '''            result = subprocess.run(
                ["taskkill", "/F", "/PID", str(pid)],
                capture_output=True, text=True, encoding="gbk", errors="ignore",
                timeout=5
            )''',
    '''            result = subprocess.run(
                ["taskkill", "/F", "/PID", str(pid)],
                capture_output=True, text=True, encoding="gbk", errors="ignore",
                timeout=5, creationflags=CREATE_NO_WINDOW
            )'''
)
print('5. kill_process 方法添加 CREATE_NO_WINDOW 完成')

with open('realtime_protection.py', 'w', encoding='utf-8') as f:
    f.write(c)

print('\nrealtime_protection.py 修复完成！')

# 同时检查 main.py 里有没有 subprocess 调用弹出窗口
with open('main.py', 'r', encoding='utf-8') as f:
    mc = f.read()

# 给 main.py 里的 subprocess.run 也加 CREATE_NO_WINDOW（如果有的话）
# 先检查有没有 subprocess 调用
if 'subprocess.run' in mc:
    print('\nmain.py 里有 subprocess.run 调用，检查是否需要修复...')
    # 简单替换：给没有 creationflags 的 subprocess.run 加上
    # 这里先不做复杂替换，主要修复 realtime_protection.py
    print('main.py 的 subprocess 调用暂不修改（主要是实时防护导致的闪烁）')

# 升级版本号到 2.4.1
with open('main.py', 'r', encoding='utf-8') as f:
    mc = f.read()

mc = mc.replace('APP_VERSION = "2.4.0"', 'APP_VERSION = "2.4.1"', 1)
mc = mc.replace(
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2", "2.4.0"]',
    '"2.0.0", "2.0.1", "2.1.0", "2.2.0", "2.2.1", "2.2.2", "2.2.3", "2.2.4", "2.2.5", "2.2.6", "2.2.7", "2.2.8", "2.2.9", "2.3.0", "2.3.1", "2.3.2", "2.4.0", "2.4.1"]'
)

old_history = '''VERSION_HISTORY = [
    ("2.4.0"'''
new_history = '''VERSION_HISTORY = [
    ("2.4.1", "补丁：修复实时防护cmd窗口闪烁问题。给所有subprocess调用（wmic/tasklist/taskkill）添加CREATE_NO_WINDOW标志（0x08000000），隐藏命令行黑窗，避免每5秒扫描时弹出cmd窗口闪烁"),
    ("2.4.0"'''
mc = mc.replace(old_history, new_history, 1)

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(mc)

print('\n版本号升级到 2.4.1 完成')
