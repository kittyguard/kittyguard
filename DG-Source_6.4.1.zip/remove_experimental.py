# -*- coding: utf-8 -*-
"""去掉AI智能检查的"实验性"标记，因为现在已经有API了，是正式功能"""

# 修改正式版
with open(r'F:\桌面保护\desktopguard\main.py', 'r', encoding='utf-8') as f:
    c = f.read()

c = c.replace('AI 智能检查（实验性）', 'AI 智能检查')
c = c.replace('AI智能检查（实验性）', 'AI智能检查')

with open(r'F:\桌面保护\desktopguard\main.py', 'w', encoding='utf-8') as f:
    f.write(c)
print("正式版：已去掉 AI 智能检查的「实验性」标记")

# 修改内测版
with open(r'F:\桌面保护\desktopguard-beta\main.py', 'r', encoding='utf-8') as f:
    bc = f.read()

bc = bc.replace('AI 智能检查（实验性）', 'AI 智能检查')
bc = bc.replace('AI智能检查（实验性）', 'AI智能检查')

with open(r'F:\桌面保护\desktopguard-beta\main.py', 'w', encoding='utf-8') as f:
    f.write(bc)
print("内测版：已去掉 AI 智能检查的「实验性」标记")

# 验证
import re
with open(r'F:\桌面保护\desktopguard\main.py', 'r', encoding='utf-8') as f:
    c = f.read()
if '实验性' in c:
    print("警告：正式版仍有「实验性」标记")
else:
    print("验证：正式版已无「实验性」标记")

with open(r'F:\桌面保护\desktopguard-beta\main.py', 'r', encoding='utf-8') as f:
    bc = f.read()
if '实验性' in bc:
    print("警告：内测版仍有「实验性」标记")
else:
    print("验证：内测版已无「实验性」标记")

print("\n完成！AI 智能检查现在是正式功能，不再是实验性。")
print("注意：1.2.7 是历史上唯一拥有「AI 智能检查实验性」功能的版本，这个历史地位不变。")
