# -*- coding: utf-8 -*-
"""官网 HTML 同步 6.4.0：zip 链接 + 版本号 + 时间轴插入 6.4.0 当前版 / 6.3.0 降为已发布 + version.json"""
import io, json, time

DG = r"F:\桌面保护\desktopguard"
paths = [
    DG + r"\官网\DG安全官网.html",
    DG + r"\官网\index.html",
    DG + r"\官网\publish\index.html",
]

# 6.3.0 当前版时间轴节点（作为插入锚点；先确认文件现状再执行）
old630 = ('<div class="tl-item">\n'
          '        <div class="tl-time">6.3.0</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>自启动实时监控 · 扫描 IO 节流</h4>')

new640 = ('<div class="tl-item">\n'
          '        <div class="tl-time">6.4.0</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>自启动监控增强 · 扫描 IO 节流补齐 · ClamAV 双库龄</h4><p>自启动监控告警弹窗升级为三动作按钮：「立即禁用」一键把注册表值名/启动文件夹文件名加 DG_OFF_ 前缀（保留原值完全可逆，收集逻辑自动跳过，可在启动项管理恢复）；「加入忽略」把该启动项写入忽略列表持久化，此后新增不再提示；「稍后处理」本次不处置下次再提醒。扫描 IO 优先级 VERY_LOW 从主扫描线程扩展到生产者/消费者/应用巡检全部扫描线程——全盘扫描时所有 DG 磁盘读写统一让路，彻底不再拖卡鼠标/系统/游戏。规则中心病毒库状态改为 main 与 daily 双库龄分开显示，daily 超 7 天标「偏旧」不再混淆；一键更新病毒库完成后自动刷新统计并写日志。</p></div>\n'
          '      </div>\n'
          + old630.replace('<span class="ver">当前版</span>自启动实时监控', '<span class="ver">已发布</span>自启动实时监控'))

ok = True
for p in paths:
    try:
        s = io.open(p, encoding="utf-8").read()
    except Exception as e:
        print("FAIL 读取", p, e)
        ok = False
        continue
    s = s.replace("DG-Security_6.3.0.zip", "DG-Security_6.4.0.zip")
    s = s.replace("DG-Source_6.3.0.zip", "DG-Source_6.4.0.zip")
    s = s.replace("DG 6.3.0", "DG 6.4.0")
    s = s.replace("当前版本 6.3.0", "当前版本 6.4.0")
    if old630 in s:
        s = s.replace(old630, new640, 1)
        print("[OK] %s：zip/版本号已改 6.4.0，时间轴已插 6.4.0 当前版 + 6.3.0 降为已发布" % p)
    else:
        print("[WARN] %s：时间轴 6.3.0 锚点未命中（版本号已改）；稍后人工核对" % p)
        ok = False
    io.open(p, "w", encoding="utf-8").write(s)

ver = {
    "latest_version": "6.4.0",
    "version": "6.4.0",
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.4.0 内容更新：自启动监控增强 + 扫描 IO 节流补齐 + ClamAV 双库龄。",
    "features": [
        "自启动监控弹窗三动作：立即禁用（DG_OFF_ 前缀可逆）/ 加入忽略（持久化不再提示）/ 稍后处理",
        "扫描 IO 优先级 VERY_LOW 扩展到生产者/消费者/应用巡检全部扫描线程，全盘扫描不再拖卡",
        "ClamAV 规则中心 main 与 daily 双库龄分开显示，一键更新后自动刷新统计",
        "全程纯用户态、零驱动、不服务化"
    ]
}
for p in (DG + r"\官网\version.json", DG + r"\官网\publish\version.json"):
    io.open(p, "w", encoding="utf-8").write(json.dumps(ver, ensure_ascii=False, indent=2))
    print("[OK] %s -> 6.4.0" % p)
print("RESULT", "OK" if ok else "NEED_CHECK")
