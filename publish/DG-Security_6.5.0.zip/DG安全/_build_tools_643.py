# -*- coding: utf-8 -*-
"""6.4.3 打包 7 个 Python 工具 exe 到 staging _internal（onefile + noconsole）"""
import os, subprocess

PYI = r"C:\Users\Administrator\AppData\Local\Programs\Python\Python312\Scripts\pyinstaller.exe"
DG = r"F:\桌面保护\desktopguard"
OUT = os.path.join(DG, "dist", "tools_643")
WORK = os.path.join(DG, "build", "tools_work")
os.makedirs(WORK, exist_ok=True)
TOOLS = ["perf_overlay", "process_manager", "net_tools", "net_monitor",
         "selfdefense", "startup_manager", "fp_regression"]

for t in TOOLS:
    print("[%s] building..." % t, flush=True)
    r = subprocess.run([PYI, "--onefile", "--noconsole",
                        "--distpath", OUT, "--workpath", WORK, "--specpath", WORK,
                        os.path.join(DG, t + ".py")],
                       capture_output=True, text=True, encoding="utf-8", errors="ignore")
    ok = os.path.isfile(os.path.join(OUT, t + ".exe"))
    print("[%s] exit=%d exists=%s size=%d" % (t, r.returncode, ok,
          os.path.getsize(os.path.join(OUT, t + ".exe")) if ok else 0), flush=True)
    if not ok:
        print("  stdout-tail:", (r.stdout or "")[-1200:], flush=True)
        print("  stderr-tail:", (r.stderr or "")[-1200:], flush=True)

print("ALL_DONE", flush=True)
