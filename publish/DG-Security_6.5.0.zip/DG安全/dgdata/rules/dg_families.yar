// DG Security - Malware Family YARA rules v1
// Covers mainstream malware families & attack techniques
// Author: DG Security | All patterns are public IOC knowledge

// ============ RAT / Remote Access Trojans ============

rule DG_RAT_NJRAT {
    meta:
        description = "njRAT remote access trojan"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $s1 = "NJrAT" ascii nocase
        $s2 = "njsock" ascii nocase
        $s3 = "NjRAT" ascii nocase
        $s4 = "JdBgjGHuBdvDH" ascii
        $s5 = "kt_" ascii nocase
    condition:
        (uint16(0) == 0x5A4D or filesize < 5MB) and (2 of them)
}

rule DG_RAT_QUASAR {
    meta:
        description = "Quasar RAT"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $q1 = "Quasar" ascii nocase
        $q2 = "QSRV" ascii
        $q3 = "quser32" ascii nocase
        $q4 = "\\QServer\\" ascii
    condition:
        (uint16(0) == 0x5A4D or filesize < 8MB) and (2 of them)
}

rule DG_RAT_ASYNC {
    meta:
        description = "AsyncRAT"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $a1 = "AsyncRAT" ascii nocase
        $a2 = "Async" ascii
        $a3 = "RSM" ascii
        $a4 = "Setting.Dat" ascii nocase
    condition:
        (uint16(0) == 0x5A4D or filesize < 8MB) and (2 of them)
}

rule DG_RAT_REMCOS {
    meta:
        description = "Remcos RAT"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $r1 = "Remcos" ascii nocase
        $r2 = "RemcosRAT" ascii nocase
        $r3 = "MgmtApp" ascii nocase
    condition:
        (uint16(0) == 0x5A4D or filesize < 8MB) and (2 of them)
}

rule DG_RAT_COBALT_BEACON {
    meta:
        description = "Cobalt Strike beacon"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $c1 = "\\\\.\\pipe\\" ascii
        $c2 = "MSSE-" ascii
        $c4 = "WSAStartup" ascii
        $c5 = "WinHttpOpen" ascii
        $c6 = "InternetOpen" ascii
        $c7 = ".tmp" ascii
    condition:
        (uint16(0) == 0x5A4D) and (2 of ($c1, $c2, $c4)) and (1 of ($c5, $c6, $c7))
}

rule DG_RAT_HOOKS {
    meta:
        description = "RAT keyboard/mouse hooking (generic)"
        author = "DG Security"
        level = "HIGH"
    strings:
        $h1 = "WH_KEYBOARD_LL" ascii
        $h2 = "WH_MOUSE_LL" ascii
        $h3 = "SetWindowsHookExW" ascii
        $h4 = "GetAsyncKeyState" ascii
        $h5 = "MapVirtualKeyW" ascii
    condition:
        (uint16(0) == 0x5A4D) and (3 of them)
}

// ============ Keyloggers / Clippers / Credential stealers ============

rule DG_KEYLOGGER {
    meta:
        description = "Keylogger (low-level keyboard capture)"
        author = "DG Security"
        level = "HIGH"
    strings:
        $k1 = "WH_KEYBOARD_LL" ascii
        $k2 = "GetAsyncKeyState" ascii
        $k3 = "MapVirtualKey" ascii
        $k4 = "SetWindowsHookEx" ascii
        $k5 = "GetForegroundWindow" ascii
        $k6 = "GetWindowText" ascii
        $k7 = "key.log" ascii nocase
    condition:
        (uint16(0) == 0x5A4D or filesize < 5MB) and (3 of them)
}

rule DG_CLIPPER {
    meta:
        description = "Cryptocurrency address clipper (clipboard swap)"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $c1 = "OpenClipboard" ascii
        $c2 = "GetClipboardData" ascii
        $c3 = "SetClipboardData" ascii
        $c4 = "CloseClipboard" ascii
        $c5 = "bitcoin:" ascii nocase
        $c6 = "bc1" ascii nocase
    condition:
        (3 of ($c1, $c2, $c3, $c4)) and (1 of ($c5, $c6))
}

rule DG_CRED_STEALER {
    meta:
        description = "Windows credential stealer (vault/DPAPI)"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $c1 = "CryptUnprotectData" ascii
        $c2 = "CredRead" ascii
        $c3 = "CredEnumerate" ascii
        $c4 = "vaultcli.dll" ascii nocase
        $c5 = "Credential Manager" ascii nocase
    condition:
        (uint16(0) == 0x5A4D) and (2 of them)
}

rule DG_MIMIKATZ {
    meta:
        description = "Mimikatz / credential dumping"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $m1 = "sekurlsa" ascii nocase
        $m2 = "mimikatz" ascii nocase
        $m3 = "logonpasswords" ascii nocase
        $m4 = "lsass" ascii nocase
        $m5 = "kerberos::" ascii nocase
        $m6 = "dpapi::" ascii nocase
    condition:
        (2 of them) and (uint16(0) == 0x5A4D or filesize < 20MB)
}

rule DG_BROWSER_PWD_STEALER {
    meta:
        description = "Browser password/cookie stealer"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $b1 = "Login Data" ascii
        $b2 = "Web Data" ascii
        $b3 = "CryptUnprotectData" ascii
        $b4 = "Local State" ascii
        $b5 = "Chrome" ascii nocase
        $b6 = "sqlite3_open" ascii
    condition:
        (2 of ($b1, $b2, $b4, $b5)) and (1 of ($b3, $b6))
}

rule DG_FTP_STEALER {
    meta:
        description = "FTP client credential stealer"
        author = "DG Security"
        level = "HIGH"
    strings:
        $f1 = "recentservers.xml" ascii nocase
        $f2 = "FileZilla" ascii nocase
        $f3 = "winscp.ini" ascii nocase
        $f4 = "WinSCP" ascii nocase
        $f5 = "hostname" ascii nocase
        $f6 = "password=" ascii nocase
    condition:
        (2 of ($f1, $f2, $f3, $f4, $f5, $f6))
}

// ============ Ransomware families ============

rule DG_RANSOM_LOCKBIT {
    meta:
        description = "LockBit ransomware"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $l1 = "LOCKBIT" ascii
        $l2 = "LockBit" ascii
        $l3 = "Restore-My-Files" ascii nocase
        $l4 = ".lockbit" ascii nocase
        $l5 = "you are being held" ascii nocase
    condition:
        2 of them
}

rule DG_RANSOM_WANNACRY {
    meta:
        description = "WannaCry ransomware"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $w1 = "WannaCry" ascii nocase
        $w2 = "wnry" ascii nocase
        $w3 = "@WanaDecryptor@" ascii
        $w4 = "Please read me" ascii nocase
        $w5 = ".WNCRY" ascii
    condition:
        2 of them
}

rule DG_RANSOM_CONTI {
    meta:
        description = "Conti ransomware"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $c1 = "CONTI" ascii
        $c2 = "conti" ascii nocase
        $c3 = "Chat.conti" ascii nocase
        $c4 = "CONTI_Ransomware" ascii nocase
    condition:
        2 of them
}

rule DG_RANSOM_STOP {
    meta:
        description = "STOP/Djvu ransomware"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $s1 = "djvu" ascii nocase
        $s2 = "STOP" ascii
        $s3 = ".reco" ascii nocase
        $s4 = "restoration" ascii nocase
        $s5 = ".djvu" ascii nocase
    condition:
        2 of them
}

rule DG_RANSOM_DHARMA {
    meta:
        description = "Dharma/CrySis ransomware"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $d1 = "Dharma" ascii nocase
        $d2 = ".dharma" ascii nocase
        $d3 = "CrySis" ascii nocase
        $d4 = ".wallet" ascii nocase
        $d5 = "Wana" ascii nocase
    condition:
        2 of them
}

rule DG_RANSOM_EXT_TARGET {
    meta:
        description = "Ransomware extension-bombing pattern (mass rename)"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $e1 = ".locked" ascii nocase
        $e2 = ".encrypted" ascii nocase
        $e3 = ".enc" ascii nocase
        $e4 = ".crypt" ascii nocase
        $e5 = "ren " ascii nocase
        $e6 = "cipher /e" ascii nocase
    condition:
        (2 of ($e1, $e2, $e3, $e4, $e5, $e6)) and (uint16(0) == 0x5A4D or filesize < 5MB)
}

// ============ Botnets / Bankers ============

rule DG_EMOTET {
    meta:
        description = "Emotet trojan"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $e1 = "Emotet" ascii nocase
        $e2 = "Epoch" ascii nocase
        $e3 = "AppData\\Roaming\\Microsoft\\Windows" ascii
        $e4 = "MSOffice" ascii
        $e5 = "spools" ascii nocase
    condition:
        (uint16(0) == 0x5A4D) and (2 of them)
}

rule DG_TRICKBOT {
    meta:
        description = "TrickBot trojan"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $t1 = "TrickBot" ascii nocase
        $t2 = "trick" ascii nocase
        $t3 = "injectdll" ascii nocase
        $t4 = "systeminfo" ascii nocase
    condition:
        (uint16(0) == 0x5A4D) and (2 of them)
}

rule DG_QAKBOT {
    meta:
        description = "QakBot/Qbot banker"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $q1 = "QakBot" ascii nocase
        $q2 = "Qbot" ascii nocase
        $q3 = "qakbot" ascii nocase
        $q4 = "AppData\\Roaming\\Adobe" ascii
    condition:
        (uint16(0) == 0x5A4D) and (2 of them)
}

rule DG_BANKING_WEBINJECT {
    meta:
        description = "Banking trojan web-inject module"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $w1 = "webinject" ascii nocase
        $w2 = "inject" ascii nocase
        $w3 = "config.bin" ascii nocase
        $w4 = "browser hook" ascii nocase
        $w5 = "SetWindowsHookEx" ascii
    condition:
        (uint16(0) == 0x5A4D) and (2 of ($w1, $w2, $w3, $w4, $w5))
}

// ============ Loaders / Droppers ============

rule DG_LOADER_MEMEXEC {
    meta:
        description = "In-memory loader (allocate-write-execute)"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $m1 = "VirtualAlloc" ascii
        $m2 = "VirtualProtect" ascii
        $m3 = "CreateThread" ascii
        $m4 = "RtlMoveMemory" ascii
        $m5 = "WriteProcessMemory" ascii
        $m6 = "LoadLibrary" ascii
        $m7 = "GetProcAddress" ascii
    condition:
        (uint16(0) == 0x5A4D) and (4 of them)
}

rule DG_DROPPER {
    meta:
        description = "Dropper writing embedded payload"
        author = "DG Security"
        level = "HIGH"
    strings:
        $d1 = "ExtractToFile" ascii
        $d2 = "WriteAllBytes" ascii
        $d3 = "File.WriteAllBytes" ascii
        $d4 = "%AppData%" ascii nocase
        $d5 = "%Temp%" ascii nocase
        $d6 = ".exe" ascii nocase
    condition:
        (2 of ($d1, $d2, $d3)) and (1 of ($d4, $d5, $d6))
}

// ============ Miners ============

rule DG_MINER_POOLS {
    meta:
        description = "Crypto miner pool config (broad)"
        author = "DG Security"
        level = "HIGH"
    strings:
        $p1 = "pool.supportxmr.com" ascii nocase
        $p2 = "minexmr.com" ascii nocase
        $p3 = "nanopool" ascii nocase
        $p4 = "ethermine" ascii nocase
        $p5 = "stratum+tcp" ascii nocase
        $p6 = "cryptonight" ascii nocase
        $p7 = "randomx" ascii nocase
        $p8 = "phoenixminer" ascii nocase
        $p9 = "t-rex" ascii nocase
    condition:
        (2 of them)
}

rule DG_XMRIG {
    meta:
        description = "XMRig miner"
        author = "DG Security"
        level = "HIGH"
    strings:
        $x1 = "XMRig" ascii
        $x2 = "xmrig" ascii nocase
        $x3 = "donate-level" ascii nocase
        $x4 = "randomx" ascii nocase
        $x5 = "rx/" ascii nocase
    condition:
        2 of them
}

// ============ Persistence ============

rule DG_PERSIST_RUNKEY {
    meta:
        description = "Registry Run key persistence"
        author = "DG Security"
        level = "HIGH"
    strings:
        $r1 = "CurrentVersion\\Run" ascii nocase
        $r2 = "RegSetValue" ascii
        $r3 = "RegSetValueEx" ascii
        $r4 = "HKCU\\Software\\Microsoft\\Windows" ascii nocase
        $r5 = "HKLM\\Software\\Microsoft\\Windows" ascii nocase
    condition:
        (uint16(0) == 0x5A4D) and (1 of ($r1, $r4, $r5)) and (1 of ($r2, $r3))
}

rule DG_PERSIST_SCHTASKS {
    meta:
        description = "Scheduled task persistence"
        author = "DG Security"
        level = "HIGH"
    strings:
        $t1 = "schtasks" ascii nocase
        $t2 = "/create" ascii nocase
        $t3 = "/tn" ascii nocase
        $t4 = "/sc" ascii nocase
        $t5 = "Task Scheduler" ascii nocase
    condition:
        (2 of ($t1, $t2, $t3, $t4, $t5))
}

rule DG_PERSIST_WMI {
    meta:
        description = "WMI event subscription persistence"
        author = "DG Security"
        level = "HIGH"
    strings:
        $w1 = "__EventFilter" ascii
        $w2 = "__EventConsumer" ascii
        $w3 = "ActiveScriptEventConsumer" ascii
        $w4 = "CommandLineEventConsumer" ascii
        $w5 = "wmic" ascii nocase
    condition:
        (2 of ($w1, $w2, $w3, $w4, $w5))
}

rule DG_PERSIST_SERVICE {
    meta:
        description = "Windows service persistence"
        author = "DG Security"
        level = "HIGH"
    strings:
        $s1 = "CreateService" ascii
        $s2 = "OpenSCManager" ascii
        $s3 = "StartService" ascii
        $s4 = "sc start" ascii nocase
        $s5 = "SERVICE_AUTO_START" ascii
    condition:
        (uint16(0) == 0x5A4D) and (2 of ($s1, $s2, $s3, $s4, $s5))
}

// ============ Anti-analysis ============

rule DG_ANTIDEBUG {
    meta:
        description = "Anti-debugging techniques"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $d1 = "IsDebuggerPresent" ascii
        $d2 = "CheckRemoteDebuggerPresent" ascii
        $d3 = "NtQueryInformationProcess" ascii
        $d4 = "OutputDebugString" ascii
        $d5 = "int 2d" ascii
        $d6 = "UnhandledExceptionFilter" ascii
    condition:
        (uint16(0) == 0x5A4D) and (2 of them)
}

rule DG_ANTISANDBOX {
    meta:
        description = "Anti-sandbox / anti-VM checks"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $s1 = "VBoxGuest" ascii
        $s2 = "VirtualBox" ascii
        $s3 = "VMware" ascii
        $s4 = "qemu" ascii nocase
        $s5 = "GetTickCount" ascii
        $s6 = "Sleep" ascii
        $s7 = "sandboxie" ascii nocase
    condition:
        (uint16(0) == 0x5A4D) and (2 of ($s1, $s2, $s3, $s4, $s5, $s6, $s7))
}

// ============ Packers / Obfuscation ============

rule DG_PACKER_UPX {
    meta:
        description = "UPX packed executable"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $u1 = "UPX0" ascii
        $u2 = "UPX1" ascii
        $u3 = "UPX!" ascii
    condition:
        uint16(0) == 0x5A4D and (2 of ($u1, $u2, $u3))
}

rule DG_PACKER_THEMIDA {
    meta:
        description = "Themida/WinLicense packed"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $t1 = "Themida" ascii
        $t2 = "WinLicense" ascii
        $t3 = ".themida" ascii nocase
    condition:
        uint16(0) == 0x5A4D and (1 of them)
}

rule DG_XOR_OBFUSCATE {
    meta:
        description = "XOR-obfuscated script/binary"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $x1 = "xor" ascii nocase
        $x2 = "chr(ord" ascii nocase
        $x3 = "char[]" ascii
        $x4 = "byte[]" ascii
        $x5 = "0x" ascii
    condition:
        filesize < 2MB and (2 of ($x1, $x2, $x3, $x4, $x5))
}

// ============ Script / document attacks ============

rule DG_OFFICE_MACRO {
    meta:
        description = "Malicious Office macro"
        author = "DG Security"
        level = "HIGH"
    strings:
        $m1 = "AutoOpen" ascii
        $m2 = "AutoExec" ascii
        $m3 = "Document_Open" ascii
        $m4 = "Workbook_Open" ascii
        $m5 = "VBA" ascii
        $m6 = "Shell(" ascii nocase
        $m7 = "CreateObject" ascii nocase
        $m8 = "Download" ascii nocase
    condition:
        (2 of ($m1, $m2, $m3, $m4, $m5)) and (1 of ($m6, $m7, $m8))
}

rule DG_VBS_OBFUSCATED {
    meta:
        description = "Obfuscated VBScript"
        author = "DG Security"
        level = "HIGH"
    strings:
        $v1 = "Execute(" ascii nocase
        $v2 = "eval(" ascii nocase
        $v3 = "Chr(" ascii nocase
        $v4 = "Replace(" ascii nocase
        $v5 = "Split(" ascii nocase
        $v6 = "WScript.Shell" ascii nocase
    condition:
        (3 of ($v1, $v2, $v3, $v4, $v5, $v6))
}

rule DG_JS_ENC_PAYLOAD {
    meta:
        description = "JavaScript with encoded payload"
        author = "DG Security"
        level = "HIGH"
    strings:
        $j1 = "unescape" ascii nocase
        $j2 = "atob" ascii nocase
        $j3 = "fromCharCode" ascii nocase
        $j4 = "document.write" ascii nocase
        $j5 = "eval(" ascii nocase
        $j6 = "ActiveXObject" ascii
    condition:
        (2 of ($j1, $j2, $j3)) and (1 of ($j4, $j5, $j6))
}

rule DG_HTML_PHISH {
    meta:
        description = "Phishing credential page"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $p1 = "password" ascii nocase
        $p2 = "username" ascii nocase
        $p3 = "login" ascii nocase
        $p4 = "credential" ascii nocase
        $p5 = "bank" ascii nocase
        $p6 = "paypal" ascii nocase
        $p7 = "verify" ascii nocase
    condition:
        filesize < 5MB and (3 of ($p1, $p2, $p3, $p4, $p7)) and (1 of ($p5, $p6))
}

rule DG_LNK_POWER {
    meta:
        description = "Malicious LNK launching PowerShell"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $l1 = "powershell" ascii nocase
        $l2 = "-enc" ascii nocase
        $l3 = "-e " ascii nocase
        $l4 = "cmd /c" ascii nocase
        $l5 = "rundll32" ascii nocase
        $l6 = "wscript" ascii nocase
    condition:
        (1 of ($l1, $l5, $l6)) and (1 of ($l2, $l3, $l4))
}

// ============ Worm / spreading ============

rule DG_WORM_NETSHARE {
    meta:
        description = "Network share worm spreading"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $n1 = "net share" ascii nocase
        $n2 = "admin$" ascii nocase
        $n3 = "IPC$" ascii nocase
        $n4 = "wmic process call create" ascii nocase
        $n5 = "\\\\*\\C$" ascii
    condition:
        (2 of them) and (uint16(0) == 0x5A4D or filesize < 3MB)
}

rule DG_WORM_USB {
    meta:
        description = "USB/autorun worm"
        author = "DG Security"
        level = "HIGH"
    strings:
        $u1 = "autorun.inf" ascii nocase
        $u2 = "RECYCLER" ascii
        $u3 = "System Volume Information" ascii nocase
        $u4 = "shell\\open\\command" ascii nocase
        $u5 = ".scr" ascii nocase
    condition:
        (2 of ($u1, $u2, $u3, $u4, $u5))
}

// ============ Exfiltration / tunneling ============

rule DG_SOCKS_TUNNEL {
    meta:
        description = "Socks proxy tunnel module"
        author = "DG Security"
        level = "HIGH"
    strings:
        $t1 = "socks5" ascii nocase
        $t2 = "socks4" ascii nocase
        $t3 = "CONNECT " ascii nocase
        $t4 = "Proxy" ascii nocase
        $t5 = "SocksPort" ascii nocase
    condition:
        (uint16(0) == 0x5A4D) and (2 of ($t1, $t2, $t3, $t4, $t5))
}

rule DG_DNS_EXFIL {
    meta:
        description = "DNS tunneling / exfiltration"
        author = "DG Security"
        level = "MEDIUM"
    strings:
        $d1 = "nslookup" ascii nocase
        $d2 = "dig " ascii nocase
        $d3 = ".nip.io" ascii nocase
        $d4 = "iodine" ascii nocase
        $d5 = "dnscat" ascii nocase
    condition:
        2 of them
}

// ============ Misc malware ============

rule DG_ADWARE_PUP {
    meta:
        description = "Adware / potentially unwanted"
        author = "DG Security"
        level = "LOW"
    strings:
        $a1 = "adware" ascii nocase
        $a2 = "toolbar" ascii nocase
        $a3 = "browser hijack" ascii nocase
        $a4 = "searchnu" ascii nocase
        $a5 = "conduit" ascii nocase
        $a6 = "offer" ascii nocase
    condition:
        (uint16(0) == 0x5A4D or filesize < 10MB) and (3 of them)
}

rule DG_SPY_WEBCAM {
    meta:
        description = "Webcam spyware"
        author = "DG Security"
        level = "CRITICAL"
    strings:
        $c1 = "capCreateCaptureWindow" ascii
        $c2 = "videoinput" ascii nocase
        $c3 = "avicap" ascii nocase
        $c4 = "WebCam" ascii nocase
        $c5 = "JPEG" ascii
    condition:
        (uint16(0) == 0x5A4D) and (2 of ($c1, $c2, $c3, $c4, $c5))
}

rule DG_SCREEN_CAPTURE {
    meta:
        description = "Screen capture spyware"
        author = "DG Security"
        level = "HIGH"
    strings:
        $s1 = "BitBlt" ascii
        $s2 = "CreateCompatibleBitmap" ascii
        $s3 = "GetDC" ascii
        $s4 = "GetDesktopWindow" ascii
        $s6 = "screen.png" ascii nocase
        $s7 = "capture" ascii nocase
    condition:
        (uint16(0) == 0x5A4D) and (3 of ($s1, $s2, $s3, $s4, $s6, $s7))
}
