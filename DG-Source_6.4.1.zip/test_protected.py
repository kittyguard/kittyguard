# -*- coding: utf-8 -*-
"""测试受保护文件功能 + 注册参考答案 PDF。"""
import io, sys, os
sys.path.insert(0, r"F:\桌面保护\desktopguard")
import database as d

# 测试文件：临时创建一个，走完整流程 添加->检查->删除->还原
tmp = os.path.join(os.environ["TEMP"], "dg_prot_test.txt")
with io.open(tmp, "w", encoding="utf-8") as f:
    f.write("DG protected file test 2026-09-25")

print("== 测试添加 ==")
ok, msg = d.add_protected_file(tmp, note="自动化测试")
print("add:", ok, msg)

print("== 测试列表/存在状态 ==")
rows = d.get_protected_files()
for r in rows:
    print("row:", r["id"], os.path.basename(r["file_path"]), "exists=", r["exists"], "backup=", r["backup_exists"])

print("== 测试删除后检查 ==")
os.remove(tmp)
miss = d.check_protected_files()
print("missing count:", len(miss), [os.path.basename(m["file_path"]) for m in miss])

print("== 测试手动还原 ==")
pid = rows[0]["id"]
ok, msg = d.restore_protected_file(pid)
print("restore:", ok, msg)
print("file back:", os.path.exists(tmp), io.open(tmp, encoding="utf-8").read())

# 清理测试记录
d.remove_protected_file(pid)
try:
    os.remove(tmp)
except Exception:
    pass
print("== 测试记录已清理 ==")

# ========== 正式注册参考答案 PDF ==========
print("== 注册参考答案 PDF ==")
pdf = r"F:\桌面保护\desktopguard\重要文件\2026年古诗文专辑（初中卷）参考答案.pdf"
ok, msg = d.add_protected_file(pdf, note="爸爸重传的作业参考答案（2026-09-25）")
print("register:", ok, msg)

print("== 最终受保护列表 ==")
for r in d.get_protected_files():
    print(" -", r["id"], r["file_path"], "| size=", r["file_size"], "| exists=", r["exists"], "| backup_exists=", r["backup_exists"])
print("PROTECTED_COUNT:", d.get_protected_file_count())
