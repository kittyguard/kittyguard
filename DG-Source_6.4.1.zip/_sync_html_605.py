# -*- coding: utf-8 -*-
"""官网 HTML 同步 6.0.5：版本引用替换 + 时间轴插入 6.0.5 当前版节点"""
import io

p = r"F:\桌面保护\desktopguard\官网\DG安全官网.html"
s = io.open(p, encoding="utf-8").read()

# 1. zip 下载链接 3 处
s = s.replace("DG-Security_6.0.4.zip", "DG-Security_6.0.5.zip")
# 2. 其余裸版本号
s = s.replace("DG 6.0.4", "DG 6.0.5")
s = s.replace("当前版本 6.0.4", "当前版本 6.0.5")
s = s.replace("v6.0.4 ·", "v6.0.5 ·")
# 3. 时间轴：6.0.4 节点降为已发布，前插 6.0.5 当前版
old604 = ('<span class="ver">当前版</span>勒索恢复向导 · 行为链导出</h4><p>一键恢复全部备份：'
          '勒索后批量找回文件，原路径丢失自动跳过、覆盖前留底防覆盖现场；行为链一键导出 CSV'
          '（UTF-8 BOM，Excel 直开，取证复盘用）；防护中心新增「勒索守护」与「弹窗拦截」模块，'
          '就绪度 8 模块一眼看全所有防线。</p></div>\n      </div>')
new605 = ('<span class="ver">当前版</span>恢复指定目录 · 扫描历史管理</h4><p>勒索备份可恢复到指定目录：'
          '原路径丢失、换盘或重装系统后照样找回全部文件，同名自动加序号防覆盖；新增扫描历史窗口，'
          '回看最近 20 次扫描记录（时间/模式/文件数/威胁/垃圾/耗时），支持一键清空全部历史，'
          '不影响扫描引擎与任何配置。</p></div>\n      </div>\n      <div class="tl-item">\n'
          '        <div class="tl-time">6.0.4</div>\n        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">已发布</span>勒索恢复向导 · 行为链导出</h4>'
          '<p>一键恢复全部备份：勒索后批量找回文件，原路径丢失自动跳过、覆盖前留底防覆盖现场；行为链一键导出 CSV'
          '（UTF-8 BOM，Excel 直开，取证复盘用）；防护中心新增「勒索守护」与「弹窗拦截」模块，'
          '就绪度 8 模块一眼看全所有防线。</p></div>\n      </div>')
assert old604 in s, "锚点未命中"
s = s.replace(old604, new605)

io.open(p, "w", encoding="utf-8").write(s)
left = s.count("6.0.4")
print("[OK] 官网 HTML 已同步 6.0.5；剩余 6.0.4 引用（应为时间轴历史节点 2 处）:", left)
