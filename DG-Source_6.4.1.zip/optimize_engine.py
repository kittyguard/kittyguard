# -*- coding: utf-8 -*-
"""优化engine.py扫描性能：预编译正则、优化文件类型判断、减少不必要的读取"""

with open('engine.py', 'r', encoding='utf-8') as f:
    e = f.read()

# 1. 检查是否已有预编译正则
if '_COMPILED_PATTERNS' not in e:
    # 在文件开头添加预编译正则
    import_section = '''import os
import re
import hashlib
import struct
import math
import time'''
    
    compiled_patterns = '''
# ===== 性能优化：预编译正则表达式 =====
_COMPILED_PATTERNS = {
    "powershell_enc": re.compile(r'powershell.*-enc', re.IGNORECASE),
    "powershell_bypass": re.compile(r'powershell.*-bypass', re.IGNORECASE),
    "download_string": re.compile(r'DownloadString|DownloadFile', re.IGNORECASE),
    "from_base64": re.compile(r'FromBase64String', re.IGNORECASE),
    "iex_invocation": re.compile(r'IEX|Invoke-Expression', re.IGNORECASE),
    "hidden_window": re.compile(r'-WindowStyle\\s+Hidden|hidden', re.IGNORECASE),
    "ncat_word": re.compile(r'\\bncat\\b', re.IGNORECASE),
    "netcat_word": re.compile(r'\\bnetcat\\b', re.IGNORECASE),
    "reverse_shell": re.compile(r'reverse.*shell|shell.*reverse', re.IGNORECASE),
    "bind_shell": re.compile(r'bind.*shell|shell.*bind', re.IGNORECASE),
    "meterpreter": re.compile(r'meterpreter', re.IGNORECASE),
    "cobalt_strike": re.compile(r'cobalt.?strike|beacon', re.IGNORECASE),
    "double_ext": re.compile(r'\\.(jpg|png|pdf|doc|docx|xls|xlsx|txt)\\.(exe|scr|vbs|js|bat|cmd|ps1)$', re.IGNORECASE),
}
print("[engine] 正则表达式已预编译，扫描性能优化生效")
'''
    
    if import_section in e:
        e = e.replace(import_section, import_section + compiled_patterns, 1)
        print("1. 预编译正则表达式添加完成")
    else:
        print("1. 未找到import区域，跳过预编译正则")

# 2. 优化文件类型判断：使用字典映射代替多次if-elif
old_type_check = '''    def _detect_file_type(self, path):
        """根据扩展名和文件头检测文件类型。"""
        ext = os.path.splitext(path)[1].lower()
        # 可执行文件
        if ext in ('.exe', '.dll', '.sys', '.scr', '.com'):
            return "PE可执行文件"
        elif ext in ('.bat', '.cmd', '.ps1', '.vbs', '.js', '.jse', '.wsf', '.wsh'):
            return "脚本文件"
        elif ext in ('.msi', '.msp'):
            return "安装包"
        elif ext in ('.zip', '.rar', '.7z', '.tar', '.gz'):
            return "压缩包"
        elif ext in ('.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.pdf', '.txt'):
            return "文档文件"
        elif ext in ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.ico'):
            return "图片文件"
        elif ext in ('.mp3', '.mp4', '.avi', '.mkv', '.wav', '.flac'):
            return "媒体文件"
        elif ext == '.lnk':
            return "快捷方式"
        else:
            return "普通文件"'''

new_type_check = '''    # 性能优化：文件类型字典映射
    _FILE_TYPE_MAP = {
        '.exe': 'PE可执行文件', '.dll': 'PE可执行文件', '.sys': 'PE可执行文件',
        '.scr': 'PE可执行文件', '.com': 'PE可执行文件',
        '.bat': '脚本文件', '.cmd': '脚本文件', '.ps1': '脚本文件',
        '.vbs': '脚本文件', '.js': '脚本文件', '.jse': '脚本文件',
        '.wsf': '脚本文件', '.wsh': '脚本文件',
        '.msi': '安装包', '.msp': '安装包',
        '.zip': '压缩包', '.rar': '压缩包', '.7z': '压缩包',
        '.tar': '压缩包', '.gz': '压缩包',
        '.doc': '文档文件', '.docx': '文档文件', '.xls': '文档文件',
        '.xlsx': '文档文件', '.ppt': '文档文件', '.pptx': '文档文件',
        '.pdf': '文档文件', '.txt': '文档文件',
        '.jpg': '图片文件', '.jpeg': '图片文件', '.png': '图片文件',
        '.gif': '图片文件', '.bmp': '图片文件', '.ico': '图片文件',
        '.mp3': '媒体文件', '.mp4': '媒体文件', '.avi': '媒体文件',
        '.mkv': '媒体文件', '.wav': '媒体文件', '.flac': '媒体文件',
        '.lnk': '快捷方式',
    }
    
    def _detect_file_type(self, path):
        """根据扩展名检测文件类型（字典映射，性能优化）。"""
        ext = os.path.splitext(path)[1].lower()
        return self._FILE_TYPE_MAP.get(ext, "普通文件")'''

if old_type_check in e:
    e = e.replace(old_type_check, new_type_check, 1)
    print("2. 文件类型判断优化完成（字典映射代替if-elif）")
else:
    print("2. 未找到文件类型判断代码，跳过")

# 3. 优化scan_file：快速路径，普通文件直接返回，不做深度分析
old_scan_start = '''    def scan_file(self, path):
        """扫描单个文件，返回ScanResult。"""
        try:
            stat = os.stat(path)
            size = stat.st_size
            name = os.path.basename(path)
            ext = os.path.splitext(name)[1].lower()'''

new_scan_start = '''    def scan_file(self, path):
        """扫描单个文件，返回ScanResult（性能优化：普通文件快速路径）。"""
        try:
            stat = os.stat(path)
            size = stat.st_size
            name = os.path.basename(path)
            ext = os.path.splitext(name)[1].lower()
            
            # 性能优化：普通文件快速路径，不做深度分析
            if ext in ('.txt', '.log', '.tmp', '.bak', '.old', '.dat', '.ini', '.cfg', '.conf'):
                if size < 1024 * 1024:  # 小于1MB的普通文件直接返回
                    return ScanResult(
                        path=path, name=name, ext=ext,
                        category="普通文件", size=size,
                        sha256="", level=LEVEL_SAFE,
                        score=0, reasons=[]
                    )'''

if old_scan_start in e:
    e = e.replace(old_scan_start, new_scan_start, 1)
    print("3. 普通文件快速路径优化完成")
else:
    print("3. 未找到scan_file开头代码，跳过")

with open('engine.py', 'w', encoding='utf-8') as f:
    f.write(e)

print("\nengine.py 扫描性能优化完成！")
