# -*- coding: utf-8 -*-
"""4.15.1 补丁：真进度条丝滑化（16ms 插值动画 + 百分比/总数显示）"""
import io

MAIN = r"F:\桌面保护\desktopguard\main.py"
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()
orig = m

def rep(old, new, tag):
    global m
    assert old in m, f"未找到锚点: {tag}"
    assert m.count(old) == 1, f"锚点重复: {tag} ({m.count(old)})"
    m = m.replace(old, new, 1)

# ============ 1) 进度条改为「进度条 + 百分比标签」同行布局 ============
rep('''        self.progress = ttk.Progressbar(scard_in, style="Horizontal.TProgressbar",
                                        mode="indeterminate", length=200)
        self.progress.pack(fill="x", pady=(8, 4))''',
    '''        prog_row = tk.Frame(scard_in, bg=C_CARD)
        prog_row.pack(fill="x", pady=(8, 4))
        self.progress = ttk.Progressbar(prog_row, style="Horizontal.TProgressbar",
                                        mode="indeterminate", length=200)
        self.progress.pack(side="left", fill="x", expand=True)
        self.scan_pct = tk.Label(prog_row, text="--%", bg=C_CARD, fg=C_SUB,
                                 font=("Microsoft YaHei UI", 9, "bold"))
        self.scan_pct.pack(side="right", padx=(8, 0))
        self._prog_target = 0''',
    "进度条+百分比布局")

# ============ 2) 平滑动画函数（加在 _schedule_refresh 之前） ============
rep('''    def _schedule_refresh(self):
        """刷新节流：最多每 0.3s 增量刷新一次表格，避免大量插入导致卡顿。"""''',
    '''    def _animate_progress(self):
        """真进度条平滑动画：每 16ms 向目标值插值爬升（指数趋近），丝滑不跳变。
        扫描结束或切回弹性块时自动退出（链断）。"""
        if not self.scanning or not self.config.get("progress_bar_mode", False):
            return
        try:
            cur = float(self.progress["value"])
            tgt = float(getattr(self, "_prog_target", 0))
            mx = float(self.progress["maximum"]) or 1
            if tgt > mx:
                tgt = mx
            diff = tgt - cur
            if abs(diff) < 0.8:
                self.progress.config(value=tgt)
            else:
                self.progress.config(value=cur + diff * 0.25)
        except Exception:
            pass
        self.root.after(16, self._animate_progress)

    def _schedule_refresh(self):
        """刷新节流：最多每 0.3s 增量刷新一次表格，避免大量插入导致卡顿。"""''',
    "平滑动画函数")

# ============ 3) 扫描开始：切 determinate 时启动动画 + 百分比复位 ============
rep('''        if self.config.get("progress_bar_mode", False):
            # 真进度条：determinate，预统计总数到达后更新 maximum
            try:
                self.progress.config(mode="determinate", maximum=1, value=0)
            except Exception:
                pass
        else:
            self.progress.start(12)''',
    '''        if self.config.get("progress_bar_mode", False):
            # 真进度条：determinate，预统计总数到达后更新 maximum
            try:
                self.progress.config(mode="determinate", maximum=1, value=0)
                self._prog_target = 0
                self.scan_pct.config(text="--%")
            except Exception:
                pass
            self.root.after(16, self._animate_progress)
        else:
            self.progress.start(12)''',
    "扫描开始-动画启动")

# ============ 4) scan_total：设 maximum + 显示总数 ============
rep('''                elif kind == "scan_total":
                    _tot = item[1]
                    if self.config.get("progress_bar_mode", False):
                        try:
                            self.progress.config(mode="determinate",
                                                 maximum=max(_tot, 1), value=0)
                        except Exception:
                            pass''',
    '''                elif kind == "scan_total":
                    _tot = item[1]
                    if self.config.get("progress_bar_mode", False):
                        try:
                            self.progress.config(mode="determinate",
                                                 maximum=max(_tot, 1), value=0)
                            self._prog_target = 0
                            self.scan_pct.config(text="0%（共 %d 个）" % _tot)
                        except Exception:
                            pass''',
    "scan_total-显示总数")

# ============ 5) progress 分支：只设目标值 + 更新百分比（动画驱动实际值） ============
rep('''                    if self.config.get("progress_bar_mode", False):
                        try:
                            _mx = getattr(self, "_scan_total", 0) or 1
                            self.progress.config(value=min(_show_n, _mx))
                        except Exception:
                            pass''',
    '''                    if self.config.get("progress_bar_mode", False):
                        try:
                            _mx = getattr(self, "_scan_total", 0) or 1
                            self._prog_target = min(_show_n, _mx)
                            _pct = int(min(_show_n, _mx) / _mx * 100)
                            self.scan_pct.config(text="%d%%（共 %d 个）" % (_pct, _mx))
                        except Exception:
                            pass''',
    "progress-目标值+百分比")

# ============ 6) core_progress 分支：同样只设目标值 + 百分比 ============
rep('''                    if self.config.get("progress_bar_mode", False):
                        try:
                            self.progress.config(maximum=max(total, 1),
                                                 value=min(done, total))
                        except Exception:
                            pass''',
    '''                    if self.config.get("progress_bar_mode", False):
                        try:
                            self.progress.config(maximum=max(total, 1))
                            self._prog_target = min(done, total)
                            _pct = int(min(done, total) / max(total, 1) * 100)
                            self.scan_pct.config(text="%d%%（共 %d 个）" % (_pct, total))
                        except Exception:
                            pass''',
    "core_progress-目标值+百分比")

# ============ 7) 扫描完成：置满 + 百分比完成 ============
rep('''        self.progress.stop()
        if self.config.get("progress_bar_mode", False):
            try:
                self.progress.config(mode="determinate", maximum=1, value=1)
            except Exception:
                pass
        self._set_sub_status("")''',
    '''        self.progress.stop()
        if self.config.get("progress_bar_mode", False):
            try:
                self.progress.config(mode="determinate", maximum=1, value=1)
                self._prog_target = 1
                self.scan_pct.config(text="100%")
            except Exception:
                pass
        self._set_sub_status("")''',
    "扫描完成-百分比")

# ============ 8) 版本号 & 历史 ============
rep('APP_VERSION = "4.15.0"', 'APP_VERSION = "4.15.1"', "版本号")
rep('''    ("4.15.0", "4.14.1", "内容更新（免打扰模式+真进度条）：''',
    '''    ("4.15.1", "4.15.0", "补丁（真进度条丝滑化）：1.【进度条平滑动画】真进度条不再一格一格跳——16ms 插值动画向目标值指数爬升（约 60fps），进度更新丝滑不卡顿；2.【百分比+总数显示】进度条右侧新增实时百分比标签，显示「42%（共 30000 个）」，弹性块模式下显示 --%；3.【完成态】扫描结束进度条平滑走到 100%"),
    ("4.15.0", "4.14.1", "内容更新（免打扰模式+真进度条）：''',
    "版本历史")

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)

import py_compile
py_compile.compile(MAIN, doraise=True)
print("[OK] 4.15.1 补丁全部应用，语法通过")
print(f"文件长度: {len(orig)} -> {len(m)}")
