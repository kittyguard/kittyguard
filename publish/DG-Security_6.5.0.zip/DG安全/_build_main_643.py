# -*- coding: utf-8 -*-
"""6.4.3 重新打包主程序到 dist/DG安全（onedir），含 _internal 数据目录"""
import os, shutil, subprocess

PYI = r"C:\Users\Administrator\AppData\Local\Programs\Python\Python312\Scripts\pyinstaller.exe"
DG = r"F:\桌面保护\desktopguard"
DIST = os.path.join(DG, "dist", "DG安全")
WORK = os.path.join(DG, "build", "main_work")

# 清旧产物，避免残留
for p in (DIST, WORK, os.path.join(DG, "build", "DG安全"), os.path.join(DG, "DG安全.spec")):
    if os.path.isdir(p):
        shutil.rmtree(p, ignore_errors=True)
    elif os.path.isfile(p):
        try: os.remove(p)
        except Exception: pass

cmd = [PYI, "--onedir", "--noconsole", "--clean", "--name", "DG安全",
       "--distpath", os.path.join(DG, "dist"),
       "--workpath", WORK, "--specpath", WORK,
       "--paths", DG,
       os.path.join(DG, "main.py")]
print("CMD:", " ".join(cmd), flush=True)
r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore")
print("exit:", r.returncode, flush=True)
ok = os.path.isfile(os.path.join(DIST, "DG安全.exe"))
print("main exe exists:", ok, flush=True)
if not ok:
    print((r.stdout or "")[-3000:], flush=True)
    print((r.stderr or "")[-3000:], flush=True)
else:
    n = sum(len(fs) for _, _, fs in os.walk(DIST))
    print("dist files:", n, flush=True)
print("MAIN_BUILD_DONE", flush=True)
