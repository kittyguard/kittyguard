// ============================================================
// DG Quarantine - C++ 隔离区引擎 (配合 DG 2.15.0)
// 功能:
//   1. isolate  : 文件 XOR(0xA5) 编码 -> 移入隔离目录, 删除原文件, 记录元数据
//   2. restore  : 从隔离目录还原 (XOR 解码 + 哈希校验 + 写回原路径)
//   3. verify   : 校验隔离文件完整性
// 编译: g++ -O2 -std=c++17 -o dg_quarantine.exe dg_quarantine.cpp
// 用法:
//   dg_quarantine.exe isolate <src> <quarantine_dir> [meta_dir]
//   dg_quarantine.exe restore <dgq_file> [meta_dir]
//   dg_quarantine.exe verify <dgq_file>
// 输出: JSON 到 stdout (含 success/msg/path/sha256/size)
// ============================================================

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <ctime>
#include <sstream>

// ---- XOR 编码 (与 Python 侧兼容: key=0xA5) ----
static void xor_buf(BYTE* buf, size_t n, BYTE key) {
    for (size_t i = 0; i < n; i++) buf[i] ^= key;
}

// ---- SHA256 (CryptoAPI) ----
static std::string sha256_file(const std::wstring& path) {
    HCRYPTPROV prov = 0;
    HCRYPTHASH hash = 0;
    std::string out;
    if (!CryptAcquireContextW(&prov, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT))
        return out;
    if (CryptCreateHash(prov, CALG_SHA_256, 0, 0, &hash)) {
        BYTE buf[1 << 16];
        HANDLE hf = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hf != INVALID_HANDLE_VALUE) {
            DWORD rd = 0;
            while (ReadFile(hf, buf, sizeof(buf), &rd, NULL) && rd > 0)
                CryptHashData(hash, buf, rd, 0);
            CloseHandle(hf);
            BYTE digest[32];
            DWORD dlen = 32;
            if (CryptGetHashParam(hash, HP_HASHVAL, digest, &dlen, 0)) {
                static const char* hex = "0123456789abcdef";
                for (DWORD i = 0; i < dlen; i++) {
                    out += hex[digest[i] >> 4];
                    out += hex[digest[i] & 0xF];
                }
            }
        }
        CryptDestroyHash(hash);
    }
    CryptReleaseContext(prov, 0);
    return out;
}

// ---- JSON 转义 ----
static std::string json_escape(const std::wstring& s) {
    std::string out;
    for (wchar_t c : s) {
        if (c == L'"') out += "\\\"";
        else if (c == L'\\') out += "\\\\";
        else if (c == L'\n') out += "\\n";
        else if (c == L'\r') out += "\\r";
        else if (c == L'\t') out += "\\t";
        else if (c < 0x20) { char b[8]; sprintf(b, "\\u%04x", c); out += b; }
        else if (c < 0x80) out += (char)c;
        else {
            // UTF-8 编码
            unsigned int cp = c;
            if (cp >= 0xD800 && cp <= 0xDBFF) continue; // 简单跳过代理对高位(文件名场景极少)
            if (cp < 0x800) {
                out += (char)(0xC0 | (cp >> 6));
                out += (char)(0x80 | (cp & 0x3F));
            } else if (cp < 0x10000) {
                out += (char)(0xE0 | (cp >> 12));
                out += (char)(0x80 | ((cp >> 6) & 0x3F));
                out += (char)(0x80 | (cp & 0x3F));
            }
        }
    }
    return out;
}

// ---- UTF-8 -> 宽字符 ----
static std::wstring utf8_to_wide(const char* s) {
    int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, NULL, 0);
    if (n <= 0) return L"";
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n);
    if (!w.empty() && w.back() == L'\0') w.pop_back();
    return w;
}

// ---- 打印 JSON 结果 ----
static void print_json(bool ok, const wchar_t* msg, const std::wstring& path,
                       const std::string& sha, const std::wstring& dgq = L"") {
    // 统一 UTF-8 字节直出（printf %s），避免 wprintf %ls 的类型错配/转码变 '?'
    printf("{\"success\":%s,\"msg\":\"%s\",\"path\":\"%s\",\"sha256\":\"%s\",\"dgq\":\"%s\"}\n",
           ok ? "true" : "false",
           json_escape(msg ? msg : L"").c_str(),
           json_escape(path).c_str(), sha.c_str(),
           json_escape(dgq).c_str());
}

// ---- 隔离 ----
static int do_isolate(const std::wstring& src, const std::wstring& qdir,
                      const std::wstring& metadir) {
    HANDLE hIn = CreateFileW(src.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hIn == INVALID_HANDLE_VALUE) {
        print_json(false, L"open source failed", src, "");
        return 1;
    }
    LARGE_INTEGER sz = {0};
    GetFileSizeEx(hIn, &sz);
    if (sz.QuadPart > (LONGLONG)2 * 1024 * 1024 * 1024) { // 2GB 上限
        CloseHandle(hIn);
        print_json(false, L"file too large", src, "");
        return 1;
    }
    std::vector<BYTE> data((size_t)sz.QuadPart);
    DWORD rd = 0, total = 0;
    while (total < data.size()) {
        if (!ReadFile(hIn, data.data() + total, (DWORD)(data.size() - total), &rd, NULL) || rd == 0)
            break;
        total += rd;
    }
    CloseHandle(hIn);
    if (total != data.size()) {
        print_json(false, L"read incomplete", src, "");
        return 1;
    }

    // 计算原始哈希
    std::string sha = sha256_file(src);

    // 目标名: <sha前16>_<时间戳>.dgq
    char ts[32];
    sprintf(ts, "%lld", (long long)time(NULL));
    std::wstring fname = utf8_to_wide((sha.substr(0, 16) + "_" + ts).c_str()) + L".dgq";
    CreateDirectoryW(qdir.c_str(), NULL);
    std::wstring dgq = qdir + L"\\" + fname;

    // XOR 编码
    xor_buf(data.data(), data.size(), 0xA5);

    HANDLE hOut = CreateFileW(dgq.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL, NULL);
    if (hOut == INVALID_HANDLE_VALUE) {
        print_json(false, L"create dgq failed", src, "", dgq);
        return 1;
    }
    DWORD wr = 0;
    WriteFile(hOut, data.data(), (DWORD)data.size(), &wr, NULL);
    CloseHandle(hOut);

    // 元数据 (JSON 旁路文件)
    if (!metadir.empty()) {
        CreateDirectoryW(metadir.c_str(), NULL);
        std::wstring mpath = metadir + L"\\" + fname + L".meta.json";
        char buf[4096];
        snprintf(buf, sizeof(buf),
                 "{\"original_path\":\"%s\",\"size\":%zu,\"sha256\":\"%s\",\"quarantined_at\":%lld}\n",
                 json_escape(src).c_str(), data.size(), sha.c_str(), (long long)time(NULL));
        HANDLE hM = CreateFileW(mpath.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                                FILE_ATTRIBUTE_NORMAL, NULL);
        if (hM != INVALID_HANDLE_VALUE) {
            DWORD mw = 0;
            WriteFile(hM, buf, (DWORD)strlen(buf), &mw, NULL);
            CloseHandle(hM);
        }
    }

    // 删除原文件 (移入回收站更安全, 但隔离场景直接删)
    if (!DeleteFileW(src.c_str())) {
        print_json(false, L"delete source failed (file kept)", src, sha, dgq);
        return 2;
    }
    print_json(true, L"isolated", src, sha, dgq);
    return 0;
}

// ---- 恢复 ----
static int do_restore(const std::wstring& dgq, const std::wstring& metadir) {
    HANDLE hIn = CreateFileW(dgq.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hIn == INVALID_HANDLE_VALUE) {
        print_json(false, L"dgq not found", dgq, "");
        return 1;
    }
    LARGE_INTEGER sz = {0};
    GetFileSizeEx(hIn, &sz);
    std::vector<BYTE> data((size_t)sz.QuadPart);
    DWORD rd = 0, total = 0;
    while (total < data.size()) {
        if (!ReadFile(hIn, data.data() + total, (DWORD)(data.size() - total), &rd, NULL) || rd == 0)
            break;
        total += rd;
    }
    CloseHandle(hIn);
    if (total != data.size()) {
        print_json(false, L"read dgq incomplete", dgq, "");
        return 1;
    }
    xor_buf(data.data(), data.size(), 0xA5);

    // 原始路径: 优先从元数据读
    std::wstring orig;
    if (!metadir.empty()) {
        std::wstring base = dgq.substr(dgq.find_last_of(L'\\') + 1);
        std::wstring mpath = metadir + L"\\" + base + L".meta.json";
        HANDLE hM = CreateFileW(mpath.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hM != INVALID_HANDLE_VALUE) {
            DWORD msz = GetFileSize(hM, NULL);
            std::vector<char> mb(msz + 1, 0);
            DWORD mrd = 0;
            ReadFile(hM, mb.data(), msz, &mrd, NULL);
            CloseHandle(hM);
            std::string s(mb.data(), mrd);
            // 提取 "original_path":"..."
            size_t k = s.find("\"original_path\":\"");
            if (k != std::string::npos) {
                k += 17;
                size_t e = s.find('"', k);
                if (e != std::string::npos) {
                    std::string raw = s.substr(k, e - k);
                    // 反转义
                    std::string un;
                    for (size_t i = 0; i < raw.size(); i++) {
                        if (raw[i] == '\\' && i + 1 < raw.size()) {
                            if (raw[i + 1] == '"') { un += '"'; i++; }
                            else if (raw[i + 1] == '\\') { un += '\\'; i++; }
                            else if (raw[i + 1] == 'n') { un += '\n'; i++; }
                            else un += raw[i];
                        } else un += raw[i];
                    }
                    orig = utf8_to_wide(un.c_str());
                }
            }
        }
    }
    if (orig.empty())
        orig = dgq.substr(0, dgq.find_last_of(L'.')); // 回退: 去掉 .dgq

    // 写回
    CreateDirectoryW(orig.substr(0, orig.find_last_of(L'\\')).c_str(), NULL);
    HANDLE hOut = CreateFileW(orig.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL, NULL);
    if (hOut == INVALID_HANDLE_VALUE) {
        print_json(false, L"create original failed", orig, "");
        return 1;
    }
    DWORD wr = 0;
    WriteFile(hOut, data.data(), (DWORD)data.size(), &wr, NULL);
    CloseHandle(hOut);

    // 校验哈希
    std::string sha = sha256_file(orig);

    // 删 dgq + 元数据
    DeleteFileW(dgq.c_str());
    if (!metadir.empty()) {
        std::wstring base = dgq.substr(dgq.find_last_of(L'\\') + 1);
        DeleteFileW((metadir + L"\\" + base + L".meta.json").c_str());
    }
    print_json(true, L"restored", orig, sha);
    return 0;
}

// ---- 校验 ----
static int do_verify(const std::wstring& dgq) {
    HANDLE hIn = CreateFileW(dgq.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hIn == INVALID_HANDLE_VALUE) {
        print_json(false, L"dgq not found", dgq, "");
        return 1;
    }
    LARGE_INTEGER sz = {0};
    GetFileSizeEx(hIn, &sz);
    CloseHandle(hIn);
    printf("{\"success\":true,\"msg\":\"ok\",\"path\":\"%s\",\"size\":%lld,\"sha256\":\"%s\"}\n",
           json_escape(dgq).c_str(), (long long)sz.QuadPart, "");
    return 0;
}

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) {
        printf("{\"success\":false,\"msg\":\"usage: dg_quarantine isolate|restore|verify ...\"}\n");
        return 1;
    }
    std::wstring cmd = argv[1];
    if (cmd == L"isolate" && argc >= 4) {
        return do_isolate(argv[2], argv[3], argc >= 5 ? argv[4] : L"");
    } else if (cmd == L"restore" && argc >= 3) {
        return do_restore(argv[2], argc >= 4 ? argv[3] : L"");
    } else if (cmd == L"verify" && argc >= 3) {
        return do_verify(argv[2]);
    }
    printf("{\"success\":false,\"msg\":\"bad args\"}\n");
    return 1;
}
