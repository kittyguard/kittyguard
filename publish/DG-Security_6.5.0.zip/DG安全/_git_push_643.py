# -*- coding: utf-8 -*-
import subprocess
SITE = r"F:\桌面保护\kittyguard_site"
cmds = [
    ["git", "-C", SITE, "add", "-A"],
    ["git", "-C", SITE, "commit", "-m", "release 6.4.3: 发行修复版（ClamAV 去代理/卸载零残留/向导版工具可用/开机动画分离）+ 官网链接更新"],
    ["git", "-C", SITE, "push", "origin", "main"],
]
for c in cmds:
    r = subprocess.run(c, capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=900)
    print("$", " ".join(c))
    print("exit:", r.returncode)
    print((r.stdout or "")[-1200:])
    print((r.stderr or "")[-1200:])
    if r.returncode != 0:
        break
print("GIT_PUSH_DONE")
