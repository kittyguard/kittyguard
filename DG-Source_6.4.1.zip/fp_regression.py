# -*- coding: utf-8 -*-
"""DG 安全 6.0.0-beta.1 · 误报回归闭环工具 fp_regression.py

设计原则（来自 6.0.0 规划，GPT 评审确认）：
  - 用户反馈不直接改线上规则，必须经回归集验证
  - 样本字段结构化：SHA256 / 文件名 / 路径 / 大小 / PE 信息 / 命中规则 / 原始分数 / 最终裁决 / 用户标签 / 备注
  - 权重配置版本化，可回滚
  - AI 只做解释辅助，不单独定罪；白名单是降分器不是免死金牌

用法：
  python fp_regression.py collect <文件路径> <标签> [备注]    # 登记样本（标签：benign/malicious/unknown）
  python fp_regression.py collect-dir <目录> <标签>            # 批量登记目录下所有文件
  python fp_regression.py run [--limit N]                     # 全量回归：重扫样本集并对比标签，输出报告
  python fp_regression.py stats                               # 样本集统计
  python fp_regression.py export <输出目录>                   # 导出当前回归集 + 权重配置（版本化备份）

样本库：dgdata\\fp_samples\\samples.json
权重版本：dgdata\\fp_samples\\weights.json
报告：dgdata\\fp_samples\\regression_report_<时间戳>.txt
"""
import os
import sys
import json
import time
import hashlib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.getenv("DG_DATA_DIR", r"F:\桌面保护\dgdata")
SAMPLES_DIR = os.path.join(DATA_DIR, "fp_samples")
SAMPLES_JSON = os.path.join(SAMPLES_DIR, "samples.json")
WEIGHTS_JSON = os.path.join(SAMPLES_DIR, "weights.json")

LEVELS = ("safe", "low", "suspicious", "high", "malicious")


def _log(msg):
    print(msg, flush=True)


# ============ 特征提取 ============

def _sha256(path, chunk=1024 * 1024):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                b = f.read(chunk)
                if not b:
                    break
                h.update(b)
    except OSError:
        return ""
    return h.hexdigest()


def _extract_features(path):
    """提取样本静态特征（不依赖引擎，纯文件系统层）。"""
    feats = {"size": 0, "ext": "", "is_pe": False}
    try:
        feats["size"] = os.path.getsize(path)
    except OSError:
        pass
    feats["ext"] = os.path.splitext(path)[1].lower()
    try:
        with open(path, "rb") as f:
            head = f.read(4096)
        feats["is_pe"] = head[:2] == b"MZ" and "PE\x00\x00" in head[0x3C:0x3C + 256]
    except OSError:
        pass
    return feats


# ============ 样本库读写 ============

def _load_samples():
    if not os.path.exists(SAMPLES_JSON):
        return {"version": "1.0", "samples": []}
    try:
        with open(SAMPLES_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"version": "1.0", "samples": []}


def _save_samples(data):
    os.makedirs(SAMPLES_DIR, exist_ok=True)
    with open(SAMPLES_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _load_weights():
    if os.path.exists(WEIGHTS_JSON):
        try:
            with open(WEIGHTS_JSON, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"version": "6.0.0-beta.1", "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "note": "当前使用 verdict_engine.assess 内置权重（5.4.0 起）。后续调权以本文件为准并版本化回滚。"}


def _save_weights(data):
    os.makedirs(SAMPLES_DIR, exist_ok=True)
    with open(WEIGHTS_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ============ collect ============

def collect_fp(path, label, note=""):
    """登记一个样本（benign=误报 / malicious=漏报 / unknown=待定）。"""
    if label not in ("benign", "malicious", "unknown"):
        _log("标签必须是 benign / malicious / unknown")
        return False
    if not os.path.isfile(path):
        _log("文件不存在: %s" % path)
        return False
    sha = _sha256(path)
    if not sha:
        _log("无法计算哈希: %s" % path)
        return False
    feats = _extract_features(path)
    samples = _load_samples()
    for s in samples["samples"]:
        if s["sha256"] == sha:
            s["label"] = label
            s["note"] = note or s.get("note", "")
            s["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            _save_samples(samples)
            _log("已更新样本（同哈希）：%s → %s" % (s["path"], label))
            return True
    rec = {
        "sha256": sha,
        "file_name": os.path.basename(path),
        "path": os.path.abspath(path),
        "size": feats["size"],
        "ext": feats["ext"],
        "is_pe": feats["is_pe"],
        "label": label,
        "note": note,
        "first_seen": time.strftime("%Y-%m-%d %H:%M:%S"),
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        # 以下字段由 run_regression 回填（原始扫描结果，用于调权对比）
        "last_scan_score": None,
        "last_scan_level": None,
        "last_scan_verdict": None,
        "last_scan_tags": [],
    }
    samples["samples"].append(rec)
    _save_samples(samples)
    _log("已登记样本：%s [%s] (%s 字节, %s)" % (os.path.basename(path), label, feats["size"], sha[:12]))
    return True


def collect_dir(path, label):
    n = 0
    for root, _dirs, files in os.walk(path):
        for fn in files:
            fp = os.path.join(root, fn)
            try:
                if collect_fp(fp, label):
                    n += 1
            except Exception:
                continue
    _log("批量登记完成：%d 个文件" % n)
    return n


# ============ run regression ============

def run_regression(limit=0):
    """全量回归：对样本集重新扫描 + 统一裁决，与用户标签对比，输出报告。"""
    samples = _load_samples()
    all_s = samples.get("samples", [])
    if not all_s:
        _log("样本集为空，先 collect")
        return
    if limit and limit > 0:
        all_s = all_s[:limit]

    sys.path.insert(0, BASE_DIR)
    from engine import Scanner
    import verdict_engine

    scanner = Scanner(hash_all=False)  # 快速模式：仅可疑候选算哈希，回归不卡
    mis_fp, mis_fn = [], []  # 误报（标 benign 被判非 safe）、漏报（标 malicious 被判非 malicious）
    rows = []
    t0 = time.time()
    for s in all_s:
        path = s.get("path", "")
        if not path or not os.path.isfile(path):
            rows.append({"sha": s["sha256"], "file": s["file_name"], "label": s["label"],
                         "verdict": "missing_file", "score": None})
            continue
        try:
            res = scanner.scan_file(path)
            tags = list(res.tags)
            hits = list(res.hits)
            v = verdict_engine.assess(
                path=path, name=res.name, category=res.category, sha256=res.sha256,
                res_tags=tags, res_hits=hits, whitelisted=res.whitelisted,
                signed_valid=res.signed_valid)
            verdict = v.get("verdict", "")
            level = v.get("level", "")
            score = v.get("final_score", 0)
        except Exception as e:
            verdict, level, score = "error", "error", -1
            tags = ["ERROR: %r" % e]

        # 回填原始扫描结果
        s["last_scan_score"] = score
        s["last_scan_level"] = level
        s["last_scan_verdict"] = verdict
        s["last_scan_tags"] = tags[:10]

        label = s.get("label", "unknown")
        # 判定：benign 应得 safe/low；malicious 应得 high/malicious
        is_bad = level in ("high", "critical") or score > 60
        if label == "benign" and is_bad:
            mis_fp.append(s["file_name"])
        if label == "malicious" and not is_bad:
            mis_fn.append(s["file_name"])
        rows.append({"sha": s["sha256"], "file": s["file_name"], "label": label,
                     "verdict": verdict, "level": level, "score": score})
        _log("  %s [%s] → %s %s分" % (s["file_name"], label, level, score))
    _save_samples(samples)
    elapsed = time.time() - t0

    n_b = sum(1 for r in all_s if r.get("label") == "benign")
    n_m = sum(1 for r in all_s if r.get("label") == "malicious")
    fp_rate = len(mis_fp) / n_b if n_b else 0.0
    fn_rate = len(mis_fn) / n_m if n_m else 0.0

    report = _build_report(all_s, rows, fp_rate, fn_rate, len(mis_fp), len(mis_fn),
                           n_b, n_m, elapsed, limit)
    os.makedirs(SAMPLES_DIR, exist_ok=True)
    rp = os.path.join(SAMPLES_DIR, "regression_report_%s.txt" % time.strftime("%Y%m%d_%H%M%S"))
    with open(rp, "w", encoding="utf-8") as f:
        f.write(report)
    _log("报告已导出：%s" % rp)
    return {"fp": len(mis_fp), "fn": len(mis_fn), "fp_rate": fp_rate, "fn_rate": fn_rate,
            "benign": n_b, "malicious": n_m, "report": rp}


def _build_report(all_s, rows, fp_rate, fn_rate, n_fp, n_fn, n_b, n_m, elapsed, limit):
    lines = []
    lines.append("DG 安全 误报回归报告")
    lines.append("时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"))
    lines.append("样本总数：%d%s" % (len(rows), ("（limit=%d）" % limit) if limit else ""))
    lines.append("  benign（误报类）：%d    误报数：%d    误报率：%.2f%%" % (n_b, n_fp, fp_rate * 100))
    lines.append("  malicious（漏报类）：%d  漏报数：%d    漏报率：%.2f%%" % (n_m, n_fn, fn_rate * 100))
    lines.append("  elapsed：%.1f 秒" % elapsed)
    lines.append("")
    if n_fp:
        lines.append("== 误报明细（标良性被判危） ==")
        for r in rows:
            if r["label"] == "benign" and r["score"] is not None and (r["score"] > 60 or r["level"] in ("high", "critical")):
                lines.append("  %s | %s %s分 | %s" % (r["file"], r["level"], r["score"], r["sha"][:12]))
    if n_fn:
        lines.append("== 漏报明细（标恶意未判危） ==")
        for r in rows:
            if r["label"] == "malicious" and r["score"] is not None and not (r["score"] > 60 or r["level"] in ("high", "critical")):
                lines.append("  %s | %s %s分 | %s" % (r["file"], r["level"], r["score"], r["sha"][:12]))
    lines.append("")
    lines.append("== 权重版本（当前） ==")
    w = _load_weights()
    lines.append(json.dumps(w, ensure_ascii=False, indent=2))
    lines.append("")
    lines.append("说明：本报告仅为证据，不自动修改线上规则。调权前先备份本报告并更新 weights.json 版本号。")
    return "\n".join(lines)


# ============ stats / export ============

def stats():
    samples = _load_samples()
    all_s = samples.get("samples", [])
    from collections import Counter
    c = Counter(s.get("label", "unknown") for s in all_s)
    _log("样本总数：%d" % len(all_s))
    for k, v in sorted(c.items()):
        _log("  %s: %d" % (k, v))
    if all_s:
        _log("示例（前 5）：")
        for s in all_s[:5]:
            _log("  %s [%s] %s" % (s["file_name"], s["label"], s["sha256"][:12]))


def export(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    if os.path.exists(SAMPLES_JSON):
        import shutil
        shutil.copy2(SAMPLES_JSON, os.path.join(out_dir, "samples.json"))
    w = _load_weights()
    with open(os.path.join(out_dir, "weights.json"), "w", encoding="utf-8") as f:
        json.dump(w, f, ensure_ascii=False, indent=2)
    _log("已导出样本集 + 权重配置到：%s" % out_dir)


def main():
    args = sys.argv[1:]
    if not args:
        _log(__doc__)
        return
    cmd = args[0]
    if cmd == "collect" and len(args) >= 3:
        collect_fp(args[1], args[2], args[3] if len(args) > 3 else "")
    elif cmd == "collect-dir" and len(args) >= 3:
        collect_dir(args[1], args[2])
    elif cmd == "run":
        limit = 0
        if "--limit" in args:
            try:
                limit = int(args[args.index("--limit") + 1])
            except Exception:
                limit = 0
        run_regression(limit)
    elif cmd == "stats":
        stats()
    elif cmd == "export" and len(args) >= 2:
        export(args[1])
    else:
        _log(__doc__)


if __name__ == "__main__":
    main()
