# -*- coding: utf-8 -*-
"""4.16.0 补丁：工具页新增「进程管理器」卡片 + 独立窗口启动 + 版本号"""
import io

MAIN = r"F:\桌面保护\desktopguard\main.py"
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()

def rep(old, new, tag):
    global m
    assert old in m, f"未找到锚点: {tag}"
    assert m.count(old) == 1, f"锚点重复: {tag} ({m.count(old)})"
    m = m.replace(old, new, 1)

# ============ 1) 工具页新增「进程管理」卡片（t8，插在权限信息卡片后） ============
rep('''        ttk.Button(t7, text="查看当前权限", style="Accent.TButton", command=self._show_privileges).pack(anchor="w", pady=(6, 0))''',
    '''        ttk.Button(t7, text="查看当前权限", style="Accent.TButton", command=self._show_privileges).pack(anchor="w", pady=(6, 0))
        t8 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)
        t8.pack(fill="x", pady=4)
        tk.Label(t8, text="进程管理", bg=C_CARD2, fg=C_PRIMARY,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")
        tk.Label(t8, text="列出全部进程（PID/名称/CPU%/内存/路径/状态），按 CPU/内存排序、关键词过滤、一键终止；系统关键进程与 DG 自身进程受保护，支持进程白名单",
                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))
        ttk.Button(t8, text="打开进程管理器", style="Accent.TButton", command=self._open_process_manager).pack(anchor="w", pady=(6, 0))''',
    "工具页进程管理卡片")

# ============ 2) _open_process_manager 方法（独立进程，防重复启动） ============
rep('''    def _open_perf_overlay(self):
        """打开性能悬浮窗（独立进程，防重复启动）"""''',
    '''    def _open_process_manager(self):
        """打开进程管理器（独立进程，防重复启动）"""
        import ctypes
        found = []
        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def cb(h, l):
            if ctypes.windll.user32.IsWindowVisible(h):
                buf = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetWindowTextW(h, buf, 256)
                if "DG 进程管理器" in buf.value:
                    found.append(h)
            return True
        try:
            ctypes.windll.user32.EnumWindows(cb, 0)
        except Exception:
            pass
        if found:
            messagebox.showinfo("进程管理器", "进程管理器已在运行。")
            return
        script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "process_manager.py")
        if not os.path.exists(script):
            messagebox.showerror("进程管理器", "未找到 process_manager.py（应位于 DG 程序目录）。")
            return
        try:
            exe = sys.executable
            if exe and exe.lower().endswith("python.exe"):
                exe = exe[:-len("python.exe")] + "pythonw.exe"
            if not exe or not os.path.exists(exe):
                exe = sys.executable
            subprocess.Popen([exe, script],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            messagebox.showinfo("进程管理器", "进程管理器已打开。")
        except Exception as e:
            messagebox.showerror("进程管理器", f"启动失败：{e}")

    def _open_perf_overlay(self):
        """打开性能悬浮窗（独立进程，防重复启动）"""''',
    "进程管理器启动方法")

# ============ 3) 版本号 & 历史 ============
rep('APP_VERSION = "4.15.2"', 'APP_VERSION = "4.16.0"', "版本号")
rep('''    ("4.15.2", "4.15.1", "补丁（扫描自动切页）：''',
    '''    ("4.16.0", "4.15.2", "内容更新（进程管理器）：1.【进程管理】工具页新增「进程管理」卡片，独立窗口进程（防重复启动、不阻塞主程序）——列出全部进程 PID/名称/CPU%/内存/路径/状态，二次采样 CPU 更准；2.【排序与过滤】按 CPU/内存/PID 一键排序（再点反向），关键词过滤（名称/PID/路径均可）；3.【一键终止】选中进程确认后先优雅退出（psutil.terminate），3 秒未退出自动 taskkill /F /T 强制结束（含子进程）；4.【三重保护】系统关键进程（smss/csrss/lsass/svchost/explorer 等）标记黄色拒绝终止、白名单进程标记绿色拒绝终止（whitelist_proc.json 持久化）、DG 自身进程（pythonw/dg_/scan_core）不受本工具终止（守护会自愈拉回）；5.深色科技风主题对齐 4.0.0 新 UI"),
    ("4.15.2", "4.15.1", "补丁（扫描自动切页）：''',
    "版本历史")

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)

import py_compile
py_compile.compile(MAIN, doraise=True)
py_compile.compile(r"F:\桌面保护\desktopguard\process_manager.py", doraise=True)
print("[OK] 4.16.0 补丁应用，main.py + process_manager.py 语法通过")
