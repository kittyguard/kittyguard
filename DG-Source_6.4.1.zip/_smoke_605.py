# -*- coding: utf-8 -*-
"""6.0.5 冒烟：版本号 / 首条历史 / 清单 / 产物 / 新功能代码 / 官网 / 打包"""
import io, json, os, sys

DG = r"F:\桌面保护\desktopguard"
ok = 0
bad = []

def chk(name, cond):
    global ok
    if cond:
        ok += 1
        print("  [PASS]", name)
    else:
        bad.append(name)
        print("  [FAIL]", name)

main = io.open(os.path.join(DG, "main.py"), encoding="utf-8").read()
chk("APP_VERSION=6.0.5", 'APP_VERSION = "6.0.5"' in main)
chk("VERSION_HISTORY 首条 6.0.5", main.index("VERSION_HISTORY = [('6.0.5'") < main.index("('6.0.4', '6.0.3'"))

sys.path.insert(0, DG)
import selfdefense as sd
man = json.load(io.open(sd.MANIFEST, encoding="utf-8"))
chk("防篡改清单 version=6.0.5", man.get("version") == "6.0.5")

vj = json.load(io.open(os.path.join(DG, "version.json"), encoding="utf-8"))
chk("根 version.json=6.0.5", vj.get("version") == "6.0.5")

wj = json.load(io.open(os.path.join(DG, "官网", "version.json"), encoding="utf-8"))
pj = json.load(io.open(os.path.join(DG, "官网", "publish", "version.json"), encoding="utf-8"))
chk("官网 version.json=6.0.5", wj.get("version") == "6.0.5")
chk("publish version.json=6.0.5", pj.get("version") == "6.0.5")

zp = os.path.join(DG, "官网", "DG-Security_6.0.5.zip")
chk("官网 6.0.5 zip 存在", os.path.exists(zp))
zold = [x for x in os.listdir(os.path.join(DG, "官网")) if x.startswith("DG-Security_") and x.endswith(".zip") and x != "DG-Security_6.0.5.zip"]
chk("官网无旧版 zip", not zold)

exe = os.path.join(DG, "dist", "DG安全", "DG安全.exe")
chk("dist DG安全.exe 存在", os.path.exists(exe))

rg = io.open(os.path.join(DG, "ransomware_guard.py"), encoding="utf-8").read()
chk("restore_backup dest_dir 参数", "def restore_backup(self, backup_path, dest_dir=None)" in rg)
chk("restore_all_backups dest_dir 参数", "def restore_all_backups(self, dest_dir=None)" in rg)
chk("main 恢复到指定目录按钮", "恢复到指定目录" in main)
chk("main _restore_all_ransom_backups_to_dir", "def _restore_all_ransom_backups_to_dir" in main)
chk("main 扫描历史卡片", "扫描历史" in main)
chk("main _open_scan_history", "def _open_scan_history" in main)
chk("main _clear_scan_history", "def _clear_scan_history" in main)
db = io.open(os.path.join(DG, "database.py"), encoding="utf-8").read()
chk("database.clear_scan_history", "def clear_scan_history" in db)
chk("main 6.0.5 历史文案含恢复指定目录", "恢复到指定目录" in main[:main.index("('6.0.4', '6.0.3'")])

vm = json.load(io.open(os.path.join(DG, "versions", "6.0.5", "manifest.json"), encoding="utf-8"))
chk("快照 6.0.5 manifest", vm.get("version") == "6.0.5" and len(vm.get("files", [])) > 100)

h = io.open(os.path.join(DG, "官网", "DG安全官网.html"), encoding="utf-8").read()
chk("官网 HTML 含 6.0.5 当前版节点", "6.0.5" in h and "当前版</span>恢复指定目录" in h)
chk("官网 HTML zip 链接 6.0.5", "DG-Security_6.0.5.zip" in h)
hp = io.open(os.path.join(DG, "官网", "publish", "index.html"), encoding="utf-8").read()
chk("publish/index.html 含 6.0.5 节点", "当前版</span>恢复指定目录" in hp and "DG-Security_6.0.5.zip" in hp)

print("----")
print("冒烟结果: %d/%d 通过" % (ok, ok + len(bad)))
if bad:
    print("未通过:", bad)
    sys.exit(1)
