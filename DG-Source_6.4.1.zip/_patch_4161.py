# -*- coding: utf-8 -*-
"""4.16.1 补丁：进程管理器重做为 DG 特色版（可疑度引擎/右侧详情/右键菜单/一键清理/自动刷新开关）"""
import io

MAIN = r"F:\桌面保护\desktopguard\main.py"
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()

def rep(old, new, tag):
    global m
    assert old in m, f"未找到锚点: {tag}"
    assert m.count(old) == 1, f"锚点重复: {tag} ({m.count(old)})"
    m = m.replace(old, new, 1)

# 1) 工具页卡片描述更新
rep('''        tk.Label(t8, text="列出全部进程（PID/名称/CPU%/内存/路径/状态），按 CPU/内存排序、关键词过滤、一键终止；系统关键进程与 DG 自身进程受保护，支持进程白名单",''',
    '''        tk.Label(t8, text="DG 规则引擎实时标记可疑进程（乱码名/临时目录自动标红）· 右侧实时详情（命令行/父进程/线程/网络外联）· 右键菜单（终止/白名单/打开位置/复制）· 一键清理可疑 · 自动刷新开关；系统关键进程与 DG 自身进程受保护，支持进程白名单",''',
    "工具页卡片描述")

# 2) 版本号 & 历史
rep('APP_VERSION = "4.16.0"', 'APP_VERSION = "4.16.1"', "版本号")
rep('''    ("4.16.0", "4.15.2", "内容更新（进程管理器）：''',
    '''    ("4.16.1", "4.16.0", "补丁（进程管理器重做·DG特色版）：1.【可疑度规则引擎】进程名乱码 / 临时目录释放（典型样本行为）自动标红「可疑·乱码名/临时目录」，非系统目录标橙「留意」，接续乱码观察者与安全日志分析思路；2.【右侧实时详情面板】选中进程即显示 PID/父进程/状态/CPU累计/线程数/路径/启动时间/命令行 + 该进程全部外联 TCP 连接（远端 IP:端口，防银狐类回连，后台线程不卡界面）；3.【右键菜单】终止 / 加入白名单 / 打开文件位置 / 复制路径 / 复制名称；4.【一键清理可疑】规则引擎批量列出全部可疑进程，确认后逐个优雅退出→强制结束（含子进程）；5.【自动刷新开关】默认手动，可开启每 3 秒自动刷新；布局改为左列表+右详情双栏，深色科技风不变；三重保护（系统关键进程黄标/白名单绿标/DG 自身进程）与 4.16.0 一致"),
    ("4.16.0", "4.15.2", "内容更新（进程管理器）：''',
    "版本历史")

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)

import py_compile
py_compile.compile(MAIN, doraise=True)
py_compile.compile(r"F:\桌面保护\desktopguard\process_manager.py", doraise=True)
print("[OK] 4.16.1 补丁应用，main.py + process_manager.py 语法通过")
