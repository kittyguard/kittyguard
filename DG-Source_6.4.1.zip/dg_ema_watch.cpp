﻿// dg_ema_watch.cpp — EMA 环境恶意活动监测：ETW Kernel-Process 实时进程监控组件（C++）
// 用法: dg_ema_watch.exe <jsonl路径> <心跳路径> <退出flag路径> [最大运行秒数(默认86400)]
// 行为:
//   - 启动时自清理 DG-ETW 系列残留 session（防魔改系统残留干扰）
//   - 持续监听进程创建(eid=1)/退出(eid=2)事件，逐行写入 jsonl
//   - 每 5 秒写心跳时间戳（证明组件存活）
//   - 检测到退出 flag 文件 或 达到最大秒数 -> 正常退出并写 {"final":事件数}
//   - CPU 占用极低（ETW 内核驱动分发，非轮询）
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <shellapi.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string>
#include <vector>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "tdh.lib")
#pragma comment(lib, "shell32.lib")

static const GUID KERNEL_PROCESS_PROVIDER = { 0x22FB2CD6, 0x0E7B, 0x422B, { 0xA0, 0xC7, 0x2F, 0xAD, 0x1F, 0xD0, 0xE7, 0x16 } };
static const wchar_t* SESSION_NAME = L"DG-EMA";
static volatile long long g_ev = 0;          // 收到的事件总数（含过滤前的）
static volatile long long g_pid_ev = 0;      // 进程事件数（eid 1/2）
static HANDLE g_hOut = INVALID_HANDLE_VALUE;

static void WriteOut(const char* s) {
    if (g_hOut == INVALID_HANDLE_VALUE) return;
    DWORD w = 0;
    WriteFile(g_hOut, s, (DWORD)strlen(s), &w, NULL);
    WriteFile(g_hOut, "\n", 1, &w, NULL);
}

// Extract ImageName property via Tdh (value is UNICODE_STRING or raw wide string; both handled)
static void ExtractImageName(EVENT_RECORD* rec, TRACE_EVENT_INFO* info, char* out, ULONG outLen) {
    out[0] = 0;
    if (!info) return;
    ULONG cnt = info->TopLevelPropertyCount;
    for (ULONG i = 0; i < cnt; i++) {
        EVENT_PROPERTY_INFO epi = info->EventPropertyInfoArray[i];
        const wchar_t* pname = (const wchar_t*)((BYTE*)info + (size_t)epi.NameOffset);
        if (wcscmp(pname, L"ImageName") != 0) continue;
        PROPERTY_DATA_DESCRIPTOR pdd;
        pdd.PropertyName = (ULONGLONG)((BYTE*)info + (size_t)epi.NameOffset);
        pdd.ArrayIndex = 0;
        pdd.Reserved = 0;
        ULONG size = 0;
        if (TdhGetPropertySize(rec, 0, NULL, 1, &pdd, &size) != ERROR_SUCCESS) return;
        if (size == 0 || size > 8192) return;
        std::vector<BYTE> buf(size, 0);
        if (TdhGetProperty(rec, 0, NULL, 1, &pdd, size, &buf[0]) != ERROR_SUCCESS) return;
        const wchar_t* wstr = NULL;
        ULONG wlen = 0;
        if (size >= 8) {
            USHORT ln = *(USHORT*)&buf[0];
            ULONG_PTR bp = 0;
            BYTE* base = &buf[0];
            if (sizeof(ULONG_PTR) == 8) {
                memcpy(&bp, base + 8, sizeof(bp));
            } else {
                memcpy(&bp, base + 4, sizeof(bp));
            }
            if (bp >= (ULONG_PTR)base && bp + ln <= (ULONG_PTR)base + (ULONG_PTR)buf.size()) {
                wstr = (const wchar_t*)bp;
                wlen = ln / 2;
            }
        }
        if (wstr == NULL) { wstr = (const wchar_t*)&buf[0]; wlen = (ULONG)(buf.size() / 2); }
        if (wlen == 0) return;
        if (wlen > 1023) wlen = 1023;
        int n = WideCharToMultiByte(CP_UTF8, 0, wstr, (int)wlen, out, (int)(outLen - 1), NULL, NULL);
        if (n > 0) out[n] = 0;
        return;
    }
}

// JSON escape: backslash / quote / control chars
static void JsonEscape(const char* src, char* dst, size_t dstLen) {
    size_t j = 0;
    for (size_t i = 0; src[i] != 0 && j + 7 < dstLen; i++) {
        unsigned char c = (unsigned char)src[i];
        if (c == '\\' || c == '"') { dst[j++] = '\\'; dst[j++] = (char)c; }
        else if (c < 0x20) { sprintf_s(dst + j, dstLen - j, "\\u%04x", (unsigned int)c); j += 6; }
        else dst[j++] = (char)c;
    }
    dst[j] = 0;
}

static void WINAPI OnEvent(EVENT_RECORD* rec) {
    if (!rec) return;
    InterlockedIncrement64(&g_ev);
    UCHAR eid = rec->EventHeader.EventDescriptor.Id;
    if (eid != 1 && eid != 2) return;
    InterlockedIncrement64(&g_pid_ev);
    // basic fields: PID/PPID/SID parsed directly from UserData (first 3 ULONGs)
    ULONG pid = rec->EventHeader.ProcessId;
    ULONG ppid = 0, sid = 0;
    if (rec->UserDataLength >= 12) {
        ULONG* u = (ULONG*)rec->UserData;
        pid = u[0]; ppid = u[1]; sid = u[2];
    }
    // image name via Tdh property decode (ImageName fixed property name);
    // only for process-create events (eid=1); ProcessEnd schema has no reliable ImageName layout
    char img[260] = "";
    if (eid == 1) {
        ULONG need = 0;
        TRACE_EVENT_INFO* info = NULL;
        if (TdhGetEventInformation(rec, 0, NULL, NULL, &need) == ERROR_INSUFFICIENT_BUFFER) {
            info = (TRACE_EVENT_INFO*)malloc(need);
            if (info) {
                if (TdhGetEventInformation(rec, 0, NULL, info, &need) == ERROR_SUCCESS) {
                    ExtractImageName(rec, info, img, sizeof(img));
                }
                free(info);
            }
        }
    }
    char esc[540];
    JsonEscape(img, esc, sizeof(esc));
    char line[640];
    sprintf_s(line, "{\"e\":%u,\"pid\":%u,\"ppid\":%u,\"sid\":%u,\"img\":\"%s\",\"t\":%llu}",
              eid, pid, ppid, sid, esc, (unsigned long long)rec->EventHeader.TimeStamp.QuadPart);
    WriteOut(line);
}

static DWORD WINAPI TraceThread(LPVOID p) {
    ProcessTrace((PTRACEHANDLE)p, 1, 0, 0);
    return 0;
}

static void CleanupResidualSessions() {
    // 清理所有可能残留的 DG-ETW 系列 session，防止魔改系统上残留干扰实时通知
    static const wchar_t* names[] = {
        L"DG-ETW-DIAG", L"DG-ETW-TEST", L"DG-ETW-TEST2", L"DG-ETW", L"DG-EMA"
    };
    BYTE buf[sizeof(EVENT_TRACE_PROPERTIES) + 64 * sizeof(wchar_t)];
    for (int i = 0; i < 5; i++) {
        EVENT_TRACE_PROPERTIES* props = (EVENT_TRACE_PROPERTIES*)buf;
        memset(buf, 0, sizeof(buf));
        props->Wnode.BufferSize = sizeof(buf);
        props->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
        wcscpy_s((wchar_t*)(buf + props->LoggerNameOffset), 64, names[i]);
        ControlTraceW(0, names[i], props, EVENT_TRACE_CONTROL_STOP);
    }
}

int wmain() {
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (argc < 4) return 2;
    std::wstring jsonl = argv[1], hb = argv[2], flag = argv[3];
    long maxSec = 86400;
    if (argc >= 5) maxSec = _wtoi(argv[4]);
    if (maxSec <= 0) maxSec = 86400;
    LocalFree(argv);

    if (GetFileAttributesW(flag.c_str()) != INVALID_FILE_ATTRIBUTES) return 0;  // 已要求退出
    g_hOut = CreateFileW(jsonl.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                         NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (g_hOut == INVALID_HANDLE_VALUE) return 3;

    CleanupResidualSessions();

    BYTE buf[sizeof(EVENT_TRACE_PROPERTIES) + 64 * sizeof(wchar_t)];
    EVENT_TRACE_PROPERTIES* props = (EVENT_TRACE_PROPERTIES*)buf;
    memset(buf, 0, sizeof(buf));
    props->Wnode.BufferSize = sizeof(buf);
    props->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
    props->Wnode.Guid = { 0x3B2E2C6A, 0x4E1A, 0x8A9F, { 0x6D, 0x5C, 0x4B, 0x3E, 0x2A, 0x10, 0x88, 0x99 } };
    props->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
    wcscpy_s((wchar_t*)(buf + props->LoggerNameOffset), 64, SESSION_NAME);
    props->LogFileMode = EVENT_TRACE_REAL_TIME_MODE;
    props->MinimumBuffers = 2; props->MaximumBuffers = 32; props->FlushTimer = 1;
    TRACEHANDLE sess = 0;
    ULONG r = StartTraceW(&sess, SESSION_NAME, props);
    if (r == ERROR_ALREADY_EXISTS) {
        ControlTraceW(0, SESSION_NAME, props, EVENT_TRACE_CONTROL_STOP);
        r = StartTraceW(&sess, SESSION_NAME, props);
    }
    if (r != ERROR_SUCCESS) { CloseHandle(g_hOut); return 4; }
    r = EnableTraceEx2(sess, &KERNEL_PROCESS_PROVIDER, EVENT_CONTROL_CODE_ENABLE_PROVIDER, 4, 0, 0, 0, NULL);
    if (r != ERROR_SUCCESS) { ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP); CloseHandle(g_hOut); return 5; }
    EVENT_TRACE_LOGFILEW lf; memset(&lf, 0, sizeof(lf));
    lf.LoggerName = (LPWSTR)SESSION_NAME;
    lf.ProcessTraceMode = PROCESS_TRACE_MODE_REAL_TIME | PROCESS_TRACE_MODE_EVENT_RECORD;
    lf.EventRecordCallback = (PEVENT_RECORD_CALLBACK)OnEvent;
    TRACEHANDLE h = OpenTraceW(&lf);
    if (h == (TRACEHANDLE)INVALID_HANDLE_VALUE) { CloseHandle(g_hOut); return 6; }
    HANDLE hThread = CreateThread(NULL, 0, TraceThread, &h, 0, NULL);

    // 持续监控主循环：flag 退出 or 超时
    long long t0 = GetTickCount64();
    long long last_hb = 0;
    while (true) {
        if (GetFileAttributesW(flag.c_str()) != INVALID_FILE_ATTRIBUTES) break;
        if (GetTickCount64() - t0 > maxSec * 1000LL) break;
        // 心跳固定每 5 秒写一次（带换行）
        long long now = GetTickCount64();
        if (now - last_hb >= 5000) {
            last_hb = now;
            HANDLE hb2 = CreateFileW(hb.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                     NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
            if (hb2 != INVALID_HANDLE_VALUE) {
                char b2[64]; sprintf_s(b2, "%lld %lld\n", now, g_pid_ev);
                DWORD w2 = 0; WriteFile(hb2, b2, (DWORD)strlen(b2), &w2, NULL); CloseHandle(hb2);
            }
        }
        Sleep(200);
    }
    ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP);
    WaitForSingleObject(hThread, 3000);
    CloseHandle(hThread);
    char fin[64]; sprintf_s(fin, "{\"final\":%lld}", g_pid_ev);
    WriteOut(fin);
    if (g_hOut != INVALID_HANDLE_VALUE) CloseHandle(g_hOut);
    return 0;
}