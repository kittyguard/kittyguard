# -*- coding: utf-8 -*-
import urllib.request, json, hashlib

PROXY = "http://127.0.0.1:33210"
opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": PROXY, "https": PROXY}))

# 1. Pages version.json
u = "https://kittyguard.github.io/kittyguard/version.json"
data = opener.open(u, timeout=60).read()
vj = json.loads(data)
print("Pages version.json:")
print("  latest_version:", vj.get("latest_version"))
print("  pkg:", vj.get("pkg"))
print("  sha256:", vj.get("sha256"))
print("  size_bytes:", vj.get("size_bytes"))

# 2. 下载便携包并本地校验 sha256
want = vj.get("sha256", "").upper()
u2 = vj.get("pkg")
print("\n下载 pkg:", u2)
buf = opener.open(u2, timeout=300).read()
h = hashlib.sha256(buf).hexdigest().upper()
print("  下载大小: %d B" % len(buf))
print("  实际 sha256: %s" % h)
print("  匹配: %s" % (h == want))

# 3. 下载 setup 验证 200
for n in ["DG-Security-Setup-6.4.1.exe", "DG-Source_6.4.1.zip"]:
    u3 = "https://github.com/kittyguard/kittyguard/releases/download/v6.4.1/" + n
    r = opener.open(u3, timeout=60)
    head = r.read(1024)
    print("  %s -> HTTP %s, 首段 %d B" % (n, r.status, len(head)))
