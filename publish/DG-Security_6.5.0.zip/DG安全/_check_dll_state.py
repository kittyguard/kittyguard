# -*- coding: utf-8 -*-
"""检查 Downloads\\DG安全 便携版 _internal DLL 现状 + 隔离区残留"""
import os, glob, json

dl = r"C:\Users\Administrator\Downloads\DG安全\_internal"
qm = r"F:\桌面保护\desktopguard\quarantine\_meta"
qp = r"F:\桌面保护\desktopguard\quarantine"

need = ["api-ms-win-core-console-l1-1-0.dll", "api-ms-win-core-datetime-l1-1-0.dll",
        "api-ms-win-core-fibers-l1-1-0.dll", "api-ms-win-core-errorhandling-l1-1-0.dll",
        "api-ms-win-core-debug-l1-1-0.dll"]

print("=== Downloads DG安全 _internal ===")
print("dir exists:", os.path.isdir(dl))
if os.path.isdir(dl):
    allfiles = os.listdir(dl)
    print("total files:", len(allfiles))
    for n in need:
        print("  ", n, "->", os.path.isfile(os.path.join(dl, n)))

print()
print("=== quarantine meta 中 5 个 _internal DLL 的残留 ===")
if os.path.isdir(qm):
    metas = glob.glob(os.path.join(qm, "*.json")) + glob.glob(os.path.join(qm, "*.meta.json"))
    for m in metas:
        try:
            with open(m, "r", encoding="utf-8") as f:
                d = json.load(f)
            op = d.get("original_path", "")
            if "api-ms-win-core" in op or "_internal" in op:
                print("meta:", os.path.basename(m), "| original:", op, "| size:", d.get("size"), "| sha:", str(d.get("sha256"))[:16])
        except Exception as e:
            pass

print()
print("=== quarantine 目录 .dgq 数量 ===")
if os.path.isdir(qp):
    print("dgq:", len(glob.glob(os.path.join(qp, "*.dgq"))), "| virus:", len(glob.glob(os.path.join(qp, "*.virus"))))
