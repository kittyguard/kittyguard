# -*- coding: utf-8 -*-
"""官网 HTML 同步 6.4.1：zip/exe 链接 + 版本号 + 时间轴插入 6.4.1 当前版 / 6.4.0 降为已发布 + version.json"""
import io, json, time

DG = r"F:\桌面保护\desktopguard"
paths = [
    DG + r"\官网\DG安全官网.html",
    DG + r"\官网\index.html",
    DG + r"\官网\publish\index.html",
]

# 6.4.0 当前版时间轴节点（作为插入锚点）
old640 = ('      <div class="tl-item">\n'
          '        <div class="tl-time">6.4.0</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>自启动监控增强 · 扫描 IO 节流补齐 · ClamAV 双库龄</h4><p>自启动监控告警弹窗升级为三动作按钮：「立即禁用」一键把注册表值名/启动文件夹文件名加 DG_OFF_ 前缀（保留原值完全可逆，收集逻辑自动跳过，可在启动项管理恢复）；「加入忽略」把该启动项写入忽略列表持久化，此后新增不再提示；「稍后处理」本次不处置下次再提醒。扫描 IO 优先级 VERY_LOW 从主扫描线程扩展到生产者/消费者/应用巡检全部扫描线程——全盘扫描时所有 DG 磁盘读写统一让路，彻底不再拖卡鼠标/系统/游戏。规则中心病毒库状态改为 main 与 daily 双库龄分开显示，daily 超 7 天标「偏旧」不再混淆；一键更新病毒库完成后自动刷新统计并写日志。</p></div>\n'
          '      </div>')

new641 = ('      <div class="tl-item">\n'
          '        <div class="tl-time">6.4.1</div>\n'
          '        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">当前版</span>移除 AI 助手聊天 · 保留 AI 实时辅助</h4><p>AI 聊天功能（工具页「AI 助手」卡片、托盘「打开 AI 聊天」入口、AI 助手聊天窗口与 AI 动作执行器）全部移除——作为一个杀毒软件，对话式 AI 助手没必要保留，入口更干净。扫描后对高危/严重文件自动 AI 二次判断（AI 智能检查）与设置页隐藏 AI 配置区完整保留，杀毒判断能力不减。</p></div>\n'
          '      </div>\n'
          + old640.replace('<span class="ver">当前版</span>自启动监控增强', '<span class="ver">已发布</span>自启动监控增强'))

ok = True
for p in paths:
    try:
        s = io.open(p, encoding="utf-8").read()
    except Exception as e:
        print("FAIL 读取", p, e)
        ok = False
        continue
    s = s.replace("DG-Security-Setup-6.4.0.exe", "DG-Security-Setup-6.4.1.exe")
    s = s.replace("DG-Security_6.4.0.zip", "DG-Security_6.4.1.zip")
    s = s.replace("DG-Source_6.4.0.zip", "DG-Source_6.4.1.zip")
    s = s.replace("DG 6.4.0", "DG 6.4.1")
    s = s.replace("当前版本 6.4.0", "当前版本 6.4.1")
    if old640 in s:
        s = s.replace(old640, new641, 1)
        print("[OK] %s：zip/exe/版本号已改 6.4.1，时间轴已插 6.4.1 当前版 + 6.4.0 降为已发布" % p)
    else:
        print("[WARN] %s：时间轴 6.4.0 锚点未命中（版本号已改）；稍后人工核对" % p)
        ok = False
    io.open(p, "w", encoding="utf-8").write(s)

ver = {
    "latest_version": "6.4.1",
    "version": "6.4.1",
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.4.1 内容更新（移除 AI 助手聊天）：AI 聊天功能从工具页/托盘/设置全部移除，保留 AI 实时辅助。",
    "features": [
        "移除 AI 助手聊天：工具页「AI 助手」卡片、托盘「打开 AI 聊天」入口、AI 助手聊天窗口与 AI 动作执行器全部移除",
        "保留 AI 实时辅助：扫描后对高危/严重文件自动 AI 二次判断（AI 智能检查）与设置页隐藏 AI 配置区完整保留",
        "全程纯用户态、零驱动、不服务化"
    ]
}
for p in (DG + r"\官网\version.json", DG + r"\官网\publish\version.json"):
    io.open(p, "w", encoding="utf-8").write(json.dumps(ver, ensure_ascii=False, indent=2))
    print("[OK] %s -> 6.4.1" % p)
print("RESULT", "OK" if ok else "NEED_CHECK")
