#!/bin/bash
export PATH="/ucrt64/bin:/usr/bin:/bin:$PATH"
cd /f/桌面保护/desktopguard
echo "开始编译 scan_core.cpp ..."
/ucrt64/bin/g++ -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -municode -o scan_core.exe scan_core.cpp -lcrypt32 -lbcrypt > compile_log.txt 2>&1
echo "GXX_EXIT=$?"
if [ -f scan_core.exe ]; then
    echo "BUILD_OK"
    ls -la scan_core.exe
else
    echo "BUILD_FAILED"
    echo "=== 编译日志（前50行）==="
    head -50 compile_log.txt
fi
