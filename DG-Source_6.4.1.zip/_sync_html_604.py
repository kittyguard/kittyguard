# -*- coding: utf-8 -*-
"""官网 HTML 同步 6.0.4：7 处版本引用 + 时间轴插入 6.0.4 当前版节点"""
import io, re

p = r"F:\桌面保护\desktopguard\官网\DG安全官网.html"
s = io.open(p, encoding="utf-8").read()

# 1. zip 下载链接 3 处
s = s.replace("DG-Security_6.0.3.zip", "DG-Security_6.0.4.zip")
# 2. 其余裸版本号（nav CTA 行 202 已含 zip 名；hero 终端行、cta-note、footer）
s = s.replace("DG 6.0.3", "DG 6.0.4")
s = s.replace("当前版本 6.0.3", "当前版本 6.0.4")
s = s.replace("v6.0.3 ·", "v6.0.4 ·")
# 3. 时间轴：6.0.3 节点降为已发布，前插 6.0.4 当前版
old603 = ('<span class="ver">当前版</span>勒索守护完善 · 行为链增强</h4><p>监控目录自定义：'
          '任意目录纳入勒索守护，一键恢复默认即时生效；保护区容量自动清理：备份超 2GB '
          '按最旧优先清理至 1.5GB，永不撑爆；行为链时间线新增时间范围过滤，EMA 事件再多也不被淹没。</p></div>\n      </div>')
new604 = ('<span class="ver">当前版</span>勒索恢复向导 · 行为链导出</h4><p>一键恢复全部备份：'
          '勒索后批量找回文件，原路径丢失自动跳过、覆盖前留底防覆盖现场；行为链一键导出 CSV'
          '（UTF-8 BOM，Excel 直开，取证复盘用）；防护中心新增「勒索守护」与「弹窗拦截」模块，'
          '就绪度 8 模块一眼看全所有防线。</p></div>\n      </div>\n      <div class="tl-item">\n'
          '        <div class="tl-time">6.0.3</div>\n        <div class="tl-axis"><div class="tl-dot"></div></div>\n'
          '        <div class="tl-content"><h4><span class="ver">已发布</span>勒索守护完善 · 行为链增强</h4>'
          '<p>监控目录自定义：任意目录纳入勒索守护，一键恢复默认即时生效；保护区容量自动清理：备份超 2GB '
          '按最旧优先清理至 1.5GB，永不撑爆；行为链时间线新增时间范围过滤，EMA 事件再多也不被淹没。</p></div>\n      </div>')
assert old603 in s, "锚点未命中"
s = s.replace(old603, new604)

io.open(p, "w", encoding="utf-8").write(s)
left = s.count("6.0.3")
print("[OK] 官网 HTML 已同步 6.0.4；剩余 6.0.3 引用（应为时间轴历史节点 2 处）:", left)
