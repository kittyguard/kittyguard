# -*- coding: utf-8 -*-
"""
DG ScanCore 适配层
==================
负责调用 C++ 编译的 scan_core.exe 完成最耗时的目录遍历 + SHA256 哈希计算。
Python 主程序只做特征分析，从而大幅提升扫描速度。

回退机制：
- 如果 scan_core.exe 不存在/无法运行，自动回退到纯 Python 遍历（功能不受影响）。
"""

import os
import sys
import json
import shutil
import subprocess
import tempfile
import threading

# 找到 scan_core.exe 的位置
def _find_scan_core():
    """查找 scan_core.exe，优先当前目录。"""
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, "scan_core.exe"),
        os.path.join(here, "bin", "scan_core.exe"),
        shutil.which("scan_core"),
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return None

_SCAN_CORE_PATH = None
_SCAN_CORE_CHECKED = False

def has_scan_core():
    """检查 C++ 核心是否可用。"""
    global _SCAN_CORE_PATH, _SCAN_CORE_CHECKED
    if not _SCAN_CORE_CHECKED:
        _SCAN_CORE_PATH = _find_scan_core()
        _SCAN_CORE_CHECKED = True
    return _SCAN_CORE_PATH is not None

def get_scan_core_path():
    """返回 scan_core.exe 路径（不存在返回 None）。"""
    global _SCAN_CORE_PATH, _SCAN_CORE_CHECKED
    if not _SCAN_CORE_CHECKED:
        _SCAN_CORE_PATH = _find_scan_core()
        _SCAN_CORE_CHECKED = True
    return _SCAN_CORE_PATH

# ============================================================
# 结果对象：与 engine.ScanResult 兼容的最小接口
# ============================================================
class CoreFileInfo:
    __slots__ = ("path", "size", "ext", "mtime", "sha256", "name")

    def __init__(self, path, size, ext, mtime, sha256):
        self.path = path
        self.size = size
        self.ext = ext
        self.mtime = mtime
        self.sha256 = sha256
        self.name = os.path.basename(path)

    def to_dict(self):
        return {
            "path": self.path,
            "name": self.name,
            "size": self.size,
            "ext": self.ext,
            "mtime": self.mtime,
            "sha256": self.sha256,
        }

# ============================================================
# 调用 C++ 核心
# ============================================================
def run_scan_core(roots, mode="quick", progress_cb=None, cancel_event=None, max_seconds=600):
    """
    调用 C++ 扫描核心。

    参数:
        roots: 要扫描的根路径列表
        mode: quick(枚举+大小) / advanced(+mtime) / deep(+sha256)
        progress_cb: 进度回调(已处理数, 总数, 当前路径)
        cancel_event: threading.Event，设置后取消
        max_seconds: 最大等待秒数

    返回:
        (files: list[CoreFileInfo], stats: dict) 或 (None, None) 表示失败
    """
    exe = get_scan_core_path()
    if not exe:
        return None, None

    # 输出缓冲文件放临时目录（避免与程序目录冲突）
    tmp_dir = tempfile.mkdtemp(prefix="dg_core_")
    out_buf = os.path.join(tmp_dir, "scan_core_output.tmp")
    work_dir = os.path.dirname(exe)

    # 构造命令行：传入模式 + 所有根路径
    cmd = [exe, mode]
    for r in roots:
        cmd.append(r)

    try:
        # 用 CREATE_NO_WINDOW 隐藏控制台窗口
        creationflags = 0x08000000 if sys.platform == "win32" else 0
        proc = subprocess.Popen(
            cmd,
            cwd=work_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=creationflags,
        )

        # 等待完成（支持取消 + 实时进度：轮询 scan_core 输出文件行数上报）
        start = _monotonic()
        out_path = os.path.join(work_dir, "scan_core_output.tmp")
        last_prog = 0
        _last_probe = 0.0
        while proc.poll() is None:
            if cancel_event and cancel_event.is_set():
                proc.kill()
                try:
                    os.remove(out_path)
                except Exception:
                    pass
                return None, None
            if _monotonic() - start > max_seconds:
                proc.kill()
                try:
                    os.remove(out_path)
                except Exception:
                    pass
                return None, None
            # 4.11.1：实时进度——C++ 核心逐行写 scan_core_output.tmp，
            # 每 0.5s 统计一次已写入行数，通过 progress_cb 上报（UI 端显示遍历进度）
            _now = _monotonic()
            if progress_cb and (_now - _last_probe) >= 0.5:
                _last_probe = _now
                try:
                    if os.path.exists(out_path):
                        with open(out_path, "r", encoding="utf-8", errors="replace") as _pf:
                            _n = _pf.read().count("\n")
                        if _n > last_prog:
                            last_prog = _n
                            progress_cb(_n, 0, "")
                except Exception:
                    pass
            _sleep(0.05)

        if proc.returncode != 0:
            return None, None

        # 读取输出缓冲文件
        files = []
        if os.path.exists(out_path):
            with open(out_path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                        files.append(CoreFileInfo(
                            path=d.get("p", ""),
                            size=d.get("s", 0),
                            ext=d.get("e", ""),
                            mtime=d.get("m", 0),
                            sha256=d.get("h"),
                        ))
                    except Exception:
                        continue
            try:
                os.remove(out_path)
            except Exception:
                pass

        # 解析 stderr 统计
        stats = {}
        try:
            stderr_text = proc.stderr.read().decode("utf-8", errors="replace")
            for line in stderr_text.splitlines():
                if line.startswith("STAT "):
                    parts = line.split()
                    for p in parts[1:]:
                        if "=" in p:
                            k, v = p.split("=", 1)
                            stats[k] = v
        except Exception:
            pass

        # 清理临时目录
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

        return files, stats

    except Exception:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass
        return None, None


def _monotonic():
    import time
    return time.monotonic()


def _sleep(sec):
    import time
    time.sleep(sec)


# ============================================================
# 纯 Python 回退：当 C++ 核心不可用时使用
# ============================================================
def fallback_list_files(roots, mode="quick", progress_cb=None, cancel_event=None):
    """
    纯 Python 目录遍历（回退方案，功能等价但较慢）。
    返回 (files, stats)。
    """
    files = []
    total = [0]

    def _count(root):
        for _, _, fnames in os.walk(root):
            total[0] += len(fnames)

    for root in roots:
        try:
            _count(root)
        except Exception:
            pass

    processed = [0]
    for root in roots:
        try:
            for dirpath, _, fnames in os.walk(root):
                if cancel_event and cancel_event.is_set():
                    break
                for fname in fnames:
                    if cancel_event and cancel_event.is_set():
                        break
                    fpath = os.path.join(dirpath, fname)
                    processed[0] += 1
                    try:
                        st = os.stat(fpath)
                        ext = os.path.splitext(fname)[1].lower()
                        files.append(CoreFileInfo(
                            path=fpath, size=st.st_size, ext=ext,
                            mtime=st.st_mtime, sha256=None,
                        ))
                    except Exception:
                        pass
                    if progress_cb and processed[0] % 200 == 0:
                        progress_cb(processed[0], total[0], fpath)
        except Exception:
            pass

    return files, {"files": str(len(files)), "fallback": "1"}
