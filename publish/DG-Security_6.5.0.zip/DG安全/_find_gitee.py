# -*- coding: utf-8 -*-
import os, subprocess
# 找 Gitee 本地仓库
hits = []
for root in (r"F:\桌面保护",):
    for d in os.listdir(root):
        p = os.path.join(root, d)
        if os.path.isdir(os.path.join(p, ".git")):
            r = subprocess.run(["git", "-C", p, "remote", "-v"], capture_output=True, text=True, encoding="utf-8", errors="ignore")
            if "gitee" in (r.stdout or "").lower() or "gitee" in (r.stderr or "").lower():
                hits.append((p, (r.stdout or r.stderr or "").strip()[:200]))
for h in hits:
    print(h)
if not hits:
    print("NO_GITEE_REPO_FOUND")
# 顺便列 F:\桌面保护 下带 .git 的目录
for d in os.listdir(r"F:\桌面保护"):
    p = os.path.join(r"F:\桌面保护", d)
    if os.path.isdir(os.path.join(p, ".git")):
        print("git repo:", p)
