# -*- coding: utf-8 -*-
# 实测 ghproxy 类加速代理对 GitHub Pages 直链的支持与速度
import urllib.request, time, socket

socket.setdefaulttimeout(25)

BASE = "https://kittyguard.github.io/kittyguard"
PROXIES = {
    "直连(基线)": BASE,
    "ghproxy.com": "https://ghproxy.com/" + BASE,
    "gh-proxy.com": "https://gh-proxy.com/" + BASE,
    "ghfast.top": "https://ghfast.top/" + BASE,
    "ghps.cc": "https://ghps.cc/" + BASE,
    "gh-proxy.lycos.com": "https://gh-proxy.lycos.com/" + BASE,
}

def speed(url, limit=1024*1024):
    t0 = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=25) as r:
            total = 0
            while total < limit:
                chunk = r.read(65536)
                if not chunk:
                    break
                total += len(chunk)
        dt = time.time() - t0
        return total, dt, None
    except Exception as e:
        return 0, 0, str(e)[:80]

# 先测小文件 version.json（验证可用性）
print("=== version.json 可用性 ===")
for name, url in PROXIES.items():
    b, d, err = speed(url + "/version.json", limit=4096)
    if err:
        print("  %-20s FAIL  %s" % (name, err))
    else:
        print("  %-20s OK  %dB %.2fs" % (name, b, d))

print()
print("=== Setup 安装包 1MB 测速（可用源）===")
for name, url in PROXIES.items():
    if name == "直连(基线)":
        continue
    b, d, err = speed(url + "/DG-Security-Setup-6.4.2.exe", limit=1024*1024)
    if err:
        print("  %-20s FAIL  %s" % (name, err))
    else:
        print("  %-20s %.1f KB/s  (%dB in %.2fs)" % (name, b/1024/max(d,0.001), b, d))
