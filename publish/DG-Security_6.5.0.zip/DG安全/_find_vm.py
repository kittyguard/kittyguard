# -*- coding: utf-8 -*-
import subprocess, os, glob

def run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=timeout)
        return r.stdout, r.stderr
    except Exception as e:
        return "", "ERR " + str(e)

# 1. VBoxManage 在哪
for cand in [r"C:\Program Files\Oracle\VirtualBox\VBoxManage.exe",
             r"C:\Program Files (x86)\Oracle\VirtualBox\VBoxManage.exe"]:
    if os.path.isfile(cand):
        print("VBoxManage:", cand)
        out, err = run([cand, "list", "vms"])
        print("VMs:", out.strip() or "(none)")
        out2, err2 = run([cand, "list", "runningvms"])
        print("Running:", out2.strip() or "(none)")
        break
else:
    # 搜一下
    r = subprocess.run(["where", "VBoxManage"], capture_output=True, text=True, errors="ignore")
    print("where VBoxManage:", r.stdout.strip() or "NOT FOUND")

# 2. 常见虚拟机目录
print()
print("=== VM files search ===")
for root in [r"C:\Users\Administrator\VirtualBox VMs", r"C:\Users\Administrator\VirtualBox", "D:/", "F:/"]:
    if os.path.isdir(root):
        for d in os.listdir(root):
            p = os.path.join(root, d)
            if os.path.isdir(p):
                vdi = glob.glob(os.path.join(p, "*.vdi")) + glob.glob(os.path.join(p, "*.vbox"))
                if vdi:
                    print(root, "\\", d, "->", [os.path.basename(x) for x in vdi])
