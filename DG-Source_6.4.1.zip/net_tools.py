# -*- coding: utf-8 -*-
"""
DG安全 · 网络工具箱 v1（测速 + 网络加速 + 游戏模式）
独立运行：python net_tools.py
被 DG 主程序调用：subprocess 启动本脚本（互不阻塞）
- 测速：国内多节点延迟/抖动/丢包 + 尽力下载带宽测速（免费，不花钱）
- 加速：一键结束后台带宽大户（记录原进程，可一键恢复）
        TCP 参数优化（记录原值，可一键回滚）
- 游戏模式：针对 FPS 对局（如三角洲 ACE 扫盘场景）一键清场，可恢复
纯用户态，不碰内核；所有修改可回滚。
"""
import os
import sys
import time
import threading
import subprocess
import tkinter as tk
from tkinter import ttk

# ---------- 主题（DG 4.x 深色科技风） ----------
BG      = "#0d1520"
FG      = "#d8e6f2"
DIM     = "#7fa3c0"
ACCENT  = "#00d4ff"
WARN    = "#ffb648"
DANGER  = "#ff5c5c"
CARD    = "#14202e"
FONT    = ("Microsoft YaHei UI", 9)
FONT_S  = ("Microsoft YaHei UI", 8)
FONT_T  = ("Microsoft YaHei UI", 9, "bold")

# 测速节点（国内）：名称 -> (host, ping 次数)
PING_NODES = [
    ("阿里 DNS",  "223.5.5.5"),
    ("腾讯 DNS",  "119.29.29.29"),
    ("114 DNS",   "114.114.114.114"),
    ("百度 DNS",  "180.76.76.76"),
]
# 下载测速候选源（国内镜像大文件，限时下载测速；依次尝试，失败降级）
DL_URLS = [
    "https://mirrors.aliyun.com/ubuntu-releases/22.04.5/ubuntu-22.04.5-desktop-amd64.iso",
    "https://mirrors.tuna.tsinghua.edu.cn/ubuntu-releases/22.04.5/ubuntu-22.04.5-desktop-amd64.iso",
    "https://mirrors.huaweicloud.com/ubuntu-releases/22.04.5/ubuntu-22.04.5-desktop-amd64.iso",
]

# 后台大户黑名单豁免（系统/核心进程，绝不杀）
SAFE_PROCS = {
    "system", "registry", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe",
    "services.exe", "lsass.exe", "svchost.exe", "explorer.exe", "dwm.exe",
    "spoolsv.exe", "dllhost.exe", "conhost.exe", "runtimebroker.exe",
    "searchindexer.exe", "audiodg.exe", "taskhostw.exe", "sihost.exe",
    "startmenuexperiencehost.exe", "shellexperiencehost.exe", "textinputhost.exe",
    "ctfmon.exe", "fontdrvhost.exe", "wudfhost.exe", "wmiadap.exe", "wmiprvse.exe",
    "memory compression", "secure system", "postgres.exe", "pg_ctl.exe",
    "pythonw.exe", "python.exe", "doubao.exe", "doubao", "powershell.exe",
    "deltarforceclient-win64-shipping.exe", "deltaforceclient-win64-shipping.exe",
    "wechat.exe", "qq.exe", "steam.exe", "epicgameslauncher.exe",
    "nvcontainer.exe", "nvdisplay.container.exe", "nvidia app",
    "hdplayer.exe", "sandbox_runner.exe", "dg_monitor.exe", "dg_guard.exe",
    "dg_warden.exe", "dg_quarantine.exe", "dg_verdict.exe", "scan_core.exe",
    "uwp.exe", "applicationframehost.exe", "widgets.exe", "yourphone.exe",
    "system idle process", "delta_force_launcher.exe",
}
SAFE_LOWER = {s.lower() for s in SAFE_PROCS}

_state = {"killed": []}          # 被结束的大户记录 [{name,path,pid}]，供恢复
_tcp_orig = {}                   # TCP 参数原值，供回滚
_lock = threading.Lock()

# 回滚中心联动（延迟导入，避免启动开销）
try:
    import selfdefense as _sd
except Exception:
    _sd = None


def _roll_log(entry):
    """写入回滚中心日志（失败静默，不影响主功能）"""
    if _sd is not None:
        try:
            _sd.append_roll_log(entry)
        except Exception:
            pass


# ---------- 工具函数 ----------
def _proc_cmd(args, timeout=8):
    """执行命令，返回 stdout 文本（容错，GBK 兼容中文系统输出）"""
    try:
        r = subprocess.run(args, capture_output=True, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                           encoding="gbk", errors="ignore")
        return (r.stdout or "") + (r.stderr or "")
    except Exception:
        return ""


def ping_node(host, count=4):
    """单节点 ping：返回 (延迟均值ms, 抖动ms, 丢包%) 或 None"""
    out = _proc_cmd(["ping", "-n", str(count), host], timeout=12)
    times = []
    for line in out.splitlines():
        low = line.lower()
        if "ttl" not in low:
            continue
        # 中文：时间=xxms / 英文：time=xxms
        for tag in ("时间=", "time=", "time<"):
            idx = low.find(tag)
            if idx >= 0:
                seg = low[idx + len(tag):]
                num = ""
                for ch in seg:
                    if ch.isdigit() or ch == ".":
                        num += ch
                    else:
                        break
                try:
                    t = float(num)
                    if t > 0:
                        times.append(t)
                except Exception:
                    pass
                break
    if not times:
        # 全部超时
        if "100%" in out or "无法访问" in out or "超时" in out:
            return None
        return None
    avg = sum(times) / len(times)
    dev = (max(times) - min(times)) / 2.0 if len(times) > 1 else 0.0
    loss = (count - len(times)) * 100.0 / count
    return round(avg, 1), round(dev, 1), round(loss, 1)


def measure_download(timeout=4):
    """尽力下载测速：返回 Mbps 或 None"""
    import urllib.request
    for url in DL_URLS:
        try:
            t0 = time.time()
            req = urllib.request.Request(url, method="GET",
                                         headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout + 2) as r:
                total = 0
                while time.time() - t0 < timeout:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    total += len(chunk)
            dur = time.time() - t0
            if total > 1024 * 1024 and dur > 0.5:
                return round(total * 8 / dur / 1e6, 1)
        except Exception:
            continue
    return None


def top_procs():
    """返回按 CPU 采样降序的非白名单大户列表（需 psutil；两次采样法）"""
    try:
        import psutil
    except Exception:
        return []
    rows = []
    try:
        procs = list(psutil.process_iter(["pid", "name", "exe"]))
        # 第一次采样（预热，返回 0）
        for p in procs:
            try:
                p.cpu_percent(interval=None)
            except Exception:
                pass
        time.sleep(1.2)
        # 第二次采样才是真实 CPU%
        for p in procs:
            try:
                name = (p.info.get("name") or "").strip()
                if not name or name.lower() in SAFE_LOWER:
                    continue
                cpu = p.cpu_percent(interval=None) or 0
                mem = p.memory_percent() or 0
                if cpu < 2 and mem < 4:
                    continue
                exe = ""
                try:
                    exe = p.exe() or ""
                except Exception:
                    pass
                rows.append({"name": name, "exe": exe, "pid": p.pid,
                             "cpu": round(cpu, 1), "mem": round(mem, 1)})
            except Exception:
                continue
    except Exception:
        return []
    rows.sort(key=lambda r: r["cpu"] + r["mem"], reverse=True)
    return rows[:12]


def kill_procs(rows):
    """结束大户并记录；返回成功列表"""
    killed = []
    for r in rows:
        try:
            subprocess.run(["taskkill", "/f", "/pid", str(r["pid"])],
                           capture_output=True, timeout=5,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            killed.append(r)
        except Exception:
            continue
    return killed


def restore_killed(records):
    """恢复被结束的进程（按 exe 路径重新拉起）"""
    ok = 0
    for r in records:
        exe = r.get("exe")
        if not exe or not os.path.exists(exe):
            continue
        try:
            subprocess.Popen([exe], cwd=os.path.dirname(exe),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            ok += 1
        except Exception:
            continue
    return ok


def read_tcp_params():
    """读取关键 TCP 全局参数，返回 dict（兼容中文/英文系统输出）"""
    out = _proc_cmd(["netsh", "int", "tcp", "show", "global"], timeout=8)
    params = {}
    for line in out.splitlines():
        low = line.strip().lower()
        for key in ("receive window auto-tuning level", "接收窗口自动调谐级别",
                    "接收窗口自动调节级别", "receive-side scaling", "rss",
                    "ecn capability", "ecn", "rfc 1323 timestamps", "timestamps",
                    "initial rto", "fast open", "max syn retransmissions"):
            if key in low:
                params[key] = line.strip()
                break
    return params


def apply_tcp(record_orig=True):
    """应用推荐的 TCP 参数；记录原值用于回滚"""
    # 先读原值（netsh show 的原始文本行）
    out = _proc_cmd(["netsh", "int", "tcp", "show", "global"], timeout=8)
    if record_orig:
        for line in out.splitlines():
            if "auto-tuning level" in line.lower() or "自动调谐" in line or "自动调节" in line:
                _tcp_orig["autotune"] = line.strip()
                break
    cmds = [
        ["netsh", "int", "tcp", "set", "global", "autotuninglevel=normal"],
        ["netsh", "int", "tcp", "set", "global", "rss=enabled"],
    ]
    results = []
    for c in cmds:
        r = _proc_cmd(c, timeout=8).strip()
        results.append((c[-1], r if r else "已执行"))
    return results


def rollback_tcp():
    """回滚 TCP 参数（恢复 autotune 原值）"""
    orig = _tcp_orig.get("autotune")
    if not orig:
        return "未找到可回滚的 TCP 原值记录"
    # 从原行提取级别：如 "接收窗口自动调谐级别 : normal" / "Autotuninglevel : normal"
    low = orig.lower()
    level = None
    for tag in ("normal", "disabled", "restricted", "highlyrestricted", "experimental"):
        if tag in low:
            level = tag
            break
    if not level:
        return "无法解析原值：" + orig
    r = _proc_cmd(["netsh", "int", "tcp", "set", "global", "autotuninglevel=" + level], timeout=8).strip()
    return r if r else "已回滚 autotuninglevel=" + level


def net_status():
    """网络状态摘要：网卡 / 信号 / 链路速率 / 网关延迟"""
    lines = []
    # 网卡
    out = _proc_cmd(["powershell", "-NoProfile", "-Command",
                     "Get-NetAdapter | Where-Object Status -eq 'Up' | Select-Object Name,LinkSpeed | Format-Table -HideTableHeaders"], timeout=10)
    for line in out.splitlines():
        s = line.strip()
        if s and ("Mbps" in s or "Gbps" in s):
            lines.append(s)
    # WiFi 信号
    w = _proc_cmd(["netsh", "wlan", "show", "interfaces"], timeout=8)
    signal = ""
    for line in w.splitlines():
        if "信号" in line or "Signal" in line:
            signal = line.strip()
            break
    if signal:
        lines.append(signal)
    # 网关延迟
    gw = ""
    out2 = _proc_cmd(["ping", "-n", "3", "192.168.1.1"], timeout=8)
    if not out2 or "TTL" not in out2.upper():
        out2 = _proc_cmd(["ping", "-n", "3", "192.168.0.1"], timeout=8)
    for line in out2.splitlines():
        if "ttl" in line.lower():
            gw = line.strip()
            break
    if gw:
        lines.append("网关: " + gw)
    return lines


# ---------- GUI ----------
class NetToolsApp:
    def __init__(self, root):
        self.root = root
        root.title("网络工具箱 - DG安全")
        root.configure(bg=BG)
        root.geometry("640x660")
        root.resizable(False, False)

        # 标题
        tk.Label(root, text="DG 安全 · 网络工具箱", bg=BG, fg=ACCENT,
                 font=("Microsoft YaHei UI", 14, "bold")).pack(pady=(12, 2))
        tk.Label(root, text="测速 · 网络加速 · 游戏模式（全部操作可回滚，纯用户态）",
                 bg=BG, fg=DIM, font=FONT_S).pack()

        body = tk.Frame(root, bg=BG)
        body.pack(fill="both", expand=True, padx=14, pady=8)

        # ---- 网络状态区 ----
        self._section(body, "当前网络状态")
        self.stat_txt = tk.Text(body, height=5, bg=CARD, fg=FG, font=FONT_S,
                                relief="flat", state="disabled", wrap="word")
        self.stat_txt.pack(fill="x", pady=(2, 6))
        tk.Button(body, text="刷新状态", command=self._refresh_stat,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(anchor="w")

        # ---- 测速区 ----
        self._section(body, "网络测速（国内节点，免费）")
        self.speed_txt = tk.Text(body, height=7, bg=CARD, fg=FG, font=FONT_S,
                                 relief="flat", state="disabled", wrap="word")
        self.speed_txt.pack(fill="x", pady=(2, 6))
        tk.Button(body, text="开始测速", command=self._start_speed,
                  bg=ACCENT, fg="#001018", activebackground="#33e0ff",
                  activeforeground="#001018", relief="flat", font=FONT_T).pack(anchor="w")

        # ---- 加速区 ----
        self._section(body, "网络加速 / 游戏模式（可回滚）")
        self.proc_txt = tk.Text(body, height=6, bg=CARD, fg=FG, font=FONT_S,
                                relief="flat", state="disabled", wrap="word")
        self.proc_txt.pack(fill="x", pady=(2, 6))
        btn_row = tk.Frame(body, bg=BG)
        btn_row.pack(anchor="w")
        tk.Button(btn_row, text="扫描后台大户", command=self._scan_procs,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(btn_row, text="一键结束大户(游戏模式)", command=self._kill_procs,
                  bg=WARN, fg="#1a0e00", activebackground="#ffc46b",
                  activeforeground="#1a0e00", relief="flat", font=FONT).pack(side="left", padx=(0, 6))
        tk.Button(btn_row, text="恢复已结束进程", command=self._restore_procs,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(side="left")
        tk.Button(body, text="一键应用 TCP 优化", command=self._do_tcp,
                  bg="#1b2b3d", fg=FG, activebackground="#24384f",
                  activeforeground=FG, relief="flat", font=FONT).pack(anchor="w", pady=(6, 2))
        tk.Button(body, text="回滚 TCP 优化", command=self._rollback_tcp,
                  bg="#3a2a1a", fg=WARN, activebackground="#4a3622",
                  activeforeground=WARN, relief="flat", font=FONT).pack(anchor="w")

        # 日志
        self._section(body, "操作日志")
        self.log_txt = tk.Text(body, height=5, bg=CARD, fg=FG, font=FONT_S,
                               relief="flat", state="disabled", wrap="word")
        self.log_txt.pack(fill="both", expand=True, pady=(2, 0))

        self._refresh_stat()
        self.log("网络工具箱就绪。测速/加速均为尽力服务，全部操作可回滚。")

    # ---- UI helpers ----
    def _section(self, parent, title):
        tk.Label(parent, text=title, bg=BG, fg=ACCENT,
                 font=FONT_T).pack(anchor="w", pady=(8, 0))

    def log(self, msg):
        try:
            self.log_txt.configure(state="normal")
            self.log_txt.insert("end", "[" + time.strftime("%H:%M:%S") + "] " + msg + "\n")
            self.log_txt.see("end")
            self.log_txt.configure(state="disabled")
        except Exception:
            pass

    def set_text(self, widget, text):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    # ---- 动作 ----
    def _refresh_stat(self):
        self.set_text(self.stat_txt, "\n".join(net_status()) or "（未能读取网络状态）")
        self.log("已刷新网络状态")

    def _start_speed(self):
        self.set_text(self.speed_txt, "测速中，请稍候…\n（约 5-15 秒）")
        self.log("开始测速…")
        threading.Thread(target=self._speed_worker, daemon=True).start()

    def _speed_worker(self):
        lines = ["【延迟 / 抖动 / 丢包】"]
        for name, host in PING_NODES:
            res = ping_node(host)
            if res is None:
                lines.append("  %s: 不可达/超时" % name)
            else:
                lines.append("  %s: %s ms（抖动 %s ms，丢包 %s%%）" % (name, res[0], res[1], res[2]))
        lines.append("【下载带宽】尽力测速中…")
        self.set_text(self.speed_txt, "\n".join(lines))
        dl = measure_download()
        if dl is not None:
            lines.append("  下载 ≈ %s Mbps" % dl)
        else:
            lines.append("  下载：测速源不可达（延迟结果仍有效）")
        self.set_text(self.speed_txt, "\n".join(lines))
        self.log("测速完成")
        # 综合判断
        ok = sum(1 for _, h in PING_NODES if ping_node(h, 1) is not None and ping_node(h, 1)[0] < 60)
        self.log("测速完成：可用节点 %s/4" % ok)

    def _scan_procs(self):
        self.set_text(self.proc_txt, "扫描后台大户中…")
        rows = top_procs()
        if not rows:
            self.set_text(self.proc_txt, "未发现可清理的后台大户（已排除系统进程/DG/游戏/常用软件）")
            self.log("扫描完成：未发现大户")
            return
        lines = ["以下进程占用较高（系统/DG/游戏已豁免）："]
        for r in rows:
            lines.append("  [%s] %s（CPU %s%% 内存 %s%%）" % (r["pid"], r["name"], r["cpu"], r["mem"]))
        self.set_text(self.proc_txt, "\n".join(lines))
        self._last_rows = rows
        self.log("扫描到 %s 个后台大户" % len(rows))

    def _kill_procs(self):
        rows = getattr(self, "_last_rows", None)
        if not rows:
            self.set_text(self.proc_txt, "请先点击「扫描后台大户」，再执行结束")
            return
        killed = kill_procs(rows)
        with _lock:
            _state["killed"].extend(killed)
        lines = ["已结束 %s 个后台大户（可一键恢复）：" % len(killed)]
        for r in killed:
            lines.append("  - %s" % r["name"])
        self.set_text(self.proc_txt, "\n".join(lines))
        self.log("已结束 %s 个进程，记录于恢复列表" % len(killed))
        # 写入回滚中心
        _roll_log({"time": time.strftime("%Y-%m-%d %H:%M:%S"),
                   "type": "kill_procs",
                   "detail": "结束 %s 个后台进程" % len(killed),
                   "records": [{"name": r["name"], "exe": r["exe"], "pid": r["pid"]} for r in killed]})

    def _restore_procs(self):
        with _lock:
            rec = list(_state["killed"])
        if not rec:
            self.set_text(self.proc_txt, "当前没有已结束的进程可恢复")
            return
        ok = restore_killed(rec)
        with _lock:
            _state["killed"] = []
        self.set_text(self.proc_txt, "已尝试恢复 %s 个进程（按原路径重新拉起）" % ok)
        self.log("恢复进程：成功 %s 个" % ok)

    def _do_tcp(self):
        results = apply_tcp()
        self.log("TCP 优化已应用：" + "；".join("%s→%s" % (a, b) for a, b in results))
        # 展示当前值
        params = read_tcp_params()
        self.set_text(self.proc_txt, "TCP 优化已应用（原值已记录，可回滚）：\n" + "\n".join(
            "  " + v for v in list(params.values())[:5]) or "  （读取当前参数失败）")
        # 写入回滚中心（记录原值 level）
        orig_level = None
        with _lock:
            raw = _tcp_orig.get("autotune", "")
        for tag in ("normal", "disabled", "restricted", "highlyrestricted", "experimental"):
            if tag in raw.lower():
                orig_level = tag
                break
        _roll_log({"time": time.strftime("%Y-%m-%d %H:%M:%S"),
                   "type": "tcp_optimize",
                   "detail": "应用 TCP 优化（自动调谐原值 %s）" % (orig_level or "未知"),
                   "orig_level": orig_level})

    def _rollback_tcp(self):
        msg = rollback_tcp()
        self.log("TCP 回滚：" + msg)
        self.set_text(self.proc_txt, "TCP 回滚：" + msg)


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    NetToolsApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
