# -*- coding: utf-8 -*-
"""
pe_heuristic.py — PE 静态启发式评分引擎（轻量 ML 特征前身）
=============================================================
从 PE 文件提取静态特征并做确定性启发式打分，模仿 PyAS 本地 ML 的特征子集：
编译时间戳 / 入口点位置 / 区段特性(W+X) / 区段熵 / 区段数 / overlay /
极小体积 / 无导入表 / 可疑壳区段。
纯用户态、纯标准库、无第三方依赖；只读文件头部与区段采样，性能可控。
"""

import os
import struct
import math

# 常见壳区段（加壳特征；UPX 合法场景多，仅作为辅助不独立加分）
PACKED_SECTION_NAMES = {
    b".vmp", b".vmp0", b".vmp1", b".themida", b".winlice", b".aspack",
    b".petite", b".nsp0", b".nsp1", b".mpress", b".enigma", b".enigma1",
    b".vmprotect", b".vmp1", b".y0da", b".y0da1", b".cryptor", b".bambam",
    b".morphine", b".sfx", b".shrink", b".pec", b".pecompact", b".kkrunchy",
}

# 入口点视为"正常代码区段"的名字（其余入口点 → 可疑）
NORMAL_CODE_SECTIONS = {b".text", b".code", b"CODE", b".init", b".textbss", b".rdata"}

# 可写+可执行 区段特性位
CHAR_WRITABLE = 0x80000000
CHAR_EXECUTE = 0x20000000


def _entropy(data: bytes) -> float:
    """香农熵（0-8）。"""
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    ent = 0.0
    for c in counts:
        if c:
            p = c / n
            ent -= p * math.log2(p)
    return ent


def _sample_entropy(path, off: int, size: int, cap: int = 32 * 1024) -> float:
    """从文件偏移处采样计算熵（最多读 cap 字节）。"""
    try:
        with open(path, "rb") as f:
            f.seek(off)
            data = f.read(min(max(size, 0), cap))
        return _entropy(data)
    except Exception:
        return 0.0


def analyze(path: str, head: bytes = b"", size: int = 0):
    """主入口：返回 (score, tags)。
    head 为已读的 PE 头（通常 64KB），size 为文件总字节数。
    """
    if not head:
        try:
            with open(path, "rb") as f:
                head = f.read(65536)
        except Exception:
            return 0, []
    if len(head) < 64:
        return 0, []
    if head[:2] != b"MZ":
        return 0, []

    pe_off = struct.unpack_from("<I", head, 0x3C)[0]
    if pe_off + 24 > len(head) or head[pe_off:pe_off + 4] != b"PE\x00\x00":
        return 0, []

    score = 0
    tags = []
    try:
        opt_off = pe_off + 24
        opt_magic = struct.unpack_from("<H", head, opt_off)[0]
        is_pe32plus = (opt_magic == 0x20B)
        num_sections = struct.unpack_from("<H", head, pe_off + 6)[0]
        size_opt = struct.unpack_from("<H", head, pe_off + 20)[0]

        # 编译时间戳（PE_off+8）
        ts = struct.unpack_from("<I", head, pe_off + 8)[0]
        _add, _tag = _check_timestamp(ts, path)
        if _add:
            score += _add
            tags.append(_tag)

        # 可选头关键字段
        entry_rva = 0
        if opt_off + 16 + 4 <= len(head):
            # AddressOfEntryPoint 在可选头 +16
            entry_rva = struct.unpack_from("<I", head, opt_off + 16)[0]

        # 区段表
        sec_off = opt_off + size_opt
        sections = []  # (name, vaddr, vsize, rawptr, rawsize, chars)
        for i in range(num_sections):
            off = sec_off + i * 40
            if off + 40 > len(head):
                break
            name = head[off:off + 8].rstrip(b"\x00")
            vsize, vaddr = struct.unpack_from("<II", head, off + 8)
            rawsize, rawptr = struct.unpack_from("<II", head, off + 16)
            chars = struct.unpack_from("<I", head, off + 36)[0]
            sections.append((name, vaddr, vsize, rawptr, rawsize, chars))

        if not sections:
            return 0, []

        # 1) 区段数异常
        if num_sections < 2:
            score += 4
            tags.append("区段数异常(仅%d个区段)" % num_sections)
        elif num_sections > 14:
            score += 4
            tags.append("区段数异常(%d个区段)" % num_sections)

        # 2) 可疑壳区段名（不含 UPX——合法工具常用）
        packed_hits = [s[0].decode("ascii", "ignore") for s in sections
                       if s[0] in PACKED_SECTION_NAMES]
        if packed_hits:
            score += 6
            tags.append("加壳特征(壳区段: %s)" % ",".join(packed_hits[:3]))

        # 3) W+X 区段 & 入口点位置
        wx_count = 0
        entry_section = None
        entry_wx = False
        for (name, vaddr, vsize, rawptr, rawsize, chars) in sections:
            is_wx = (chars & CHAR_WRITABLE) and (chars & CHAR_EXECUTE)
            if is_wx and name not in (b"UPX0", b"UPX1"):
                wx_count += 1
            if vaddr <= entry_rva < vaddr + max(vsize, rawsize) or (
                    rawptr <= entry_rva < rawptr + max(vsize, rawsize)):
                entry_section = name
                entry_wx = is_wx
        if wx_count >= 2:
            score += 6
            tags.append("可写可执行区段%d个(W+X,代码注入高风险)" % wx_count)
        if entry_section is not None:
            if entry_wx and entry_section not in (b"UPX0", b"UPX1"):
                score += 6
                tags.append("入口点在可写可执行区段(%s)" %
                            entry_section.decode("ascii", "ignore"))
            elif entry_section not in NORMAL_CODE_SECTIONS and \
                    entry_section not in (b"UPX0", b"UPX1") and \
                    entry_section not in PACKED_SECTION_NAMES:
                score += 5
                tags.append("入口点位于非常规区段(%s)" %
                            entry_section.decode("ascii", "ignore"))

        # 4) 高熵区段（平均熵 > 7.3，加壳/加密特征；采样读，控制 IO）
        if size > 0:
            ent_sum = 0.0
            ent_n = 0
            for (name, vaddr, vsize, rawptr, rawsize, chars) in sections:
                if rawsize <= 0 or rawptr <= 0:
                    continue
                e = _sample_entropy(path, rawptr, rawsize)
                ent_sum += e
                ent_n += 1
            if ent_n >= 2:
                avg = ent_sum / ent_n
                if avg > 7.3:
                    score += 5
                    tags.append("高熵区段(平均熵%.2f,疑似加壳/加密)" % avg)

        # 5) overlay：文件比头部声明的原始数据末尾大很多 → 附加数据（捆绑/加壳常见）
        max_end = 0
        for (name, vaddr, vsize, rawptr, rawsize, chars) in sections:
            if rawsize > 0:
                max_end = max(max_end, rawptr + rawsize)
        if size > 0 and max_end > 0 and size - max_end > 1024 * 1024:
            score += 3
            tags.append("PE尾部附加数据(overlay %dKB)" % ((size - max_end) // 1024))

        # 6) 极小可执行文件
        if 0 < size < 15000:
            score += 6
            tags.append("极小的可执行文件(%d字节)" % size)

        # (7) 导入表缺失规则已移除：64KB 头部读不到导入目录时系统文件误判严重

        # 汇总（分值上限约束：避免纯启发式单点堆上严重；组合特征才允许高）
        if score > 25:
            score = 25
        return score, tags
    except Exception:
        return 0, []


def _check_timestamp(ts: int, path: str = ""):
    """编译时间戳异常：1970 纪元（伪造）或指向未来（时间戳欺诈）。
    返回 (加分, 标签)。Windows 系统目录（C:\\Windows）二进制的时间戳
    常被微软设为 1970/0/未来值（确定性构建），系统目录一律豁免时间戳规则。"""
    try:
        lp = (path or "").lower()
        if "\\windows\\" in lp or lp.startswith("c:\\windows"):
            return 0, ""
        if 0 <= ts < 315532800:  # <= 1980-01-01（含0）：几乎必为伪造/壳工具生成
            return 8, "编译时间戳异常(1970纪元伪造)"
        import time as _t
        now = int(_t.time())
        if ts > now + 180 * 86400:
            return 4, "编译时间戳指向未来(时间戳欺诈)"
    except Exception:
        pass
    return 0, ""


if __name__ == "__main__":
    import sys
    for p in sys.argv[1:]:
        try:
            with open(p, "rb") as f:
                h = f.read(65536)
            sz = os.path.getsize(p)
            s, t = analyze(p, h, sz)
            print("%s => score=%d tags=%s" % (p, s, t))
        except Exception as e:
            print("%s => ERR %s" % (p, e))
