# -*- coding: utf-8 -*-
"""6.4.1 修复版完整重建：便携zip + 源码zip + staging 同步 + ISCC 安装包"""
import io, os, zipfile, json, hashlib, time, shutil, subprocess

DG = r"F:\桌面保护\desktopguard"
OFF = os.path.join(DG, "官网")
PUB = os.path.join(OFF, "publish")
DIST = os.path.join(DG, "dist", "DG安全")
STAGING = r"F:\桌面保护\vmware\dg_staging\DG安全"
ISCC = r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
ISS = r"F:\桌面保护\vmware\dg_setup.iss"
NEW_VER = "6.4.1"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

def make_zip(src_dir, out_zip):
    if os.path.exists(out_zip):
        os.remove(out_zip)
    total = 0
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(src_dir):
            for f in files:
                fp = os.path.join(root, f)
                arc = os.path.relpath(fp, src_dir)
                z.write(fp, arc)
                total += 1
    return total

# ---- 1) 便携 zip（从 dist 打包） ----
portable = os.path.join(PUB, "DG-Security_%s.zip" % NEW_VER)
n = make_zip(DIST, portable)
portable_sha = sha256(portable)
print("[OK] portable zip: %d files, %d B, sha256 %s" % (n, os.path.getsize(portable), portable_sha[:16]))
# 同步到官网根目录
shutil.copy2(portable, os.path.join(OFF, os.path.basename(portable)))

# ---- 2) 源码 zip（沿用 641 基准逻辑） ----
SRC_SKIP = {".gitignore"}
src_files = set()
old_src = os.path.join(PUB, "DG-Source_%s.zip" % NEW_VER)
if os.path.isfile(old_src):
    with zipfile.ZipFile(old_src) as z:
        src_files = set(n for n in z.namelist() if "/" not in n)
root_files = set(f for f in os.listdir(DG) if os.path.isfile(os.path.join(DG, f)))
include = sorted((src_files | root_files) - SRC_SKIP)
src_zip = os.path.join(PUB, "DG-Source_%s.zip" % NEW_VER)
if os.path.exists(src_zip):
    os.remove(src_zip)
with zipfile.ZipFile(src_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for fn in include:
        p = os.path.join(DG, fn)
        if os.path.isfile(p):
            z.write(p, fn)
src_sha = sha256(src_zip)
print("[OK] source zip: %d files, %d B, sha256 %s" % (len(include), os.path.getsize(src_zip), src_sha[:16]))
shutil.copy2(src_zip, os.path.join(OFF, os.path.basename(src_zip)))

# ---- 3) staging 同步（dist -> staging） ----
if os.path.exists(STAGING):
    shutil.rmtree(STAGING)
shutil.copytree(DIST, STAGING)
staging_n = len(os.listdir(STAGING))
print("[OK] staging synced: %d top items" % staging_n)

# ---- 4) ISCC 编译安装包 ----
setup_out = os.path.join(OFF, "DG-Security-Setup-%s.exe" % NEW_VER)
if os.path.exists(setup_out):
    os.remove(setup_out)
r = subprocess.run([ISCC, ISS], capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=300)
print("ISCC exit:", r.returncode)
if r.returncode == 0 and os.path.isfile(setup_out):
    setup_sha = sha256(setup_out)
    print("[OK] setup: %d B, sha256 %s" % (os.path.getsize(setup_out), setup_sha[:16]))
    shutil.copy2(setup_out, os.path.join(PUB, os.path.basename(setup_out)))
else:
    print("ISCC failed:", r.stdout[-800:] if r.stdout else "", r.stderr[-800:] if r.stderr else "")

# ---- 5) version.json 全量（完整 URL pkg/sha256） ----
rel = "https://github.com/kittyguard/kittyguard/releases/download/v%s" % NEW_VER
notes = {
    "latest_version": NEW_VER,
    "version": NEW_VER,
    "release_date": "2026-10-09",
    "release_notes": "6.4.1 内容更新（移除 AI 助手聊天）：AI 聊天功能从工具页/托盘/设置全部移除，保留 AI 实时辅助。",
    "features": [
        "移除 AI 助手聊天：工具页「AI 助手」卡片、托盘「打开 AI 聊天」入口、AI 助手聊天窗口与 AI 动作执行器全部移除——作为一个杀毒软件，对话式 AI 助手没必要保留，入口更干净",
        "保留 AI 实时辅助：扫描后对高危/严重文件自动 AI 二次判断（AI 智能检查）与设置页隐藏 AI 配置区完整保留，杀毒判断能力不减",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ],
    "pkg": "%s/DG-Security_%s.zip" % (rel, NEW_VER),
    "sha256": portable_sha,
}
for d in (OFF, PUB, r"F:\桌面保护\kittyguard_site", r"F:\桌面保护\kittyguard_site\publish"):
    os.makedirs(d, exist_ok=True)
    with io.open(os.path.join(d, "version.json"), "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)
# dist/staging 内副本
for d in (os.path.join(DIST, "_internal"), os.path.join(STAGING, "_internal")):
    with io.open(os.path.join(d, "version.json"), "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 全量同步（pkg=完整 URL）")
print("PORTABLE_SHA=%s" % portable_sha)
print("SRC_SHA=%s" % src_sha)
