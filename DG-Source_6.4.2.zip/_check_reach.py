# -*- coding: utf-8 -*-
import urllib.request, socket, json

socket.setdefaulttimeout(25)

def fetch(url, proxy=None):
    if proxy:
        h = urllib.request.ProxyHandler({"http": proxy, "https": proxy})
        op = urllib.request.build_opener(h)
    else:
        op = urllib.request.build_opener()
    try:
        with op.open(url, timeout=25) as r:
            return r.status, r.read(2000)
    except Exception as e:
        return None, str(e)[:300]

print("=== 1. 线上 Pages HTML（走代理验证内容） ===")
st, body = fetch("https://kittyguard.github.io/kittyguard/index.html", "http://127.0.0.1:33210")
print("status:", st)
if body:
    import re
    m = re.findall(r'href="([^"]*6\.4\.1[^"]*)"', body.decode("utf-8", "ignore"))
    print("下载链接:", set(m))

print("\n=== 2. GitHub Release 直连（不走代理） ===")
for name in ["DG-Security-Setup-6.4.1.exe", "DG-Security_6.4.1.zip"]:
    u = "https://github.com/kittyguard/kittyguard/releases/download/v6.4.1/" + name
    st, body = fetch(u)
    print("%s: %s" % (name, st if st else body))

print("\n=== 3. GitHub Release 走代理 ===")
u = "https://github.com/kittyguard/kittyguard/releases/download/v6.4.1/DG-Security_6.4.1.zip"
st, body = fetch(u, "http://127.0.0.1:33210")
print("走代理:", st)

print("\n=== 4. Pages 直连（不走代理） ===")
st, body = fetch("https://kittyguard.github.io/kittyguard/index.html")
print("Pages 直连:", st if st else body)
