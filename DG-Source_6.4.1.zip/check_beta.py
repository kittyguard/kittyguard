# -*- coding: utf-8 -*-
import os
import re

beta_dir = r"F:\桌面保护\desktopguard-beta"

if os.path.exists(beta_dir):
    print("内测版目录存在")
    files = os.listdir(beta_dir)
    print("文件列表:", files[:20])
    
    main_py = os.path.join(beta_dir, "main.py")
    if os.path.exists(main_py):
        with open(main_py, 'r', encoding='utf-8') as f:
            c = f.read()
        m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', c)
        print("内测版当前版本:", m.group(1) if m else "未找到")
    else:
        print("内测版没有 main.py")
else:
    print("内测版目录不存在")
