# -*- coding: utf-8 -*-
"""4.17.0 补丁：工具页新增「启动项管家」+「文件粉碎」卡片，版本号提升"""
import io

MAIN = r"F:\桌面保护\desktopguard\main.py"
with io.open(MAIN, "r", encoding="utf-8") as f:
    m = f.read()

def rep(old, new, tag):
    global m
    assert old in m, f"未找到锚点: {tag}"
    assert m.count(old) == 1, f"锚点重复: {tag} ({m.count(old)})"
    m = m.replace(old, new, 1)

# ============ 1) 工具页新增 启动项管家(t9) + 文件粉碎(t10) 卡片 ============
rep('''        ttk.Button(t8, text="打开进程管理器", style="Accent.TButton", command=self._open_process_manager).pack(anchor="w", pady=(6, 0))''',
    '''        ttk.Button(t8, text="打开进程管理器", style="Accent.TButton", command=self._open_process_manager).pack(anchor="w", pady=(6, 0))
        t9 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)
        t9.pack(fill="x", pady=4)
        tk.Label(t9, text="启动项管家", bg=C_CARD2, fg=C_PRIMARY,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")
        tk.Label(t9, text="扫描全部开机自启动项（注册表 Run/RunOnce + 启动文件夹），一键禁用/启用（仅改值名/文件名，可逆恢复）；HKLM 与全局启动文件夹只读展示，不碰系统级配置",
                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))
        ttk.Button(t9, text="打开启动项管家", style="Accent.TButton", command=self._open_startup_manager).pack(anchor="w", pady=(6, 0))
        t10 = tk.Frame(tools, bg=C_CARD2, padx=14, pady=12)
        t10.pack(fill="x", pady=4)
        tk.Label(t10, text="文件粉碎", bg=C_CARD2, fg=C_PRIMARY,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w")
        tk.Label(t10, text="对选中的文件多次覆写（随机→00→FF）后删除，常规手段不可恢复；适合粉碎隐私文件/临时敏感数据，系统文件自动拒绝",
                 bg=C_CARD2, fg=C_SUB, font=("Microsoft YaHei UI", 9), justify="left").pack(anchor="w", pady=(4, 0))
        ttk.Button(t10, text="粉碎文件…", style="Accent.TButton", command=self._on_shred_files).pack(anchor="w", pady=(6, 0))''',
    "工具页启动项管家+文件粉碎卡片")

# ============ 2) 启动方法：启动项管家 + 文件粉碎 ============
rep('''    def _open_process_manager(self):
        """打开进程管理器（独立进程，防重复启动）"""''',
    '''    def _open_startup_manager(self):
        """打开启动项管家（独立进程，防重复启动）"""
        import ctypes
        found = []
        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def cb(h, l):
            if ctypes.windll.user32.IsWindowVisible(h):
                buf = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetWindowTextW(h, buf, 256)
                if "DG 启动项管家" in buf.value:
                    found.append(h)
            return True
        try:
            ctypes.windll.user32.EnumWindows(cb, 0)
        except Exception:
            pass
        if found:
            messagebox.showinfo("启动项管家", "启动项管家已在运行。")
            return
        script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "startup_manager.py")
        if not os.path.exists(script):
            messagebox.showerror("启动项管家", "未找到 startup_manager.py。")
            return
        try:
            exe = sys.executable
            if exe and exe.lower().endswith("python.exe"):
                exe = exe[:-len("python.exe")] + "pythonw.exe"
            if not exe or not os.path.exists(exe):
                exe = sys.executable
            subprocess.Popen([exe, script],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            messagebox.showinfo("启动项管家", "启动项管家已打开。")
        except Exception as e:
            messagebox.showerror("启动项管家", f"启动失败：{e}")

    def _on_shred_files(self):
        """文件粉碎：多选文件 → 确认 → 后台覆写删除"""
        try:
            from shred import shred_files
        except Exception as e:
            messagebox.showerror("文件粉碎", f"模块加载失败：{e}", parent=self.root)
            return
        paths = filedialog.askopenfilenames(title="选择要粉碎的文件（DG 文件粉碎）", parent=self.root)
        if not paths:
            return
        total = sum(os.path.getsize(p) for p in paths if os.path.isfile(p))
        gb = total / (1024 ** 3)
        if not messagebox.askyesno(
                "文件粉碎",
                f"确认粉碎 {len(paths)} 个文件？\n\n"
                f"共约 {gb:.2f} GB，将被多次覆写后删除，**常规手段不可恢复**。\n\n"
                f"系统文件会自动拒绝，请勿粉碎仍需要的文件。",
                parent=self.root):
            return
        self._append_log(f"文件粉碎开始：{len(paths)} 个文件，约 {gb:.2f} GB")
        threading.Thread(target=self._shred_worker, args=(list(paths),), daemon=True).start()

    def _shred_worker(self, paths):
        from shred import shred_files
        ok, fails = shred_files(paths)
        msg = f"文件粉碎完成：成功 {ok} 个"
        if fails:
            msg += f"，失败 {len(fails)} 个"
            for p, r in fails[:5]:
                msg += f"\n  {os.path.basename(p)}：{r}"
            if len(fails) > 5:
                msg += f"\n  …另 {len(fails) - 5} 个"
        try:
            self.root.after(0, lambda: (self._append_log(msg),
                                        messagebox.showinfo("文件粉碎", msg, parent=self.root)))
        except Exception:
            pass

    def _open_process_manager(self):
        """打开进程管理器（独立进程，防重复启动）"""''',
    "启动项管家+文件粉碎方法")

# ============ 3) 版本号 & 历史 ============
rep('APP_VERSION = "4.16.1"', 'APP_VERSION = "4.17.0"', "版本号")
rep('''    ("4.16.1", "4.16.0", "补丁（进程管理器重做·DG特色版）：''',
    '''    ("4.17.0", "4.16.1", "内容更新（启动项管家+文件粉碎）：1.【启动项管家】独立窗口——扫描全部开机自启动项（注册表 Run/RunOnce + 用户/全局启动文件夹），状态/来源/名称/命令一目了然；一键禁用/启用（仅改注册表值名或文件名加 DG_OFF_ 前缀，可逆恢复，不删除任何数据）；HKLM 与全局启动文件夹只读展示，系统级配置本工具不碰；支持右键操作与打开文件位置定位程序；2.【文件粉碎】工具页入口——多选文件后随机→00→FF 三次覆写再删除（含 fsync 落盘），常规手段不可恢复；自动拒绝 .sys/.dll 系统文件，占用/无权限文件跳过并报告；适合粉碎隐私与临时敏感文件"),
    ("4.16.1", "4.16.0", "补丁（进程管理器重做·DG特色版）：''',
    "版本历史")

with io.open(MAIN, "w", encoding="utf-8") as f:
    f.write(m)

import py_compile
for p in (MAIN, r"F:\桌面保护\desktopguard\startup_manager.py", r"F:\桌面保护\desktopguard\shred.py"):
    py_compile.compile(p, doraise=True)
print("[OK] 4.17.0 补丁应用，main.py + startup_manager.py + shred.py 语法通过")
