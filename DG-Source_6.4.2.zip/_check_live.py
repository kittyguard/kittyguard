# -*- coding: utf-8 -*-
import subprocess, re

# 1) curl 拉线上 Pages HTML 全文（模拟真实浏览器，无代理直连）
r = subprocess.run(
    ["curl", "-s", "-L", "--max-time", "60", "https://kittyguard.github.io/kittyguard/index.html"],
    capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=90)
html = r.stdout
print("线上 Pages HTML 长度:", len(html))
links = set(re.findall(r'href="([^"]*6\.4\.1[^"]*)"', html))
print("下载链接:", sorted(links))
print("是否相对路径残留:", any(l.startswith("DG-") for l in links))

# 2) curl 直连 GitHub Release（无代理）
for name in ["DG-Security-Setup-6.4.1.exe", "DG-Security_6.4.1.zip"]:
    u = "https://github.com/kittyguard/kittyguard/releases/download/v6.4.1/" + name
    r2 = subprocess.run(
        ["curl", "-s", "-o", "NUL", "-w", "%{http_code} %{size_download}", "-L", "--max-time", "90", u],
        capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=120)
    print("直连 %s: %s" % (name, r2.stdout or r2.stderr[:200]))
