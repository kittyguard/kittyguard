# -*- coding: utf-8 -*-
"""2.8.0 发布：安全体检全面加固"""
import os, shutil, json

src = r'F:\桌面保护\desktopguard'
beta = r'F:\桌面保护\desktopguard-beta'

# 1. 同步到内测版
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp']:
    s = os.path.join(src, fname)
    d = os.path.join(beta, fname)
    if os.path.exists(s):
        shutil.copy2(s, d)
print("已同步内测版")

# 2. 版本号 -> 2.8.0
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py', 'scan_core_bridge.py']:
    p = os.path.join(src, fname)
    with open(p, 'r', encoding='utf-8') as f:
        c = f.read()
    c = c.replace('APP_VERSION = "2.7.1"', 'APP_VERSION = "2.8.0"')
    c = c.replace('"2.7.1"', '"2.8.0"')
    with open(p, 'w', encoding='utf-8') as f:
        f.write(c)
print("版本号 -> 2.8.0")

# 3. version.json
version_data = {
    "latest_version": "2.8.0",
    "release_date": "2026-09-08",
    "release_notes": "2.8.0 内容更新：安全体检全面加固。1.新增30秒总超时兜底（任何检查卡住都会强制完成并显示已收集结果，不再永远卡在\"正在体检\"）；2.缩短所有subprocess超时（schtasks 8->6s，sc/netsh 5->4s）；3.体检线程全程异常保护；4.超时时自动补全未完成项提示",
    "features": [
        "安全体检永不卡死：30秒超时兜底自动完成",
        "体检速度更快：subprocess超时全面缩短",
        "窗口标题 DG 桌面安全卫士，窗口1280宽按钮完整"
    ]
}
with open(os.path.join(src, 'version.json'), 'w', encoding='utf-8') as f:
    json.dump(version_data, f, ensure_ascii=False, indent=2)
print("version.json 已更新")

# 4. 快照
snap = os.path.join(src, 'versions', '2.8.0')
os.makedirs(snap, exist_ok=True)
for fname in ['main.py', 'engine.py', 'database.py', 'logger.py', 'realtime_protection.py',
              'scan_core_bridge.py', 'scan_core.exe', 'scan_core.cpp']:
    s = os.path.join(src, fname)
    if os.path.exists(s):
        shutil.copy2(s, os.path.join(snap, fname))
print("快照 versions/2.8.0 已创建")
print("\n2.8.0 发布完成！")
