# -*- coding: utf-8 -*-
import os, sys

def show(p):
    print(p, "exists:", os.path.isdir(p))
    if os.path.isdir(p):
        try:
            items = os.listdir(p)
        except Exception as e:
            print("  listdir error:", e)
            return
        print("  count:", len(items))
        for f in items[:50]:
            fp = os.path.join(p, f)
            try:
                sz = os.path.getsize(fp) if os.path.isfile(fp) else "<dir>"
            except Exception:
                sz = "?"
            print("   ", f, sz)
        print()

for p in [r"F:\桌面保护", r"F:\桌面保护\kittyguard_site", r"F:\桌面保护\desktopguard\官网", r"F:\桌面保护\desktopguard\官网\publish"]:
    show(p)
