// dg_etw2.cpp — 二进制对照版：完全复制 diag_etw.cpp 能收事件的 ETW 结构 + 输出逻辑
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <shellapi.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "tdh.lib")
#pragma comment(lib, "shell32.lib")

static const GUID KERNEL_PROCESS_PROVIDER = { 0x22FB2CD6, 0x0E7B, 0x422B, { 0xA0, 0xC7, 0x2F, 0xAD, 0x1F, 0xD0, 0xE7, 0x16 } };
static const wchar_t* SESSION_NAME = L"DG-ETW-DIAG";
static volatile bool g_done = false;
static volatile long long g_ev = 0;

// 参数：<jsonl> <hb> <flag>
static std::wstring g_jsonl, g_hb, g_flag;
static HANDLE g_hOut = INVALID_HANDLE_VALUE;

static void WriteOut(const char* s) {
    if (g_hOut == INVALID_HANDLE_VALUE) return;
    DWORD w = 0;
    WriteFile(g_hOut, s, (DWORD)strlen(s), &w, NULL);
    WriteFile(g_hOut, "\n", 1, &w, NULL);
    FlushFileBuffers(g_hOut);
}

static void WINAPI OnEvent(EVENT_RECORD* rec) {
    if (!rec) return;
    g_ev++;
    // 无条件记录：任何事件到达立即写 status
    HANDLE hs = CreateFileW(L"C:\\etwtest\\cb_status.txt", FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                            NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hs != INVALID_HANDLE_VALUE) {
        char b[64]; sprintf_s(b, "cb ev=%lld id=%u\n", g_ev, rec->EventHeader.EventDescriptor.Id);
        DWORD w = 0; WriteFile(hs, b, (DWORD)strlen(b), &w, NULL); CloseHandle(hs);
    }
    UCHAR eid = rec->EventHeader.EventDescriptor.Id;
    if (eid != 1 && eid != 2) return;
    char line[256];
    sprintf_s(line, "{\"e\":%u,\"pid\":%u}", eid, rec->EventHeader.ProcessId);
    WriteOut(line);
}

static DWORD WINAPI TraceThread(LPVOID p) {
    ProcessTrace((PTRACEHANDLE)p, 1, 0, 0);
    g_done = true;
    return 0;
}

static DWORD WINAPI HbThread(LPVOID) {
    while (!g_done) {
        HANDLE h = CreateFileW(g_hb.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (h != INVALID_HANDLE_VALUE) {
            char b[32]; sprintf_s(b, "%lld", (long long)GetTickCount64());
            DWORD w = 0; WriteFile(h, b, (DWORD)strlen(b), &w, NULL); CloseHandle(h);
        }
        Sleep(5000);
    }
    return 0;
}

int wmain() {
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    // GetCommandLineW 含程序名：argv[0]=exe, 参数从 argv[1] 开始
    if (argc < 4) return 2;
    g_jsonl = argv[1]; g_hb = argv[2]; g_flag = argv[3];
    LocalFree(argv);

    if (GetFileAttributesW(g_flag.c_str()) != INVALID_FILE_ATTRIBUTES) return 0;
    g_hOut = CreateFileW(g_jsonl.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                         NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (g_hOut == INVALID_HANDLE_VALUE) return 3;

    BYTE buf[sizeof(EVENT_TRACE_PROPERTIES) + 64 * sizeof(wchar_t)];
    EVENT_TRACE_PROPERTIES* props = (EVENT_TRACE_PROPERTIES*)buf;
    memset(buf, 0, sizeof(buf));
    props->Wnode.BufferSize = sizeof(buf);
    props->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
    props->Wnode.Guid = { 0x3B2E2C6A, 0x5F7A, 0x9D4E, { 0x8C, 0x1B, 0x2A, 0x4D, 0x6E, 0x3F, 0x9C, 0x5D } };
    props->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
    wcscpy_s((wchar_t*)(buf + props->LoggerNameOffset), 64, SESSION_NAME);
    props->LogFileMode = EVENT_TRACE_REAL_TIME_MODE;
    props->MinimumBuffers = 2; props->MaximumBuffers = 16; props->FlushTimer = 1;
    TRACEHANDLE sess = 0;
    ULONG r = StartTraceW(&sess, SESSION_NAME, props);
    if (r == ERROR_ALREADY_EXISTS) {
        ControlTraceW(0, SESSION_NAME, props, EVENT_TRACE_CONTROL_STOP);
        Sleep(500);
        r = StartTraceW(&sess, SESSION_NAME, props);
    }
    if (r != ERROR_SUCCESS) { CloseHandle(g_hOut); return 4; }
    r = EnableTraceEx2(sess, &KERNEL_PROCESS_PROVIDER, EVENT_CONTROL_CODE_ENABLE_PROVIDER, 4, 0, 0, 0, NULL);
    if (r != ERROR_SUCCESS) { ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP); CloseHandle(g_hOut); return 5; }

    EVENT_TRACE_LOGFILEW lf; memset(&lf, 0, sizeof(lf));
    lf.LoggerName = (LPWSTR)SESSION_NAME;
    lf.ProcessTraceMode = PROCESS_TRACE_MODE_REAL_TIME | PROCESS_TRACE_MODE_EVENT_RECORD;
    lf.EventRecordCallback = (PEVENT_RECORD_CALLBACK)OnEvent;
    TRACEHANDLE h = OpenTraceW(&lf);
    if (h == (TRACEHANDLE)INVALID_HANDLE_VALUE) { CloseHandle(g_hOut); return 6; }

    HANDLE hThread = CreateThread(NULL, 0, TraceThread, &h, 0, NULL);
    HANDLE hHb = CreateThread(NULL, 0, HbThread, NULL, 0, NULL);

    while (GetFileAttributesW(g_flag.c_str()) == INVALID_FILE_ATTRIBUTES) {
        Sleep(500);
    }
    ControlTraceW(sess, SESSION_NAME, NULL, EVENT_TRACE_CONTROL_STOP);
    WaitForSingleObject(hThread, 3000);
    CloseHandle(hThread); CloseHandle(hHb);
    char fin[64]; sprintf_s(fin, "{\"final\":%lld}", g_ev); WriteOut(fin);
    if (g_hOut != INVALID_HANDLE_VALUE) CloseHandle(g_hOut);
    return 0;
}
