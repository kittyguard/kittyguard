# -*- coding: utf-8 -*-
"""
cloud_lookup.py — 云查威胁情报模块（3.1.0 新增，3.2.0 扩展多引擎）
查询链：本地病毒库 → 本地缓存 → 云端（微步 ThreatBook / VirusTotal / 双通道）。
无 API Key / 断网 / 超时 时优雅降级（返回 None），不影响任何本地功能。
"""
import json
import time

TIMEOUT = 3  # 单次云查超时（秒），保证不拖慢体验
VT_TIMEOUT = 5  # VirusTotal 响应较慢，放宽到 5 秒


def _http_get(url, params=None, headers=None, timeout=TIMEOUT):
    """极简 GET+JSON，返回 dict 或 None。用 urllib（零依赖），任何异常返回 None。"""
    import urllib.request
    import urllib.parse
    try:
        full = url
        if params:
            qs = urllib.parse.urlencode(params)
            full = url + ("&" if "?" in url else "?") + qs
        hdrs = {"User-Agent": "DG-Security/3.2.0", "Accept": "application/json"}
        if headers:
            hdrs.update(headers)
        req = urllib.request.Request(full, headers=hdrs)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            raw = resp.read(1024 * 1024).decode("utf-8", "ignore")
        return json.loads(raw)
    except Exception:
        return None


def _query_threatbook(sha256, api_key, timeout=TIMEOUT):
    """微步在线 v3：GET /v3/file/report?apikey=KEY&sha256=HASH"""
    data = _http_get("https://api.threatbook.cn/v3/file/report",
                     {"apikey": api_key, "sha256": sha256}, timeout=timeout)
    if not data or data.get("response_code", -1) != 0:
        return None
    d = data.get("data") or {}
    basic = d.get("basic") or {}
    summary = d.get("summary") or {}
    verdict = summary.get("verdict", "unknown")
    if verdict == "clean":
        return {"verdict": "clean", "name": "", "severity": "低危",
                "source": "微步", "detail": "微步云端：未发现威胁"}
    if verdict in ("malicious", "suspicious"):
        sev = {"high": "高危", "medium": "中危", "low": "低危"}.get(
            str(summary.get("severity", "")).lower(), "中危")
        name = basic.get("threat_name") or basic.get("threat_type") or "未知威胁"
        detail = ("微步云端判定：%s（%s），威胁名称 %s"
                  % ("恶意" if verdict == "malicious" else "可疑", sev, name))
        return {"verdict": verdict, "name": name, "severity": sev,
                "source": "微步", "detail": detail}
    return None  # unknown 不判


def _query_virustotal(sha256, api_key, timeout=VT_TIMEOUT):
    """VirusTotal v3：GET /api/v3/files/{sha256}，header x-apikey。
    返回 last_analysis_stats 的检出统计判定。未收录(404)/失败 → None。"""
    data = _http_get("https://www.virustotal.com/api/v3/files/" + sha256,
                     headers={"x-apikey": api_key}, timeout=timeout)
    if not data:
        return None
    d = data.get("data") or {}
    attrs = d.get("attributes") or {}
    stats = attrs.get("last_analysis_stats") or {}
    malicious = int(stats.get("malicious", 0) or 0)
    suspicious = int(stats.get("suspicious", 0) or 0)
    if malicious > 0:
        sev = "高危" if malicious >= 5 else "中危"
        name = attrs.get("meaningful_name") or "VirusTotal 检出"
        return {"verdict": "malicious", "name": name, "severity": sev,
                "source": "VirusTotal",
                "detail": "VirusTotal：%d 个引擎检出恶意（%d 可疑，%d 未检出）"
                          % (malicious, suspicious, int(stats.get("undetected", 0) or 0))}
    if suspicious > 0:
        return {"verdict": "suspicious", "name": attrs.get("meaningful_name") or "VirusTotal 可疑",
                "severity": "中危", "source": "VirusTotal",
                "detail": "VirusTotal：%d 个引擎标记可疑（%d 未检出）"
                          % (suspicious, int(stats.get("undetected", 0) or 0))}
    if attrs.get("last_analysis_date"):
        return {"verdict": "clean", "name": "", "severity": "低危", "source": "VirusTotal",
                "detail": "VirusTotal：%d 个引擎均未检出威胁" % int(stats.get("harmless", 0) or 0)}
    return None  # 无分析记录（未收录），不判


def lookup_sha256(sha256, api_key, engine="threatbook", vt_key=None, timeout=None):
    """查询单个文件的云端威胁情报（不查本地缓存）。
    engine: threatbook | virustotal | both（微步优先，未命中再补 VT）
    返回 dict（verdict/name/severity/source/detail）或 None。
    """
    if not sha256 or len(sha256) != 64:
        return None
    try:
        if engine == "virustotal":
            if not vt_key:
                return None
            return _query_virustotal(sha256, vt_key, timeout=timeout or VT_TIMEOUT)
        if engine == "both":
            # 双通道：微步优先（国内快），未命中/unknown 再补 VT
            if api_key:
                r = _query_threatbook(sha256, api_key, timeout=timeout or TIMEOUT)
                if r:
                    return r
            if vt_key:
                return _query_virustotal(sha256, vt_key, timeout=timeout or VT_TIMEOUT)
            return None
        # threatbook（默认）
        if not api_key:
            return None
        return _query_threatbook(sha256, api_key, timeout=timeout or TIMEOUT)
    except Exception:
        return None


def query(sha256, api_key, engine="threatbook", vt_key=None):
    """带缓存的云查（本地优先）：
    1. 本地病毒库哈希命中 → 直接返回（不花云端配额）
    2. cloud_cache 命中 → 返回缓存
    3. 调云端并回写缓存
    断网/无 key/超时 → 静默返回 None，本地功能不受影响。
    """
    if not sha256 or len(sha256) != 64:
        return None
    try:
        import database as _db
        vmap = _db.get_virus_hash_map()
        if sha256 in vmap:
            desc = vmap[sha256]
            return {"verdict": "malicious", "name": desc, "severity": "高危",
                    "source": "本地病毒库",
                    "detail": "本地病毒库命中：%s" % desc}
    except Exception:
        pass
    try:
        import database as _db
        hit = _db.get_cloud_cache(sha256)
        if hit:
            if not hit.get("detail"):
                hit["detail"] = "云端缓存判定：%s（%s）" % (
                    {"malicious": "恶意", "suspicious": "可疑", "clean": "未发现威胁"}.get(
                        hit.get("verdict", ""), hit.get("verdict", "")),
                    hit.get("source", ""))
            return hit
    except Exception:
        pass
    result = lookup_sha256(sha256, api_key, engine, vt_key)
    if result:
        try:
            import database as _db
            _db.set_cloud_cache(sha256, result.get("verdict", ""),
                                result.get("name", ""), result.get("severity", ""),
                                result.get("source", ""))
        except Exception:
            pass
        return result
    return None
