# -*- coding: utf-8 -*-
"""发布 5.4.1：快照 + 重建防篡改清单 + version.json（扫描加速开关）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "5.4.1"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

# 重建防篡改清单（当前安装态 = 受信任态）
sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

# 更新 version.json（更新服务器读取）
notes = {
    "latest_version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "5.4.1 扫描加速开关版：C++ 加速核心对三种扫描模式可独立开关。",
    "features": [
        "扫描加速开关：设置-扫描加速分组，深度/高级/快速扫描可独立开关 C++ 加速核心（默认深度/高级开、快速关）",
        "部分目录加速：快速/高级扫描由 C++ 枚举桌面/下载/AppData，Python 补扫盘根浅层，两路合并入队",
        "提示联动：扫描副状态按模式显示 C++ 加速核心启用范围",
        "停止联动：停止按钮对三种模式的 C++ 核心均生效",
        "预统计优化：有 C++ 结果时跳过 Python 重复枚举，进度走 C++ 遍历进度"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
