# -*- coding: utf-8 -*-
"""Gitee 仓库同步 6.4.3（index/version/便携/源码/publish，跳过 327MB 安装包）"""
import os, shutil, subprocess

TOKEN = "964d5ca1cfc09792719272c1260170a8"
GITEE = "https://kittyguard:%s@gitee.com/kittyguard/kittyguard.git" % TOKEN
SYNC = r"F:\桌面保护\gitee_sync"
SITE = r"F:\桌面保护\kittyguard_site"
OFF = r"F:\桌面保护\desktopguard\官网"

def run(c):
    r = subprocess.run(c, capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=1800)
    print("$", " ".join(c)[:120], "exit", r.returncode)
    if r.stdout: print((r.stdout or "")[-600:])
    if r.stderr and r.returncode != 0: print((r.stderr or "")[-600:])
    return r.returncode

if os.path.isdir(SYNC):
    shutil.rmtree(SYNC, ignore_errors=True)
run(["git", "clone", "--depth", "1", GITEE, SYNC])
if not os.path.isdir(os.path.join(SYNC, ".git")):
    print("CLONE_FAILED"); raise SystemExit(1)

# 更新文件
files = ["index.html", "version.json", "DG安全官网.html",
         "DG-Security_6.4.3.zip", "DG-Source_6.4.3.zip"]
for f in files:
    for src in (SITE, OFF):
        p = os.path.join(src, f)
        if os.path.isfile(p):
            shutil.copy2(p, os.path.join(SYNC, f))
            print("updated", f)
            break
pub = os.path.join(SYNC, "publish")
os.makedirs(pub, exist_ok=True)
for f in ("index.html", "version.json", "DG-Security_6.4.3.zip", "DG-Source_6.4.3.zip"):
    for src in (os.path.join(SITE, "publish"), os.path.join(OFF, "publish"), SITE, OFF):
        p = os.path.join(src, f)
        if os.path.isfile(p):
            shutil.copy2(p, os.path.join(pub, f))
            print("publish updated", f)
            break
# 删除旧版产物（保持仓库干净：6.4.1/6.4.2 保留可回滚）
for f in os.listdir(SYNC):
    if f.startswith("DG-Security") and "6.4.3" not in f:
        os.remove(os.path.join(SYNC, f)); print("removed old", f)
for f in os.listdir(pub):
    if f.startswith("DG-Security") and "6.4.3" not in f:
        os.remove(os.path.join(pub, f)); print("publish removed old", f)

run(["git", "-C", SYNC, "add", "-A"])
run(["git", "-C", SYNC, "-c", "user.name=kittyguard", "-c", "user.email=3946983359@qq.com",
     "commit", "-m", "sync 6.4.3 发行修复版（ClamAV 去代理/卸载零残留/向导版工具可用）官网+产物+version.json"])
run(["git", "-C", SYNC, "push", "origin", "main"])
print("GITEE_SYNC_DONE")
