# -*- coding: utf-8 -*-
"""查找免责声明.txt 实际位置"""
import os
cands = [
    r"F:\桌面保护\desktopguard\重要文件",
    r"F:\桌面保护\vmware\dg_staging",
    r"F:\桌面保护\vmware",
    r"F:\桌面保护\desktopguard",
]
for c in cands:
    if os.path.isdir(c):
        for f in os.listdir(c):
            if "免责" in f or "声明" in f:
                print(os.path.join(c, f), os.path.getsize(os.path.join(c, f)))
