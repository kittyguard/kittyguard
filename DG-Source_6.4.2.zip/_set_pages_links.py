# -*- coding: utf-8 -*-
import io, os

# 目标：6 份 HTML（本地官网 3 份 + Pages 仓库 3 份）
targets = [
    r'F:\桌面保护\desktopguard\官网\DG安全官网.html',
    r'F:\桌面保护\desktopguard\官网\index.html',
    r'F:\桌面保护\desktopguard\官网\publish\index.html',
    r'F:\桌面保护\kittyguard_site\DG安全官网.html',
    r'F:\桌面保护\kittyguard_site\index.html',
    r'F:\桌面保护\kittyguard_site\publish\index.html',
]

PAGES = "https://kittyguard.github.io/kittyguard/"
RELEASE = "https://github.com/kittyguard/kittyguard/releases/download/v6.4.1/"

# 替换规则：相对路径 / Release 直链 -> Pages 直链（Pages 上已有文件）
pairs = [
    # 安装向导版
    ('href="DG-Security-Setup-6.4.1.exe"', 'href="%sDG-Security-Setup-6.4.1.exe"' % PAGES),
    ('href="%sDG-Security-Setup-6.4.1.exe"' % RELEASE, 'href="%sDG-Security-Setup-6.4.1.exe"' % PAGES),
    # 便携版
    ('href="DG-Security_6.4.1.zip"', 'href="%sDG-Security_6.4.1.zip"' % PAGES),
    ('href="%sDG-Security_6.4.1.zip"' % RELEASE, 'href="%sDG-Security_6.4.1.zip"' % PAGES),
    # 源码版（如果有）
    ('href="DG-Source_6.4.1.zip"', 'href="%sDG-Source_6.4.1.zip"' % PAGES),
    ('href="%sDG-Source_6.4.1.zip"' % RELEASE, 'href="%sDG-Source_6.4.1.zip"' % PAGES),
]

for t in targets:
    if not os.path.exists(t):
        print("SKIP:", t)
        continue
    with io.open(t, 'r', encoding='utf-8') as f:
        s = f.read()
    changed = []
    for old, new in pairs:
        c = s.count(old)
        if c:
            s = s.replace(old, new)
            changed.append((old.split('"')[1], c))
    with io.open(t, 'w', encoding='utf-8') as f:
        f.write(s)
    print(os.path.basename(t), "->", changed if changed else "无变化")
