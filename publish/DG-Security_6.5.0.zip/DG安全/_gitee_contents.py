# -*- coding: utf-8 -*-
"""查 Gitee 仓库文件列表"""
import json, urllib.request
TOKEN = "964d5ca1cfc09792719272c1260170a8"
BASE = "https://gitee.com/api/v5/repos/kittyguard/kittyguard"
req = urllib.request.Request(BASE + "/contents?access_token=%s" % TOKEN, headers={"User-Agent": "kittyguard"})
with urllib.request.urlopen(req, timeout=30) as r:
    j = json.loads(r.read().decode("utf-8"))
    for f in j:
        print(f.get("type"), f.get("name"))
