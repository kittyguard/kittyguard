# -*- coding: utf-8 -*-
"""真实桌面：强制激活 DG 主窗口（AttachThreadInput + 模拟Alt + SetForegroundWindow）。"""
import ctypes, time
import ctypes.wintypes as w

try:
    import psutil
except ImportError:
    psutil = None

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
SW_RESTORE = 9

pid = 0
if psutil:
    for p in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            nm = (p.info.get("name") or "").lower()
            if "python" not in nm:
                continue
            cl = " ".join(p.info.get("cmdline") or [])
            if "main.py" in cl:
                pid = p.info["pid"]
                break
        except Exception:
            continue
print("PID", pid)

found = []
def _cb(h, l):
    p = w.DWORD()
    user32.GetWindowThreadProcessId(h, ctypes.byref(p))
    if pid and p.value == pid:
        buf = ctypes.create_unicode_buffer(256)
        user32.GetWindowTextW(h, buf, 256)
        if buf.value.strip():
            found.append((h, p.value, buf.value))
    return True

WNDENUMPROC = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
user32.EnumWindows(WNDENUMPROC(_cb), 0)
print("WIN:", [(hex(h), t) for h, _, t in found[:6]])
hwnd = 0
for h, _, t in found:
    if t and "安全卫士" in t:
        hwnd = h
        break
if not hwnd:
    for h, _, t in found:
        if t and ("DG" in t or "安全" in t or "桌面" in t):
            hwnd = h
            break
if not hwnd and found:
    hwnd = found[0][0]
if not hwnd:
    print("NOT_FOUND")
    raise SystemExit

# 强制置前：前台线程 AttachThreadInput + 模拟 Alt
fg = user32.GetForegroundWindow()
fg_tid = user32.GetWindowThreadProcessId(fg, None)
my_tid = kernel32.GetCurrentThreadId()
if fg_tid != my_tid:
    user32.AttachThreadInput(my_tid, fg_tid, True)
try:
    user32.ShowWindow(hwnd, SW_RESTORE)
    user32.BringWindowToTop(hwnd)
    user32.SetForegroundWindow(hwnd)
    user32.keybd_event(0x12, 0, 0, 0)   # Alt down
    user32.keybd_event(0x12, 0, 2, 0)   # Alt up
    user32.SetForegroundWindow(hwnd)
finally:
    if fg_tid != my_tid:
        user32.AttachThreadInput(my_tid, fg_tid, False)
print("SHOWN", hex(hwnd))
