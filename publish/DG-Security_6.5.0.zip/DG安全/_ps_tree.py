# -*- coding: utf-8 -*-
import subprocess

ps = subprocess.run(["powershell", "-NoProfile", "-Command",
    "Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -match 'desktopguard' -or ($_.Name -eq 'pythonw.exe' -and $_.CommandLine -match 'main.py') } | ForEach-Object { $_.ProcessId.ToString() + '|' + $_.Name + '|' + $_.CommandLine }"],
    capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=60)
print(ps.stdout)
