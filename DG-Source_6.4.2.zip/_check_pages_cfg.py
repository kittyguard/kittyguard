# -*- coding: utf-8 -*-
import urllib.request, json, ssl

PROXY = "http://127.0.0.1:33210"
TOKEN = "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"

h = urllib.request.ProxyHandler({"http": PROXY, "https": PROXY})
op = urllib.request.build_opener(h)

def api(url):
    req = urllib.request.Request(url, headers={"Authorization": "token " + TOKEN,
                                               "User-Agent": "dg-fix"})
    with op.open(req, timeout=60) as r:
        return r.status, json.loads(r.read().decode("utf-8", "ignore"))

st, data = api("https://api.github.com/repos/kittyguard/kittyguard/pages")
print("pages status:", st)
print(json.dumps(data, ensure_ascii=False, indent=1)[:1200])

st2, data2 = api("https://api.github.com/repos/kittyguard/kittyguard/branches")
print("\nbranches:", st2)
for b in data2:
    print(" -", b["name"], b["commit"]["sha"][:7])
