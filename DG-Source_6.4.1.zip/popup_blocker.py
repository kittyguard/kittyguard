# -*- coding: utf-8 -*-
"""DG 弹窗拦截模块
枚举系统所有顶层可见窗口，按规则（标题关键词 / 进程名黑名单）自动关闭
广告、流氓软件弹窗。温和模式默认只发送 WM_CLOSE；强力模式在连续关闭
无效后升级为结束进程（默认关闭，需在设置中开启）。
安全保护：跳过前台窗口（用户正在使用的）、跳过 DG 自身组件窗口、
跳过无标题/超长标题窗口（多为正常主窗口）、支持标题白名单。
"""
import ctypes
import ctypes.wintypes as wt
import os
import threading
import time

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
psapi = ctypes.windll.psapi

WM_CLOSE = 0x0010
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_INFORMATION = 0x0400

WNDENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)

# GetModuleBaseNameW: BOOL GetModuleBaseNameW(HANDLE, HMODULE, LPWSTR, DWORD)
psapi.GetModuleBaseNameW.argtypes = [wt.HANDLE, wt.HMODULE, wt.LPWSTR, wt.DWORD]
psapi.GetModuleBaseNameW.restype = wt.DWORD
user32.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
user32.GetWindowTextW.restype = ctypes.c_int
user32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
user32.GetWindowThreadProcessId.restype = wt.DWORD
user32.PostMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
user32.PostMessageW.restype = wt.BOOL

# ---------------- 弹窗标题黑名单关键词 ----------------
BLOCK_TITLE_KEYWORDS = [
    "广告", "推广", "弹窗", "推荐", "猜你喜欢", "热门推荐", "福利", "抽奖", "红包",
    "领奖", "签到领", "限时", "优惠", "秒杀", "免费领取", "赚钱", "金币", "任务中心",
    "每日福利", "热点", "直播", "传奇", "一刀", "游戏推广", "更新提示", "升级通知",
    "推送", "资讯弹窗", "提醒您", "精彩推荐", "专属推荐", "惊喜", "好礼",
]

# ---------------- 进程名黑名单（常见流氓弹窗进程，可增补） ----------------
BLOCK_PROC_NAMES = [
    "hyupdate.exe", "hysetup.exe", "2345picload.exe", "2345explorer.exe",
    "2345weather.exe", "news_adv.exe", "xl_service.exe", "xlfresh.exe",
    "kuxinpro.exe", "bk_stock.exe", "bt_browser_launcher.exe",
]


class PopupBlocker:
    def __init__(self, own_pids=None, app_title_hint="DG"):
        self._own_pids = set(own_pids or [os.getpid()])
        self._app_hint = app_title_hint.lower()
        self._stop = threading.Event()
        self._thread = None
        self.enabled = False
        self.strong_mode = False          # 强力模式：关闭无效后结束进程
        self.whitelist_titles = []        # 标题白名单（用户配置）
        self.blocked_count = 0
        self._recent = {}                 # hwnd -> 连续关闭次数

    # ---------------- 生命周期 ----------------
    def start(self):
        if self._thread and self._thread.is_alive():
            self.enabled = True
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="dg-popup-blocker")
        self._thread.start()
        self.enabled = True

    def stop(self):
        self._stop.set()
        self.enabled = False
        self._recent.clear()

    # ---------------- 判定 ----------------
    def _get_pid(self, hwnd):
        pid = wt.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value

    def _get_proc_name(self, pid):
        h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(260)
            n = psapi.GetModuleBaseNameW(h, None, buf, 260)
            return buf.value[:n].lower() if n else ""
        finally:
            kernel32.CloseHandle(h)

    def _get_title(self, hwnd):
        buf = ctypes.create_unicode_buffer(512)
        n = user32.GetWindowTextW(hwnd, buf, 512)
        return buf.value[:n] if n else ""

    def _is_own(self, hwnd):
        pid = self._get_pid(hwnd)
        if pid in self._own_pids:
            return True
        pn = self._get_proc_name(pid)
        return pn.startswith("dg_") or "doubao" in pn

    def _check(self, hwnd):
        try:
            if not user32.IsWindowVisible(hwnd):
                return None
            if hwnd == user32.GetForegroundWindow():   # 前台窗口不碰
                return None
            if self._is_own(hwnd):                     # DG 自身不碰
                return None
            title = self._get_title(hwnd)
            if not title or len(title) > 60:           # 无标题/长标题 = 正常主窗
                return None
            tl = title.lower()
            for w in self.whitelist_titles:
                if w and w.lower() in tl:
                    return None
            for kw in BLOCK_TITLE_KEYWORDS:
                if kw.lower() in tl:
                    pid = self._get_pid(hwnd)
                    return {"hwnd": hwnd, "title": title, "pid": pid,
                            "proc": self._get_proc_name(pid), "kw": kw}
            pn = self._get_proc_name(self._get_pid(hwnd))
            if pn in BLOCK_PROC_NAMES:
                return {"hwnd": hwnd, "title": title, "pid": self._get_pid(hwnd),
                        "proc": pn, "kw": "进程名黑名单"}
        except Exception:
            pass
        return None

    # ---------------- 主循环 ----------------
    def _loop(self):
        while not self._stop.is_set():
            try:
                self._block_once()
            except Exception:
                pass
            self._stop.wait(1.5)

    def _block_once(self):
        result = []

        def cb(hwnd, lparam):
            r = self._check(hwnd)
            if r:
                result.append(r)
            return True

        user32.EnumWindows(WNDENUMPROC(cb), 0)
        for r in result:
            n = self._recent.get(r["hwnd"], 0)
            if n >= 3 and self.strong_mode:
                # 强力模式：温和关闭 3 次无效 -> 结束进程
                h = kernel32.OpenProcess(PROCESS_TERMINATE, False, r["pid"])
                if h:
                    try:
                        kernel32.TerminateProcess(h, 1)
                    finally:
                        kernel32.CloseHandle(h)
                self._recent.pop(r["hwnd"], None)
            else:
                user32.PostMessageW(r["hwnd"], WM_CLOSE, 0, 0)
                self._recent[r["hwnd"]] = n + 1
            self.blocked_count += 1
        return result

    # ---------------- 状态 ----------------
    def get_status(self):
        if not self.enabled:
            return "弹窗拦截：已停止"
        mode = "强力" if self.strong_mode else "温和"
        return f"弹窗拦截：运行中（{mode}模式）| 已拦截 {self.blocked_count} 次"
