# -*- coding: utf-8 -*-
"""6.4.3 发布：dist 补全（C++组件+ML模型+YARA）→ staging 同步 → ISCC 安装包"""
import os, shutil, subprocess, hashlib

DG = r"F:\桌面保护\desktopguard"
DIST = os.path.join(DG, "dist", "DG安全")
STAGING = r"F:\桌面保护\vmware\dg_staging\DG安全"
ISCC = r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
ISS = r"F:\桌面保护\vmware\dg_setup.iss"
OUT = r"F:\桌面保护\desktopguard\官网"

# ---- 1) dist _internal 补全 ----
IN = os.path.join(DIST, "_internal")
CPP = ["dg_ema_watch.exe", "dg_etw.exe", "dg_etw2.exe", "dg_etw3.exe", "dg_etw4.exe",
       "dg_etw5.exe", "dg_etw6.exe", "dg_guard.exe", "dg_monitor.exe", "dg_quarantine.exe",
       "dg_verdict.exe", "dg_warden.exe", "dg_watcher_tpl.exe", "sandbox_runner.exe", "scan_core.exe"]
n = 0
for f in CPP:
    src = os.path.join(DG, f)
    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(IN, f)); n += 1
for f in ("ml_model.joblib", "ml_model.onnx"):
    src = os.path.join(DG, f)
    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(IN, f)); n += 1
if os.path.isfile(os.path.join(DG, "shield.ico")):
    shutil.copy2(os.path.join(DG, "shield.ico"), os.path.join(IN, "shield.ico")); n += 1
print("[OK] dist _internal +%d 组件/模型/图标" % n)

# ---- 2) dist dgdata（yara 引擎 + 规则；ClamAV 由安装版 iss 单独打包）----
for sub in ("yara", "rules"):
    os.makedirs(os.path.join(DIST, "dgdata", sub), exist_ok=True)
for f in ("yara64.exe", "yarac64.exe"):
    src = os.path.join(r"F:\桌面保护\dgdata\yara", f)
    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(DIST, "dgdata", "yara", f))
for f in ("dg_builtin.yar", "dg_families.yar"):
    src = os.path.join(r"F:\桌面保护\dgdata\rules", f)
    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(DIST, "dgdata", "rules", f))
print("[OK] dist dgdata (yara+rules) 就绪")

# ---- 3) staging 同步（先清空再 copytree，随后补 7 工具 exe + uninstall bat）----
if os.path.exists(STAGING):
    shutil.rmtree(STAGING)
os.makedirs(STAGING, exist_ok=True)
shutil.copytree(DIST, STAGING, dirs_exist_ok=True)
print("[OK] staging synced: %d top items" % len(os.listdir(STAGING)))

# ---- 4) 7 工具 exe 补进 staging _internal（源：dist 旁 build 缓存之外，直接调 PyInstaller 输出的固定目录）----
TOOL_SRC = os.path.join(DG, "dist", "tools_643")
TOOLS = ["perf_overlay", "process_manager", "net_tools", "net_monitor",
         "selfdefense", "startup_manager", "fp_regression"]
for t in TOOLS:
    p = os.path.join(TOOL_SRC, t + ".exe")
    if os.path.isfile(p):
        shutil.copy2(p, os.path.join(STAGING, "_internal", t + ".exe"))
        print("  tool %s.exe: OK" % t)
    else:
        print("  tool %s.exe: MISSING (%s)" % (t, p))

# ---- 5) ISCC ----
if os.path.isfile(ISCC):
    r = subprocess.run([ISCC, ISS], capture_output=True, text=True, encoding="utf-8",
                       errors="ignore", timeout=600)
    print("ISCC exit:", r.returncode)
    if r.returncode == 0:
        for f in os.listdir(OUT):
            if f.startswith("DG-Security-Setup-6.4.3"):
                fp = os.path.join(OUT, f)
                print("[OK] setup:", f, os.path.getsize(fp))
    else:
        print((r.stdout or "")[-2500:]); print((r.stderr or "")[-2500:])
else:
    print("[skip] ISCC not found")
print("SYNC_DONE")
