# -*- coding: utf-8 -*-
import py_compile
for p in (r"F:\桌面保护\desktopguard\main.py",
          r"F:\桌面保护\desktopguard\startup_manager.py",
          r"F:\桌面保护\desktopguard\shred.py"):
    try:
        py_compile.compile(p, doraise=True)
        print("OK", p)
    except Exception as e:
        print("FAIL", p, e)
