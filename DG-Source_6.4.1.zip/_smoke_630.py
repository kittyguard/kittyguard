# -*- coding: utf-8 -*-
"""6.3.0 冒烟：版本号 / 首条历史 / 清单 / 产物 / 新功能代码 / 官网 / 打包 / 自启动监控"""
import io, json, os, sys

DG = r"F:\桌面保护\desktopguard"
ok = 0
bad = []

def chk(name, cond):
    global ok
    if cond:
        ok += 1
        print("  [PASS]", name)
    else:
        bad.append(name)
        print("  [FAIL]", name)

main = io.open(os.path.join(DG, "main.py"), encoding="utf-8").read()
chk("APP_VERSION=6.3.0", 'APP_VERSION = "6.3.0"' in main)
chk("VERSION_LIST 含 6.3.0", "'6.3.0'" in main)
chk("VERSION_HISTORY 首条 6.3.0", main.index("VERSION_HISTORY = [('6.3.0'") < main.index("('6.2.0', '6.1.0'"))
# 自启动监控
for m in ["_init_startup_monitor_lazy", "_startup_collect", "_startup_suspicious",
          "_startup_monitor_start", "_startup_monitor_loop", "_startup_handle_new",
          "_show_startup_alert", "_startup_setting_changed"]:
    chk("main " + m, ("def " + m) in main)
chk("main 设置页自启动监控开关", "startup_monitor_enabled" in main)
chk("main 启动调度 after(3000)", "self.root.after(3000, self._init_startup_monitor_lazy)" in main)
chk("main IO 节流调用", "_set_io_priority_low()" in main)
chk("main _process_rtp_alerts startup 分支", '"startup_alert"' in main)

u = io.open(os.path.join(DG, "dg_utils.py"), encoding="utf-8").read()
chk("dg_utils._set_io_priority_low", "def _set_io_priority_low" in u)
chk("dg_utils NtSetInformationProcess", "NtSetInformationProcess" in u)

sd = io.open(os.path.join(DG, "selfdefense.py"), encoding="utf-8").read()
chk("selfdefense APP_VERSION=6.3.0", 'APP_VERSION = "6.3.0"' in sd)

sys.path.insert(0, DG)
import selfdefense as sdmod
man = json.load(io.open(sdmod.MANIFEST, encoding="utf-8"))
chk("防篡改清单 version=6.3.0", man.get("version") == "6.3.0")

vj = json.load(io.open(os.path.join(DG, "version.json"), encoding="utf-8"))
chk("根 version.json=6.3.0", vj.get("version") == "6.3.0")

wj = json.load(io.open(os.path.join(DG, "官网", "version.json"), encoding="utf-8"))
pj = json.load(io.open(os.path.join(DG, "官网", "publish", "version.json"), encoding="utf-8"))
chk("官网 version.json=6.3.0", wj.get("version") == "6.3.0")
chk("publish version.json=6.3.0", pj.get("version") == "6.3.0")
chk("官网 version.json pkg=DG-Source_6.3.0.zip", wj.get("pkg") == "DG-Source_6.3.0.zip")

sz = os.path.join(DG, "官网", "DG-Source_6.3.0.zip")
chk("官网 DG-Source_6.3.0.zip 存在", os.path.exists(sz))

zp = os.path.join(DG, "官网", "DG-Security_6.3.0.zip")
chk("官网 DG-Security_6.3.0.zip 存在", os.path.exists(zp))
zold = [x for x in os.listdir(os.path.join(DG, "官网")) if x.startswith("DG-Security_") and x.endswith(".zip") and x != "DG-Security_6.3.0.zip"]
chk("官网无旧版 DG-Security zip", not zold)
sold = [x for x in os.listdir(os.path.join(DG, "官网")) if x.startswith("DG-Source_") and x.endswith(".zip") and x != "DG-Source_6.3.0.zip"]
chk("官网无旧版 DG-Source zip", not sold)

exe = os.path.join(DG, "dist", "DG安全", "DG安全.exe")
chk("dist DG安全.exe 存在", os.path.exists(exe))
txt = io.open(os.path.join(DG, "dist", "DG安全", "_internal", "使用说明.txt"), encoding="utf-8").read()
chk("dist 使用说明 6.3.0", "6.3.0 便携版" in txt and "6.2.0 便携版" not in txt)
chk("dist 使用说明含免责声明", "不可将其用于主力杀毒软件" in txt)

vm = json.load(io.open(os.path.join(DG, "versions", "6.3.0", "manifest.json"), encoding="utf-8"))
chk("快照 6.3.0 manifest", vm.get("version") == "6.3.0" and len(vm.get("files", [])) > 100)

h = io.open(os.path.join(DG, "官网", "DG安全官网.html"), encoding="utf-8").read()
chk("官网 HTML 含 6.3.0 当前版节点", "当前版</span>自启动实时监控 · 扫描 IO 节流" in h)
chk("官网 HTML 含 6.2.0 已发布节点", "已发布</span>洪流冲刷一键直达" in h)
chk("官网 HTML zip 链接 6.3.0", "DG-Security_6.3.0.zip" in h)
chk("官网 HTML cta 当前版本 6.3.0", "当前版本 6.3.0" in h)
hp = io.open(os.path.join(DG, "官网", "publish", "index.html"), encoding="utf-8").read()
chk("publish/index.html 含 6.3.0 节点", "当前版</span>自启动实时监控" in hp and "DG-Security_6.3.0.zip" in hp)

print("----")
print("冒烟结果: %d/%d 通过" % (ok, ok + len(bad)))
if bad:
    print("未通过:", bad)
    sys.exit(1)
