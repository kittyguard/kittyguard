# -*- coding: utf-8 -*-
"""发布 6.0.0：快照 + 重建防篡改清单 + version.json（勒索文档守护·误报回归闭环·签名验证缓存·实时签名感知）"""
import io, os, shutil, time, json, sys

DG = r"F:\桌面保护\desktopguard"
NEW_VER = "6.0.0"

ver_dir = os.path.join(DG, "versions", NEW_VER)
os.makedirs(ver_dir, exist_ok=True)
manifest = {"version": NEW_VER, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": [], "py": []}
src_files = []
for fn in os.listdir(DG):
    p = os.path.join(DG, fn)
    if os.path.isfile(p) and fn.lower().endswith(".py"):
        src_files.append(fn)
        manifest["py"].append(fn)
for fn in ("dg_monitor.exe", "dg_guard.exe", "dg_verdict.exe", "shield.ico",
           "scan_core.exe", "dg_quarantine.exe", "dg_ema_watch.exe",
           "ml_model.joblib", "ml_model.onnx"):
    if os.path.isfile(os.path.join(DG, fn)):
        src_files.append(fn)
copied = 0
for fn in src_files:
    try:
        shutil.copy2(os.path.join(DG, fn), os.path.join(ver_dir, fn))
        manifest["files"].append(fn)
        copied += 1
    except Exception as e:
        print("  跳过", fn, e)
with io.open(os.path.join(ver_dir, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print("[OK] 快照 %s: %d 个文件" % (NEW_VER, copied))

sys.path.insert(0, DG)
import selfdefense as sd
man = sd.build_manifest()
if sd.save_manifest(man):
    print("[OK] 防篡改清单已重建 version=%s py=%d cfg=%d" % (
        man.get("version"), len(man.get("py", {})), len(man.get("cfg", {}))))
else:
    print("[FAIL] 防篡改清单保存失败")

notes = {
    "latest_version": NEW_VER,
    "release_date": time.strftime("%Y-%m-%d"),
    "release_notes": "6.0.0 用户态防护平台：勒索文档守护 + 误报回归闭环 + 签名验证缓存 + 实时签名感知。",
    "features": [
        "勒索文档守护：监控桌面/文档/图片/下载目录，批量异常改写自动冻结进程+备份改动文件，可恢复可放行（纯用户态）",
        "误报回归闭环：误报文件拖入自动提特征生成回归样本集，权重版本化、调权前全量回归验证可回滚",
        "签名验证缓存：Authenticode 验签按路径/修改时间/大小缓存，同一文件跨扫描只验签一次，扫描收尾显示命中统计",
        "实时防护签名感知：下载保护对 PE 自动验签，有效签名+无强特征直接放行，商业软件误报大幅下降",
        "全程纯用户态、零驱动、不服务化、CPU≈0"
    ]
}
with io.open(os.path.join(DG, "version.json"), "w", encoding="utf-8") as f:
    json.dump(notes, f, ensure_ascii=False, indent=2)
print("[OK] version.json 已更新为 %s" % NEW_VER)
